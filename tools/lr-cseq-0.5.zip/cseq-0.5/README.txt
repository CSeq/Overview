
             CSeq    C-to-C Sequentialisation Tool
                     version 0.5
                     6 Jun 2013


* Package contents *
README.txt        this file
cseq.py           CSeq tool
cseq-feeder.py    feeder script to automatically invoke a model-checker on CSeq's output 
include/          include files needed by  cseq.py  for parsing the input and generating the output
benchmarks/       sample test cases


* Installation *
To install CSeq, follow the steps below:

1. install the dependencies:
		Python 2.7.1
		PYCparser 2.08
		ESBMC 1.21.1 (optional back-en)
		CBMC 4.3 (optional back-end)
		LLBMC 2012.2a (optional back-end)

2. copy at the same path all the files in the package
    
3. make sure that both  cseq.py  and  cseq-feeder.py  have execution (+x) permissions.


* Usage *
Assuming that the current working directory is where all the file have been copied
(see installation, step 2), the following command:

./cseq.py  -t2 -r4 -i filename.c -f cbmc
 
invokes CSeq to perform sequentialisation on  filename.c. In this case, the output
will simulate all runs with at most 2 threads and 4 round robin schedules.
The output is instrumented for verifying with CBMC and printed to stdout.
For a full list of settings, run  cseq.py  without parameters. 


* Verification *
CSeq comes with a wrapper script to automatically invoke the verification backend.
For instance:
	 
./cseq-feeder.py  -t2 -r2 -i input.c -f esbmc -u 10

first calls CSeq to convert  input.c  into a sequentialised version  _cs_input.c
with 2 threads and 2 rounds instrumented for ESBMC, then calls ESBMC on the sequentialised
file for verification.

The values of parameters -t and -r are used for generating the sequentialised code.
The parameter  -f  should be changed according to the backend tool of preference,
and specifies both the format for the instrumentation of the sequentialised output
and the backend tool to be used for the verification.

To avoid poor performance, fine-tuning of all the parameters is recommended.
For a full list of settings, run  cseq-feeder.py  without parameters.

