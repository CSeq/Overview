_Bool Read_Bool(__CS_typeV codeVar){
	__CS_typeM jump;
	
	if (__CS_ret) return;
	__CPROVER_assume(jump<thw[thread_index][thread_pos] && (jump >= thread_pos));

	thread_pos=jump;

	//<insert-assume-atomic-here>

	if ( thread_pos >= memory_notvalid ) {__CS_ret=1;}
	return (__memory_bool[codeVar][thread_pos]);
}


void Write_Bool(__CS_typeV codeVar, _Bool val){

	if (__CS_ret) return;
	thread_pos=thw[thread_index][thread_pos];
	if (thread_pos >= memory_notvalid ) {__CS_ret=1; return;}
	<insert-assume-atomic-here>

	__CPROVER_assume (
           (var_name[thread_pos] == codeVar)
       &&  (__memory_bool[codeVar][thread_pos] == val)
	) ;
}

