
import getopt, sys, os.path


''' Loads in a string the content of a file, then returns it. 
'''
def printFile(filename):
	if not os.path.isfile(filename):
		print "ERROR: printfile(%s): file does not exist.\n" % filename
		return

	in_file = open(filename,"r")
	text = in_file.read()
	in_file.close()

	return text


''' Write to a file the contents of a string. 
'''
def saveFile(filename, string):
	outfile = open(filename,"w")
	outfile.write(string)
	outfile.close()


''' Check whether a file contains at least one occurrence of the given string.
'''
def fileContains(filename, string):
	if os.path.isfile(filename):
		myfile = open(filename)
		lines = list(myfile)

		for line in lines:
			if string in line: return True
	else: return False

	return False


''' Return the number of lines (or of '\n's +1) in the given file.
'''
def fileLength(filename):
	with open(filename) as f:
		for i, l in enumerate(f): pass

	return i + 1
	

''' 
	strip()  -  Strips every line in the given string
				from the line with '_____STARTSTRIPPINGFROMHERE_____' as substring
				to the one with '_____STOPSTRIPPINGFROMHERE_____' as substring.

				Lines are identified by '\n'
'''
def strip(s):
	s2 = ''
	status = 0

	for line in s.split('\n'):
		if '_____STARTSTRIPPINGFROMHERE_____' in line:
			status = 1
			continue;

		if '_____STOPSTRIPPINGFROMHERE_____' in line:
			status = 2
			continue;

		if status == 0 or status == 2: s2 += line + '\n'

	return s2


	
def stripSpaces(s):
	return s.replace(" ","").replace("\t","").replace("\n","")
