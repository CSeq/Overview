#include <stdlib.h>
#include <pthread.h>

#define LOCK_SIZE <insert-LOCK_SIZE-here>
#define vLOCK_SIZE <insert-vLOCK_SIZE-here>

//#define NUM_WRITES <insert-NUM_WRITES-here>

#define MEM_SIZE <insert-MEM_SIZE-here>
#define MEM_SIZE_VARS <insert-MEM_SIZE_VARS-here>
#define NumVars <insert-NumVars-here>
#define MaxNumThreads <insert-NumThreads-here>
#define NumAddresses <insert-npointers-here>
#define NumMalloc <insert-nmalloc-here>
 
 
#define  intV unsigned __CPROVER_bitvector[<insert-bit-here>]
//#define  intV unsigned
//#define  intV int
//#define __CS_type unsigned char
#define __CS_type unsigned __CPROVER_bitvector[<insert-bit-here>]
#define  __cs_t unsigned __CPROVER_bitvector[<insert-bit-here>]



#define __CS_typeM unsigned __CPROVER_bitvector[<insert-bit-here>]
#define __CS_typeV unsigned __CPROVER_bitvector[<insert-bit-here>]
#define __CS_typeT unsigned __CPROVER_bitvector[<insert-bit-here>]
 
 /*
#define  intV unsigned __CPROVER_bitvector[<insert-bit-here>]
//#define  intV unsigned int
//#define __CS_type unsigned char
#define __CS_type unsigned int
#define  __cs_t unsigned __CPROVER_bitvector[<insert-bit-here>]
//#define  __cs_t unsigned int


#define __CS_typeM unsigned int
#define __CS_typeV unsigned int
#define __CS_typeT unsigned int
*/

/*
#define __CS_typeM unsigned char
#define __CS_typeV unsigned char
#define __CS_typeT unsigned char
#define __CS_typeM unsigned __CPROVER_bitvector[<insert-type-typeM-here>]
#define __CS_typeV unsigned __CPROVER_bitvector[<insert-type-typeV-here>]
#define __CS_typeT unsigned __CPROVER_bitvector[<insert-type-typeT-here>]
*/

#define __CS_pthread_t unsigned __CPROVER_bitvector[<insert-bit-here>]
#define __CS_pthread_mutex_t unsigned char
#define __cs_mutex_t unsigned char
#define __CS_pthread_cond_t unsigned char

//start global variables
<insert-define-global-variables-here>
//end global variables
 
 
// shared memory

<insert-atomic-declaration-here>
<insert-lockVariable-declaration-here>

//for each variable "i" we represent a MU composed by
intV __value[NumVars] [MEM_SIZE_VARS]; //value written at variable i
__CS_typeM __ticket [NumVars] [MEM_SIZE_VARS+1]; //Unique ticket assigned to the write opereation
__CS_typeT __thread_id [NumVars] [MEM_SIZE_VARS]; //Which thread writes variable i
__CS_typeT __visible [NumVars] [MEM_SIZE_VARS]; //it is not in a locked memory position
__CS_typeM __thw[NumVars][MaxNumThreads][MEM_SIZE_VARS]; //next write of each thread for i 
__CS_typeM __last_used_pos_of[NumVars]; //last used pos of i
__CS_typeM __memory_notvalid_of[NumVars]; //last valid write pos of i


//Gildo: tolgo isBool
//<insert-bool-declaration-here>
//__CS_typeT thread[MEM_SIZE];  
//__CS_typeM thw[MaxNumThreads][MEM_SIZE];


__CS_typeM ticket_pos; //greatest ticket number encountered during the simulation
_Bool __used_ticket[MEM_SIZE+NumVars+3]; //used by guessing in order to guarantee that each ticket is unique



//<insert-defMax-here>
 
 __CS_typeT n_treads_createad=1;

_Bool __CS_error = 0;                                              //cseq: set whenever an error is found and checked after thread-wrapping
intV __CS_ret = 0; 
_Bool terminated[MaxNumThreads];//=<insert-Terminated-here>;		//viene settato ad 1 solo se il thread viene terminato
  intV GuessedNumThreads;
__CS_typeM ticket_pos_terminated[MaxNumThreads]=<insert-Terminated-here>;		//last ticket_pos



//cseq: handling of the status of the threads 
__CS_typeT __cs_thread_index;                                           //cseq: currently running thread ranging in [1..max+1], 1 being main()
__CS_typeT number_threads;

__CPROVER_bitvector[1] nondet_0(){__CPROVER_bitvector[1] pippo; return pippo;};
__CPROVER_bitvector[1] nondet_1(){__CPROVER_bitvector[1] pippo; return pippo;};
intV __VERIFIER_nondet_uint(){
	intV _cs_mu_tmpVar; 
	__CPROVER_assume(_cs_mu_tmpVar>=0);
	return _cs_mu_tmpVar;
};
_Bool nondet_bool(){_Bool pippo; return pippo;};

intV Read_atomic(__CS_typeV codeVar);
intV Read_var_atomic();
void Write_var_atomic();

//<insert-read-write-functions-here>
intV Read(__CS_typeV codeVar){
	__CS_typeM jump;
	
	if ((__CS_ret) || ( jump >= __memory_notvalid_of[codeVar] )) {__CS_ret=1; return;}
	
	__CS_typeM ticket_jump = __ticket[codeVar][jump];
    __CPROVER_assume( (jump<__thw[codeVar][__cs_thread_index][__last_used_pos_of[codeVar]] )
				&& (__ticket[codeVar][jump+1]>ticket_pos)			
				<insert-atomic-constrain-here>
				);						
						/*&& ( !(ticket_jump > ticket_pos) || (__visible[codeVar][jump]) )*/

	ticket_pos = (ticket_jump > ticket_pos) ? ticket_jump : ticket_pos;
	/*<insert-atomic-constrain-here>*/
	intV valueRet=__value[codeVar][jump];
	//return (__value[codeVar][jump]);
	return valueRet;
	

}
void Write(__CS_typeV codeVar, int val){
	if (__CS_ret) return;
	
	__CS_typeM last_pos = __thw[codeVar][__cs_thread_index][__last_used_pos_of[codeVar]];
	
	if (last_pos >= __memory_notvalid_of[codeVar] ) {__CS_ret=1; return;}
	__last_used_pos_of[codeVar]=last_pos;

	
	__CPROVER_assume (
				(__ticket[codeVar][last_pos] > ticket_pos)
			&&  (__value[codeVar][last_pos] == val)
		) ;
	ticket_pos=__ticket[codeVar][last_pos];
	/*<insert-atomic-constrain-here>*/

}
intV Read_atomic(__CS_typeV codeVar){
	__CS_typeM jump;
	
	if ((__CS_ret) || ( jump >= __memory_notvalid_of[codeVar] )) {__CS_ret=1; return;}
	
    __CPROVER_assume( (jump<__thw[codeVar][__cs_thread_index][__last_used_pos_of[codeVar]] )
				&& (__ticket[codeVar][jump+1]>ticket_pos)			
				&& (__ticket[codeVar][jump] <= ticket_pos)			
					);						
	intV valueRet=__value[codeVar][jump];
	//return (__value[codeVar][jump]);
	return valueRet;
}
void Write_atomic(__CS_typeV codeVar, int val){
	if (__CS_ret) return;
	
	__CS_typeM last_pos = __thw[codeVar][__cs_thread_index][__last_used_pos_of[codeVar]];
	
	if (last_pos >= __memory_notvalid_of[codeVar] ) {__CS_ret=1; return;}
	__last_used_pos_of[codeVar]=last_pos;

	
	__CPROVER_assume (
				(__ticket[codeVar][last_pos] == (ticket_pos+1))
			&&  (__value[codeVar][last_pos] == val)
			&&  (!__visible[codeVar][last_pos])
		) ;
	ticket_pos=__ticket[codeVar][last_pos];
}



intV nondet_int();

/*
intV Read_atomic(__CS_typeV codeVar){
	//return (__value[codeVar][jump]);
	return (__value[codeVar][__last_used_pos_of[codeVar]]);
}
*/
_Bool nondet_bool();

<insert-locVars-here>

void Jump(){

__CS_typeV _cs_v;
__CPROVER_assume(_cs_v<NumVars);
  if (nondet_int()) {__CS_ret=1; return;}
  Read(_cs_v);
  <insert-pthread_join-here>
  //Read_var_lock();
}

intV __pthread_join( __CS_pthread_t _cs_t1, __CS_type __p){
//  return;
	Jump();
	if (__CS_ret) return;
  
   __CPROVER_assume((_cs_t1<MaxNumThreads) && (terminated[_cs_t1]) && (ticket_pos >= ticket_pos_terminated[_cs_t1]));

}

<insert-atomic-function-here>

intV __pthread_create_thread1(__CS_pthread_t *thread_id, void *attr, void *arg);
intV __pthread_create_thread2(__CS_pthread_t *thread_id, void *attr, void *arg);
intV __pthread_create_thread3(__CS_pthread_t *thread_id, void *attr, void *arg);
intV __pthread_create_thread_ath9k_0(__CS_pthread_t *thread_id, void *attr, void *arg);
intV __pthread_create_thread_ath9k_1(__CS_pthread_t *thread_id, void *attr, void *arg);
