#!/usr/bin/env python
PARSER_VERSION = '0.0 2013.09.18'

"""

to handle here:
- typedef expansion

"""

import pycparser.c_parser, pycparser.c_ast, pycparser.c_generator
import utils


class Parser(pycparser.c_generator.CGenerator):
	__sourcecode = ''

	""" Uses the same visitor pattern as c_ast.NodeVisitor, but modified to
		return a value from each visit method, using string accumulation in 
		generic_visit.
	"""
	def __init__(self):
		pass


	def getversion(self):
		return PARSER_VERSION


	def load(self, filename):
		self._inputFilename = filename

		
		self.inInLoop=0
		self.numThreadCreate=1
		self.inFor=0
		self.createInFor=0
		self.numLoops=0
		self.countAssignment=0
		self.containsArray=""
		
		
		self.currentFunct = '' # name of the function being parsed (if any)
		self.funcName = ['']  # names of all the functions (consider '' to be a special function to model global scope)

		
		
		self.funcNode = {}
		
		
		self.currentVarAssign = '' # name of the current variable used as a lvalue in an assignment statement

		self.currentStruct = ''
		self.structName = []
		self.currentAnonStructsCount = 0   # counts the number of anonymous structures (used to assign consecutive names)

		self.mainParametersDecl = ''     # parameters of the main() function to be transferred to thread 0.
 
		""" The following are indexed either using
			(struct, variable)  for struct fields, or
			(function, variable) local variables and function parameters, or
			('', variable) for global variables.	

			See _generate_decl(self, n) below for details. 
		"""
		self.varNames = {}    # names of all the variables (global, local, parameters) + variables in structs
		self.varType = {}     # int, char, ....
		self.varArity = {}    # 0 for scalar, k for k-dimensional arrays
		self.varSize = {}     #  [] for scalar, [n1,...,k] for k-dimensional arrays
		self.varKind = {}     # g, l, p, s
		self.varMallocd = {}  # used only for pointers
		self.varID = {}       # unique IDs for variables, as they are found while parsing, starting with 0
		self.varCount = 0     #
		self.extraGlovalVarCount = 0 # Count global variables introduced in the above data structures, but not from original input. 

		self.varNames[''] = [] # initialisation for global var names ('' is the global scope)

		# Handling of typedefs.
		# We put in the first variable below the last part of a typedef statement, 
		# and in the second variable its correspondent expansion.
		#
		# Anonymous typedefs are no exception, as they are assigned an internal name to be used as described.
		#
		self.typedefs = []          # contains last the part of a typedef stmt, e.g. typedef struct struct_name {.... } last_part;
		self.typedefExpansion = {}  # e.g. typedefs['field'] = struct { int a; int b; ... }  from the original typedef statement
	
		# Statements start with indentation of self.indent_level spaces, using
		# the _make_indent method
		#
		self.indent_level = 0			# to keep track of the depth of the block {}
		self.INDENT_SPACING = '\t'	# ....

		# = True while parsing the subtree for a function declaration
		self.parsingFuncDecl = False

		# = True while parsing the subtree for a struct (or union) declaration
		self.parsingStruct = False

		# Declarations have always one of the following two forms: 
		#		 <lastDeclarationL> = <lastDeclarationR>;   when there is an init expression
		#			   OR
		#		 <lastDeclarationL>;   when there is no init expression
		self.lastDeclarationL = ''
		self.lastDeclarationR = ''
		self.lastDeclaration = ''

		# this will set to True after parsing the first function definition (not declaration!)
		self.firstFunctionDefinitionDone = False

		# set to True while parsing void functions
		self.parsingVoidFunction = False

		# set to True while parsing typedef blocks 
		self.parsingTypedef = False

		#
		self.currentInputCoord = ''
		self.currentInputLineNumber = -1
		self.currentOutputLineNumber = -1

		self.lines = []
	
		# Load the input source file to build the AST, then generate the symbol table
		self.ast = pycparser.parse_file(self._inputFilename, use_cpp=True, cpp_args=r'-Iinclude -E -C ')
		self.__sourcecode = self.visit(self.ast)


	def show(self):
		##print(self.visit(self.ast))
		print self.__sourcecode


	def save(self, filename):
		outfile = open(filename,"w")
		outfile.write(self.__sourcecode)
		outfile.close()


	def string(self):
		return(self.visit(self.ast))


	def printsymbols(self):
		print "parameters for main():\n"+ self.mainParametersDecl

		# List of all variables
		print "Variables:"
		for f in self.funcName:
			if not f == '':	print "   " + f
			else: print "   (global)"
			
			for v in self.varNames[f]:
				# detailed var description
				s = "       "
				s += "id " + str(self.varID[f,v]) + "  "
				s += "var '" + v + "'   "
				s += "type '" + self.varType[f, v] + "'   "
				s += "kind '" + self.varKind[f, v] + "'   "
				s += "arity '" + str(self.varArity[f, v]) + "'   "
				s += "size '" + str(self.varSize[f, v]) + "'   "
				s += "mallocd '" + str(self.varMallocd[f,v]) + "'"
				
				print s

		print '\n'

		# List of all fields
		print "Fields:"
		for f in self.structName:
			if not f == '':	print "   " + str(f)
			else: print "   (global)"
			
			for v in self.varNames[f]:
				# detailed var description
				s = "       "
				s += "id " + str(self.varID[f,v]) + "  "
				s += "var '" + v + "'   "
				s += "type '" + self.varType[f, v] + "'   "
				s += "kind '" + self.varKind[f, v] + "'   "
				s += "arity '" + str(self.varArity[f, v]) + "'   "
				s += "size '" + str(self.varSize[f, v]) + "'   "
				s += "mallocd '" + str(self.varMallocd[f,v]) + "'"

				
				print s

		print '\n'

		print "Typedefs:"
		for x in self.typedefs:
			print x + " -> " + self.typedefExpansion[x]

		print '\n'

		print "Pointer variables:"
		for f in self.funcName:
			if not f == '':	print "   " + f
			else: print "   (global)"
			
			for v in self.varNames[f]:
				if self.varType[f,v].endswith('*'):
					s = "       "
					s += "var '" + v + "'   "
					s += "type '" + self.varType[f, v] + "'   "
					s += "kind '" + self.varKind[f, v] + "'   "
					s += "arity '" + str(self.varArity[f, v]) + "'   "
					s += "size '" + str(self.varSize[f, v]) + "'   "
				
					print s

		print '\n'


	def _make_indent(self, delta=0):
		return (self.indent_level+delta) * self.INDENT_SPACING


	def visit(self, node):
		method = 'visit_' + node.__class__.__name__
		
		# This is to update the current coord (= filename+line number) of the input file being parsed,
		# considering that:
		#
		# - on the same line of input, there may be more AST nodes (shouldn't enter duplicates)
		# - compound statement and empty statements have line number 0 (shouldn't update the current line)
		# - the same line of input may correspond to many lines of output
		#
		lineCoords = ''

		if not isinstance(node, pycparser.c_ast.FileAST) and str(node) != 'None' and self.indent_level == 0:
			##print "       VISITING %s - %s" % (str(node), node.coord)

			linenumber = str(node.coord)
			linenumber = linenumber[linenumber.rfind(':')+1:]

			self.currentInputLineNumber = int(linenumber)

			# Each line of the output is annotated when 
			# either it is coming from a new input line number
			# or the input line has generated many output lines, 
			# in which case the annotation needs to be repeated at each line..
			#
			if linenumber not in self.lines and linenumber != '0':
				### print "      adding line number %s" % linenumber
				self.lines.append(linenumber)
				lineCoords = self._getCurrentCoords(node)

		return lineCoords + getattr(self, method, self.generic_visit)(node)


	def _getCurrentCoords(self, item):
		return ''
		return '/*cseq:coords '+ str(item.coord) +' */\n'


	def visit_Typedef(self, n):
		s = ''
		if n.storage: s += ' '.join(n.storage) + ' '

		self.parsingTypedef = True
		typestring = self._generate_type(n.type)
		self.parsingTypedef = False

		# Typical  typedef struct  statement...
		if  typestring.startswith("struct "):
			## print "     adding typedef name '" +s+ "'"
			## print "     adding typedef type '" +typestring+ "'"

			leftPart = typestring[:typestring.find('{')]
			if leftPart.endswith(' '): leftPart = leftPart[:-1]
			if leftPart.endswith('\n'): leftPart = leftPart[:-1]
			if leftPart.endswith(' '): leftPart = leftPart[:-1]

			rightPart = typestring[typestring.rfind('} ')+2:]

			## print "      LEFT: '" + leftPart + "'"
			## print "      RIGHT: '" + rightPart + "'"

			self.typedefs.append(rightPart)
			self.typedefExpansion[rightPart] = leftPart

		s += typestring
		return s
		
	def visit_Assignment(self, n):
		self.countAssignment=self.countAssignment+1
		return super(Parser, self).visit_Assignment(n)

	def visit_FuncCall(self, n):
		fref = self._parenthesize_unless_simple(n.name)




		if fref == 'pthread_create': 
			if self.inInLoop==1:
				self.numThreadCreate=-1
				if self.inFor==1:
					self.createInFor=1
				#elif self.numThreadCreate<5:			
			else:
				self.numThreadCreate=self.numThreadCreate+1


		return fref + '(' + self.visit(n.args) + ')'

	# Note: function definition = function declaration + body.
	# This method is not called when parsing simple declarations of function (i.e., function prototypes).
	#
	def visit_FuncDef(self, n):
		self.currentFunct = n.decl.name
		self.funcName.append(n.decl.name)
		
		self.funcNode[n.decl.name]=n
		
		self.varNames[self.currentFunct] = []

		# Note: the function definition is in two parts:
		#       one is 'decl' and the other is 'body'
		decl = self.visit(n.decl)

		if decl.startswith("void") and not decl.startswith("void *"): self.parsingVoidFunction = True
		else: self.parsingVoidFunction = False

		body = self.visit(n.body)
		#comunicare ad Omarix
		self.currentFunct = ""
		return decl + '\n' + body + '\n'


	def visit_Compound(self, n):
		'''
		s = ''

		if n.block_items:
			s += ''.join(self._generate_stmt(stmt) for stmt in n.block_items)

		return s
		'''
		s = self._make_indent() + '{\n'
		self.indent_level += 1
		##if n.block_items:
		##	s += ''.join(self._generate_stmt(stmt) for stmt in n.block_items)

		if n.block_items:
			for stmt in n.block_items:
				newStmt = self._getCurrentCoords(stmt) + self._generate_stmt(stmt)
				s += newStmt
				##### s += self._generate_stmt(stmt)

		self.indent_level -= 1

		s += self._make_indent() + '}\n'
		
		return s

	
	def visit_If(self, n):
		s = 'if ('
		if n.cond: s += self.visit(n.cond)
		s += ')\n'
		t = self._generate_stmt(n.iftrue, add_indent=True)   
		if not t.startswith(self._make_indent()+ ('{\n')):      # add brakets for single non parenthesised statements after if
			t = self._make_indent() + '{\n' + t + self._make_indent() + '}\n'
		#t = '--->' + t +'<---'
		s += t
		
		if n.iffalse:
			s += '\n' + self._make_indent() + 'else\n'
			e = self._generate_stmt(n.iffalse, add_indent=True)
			if not t.startswith(self._make_indent()+ ('{\n')):      # add brakets for single non parenthesised statements after if
				e = self._make_indent() + '{\n' + e + self._make_indent() + '}\n'	
			s += e
		return s
	

	def visit_For(self, n):
	
	
		self.inInLoop=1
		self.numLoops=1
		self.inFor=1
	
		s = 'for ('
		if n.init: s += self.visit(n.init)
		s += ';'
		if n.cond: s += ' ' + self.visit(n.cond)
		s += ';'
		if n.next: s += ' ' + self.visit(n.next)
		s += ')\n'
		t = self._generate_stmt(n.stmt, add_indent=True)
		if not t.startswith(self._make_indent()+ ('{\n')):      # add brakets for single non parenthesised statements after if
			t = self._make_indent() + '{\n' + t + self._make_indent() + '}\n'
		s += t


		self.inInLoop=0
		self.inFor=0

		
		return s


	def visit_While(self, n):
		self.inInLoop=1
		self.numLoops=1



		s = 'while ('
		if n.cond: s += self.visit(n.cond)
		s += ')\n'
		t = self._generate_stmt(n.stmt, add_indent=True)
		if not t.startswith(self._make_indent()+ ('{\n')):      # add brakets for single non parenthesised statements after if
			t = self._make_indent() + '{\n' + t + self._make_indent() + '}\n'
		s += t

		self.inInLoop=0

		return s


	def visit_DoWhile(self, n):
		s = 'do\n'
		t = self._generate_stmt(n.stmt, add_indent=True)
		if not t.startswith(self._make_indent()+ ('{\n')):      # add brakets for single non parenthesised statements after if
			t = self._make_indent() + '{\n' + t + self._make_indent() + '}\n'

		s += t
		s += self._make_indent() + 'while ('
		if n.cond: s += self.visit(n.cond)
		s += ');'
		return s


	def visit_Case(self, n):
		s = 'case ' + self.visit(n.expr) + ':\n'
		self.indent_level += 2
		for stmt in n.stmts:
			s += self._generate_stmt(stmt)
		self.indent_level -= 2
		return s


	def visit_Default(self, n):
		s = 'default:\n'
		self.indent_level += 2
		for stmt in n.stmts:
			s += self._generate_stmt(stmt)
		self.indent_level -= 2
		return s


	def visit_Struct(self, n):
		# Assign a name to anonymous structs
		if n.name == None:
			n.name = '__CS_anonstruct_' + str(self.currentAnonStructsCount)
			self.currentAnonStructsCount += 1

		# This method is called more than once on the same struct,
		# the following is done only on the first time.
		#
		if n.name not in self.structName:
			self.currentStruct = n.name
			self.structName.append(n.name)
			self.varNames[self.currentStruct] = []

		oldParsingStruct = self.parsingStruct
		self.parsingStruct = True
		s = self._generate_struct_union(n, 'struct')
		self.parsingStruct = oldParsingStruct

		# Parsing  typedef struct
		'''
		if self.parsingTypedef: 
			print "    PARSING TYPEDEF STRUCT!!!!!!"
			print "       s: " + s 
			print "    name: " + str(n.name) + '\n\n\n'
		'''

		return s


	def visit_Union(self, n):
		oldParsingStruct = self.parsingStruct
		self.parsingStruct = True
		s = self._generate_struct_union(n, 'union')
		self.parsingStruct = oldParsingStruct
		
		return s


	def _generate_decl(self, n):
		""" Generation from a Decl node.
		"""
		s = ''
		
		# use flags to keep track through recursive calls of what is being parsed (START)
		if 'FuncDecl' in str(n.type):
			oldParsingFuncDecl = self.parsingFuncDecl
			self.parsingFuncDecl = True
			self.CurrentFunct = n.name
			###self.varNames[self.currentFunct] = []

		if 'Struct' in str(n.type): self.parsingStruct = True

		if n.funcspec: s = ' '.join(n.funcspec) + ' '
		if n.storage: s += ' '.join(n.storage) + ' '

		s += self._generate_type(n.type)

		# use flags to keep track through recursive calls of what is being parsed (END)
		if 'FuncDecl' in str(n.type):
			### self.parsingFuncDecl = False
			self.parsingFuncDecl = oldParsingFuncDecl
			self.CurrentFunct = ''

		if 'Struct' in str(n.type): self.parsingStruct = False


		""" Handling of struct declarations.
		"""
		if 'Struct' in str(n.type):
			# new structure declaration
			1
			if self.parsingStruct:
				# new field in a structure
				1

		""" Handling of variable declarations.

			Each variable has the following info associated with it:

				name, type, kind, arity, size
	
			name
		    	varName[''] = list of global variables
		    	varName['x'] = list local variables in function or struct 'x'
				              (incl. input params for functions)

			type
				the type as declared in the original code (e.g. 'unsigned int', 'char *', ...)

			kind
				'g'  for global variables
				'l'  for local variables
				'p'  for function input parameters
				'f'  for struct fields

			arity
				0  for scalar variables
				k  for for k-dimensional arrays

			size
				[] for scalar variables
				[size1, ..., sizek] for k-dimensional arrays

		"""
		# Whatever is not a function or a struct here, is a variable declaration
		# TODO: see what else should be excluded to only have var declarations after the if
		#
		if 'FuncDecl' not in str(n.type) and 'Struct' not in str(n.type) and 'Union' not in str(n.type):
			# Variable name (for variables) or field name (for structs fields).
			#
			# At this point,
			# any variable declaration can occur (a) in the global scope,
			# or (b) in a function or (c) in a struct.
			#
			# Each of those will have a name, apart from the global scope,
			# for which name we use the empty string. We call it Context. 
			#
			# For example,
			#   if a variable V is declared in a function F, its Context is F.
			#   if a variable V is declared in a struct S, its Context is S.
			#   if a variable V is declared globally, its Context is ''.
			#
			# We use the context to index the arrays:
			# (1) to index the array name
			# (2) to index the arrays type, kind, arity, size,
			# in this case with the tuple (context, variable)
			#
			if not self.parsingStruct: variableContext = self.currentFunct
			else: variableContext = self.currentStruct

			##print "appending var  [%s]\n          from context [%s]\n          type [%s]\n          string [%s]\n\n\n" % (n.name, variableContext, n.type, s)  

			if not n.name in self.varNames[variableContext]:   # avoid duplicates
				# print "appending var  [%s]\n          from context [%s]\n          type [%s]\n          string [%s]\n\n\n" % (n.name, variableContext, n.type, s)  
				self.varNames[variableContext].append(n.name)
				# Associate each new variable with a unique IDs
				self.varID[variableContext,n.name] = self.varCount
				self.varCount += 1

			# Variable or field type
			if s.count('[') > 0: s2 = s[ :s.find('[')]		
			else: s2 = s

			s2 = s2[:-len(n.name)]
			if s2.endswith(' '): s2 = s2[:-1]

			# Typedef expansion:
			# when some type of variable is found for which there is an entry in the list of typedefs,
			# expands directly in the symbol table the corresponding string.
			#
			for x in self.typedefs:
				## print "found %s ---> %s" % (x, self.typedefExpansion[x])

				if s2 == x: s2 = self.typedefExpansion[x]
				if s2.startswith(x+ ' '): s2 = s2.replace(x+' ', self.typedefExpansion[x]+' ', 1)

				s2 = s2.replace(' '+x+' ', ' '+self.typedefExpansion[x]+' ')

			self.varType[variableContext,n.name] = s2

			# Variable kind
			if self.parsingFuncDecl:    # parameter (from a function declaration)
				self.varKind[variableContext, n.name] = 'p'

				## print "FOUND MAIN PARAMETER %s, DECL %s\n\n" % (n.name, s)
				if variableContext == 'main':
					varDecl = s;
					varDecl = varDecl.replace(' '+n.name, ' __CS_main_arg_'+n.name)
					varDecl = varDecl.replace(' *'+n.name, ' *__CS_main_arg_'+n.name)
					varDecl = varDecl.replace(' *__CS_main_arg_'+n.name+'[]', ' **__CS_main_arg_'+n.name)

					self.mainParametersDecl += '\t' + varDecl + ';\n'

			elif self.parsingStruct:    # field in a struct (this are not really variables, but we handle them using the same data structures)
				self.varKind[variableContext, n.name] = 'f'
			elif self.indent_level < 1:  # global variable
				self.varKind[variableContext, n.name] = 'g'
			else:                       # local variable
				self.varKind[variableContext, n.name] = 'l'

			# Variable arity (scalars have arity 0)
			self.varArity[variableContext,n.name] = int(s.count('['))
			
			
			if n.name!="argv" and self.varArity[variableContext,n.name]>0:
				self.containsArray+="--"+n.name
			

			# Variable size(s) (for scalars that is an empty array)
			self.varSize[variableContext,n.name] = []

			tmp_s = s
			i = self.varArity[variableContext,n.name]

			while i > 0:
				#tmp = eval(tmp_s[tmp_s.find("[")+1:tmp_s.find("]")])
				tmp = tmp_s[tmp_s.find("[")+1:tmp_s.find("]")]
				
				tmp1 = utils.stripSpaces(tmp).replace("*","").replace("+","").replace("(","").replace(")","")
				if tmp1.isdigit(): tmp=eval(tmp_s[tmp_s.find("[")+1:tmp_s.find("]")])
				
				#print "tmp1="+str(tmp)
				#print tmp_s+"-- parser: "+tmp
				if tmp == '': ithSize = -1           # Unbounded array. This is equivalent to declare a pointer. TODO
				elif not tmp1.isdigit(): ithSize = -2 # Array size given by a complex expression. This is like dynamically allocated blocks. TODO
				else: ithSize = int(tmp)             # Array size given by a constant expression

				self.varSize[variableContext,n.name].append(ithSize)
				tmp_s = tmp_s[tmp_s.find("]")+1:]
				i = i-1

			# This is used later on to see if a pointer is ever associated with a malloc()
			self.varMallocd[variableContext,n.name] = False
	
		return s


