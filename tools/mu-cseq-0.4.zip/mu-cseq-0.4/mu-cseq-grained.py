#!/usr/bin/env python



'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                  Options & parameters below.

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
# Name of the executable file to run, by backend.x
backendFilename = {}
backendFilename['esbmc'] = 'esbmc'
backendFilename['cbmc'] = './cbmc-gildo'
backendFilename['llbmc'] = 'llbmc'

# Command-line parameters, by backend.
cmdLineOptions = {};
# 2600s cmdLineOptions['esbmc'] = '--64  --no-slice --no-bounds-check --no-div-by-zero-check --no-pointer-check --no-unwinding-assertions'
cmdLineOptions['esbmc'] = '--no-slice --no-bounds-check --no-div-by-zero-check --no-pointer-check --no-unwinding-assertions --z3-ir '

# 1600 cmdLineOptions['esbmc'] = '--64 --no-slice --inlining --no-bounds-check --no-div-by-zero-check --no-pointer-check --no-unwinding-assertions'
cmdLineOptions['cbmc'] = '--no-unwinding-assertions'
cmdLineOptions['llbmc'] = '-no-max-function-call-depth-checks -no-memory-free-checks -no-shift-checks -no-memcpy-disjoint-checks -no-memory-access-checks -no-memory-allocation-checks --no-max-loop-iterations-checks --ignore-missing-function-bodies -no-overflow-checks -no-div-by-zero-checks'

# Expressions to check for from the log to check whether verification went fine.
verificationOK = {}
verificationOK['esbmc'] = 'VERIFICATION SUCCESSFUL\n'
verificationOK['cbmc'] = 'VERIFICATION SUCCESSFUL\n'
verificationOK['llbmc'] = 'No error detected.\n'
verificationOK['cpachecker'] = 'Verification result: SAFE. No error path found by chosen configuration.\n'

# Expressions to check for from the log to check whether verification failed.
verificationFAIL = {}
verificationFAIL['esbmc'] = 'VERIFICATION FAILED\n'
verificationFAIL['cbmc'] = 'VERIFICATION FAILED\n'
verificationFAIL['llbmc'] = 'Error detected.\n'
verificationFAIL['cpachecker'] = 'Verification result: UNSAFE. Error path found by chosen configuration.\n'




'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                  Nothing to set past this point.

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
#import os, sys, getopt, time
import os, sys, getopt, string, time

from time import sleep
from threading import Timer

from time import gmtime, strftime

import signal
import sys


class colors:
    BLACK = '\033[90m'
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    NO = '\033[0m'





def getValue(line_tmp):
    start_value=string.find(line_tmp,"=")+1
    end_value=string.find(line_tmp," ",start_value)
    value = int(line_tmp[start_value:end_value])
    return value

def getVariable(line_tmp):
    line_tmp=line_tmp.strip()
    end_value=string.find(line_tmp,"=")
    value = line_tmp[:end_value]
    return value

def getVariableThreadCreate(line_tmp):
    start_value=string.find(line_tmp,"=")+1
    end_value=string.find(line_tmp,"!",start_value)
    value = line_tmp[start_value:end_value]
    return value


def getLineNumber(line_tmp):
    start_value=string.find(line_tmp," line ")+6
    end_value=string.find(line_tmp," ",start_value)
    value = line_tmp[start_value:end_value]
    return value

def getNameFunction(line_tmp):
    start_value=string.find(line_tmp," function ")+10
    end_value=string.find(line_tmp," ",start_value)
    value = line_tmp[start_value:end_value]
    return value



def rreplace(s, old, new, occurrence):
    li = s.rsplit(old, occurrence)
    return new.join(li)


def usage(cmd):
    print "MU-CSeq-Feeder:   verification front-end for MU-CSeq\n"
    print "Usage:"
    print "   -h, --help                         display this help screen\n"
    print "   -i<filename>, --input=<filename>   read input from given filename"
    print "   -t<X>, --threads<X>                set upper bound on the number of threads (default: 5)"
    print "   -w<X>                              set max number of writes\n"
    print "   --depth <X>                        set depth parameter for the backend (default: no bound)\n"
    print "   --unwind <X>                       set max loop unwind (default: 1)\n"
    print "   -f<X>, --ufor<X>                   set max for loop unwind (default: 1,  overrides unwind setting)\n"
    print "   --witness<counterexample-filename>   write counterexample to given counterexample-filename\n"
    print "   --spec<specification-filename>     specification-filename contains the specification to be verified for a program\n"
    print "   --MaxThreadCreate<X>               set max Thread Create in while loops"
    print "   --partial-loops                    permit paths with partial loops\n"
    print "   -T, --timelimit<X>                 set time limit (in seconds, default: no limit)\n"
    print "   -M, --memorylimit<X>               set memory limit (in megabytes, default: no limit)\n"
    #print "   -s, --speedup<X>                   limit read jumps in memory unwinding\n"
    print "   -s, --schema<X>                    a: fine-grained schema | b: coarse-grained schema\n"
    print "   --spec<specification-filename>     specification-filename contains the specification to be verified for a program\n"
    print "   example:  %s -T3000 -M10000 -t4 -u1 -w8 -s a -i lazy_unsafe.c\n" % cmd



'''
    strip()  -  Strips every line in the given string
                from the line with 'startmarker' as substring
                to the one with 'endmarker' as substring.

                Lines are identified by '\n'
'''
def strip(s, startmarker, endmarker):
    s2 = ''
    status = 0

    for line in s:
        if line.startswith(startmarker) and status == 0:
            print "start marker found\n"
            status = 1
            continue;

        if line.endswith(endmarker) and line.startswith(startmarker) and status == 1:
            print "end marker found\n"
            status = 2
            continue;

        if status == 0 or status == 2: s2 += line + '\n'

    return s2


''' Check whether a file starts with 'string'
'''
def fileStartsWith(filename, string):
    if os.path.isfile(filename):
        myfile = open(filename)
        lines = list(myfile)

        if lines[0].startswith(string): return True
        else: return False

    else: return False

    return False


''' Check whether a file contains at least one occurrence of 'string' in any of its lines
'''
def fileContains(filename, string):
    if os.path.isfile(filename):
        myfile = open(filename)
        lines = list(myfile)

        for line in lines:
            if string in line: return True
    else: return False

    return False


''' For now, we assume that if the input file contains "__attribute__ ((",
    it is in (.i) preprocessed format rather than in plain (.c) format.
'''
def isPreprocessed(filename):
    return fileContains(filename, "__attribute__ ((")

def geterrorlabel(specfile):
    error_label = 'ERROR'


    inp = open(specfile,"r")


    for line in inp.readlines():
        i_label = line.find("call")


        if i_label>=0:
            line = line[i_label:]
            i_label = line.find("(",)
            line = line[i_label+1:]
            i_label = line.find("(",)
            error_label = line[:i_label]

    inp.close()
    return error_label


def main(args):
    ### signal.signal(signal.SIGINT, signal_handler)

    realstarttime = time.time()    # save wall time
    timelimit = memorylimit = 0
    ''' 1. Check command-line options
    '''
    cmd = args[0]


    try:
        #opts, args = getopt.getopt(sys.argv[1:], "hdsci:f:u:", ["help", "detail", "skip", "cex", "input=", "format=", "unwind=", "threads=","rounds="])
        #opts, args = getopt.getopt(sys.argv[1:], "d:s:hi:o:x:d:u:w:f:b:t:c:l:m:DT:M:z:a", ["maxContext","schema=","help", "input=", "output=",  "ucheck=", "depth=", "unwind=", "nwrites", "ufor", "bit", "threads", "witness=", "partial-loops", "MaxThreadCreate=", "debug", "timelimit=", "memorylimit=", "backend=","atomicRead="])
        opts, args = getopt.getopt(sys.argv[1:], "hi:o:d:u:w:f:b:t:c:e:l:m:DT:M:z:a:s:", ["help", "input=", "output=",  "depth=", "unwind=", "nwrites", "ufor", "bit", "threads", "witness=", "spec=", "partial-loops", "MaxThreadCreate=", "debug", "timelimit=", "memorylimit=", "backend=","speedup","schema="])
    except getopt.GetoptError, err:
        # print help information and exit:
        usage(cmd)
        print "error: " +str(err) # will print something like "option -a not recognized"
        sys.exit(2)

    inputfile = format = seconds = ''
    #unwind = threads = depth = partialLoops = 0
    unwind = 1
    threads = 5
    depth = 0
    partialLoops = 0
    timelimit = memorylimit = 0
    dontsequentialise = False
    #outputcounterexample = False
    outputdetail = False
    bit=32
    witness=""
    backend=""
    ufor=0
    MaxThreadCreate=0
    speedup = 3
    timelimit=0
    schema="a"
    spec=""

    for o, a in opts:
        if o == "-v": verbose = True
        elif o in ("-h", "--help"):
            usage(cmd)
            sys.exit()
        elif o in ("-e", "--spec"): spec = a
        elif o in ("-c", "--witness"): witness = a
        elif o in ("-l", "--partial-loops"): partialLoops = 1
        elif o in ("-z", "--backend"): backend = a
        elif o in ("-i", "--input"): inputfile = a
        #elif o in ("-f", "--format"): format = a
        elif o in ("-u", "--unwind"): unwind = a
        elif o in ("-t", "--threads"): threads = int(a)
        elif o in ("-w", "--nwrites"): nwrites = int(a)
        elif o in ("-f", "--ufor"): ufor = int(a)
        elif o in ("-b", "--bit"): bit = int(a)
        elif o in ("-d", "--depth"): depth = int(a)
        elif o in ("-m", "--MaxThreadCreate"): MaxThreadCreate = int(a)
        elif o in ("-T", "--timelimit"): timelimit = int(a)
        elif o in ("-a", "--speedup"): speedup = int(a)
        elif o in ("-s", "--schema"): schema = a
        #elif o in ("-T", "--timelimit"): timelimit = 600
        elif o in ("-M", "--memorylimit"): memorylimit = int(a)
        else: assert False, "unhandled option"

    #print "partial-loops="+str(partialLoops)
    #return


    if timelimit==0:
        timelimit=1500

    if backend!="":
        backend = " --"+backend


    error_label = 'ERROR'
    if spec!="":
        error_label = geterrorlabel(spec)
    #print error_label + "---"+spec
    #return



    '''
    inp = open(spec,"r")
    for line in inp.readlines():
        i_label = line.find("label")
        if i_label>=0:
            line = line[i_label:]
            i_label = line.find("(",)
            line = line[i_label+1:]
            i_label = line.find(")",)
            error_label = line[:i_label]
    inp.close()
    '''


    if inputfile == '':
        usage(cmd)
        print "error: input file name not specified\n"
        sys.exit(2)

    # set default values if needed
    if unwind == 0: unwind = 1
    if threads == 0: threads = 5
    #if rounds == 0: rounds = 10
    if format == '': format = 'cbmc'


    ''' 1'. Intermediate step - if the filename ends with .i, then the file has to be stripped
                                and transformed back into a .c file in order to get properly
                                parsed with PYCparser
    '''
    if '/' in inputfile: seqfile = rreplace(inputfile, '/', '/_cs_', 1)
    else: seqfile = '_cs_' + inputfile

    seqfile+='.c'


    #logfilename = seqfile + '.log'
    logfilename = witness
    if logfilename=="":
        logfilename = seqfile + '.log'
    #risfilename = seqfile + '.LOG'

    #fd1 = open( risfilename, 'w')


    #fd1.write("Log started")
    #fd1.write(strftime("  %Y-%m-%d %H:%M:%S", gmtime()) +'\n')

    ''' 2. Call CSeq and save the sequentialised file as '_cs_.....'
    '''
    ##############print ("\ninput:  %s") % (inputfile)

    #fd1.write("\ninput:  %s\n"% (inputfile))


    #cmdline = 'python new-clean.py' + ' -i '+str(inputfile) + ' --nwrites '+str(nwrites) + '' -f'+format
    '''
    if schema=="b":
        cmdline = "./mu-seq-grained.py -i %s -w %s -f %s -t %s --error_label %s --MaxThreadCreate %s -s %s"  % (inputfile,nwrites,ufor,threads,error_label,MaxThreadCreate, speedup)
    else:
        cmdline = "./mu-seq.py -i %s  -w %s -f %s -t %s --error_label %s --MaxThreadCreate %s"  % (inputfile,nwrites,ufor,threads,error_label,MaxThreadCreate)
    '''
    #cmdline = "./mu-seq-new.py -i %s -w %s -f %s -t %s --error_label %s --MaxThreadCreate %s -a %s -s %s -o %s"  % (inputfile,nwrites,ufor,threads,error_label,MaxThreadCreate, speedup, schema, logfilename)
    cmdline = "./mu-cseq-translation.py -i %s --error_label %s -o %s"  % (inputfile,error_label,logfilename)
    #print cmdline
    #cmdline = "./mu-seq.py -i %s  -w %s -f %s -t %s --error_label %s --MaxThreadCreate %s"  % (inputfile,nwrites,ufor,threads,error_label,MaxThreadCreate)


    if partialLoops==1:
        cmdline += " --partial-loops"
    #cmdline = "python run-bench.py -i %s  -w %s -f %s --error_label %s"  % (inputfile,nwrites,ufor,error_label)
    #print 'cmd:    ' + cmdline
    #return
    #fd1.write('cmd:    ' + cmdline+'\n')

    if outputdetail: cmdline += ' -d'
    cseqanswer = os.system(cmdline + " > " +seqfile);


    if cseqanswer != 0:
        print "       (unable to sequentialise input file  -  see output from CSeq below for details)\n"
        print colors.BLACK + '-----------------------------------------------------------------'
        with open(seqfile) as file:
            data = file.read()
            print data
        print '-----------------------------------------------------------------' + colors.NO + '\n'

        print colors.YELLOW + "        UNKNOWN\n" + colors.NO
        sys.exit(-1)

    ''' 4. Run the verification tool (from the command-line option -f) on the sequentialised file
    '''
    #print ("output: %s") % (seqfile)
    #fd1.write('output:    ' + seqfile+'\n')

    if dontsequentialise == True:
        seqfile = inputfile
        print "\nnote!  --skip  option used, no sequentialisation will be verified!"

    ##############print "log:    %s\n" % (logfilename)
    #fd1.write('log:    ' + logfilename+'\n')

    ##t.start()
    start_time = time.time()  # Save the time.

    timeBeforeCallingBackend = time.time()    # save wall time

    if dontsequentialise == False: # normal behaviour (no --skip)
        if format == 'esbmc':
            cmdline =  backendFilename[format] + ' --unwind '+ str(unwind)+ ' ' + cmdLineOptions[format] + ' ' + seqfile + ' > ' + logfilename
        elif format == 'cbmc':
            cmdline = backendFilename[format] + ' --' + str(bit) +backend+' --unwind '+ str(unwind)+ ' --no-unwinding-assertions --depth '+str(depth)+ ' ' + seqfile + ' > ' + logfilename
        elif format == 'llbmc':
            # note: there are two different statements here,
            #  (1) for Clang to generate llvm code, and
            #  (2) for llbmc to perform model-checking
            cmdline = "clang -c -g -I. -emit-llvm %s -o %s.bc 2> %s; " % (seqfile, seqfile, logfilename)
            cmdline += backendFilename[format] + ' --max-loop-iterations=' + str(unwind) + ' ' + cmdLineOptions[format] + ' ' + seqfile +'.bc' + ' 1> ' + logfilename

        elif format == 'cpachecker':
            options = ' -predicateAnalysis  -spec ErrorLabel.spc '
            cmdline = 'scripts/cpa.sh ' + options + seqfile + ' > ' + logfilename


    cmdline = 'timeout/timeout ' + cmdline
    memorylimit = 1000*memorylimit # kBytes --> mBytes

    ##ulimit -Sv 500000     # Set ~500 mb limit
    if timelimit > 0: cmdline = 'timeout %s ' % (timelimit) + cmdline
    if memorylimit > 0: cmdline = 'ulimit -Sv %s; ' % (memorylimit) + cmdline

    #print "cmd:    " + cmdline
    #print "start:  %s\n" % (strftime("%Y-%m-%d %H:%M:%S", gmtime()))


    #print "        note: clauses (x1000), variables (x1000), time (s), space (MB)\n"


    #fd1.write("cmd:    " + cmdline+'\n')
    #fd1.write("start:  %s\n" % (strftime("%Y-%m-%d %H:%M:%S", gmtime())+'\n'))
    #fd1.write("        note: clauses (x1000), variables (x1000), time (s), space (MB)\n")



    #os.system(cmdline)

    '''
    if outputcounterexample:
        with open(logfilename) as file:
            data = file.read()
            print data
    '''
    if os.path.isfile(logfilename):
        myfile = open(logfilename)
        backendAnswer = list(myfile)

        outcome = ''
        mem = maxmem = cpu = stale = 0
        variables = clauses = 0

        for line in backendAnswer:
            if ('MEM CPU ' in line  or
                'HANGUP CPU ' in line or
                'TIMEOUT CPU ' in line or
                'SIGNAL CPU ' in line or
                'FINISHED CPU ' in line):
                #SIGNAL CPU 4.90 MEM 84596 MAXMEM 84596 STALE 0
                line = line[line.find('CPU '):]
                splitline = line.split()
                cpu = splitline[1]
                mem = splitline[3]
                maxmem = splitline[5]
                stale = splitline[7]
            if ' variables, ' in line:
                splitline = line.split()
                variables = splitline[0]
                clauses = splitline[2]

        ##   2174 variables, 5558 clauses

        variables = float(variables) / 1000
        clauses = float(clauses) / 1000

        ##########print "size:   %0.2f variables" % variables
        ##########print "        %0.2f clauses" % clauses
        #############print ""
        #fd1.write("size:   %0.2f variables\n" % variables)
        #fd1.write("        %0.2f clauses\n" % clauses)
        #fd1.write("\n")

        mem = float(mem) / 1000
        maxmem = float(maxmem) / 1000
        #print "space:  %0.2f " % mem
        #print "        %0.2f peak" % maxmem
        #print ""

        #print "cpu:    %s " % cpu
        #print ""

        '''
        print "time:   %0.2f preprocess" % (timeBeforeCallingBackend - realstarttime)
        print "        %0.2f backend" % (time.time() - timeBeforeCallingBackend)
        print "        %0.2f overall" % (time.time() - realstarttime)
        print ""
        '''
        overalltime = "%0.2f" % (time.time() - realstarttime)

        #fd1.write("time:   %0.2f preprocess\n" % (timeBeforeCallingBackend - realstarttime))
        #fd1.write("        %0.2f backend\n" % (time.time() - timeBeforeCallingBackend))
        #fd1.write("        %0.2f overall\n" % (time.time() - realstarttime))



        for line in backendAnswer:
            if verificationFAIL[format] in line:
                #print inputfile+","+logfilename+","+overalltime+","+colors.RED + "FALSE" + colors.NO
                # print colors.RED + "FALSE" + colors.NO + ","+logfilename+","+overalltime
                #fd1.write(colors.RED + "        FALSE" + colors.NO)
                outcome = 'FALSE'
                break
            elif verificationOK[format] in line:
                #print inputfile+","+logfilename+","+overalltime+","+colors.GREEN + "TRUE" + colors.NO
                # print colors.GREEN + "TRUE" + colors.NO + ","+logfilename+","+overalltime
                #fd1.write(colors.GREEN + "        TRUE" + colors.NO )
                outcome = 'TRUE'
                break
            elif 'UNKNOWN' in line:
                # print colors.YELLOW + "UNKNOWN" + colors.NO + ","+logfilename+","+overalltime
                #fd1.write(colors.GREEN + "        TRUE" + colors.NO )
                outcome = 'UNKNOWN'
                break


        if  outcome == '':
            #print overalltime +", "+colors.YELLOW + "        UNKNOWN" + colors.NO
            #print inputfile+","+logfilename+","+overalltime+","+colors.GREEN + "TRUE" + colors.NO
            #print inputfile+","+logfilename+","+overalltime+","+colors.YELLOW + "TRUE" + colors.NO
            # print colors.GREEN + "TRUE" + colors.NO + ","+logfilename+","+overalltime
            #fd1.write(colors.YELLOW + "        UNKNOWN" + colors.NO)
            outcome = 'UNKNOWN'

        #print ''

    verdict = colors.YELLOW +'--'+ colors.NO
    if outcome != 'UNKNOWN':
        if ('_false' in inputfile or '_unsafe' in inputfile) and outcome == 'TRUE':
            verdict = colors.RED +'ko'+ colors.NO
        elif ('_true' in inputfile or '_safe' in inputfile) and outcome == 'FALSE':
            verdict = colors.RED +'ko'+ colors.NO
        else:
            verdict = colors.GREEN +'ok'+ colors.NO
    print "%s, %s, %s, %0.2f" % (verdict, outcome, inputfile, time.time() - realstarttime)


    #fd1.close()


    return
    memory_notvalid=0
    thread_pos=0
    thread_index=0
    num_linea=1
    start_line_main=0

    whereIam=""


    listString=[]
    listLinesNumberCx=[]
    listLinesNumberSource=[]
    listThread=[]
    listFunction=[]

    for k in range (0, 30):
        listString.append([])
        listLinesNumberCx.append([])
        listLinesNumberSource.append([])
        listString.append([])
        listFunction.append([])
        listThread.append([])



    '''
    listLinesAlias[0].append("ciao")
    listLinesAlias[0].append("ciao2")
    listLinesAlias[1].append("ciao3")
    listLinesAlias[1].append("ciao4")


    print listLinesAlias[0][0]
    print listLinesAlias[0][1]
    '''



    f = open( logfilename, 'r')
    linesFile=f.readlines()
    f.close()
    f = open( seqfile, 'r')
    linesFileGenerato=f.readlines()
    f.close()

    variabili=[]
    start_vars=0
    for line in linesFileGenerato:
        if line.find("start global variables")>0:
            start_vars=1
        if start_vars==1 and line.find("define")>0:
            start_value=string.find(line," ")+1
            end_value=string.find(line," ",start_value)
            value = line[start_value:end_value]
            variabili.append(value)
        if line.find("end global variables")>0:
            start_vars=0






    String_tmp=""
    LinesNumberCx_tmp=""
    LinesNumberSource_tmp=""
    Thread_tmp=""
    i=0
    for line in linesFile:
        if line.find("Counterexample:")>=0:
            start_line_main=0
        if start_line_main==0:
            if line.find("memory_notvalid=")>=0:
                #memory_notvalid = int(line[18:string.find(line," ",3)])
                memory_notvalid = getValue(line)
                print str(num_linea)+"> "+getVariable(line)+" = "+str(memory_notvalid)

            if line.find("main_thread")>=0 and start_line_main==0:
                start_line_main=num_linea
                print str(num_linea)+"> start_main"
        else:
            if line.find(" thread_pos=")>=0:
                thread_pos = getValue(line)
                print str(num_linea)+"> "+getVariable(line)+" = "+str(thread_pos)

            if line.find(" thread_index=")>=0:
                thread_index = getValue(line)
                print str(num_linea)+"> "+getVariable(line)+" = "+str(thread_index)

            if line.find("__pthread_mutex_init")>=0:
                if whereIam=="":
                    mutex = getValue(linesFile[i-6])
                    print str(num_linea)+"> __pthread_mutex_init(%s)"%(variabili[mutex])
                    listString[thread_pos].append("__pthread_mutex_init(%s)"%(variabili[mutex]))
                    listLinesNumberCx[thread_pos].append(str(num_linea))
                    listLinesNumberSource[thread_pos].append(getLineNumber(linesFile[i-4]))
                    listFunction[thread_pos].append(getNameFunction(linesFile[i-4]))
                    listThread[thread_pos].append(str(thread_index))
                    whereIam="__pthread_mutex_init"
                elif whereIam=="__pthread_mutex_init":
                    whereIam=""


            if line.find("__pthread_create_")>=0 and linesFile[i-10].find("thread_id")>=0:
                print str(num_linea)+"> __pthread_create(%s)"%getVariableThreadCreate(linesFile[i-10])
                listString[thread_pos].append("pthread_create(%s)"%getVariableThreadCreate(linesFile[i-10]))
                listLinesNumberCx[thread_pos].append(str(num_linea))
                listLinesNumberSource[thread_pos].append(getLineNumber(linesFile[i-4]))
                listFunction[thread_pos].append(getNameFunction(linesFile[i-4]))
                listThread[thread_pos].append(str(thread_index))




            if line.find("__pthread_mutex_lock")>=0:
                if whereIam=="":
                    mutex = getValue(linesFile[i-2])
                    print str(num_linea)+"> pthread_mutex_lock(%s)"%(variabili[mutex])
                    print linesFile[i-4]
                    String_tmp="pthread_mutex_lock(%s)"%(variabili[mutex])
                    LinesNumberCx_tmp=str(num_linea)
                    LinesNumberSource_tmp=getLineNumber(linesFile[i-4])
                    listFunction_tmp=getNameFunction(linesFile[i-4])
                    Thread_tmp=str(thread_index)
                    whereIam="__pthread_mutex"
                elif whereIam=="__pthread_mutex" and linesFile[i+4].find("__pthread_mutex_lock")<0 and linesFile[i+4].find("function Write")<0:
                    pos=0
                    if schema=="b":
                        pos=len(listString[thread_pos])
                    listString[thread_pos].insert(pos,String_tmp)
                    listLinesNumberCx[thread_pos].insert(pos,LinesNumberCx_tmp)
                    listLinesNumberSource[thread_pos].insert(pos,LinesNumberSource_tmp)
                    listFunction[thread_pos].insert(pos,listFunction_tmp)
                    listThread[thread_pos].insert(pos,Thread_tmp)
                    whereIam=""


            if line.find("__pthread_mutex_unlock")>=0:
                if whereIam=="":
                    mutex = getValue(linesFile[i-2])
                    print str(num_linea)+"> pthread_mutex_unlock(%s)"%(variabili[mutex])
                    print linesFile[i-4]
                    String_tmp="pthread_mutex_unlock(%s)"%(variabili[mutex])
                    LinesNumberCx_tmp=str(num_linea)
                    LinesNumberSource_tmp=getLineNumber(linesFile[i-4])
                    listFunction_tmp=getNameFunction(linesFile[i-4])
                    Thread_tmp=str(thread_index)
                    whereIam="__pthread_mutex"
                elif whereIam=="__pthread_mutex" and linesFile[i+4].find("__pthread_mutex_unlock")<0 and linesFile[i+4].find("function Write")<0:
                    pos=0
                    if schema=="b":
                        pos=len(listString[thread_pos])
                    listString[thread_pos].insert(pos,String_tmp)
                    listLinesNumberCx[thread_pos].insert(pos,LinesNumberCx_tmp)
                    listLinesNumberSource[thread_pos].insert(pos,LinesNumberSource_tmp)
                    listFunction[thread_pos].insert(pos,listFunction_tmp)
                    listThread[thread_pos].insert(pos,Thread_tmp)
                    whereIam=""

            if line.find("Write")>=0 and whereIam!="__pthread_mutex":
                if whereIam=="":
                    val = getValue(linesFile[i-2])
                    var = getValue(linesFile[i-6])
                    print str(num_linea)+"> Write(%s,%s)"%(variabili[var],val)
                    String_tmp="Write(%s,%s)"%(variabili[var],val)
                    LinesNumberCx_tmp=str(num_linea)
                    LinesNumberSource_tmp=getLineNumber(linesFile[i-4])
                    listFunction_tmp=getNameFunction(linesFile[i-4])
                    Thread_tmp=str(thread_index)
                    whereIam="Write"
                elif whereIam=="Write" and linesFile[i+4].find("Write")<0:
                    pos=0
                    if schema=="b":
                        pos=len(listString[thread_pos])
                    listString[thread_pos].insert(pos,String_tmp)
                    listLinesNumberCx[thread_pos].insert(pos,LinesNumberCx_tmp)
                    listLinesNumberSource[thread_pos].insert(pos,LinesNumberSource_tmp)
                    listFunction[thread_pos].insert(pos,listFunction_tmp)
                    listThread[thread_pos].insert(pos,Thread_tmp)
                    whereIam=""

            if line.find("function Read")>=0 and whereIam!="__pthread_mutex":
                if whereIam=="":
                    #val = getValue(linesFile[i-2])
                    var = getValue(linesFile[i-2])
                    #var = linesFile[i-2]
                    print str(num_linea)+"> Read(%s)"%(variabili[var])
                    String_tmp="Read(%s)"%(variabili[var])
                    LinesNumberCx_tmp=str(num_linea)
                    LinesNumberSource_tmp=getLineNumber(linesFile[i-4])
                    listFunction_tmp=getNameFunction(linesFile[i-4])
                    Thread_tmp=str(thread_index)
                    whereIam="Read"
                elif whereIam=="Read" and linesFile[i+4].find("function Read")<0:
                    val = getValue(linesFile[i-2])
                    #val = linesFile[i-2]
                    listString[thread_pos].append(String_tmp+"="+str(val))
                    listLinesNumberCx[thread_pos].append(LinesNumberCx_tmp)
                    listLinesNumberSource[thread_pos].append(LinesNumberSource_tmp)
                    listFunction[thread_pos].append(listFunction_tmp)
                    listThread[thread_pos].append(Thread_tmp)
                    whereIam=""

            if line.find("__CS_error=1")>=0:
                print str(num_linea)+"> ERROR"
                String_tmp=colors.NO+colors.RED+"ERROR"
                LinesNumberCx_tmp=str(num_linea)
                LinesNumberSource_tmp=getLineNumber(linesFile[i-2])
                listFunction_tmp=getNameFunction(linesFile[i-2])
                Thread_tmp=str(thread_index)
                listString[thread_pos].append(String_tmp)
                listLinesNumberCx[thread_pos].append(LinesNumberCx_tmp)
                listLinesNumberSource[thread_pos].append(LinesNumberSource_tmp)
                listFunction[thread_pos].append(listFunction_tmp)
                listThread[thread_pos].append(Thread_tmp)
                break


        i=i+1




        num_linea=num_linea+1

    fd2 = open( 'log.txt', 'w')
    print "\n\n\nstampaLista\n\n\n"+str(memory_notvalid)
    for k in range (0, memory_notvalid):
        print colors.RED +"\nthread_pos:%s"%k +colors.NO
        fd2.write("\nthread_pos:%s"%k)
        for i in range(0,len(listString[k])):
            print listLinesNumberCx[k][i]+" >numberLine: "+listLinesNumberSource[k][i]+" >function: "+listFunction[k][i]+" >thread:"+listThread[k][i]+" >"+colors.GREEN +listString[k][i]+colors.NO
            print colors.BLUE +linesFileGenerato[int(listLinesNumberSource[k][i])-1] +colors.NO

            fd2.write("\n"+listLinesNumberCx[k][i]+" >numberLine: "+listLinesNumberSource[k][i]+" >function: "+listFunction[k][i]+" >thread:"+listThread[k][i]+" >"+listString[k][i])
            fd2.write("\n"+linesFileGenerato[int(listLinesNumberSource[k][i])-1])

    fd2.close()





if __name__ == '__main__':
    import sys
    main(sys.argv[0:])





