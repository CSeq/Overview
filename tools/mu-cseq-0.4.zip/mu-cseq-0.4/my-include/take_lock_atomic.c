



void Write_var_atomic(){
	if (__CS_ret) return;
	
	__CS_typeM last_pos = __thw_atomic[__cs_thread_index][__last_used_pos_of_atomic];
	
	if (last_pos >= __memory_notvalid_of_atomic ) {__CS_ret=1; return;}
	__last_used_pos_of_atomic=last_pos;

	
	__CPROVER_assume (
				(__ticket_atomic[last_pos] > ticket_pos)
			//&&  (__value_atomic[last_pos] == val)
		) ;
	ticket_pos=__ticket_atomic[last_pos];

}
intV Read_var_atomic(){
	__CS_typeM jump;
	
	if ((__CS_ret) || ( jump >= __memory_notvalid_of_atomic )) {__CS_ret=1; return;}
	
	__CS_typeM ticket_jump = __ticket_atomic[jump];
    __CPROVER_assume( (jump<__thw_atomic[__cs_thread_index][__last_used_pos_of_atomic] )
				&& (__ticket_atomic[jump+1]>ticket_pos)			
				//<insert-atomic-constrain-here>
				);						
						/*&& ( !(ticket_jump > ticket_pos) || (__visible[codeVar][jump]) )*/

	ticket_pos = (ticket_jump > ticket_pos) ? ticket_jump : ticket_pos;
	/*<insert-atomic-constrain-here>*/

}


/*



intV Read_var_atomic(){
	__CS_typeM jump;
	
	if ((__CS_ret) || ( jump >= __memory_notvalid_of_atomic )) {__CS_ret=1; return;}
	
    __CPROVER_assume( (jump<__thw_atomic[__cs_thread_index][__last_used_pos_of_atomic] )
				&& (__ticket_atomic[jump+1]>ticket_pos)			
				&& (__ticket_atomic[jump] <= ticket_pos)			
					);						
						
	return (__value_atomic[jump]);
}
*/
void Take_lock__atomic_function(){

	Write_var_atomic();
	//if (__CS_ret) return;
	//__CPROVER_assume (__value_atomic[__last_used_pos_of_atomic-1] == MaxNumThreads);

}




void Release_lock__atomic_function(){
//	if (__CS_ret) return;
	Write_var_atomic();
}
