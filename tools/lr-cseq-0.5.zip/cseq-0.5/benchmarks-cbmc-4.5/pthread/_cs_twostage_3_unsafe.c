Conversion error:  use of 'malloc' is currently not handled.
