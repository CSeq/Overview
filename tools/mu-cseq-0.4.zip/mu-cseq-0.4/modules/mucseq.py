""" Lazy-CSeq Sequentialization module
	written by Omar Inverso, University of Southampton.
"""
VERSION = 'lazyseq-0.0-2015.07.18'   # CSeq-1.0 Release ASE2015
#VERSION = 'lazyseq-0.0-2015.07.16'   # main driver bug fixing (Truc)
#VERSION = 'lazyseq-0.0-2015.07.10'
#VERSION = 'lazyseq-0.0-2015.06.30'
#VERSION = 'lazyseq-0.0-2015.06.11'
#VERSION = 'labeler-0.0-2015.02.22'   # bugfix
#VERSION = 'labeler-0.0-2015.01.27'   # more efficient handling of mutexes
#VERSION = 'labeler-0.0-2015.01.17'   # small optimization
#VERSION = 'labeler-0.0-2015.01.12'   # back to CAV-style constraints in the main driver
#VERSION = 'labeler-0.0-2014.10.29'   # CSeq-1.0beta
#VERSION = 'labeler-0.0-2014.10.29'   # newseq-0.6c SVCOMP15
#VERSION = 'labeler-0.0-2014.10.26'   # newseq-0.6a
#VERSION = 'labeler-0.0-2014.10.15'
#VERSION = 'labeler-0.0-2014.06.26' (CSeq-Lazy-0.4)
#VERSION = 'labeler-0.0-2014.03.14' (CSeq-Lazy-0.3)
#VERSION = 'labeler-0.0-2014.02.25' (CSeq-Lazy-0.2)

"""

Transformation:
	implements the lazy sequentialization schema
	(see Inverso, Tomasco, Fischer, La Torre, Parlato, CAV'14)

Prerequisites:
	- all functions should have been inlined, except the main(), all thread functions, all __CSEQ_atomic_ functions, and function __CSEQ_assert
	- all loops should habe been unrolled
	- no two threads refers to the same thread function (use module duplicator.py)

TODO:
	- get rid of _init_scalar() (see ext. notes)
	- check the STOP() inserting mechanism
	- this schema assumes no mutex_lock() in main() - is this fine?

Changelog:
	2015.07.18  new --schedule parameter to set schedule restrictions (Omar)
	2015.07.15  changed visit of atomic function definitions (Truc,Omar)
	2015.07.10  no context switch between __CSEQ_atomic_begin() and __CSEQ_atomic_end()
	2015.06.30  major refactory (converted to stand-alone instrumentation, etc.)
	2015.04.23  __globalAccess()  was causing  if(cond)  blocks to disappear
	2015.02.22  __CSEQ_assume() without occurrences of shared vars produces no context switch points
	2015.01.27  using macros rather than functions to model pthread_mutex_lock/unlock() avoids using ptrs and thus yields faster analysis
	2014.01.17  main driver: first thread execution context must have length > 0 (faster analysis)
	2014.12.24  linemap (overrides the one provided by core.module)
				bugfixes, code maintenance
	2014.12.09  further code refactory to match the new organisation of the CSeq framework
	2014.10.29  bitvector encoding for all control variables (pc, pc_cs, ...)
				new main driver where guessed jump lenghts are all at the top (this allows inserting p.o.r. constraints right after them)
	2014.10.26  removed dead/commented-out/obsolete code
	2014.10.15  removed visit() and moved visit call-stack handling to module class (module.py)
	2014.06.26  improved backend-specific instrumentation
				added new backend Klee
	2014.03.14  further code refactory to match  module.Module  class interface
	2014.02.25  switched to  module.Module  base class for modules
	2014.01.19  fixed assert()s missing their stamps at the beginning

"""
import math, re
from time import gmtime, strftime
import pycparser.c_parser, pycparser.c_ast, pycparser.c_generator
import core.common, core.module, core.parser, core.utils











notHandledPrimitives = [ 'pthread_mutex_trylock', 'pthread_mutex_timedlock', 'pthread_mutex_consistent']  # mutexes
notHandledPrimitives += ['pthread_cond_timedwait', 'pthread_cond_destroy'] # conditionals
notHandledPrimitives += ['free', 'calloc'] # dynamic memory allocation
renameFunct=["thread"]


class colors:
	BLACK = '\033[90m'
	RED = '\033[91m'
	GREEN = '\033[92m'
	YELLOW = '\033[93m'
	BLUE = '\033[94m'
	NO = '\033[0m'

mainSimulationBlock = (
"<insert-thread-create-block-here>"
"\n\nvoid *main_thread(int __cs_param_main_argc, char *__cs_param_main_argv[])\n"
"{\n"
"\t<insert-main-parameters-decl-here>\n"
"\t<insert-mainthread-here>\n"
"}\n"
"\n"
"\n"
"\n\n<insert-check-block-here>\n\n"

"\n"
"\n"
#"<insert-main-prototype-here>\n"
"\nint main(int argc, char **argv)\n"
"\n{"
"\n"
"\nGuessedNumThreads=nondet_int();"
"\n__CPROVER_assume(GuessedNumThreads<=MaxNumThreads);"
"\n"
"\n"
"\nguessMU();"
"\n"
"\n//ticket_pos=NumVars-1;"
"\n//cseq: simulation of the threads main"
"\nmain_thread(argc, argv);"
"\n  //__CPROVER_assume((thw[thread_index][thread_pos] >=memory_notvalid) );"
"\n  insert-end-thread-create-here>"
"\n  __CPROVER_assume(GuessedNumThreads==n_treads_createad);"
"\n"
"\n//cseq: Error check"
"\nassert(__CS_error != 1);"
"\n}"
)
exitBlock = (
"if (nondet_int()){__CS_ret=1; return 0;}\n"
)

errorBlock2 = (
"\tERROR: if (__CS_ret) return 0; \n"
"\t__CS_error = 1;  <return_statement>;\n "
)
errorBlock = (
"\tif (__CS_ret) return 0; "
"\t__CS_error = 1;  <return_statement> "
)


pthread_create_block_static = (
"(__CS_pthread_t *thread_id, void *attr, void *arg){\n"
"	int __ret=0;\n"
"__CS_typeT my_thread_index;\n"
"__CS_typeM my_ticket_pos;\n"
"insert-mylast-used-pos-here>\n"
"\n"
"   if (MaxNumThreads==++number_threads) return 0;\n"
""
"	my_thread_index = thread_index; \n"
" 	my_ticket_pos   = ticket_pos;\n"
" 	thread_index = number_threads;\n"
"   n_treads_createad++;\n"
" 	insert-start-thread-create-here>\n"
"	if (nondet_int()){ __CS_ret=1; __ret=-1;}\n"
" 	else { <insert-thread-routine-here>( arg); }\n"
" 	*thread_id=thread_index;\n"
" 	//__CPROVER_assume((thw[thread_index][thread_pos] >=memory_notvalid) );\n"
" 	 	//__CPROVER_assume((thread_pos< memory_notvalid) && (thw[thread_index][thread_pos] >=memory_notvalid) );\n"
" 	insert-end-thread-create-here>\n"
" 	//if (__CS_ret==1) terminated[thread_index]=1;\n"
"	terminated[thread_index]=!__CS_ret;\n"
"	__CPROVER_assume(ticket_pos_terminated[thread_index]==ticket_pos);\n"
"	//sistemare thread_pos_terminated[thread_index]=ticket_pos;\n"
"	//ticket_pos_terminated[thread_index]=ticket_pos;\n"
" 	__CS_ret=0;\n"
" 	thread_index = my_thread_index;\n"
" 	ticket_pos   = my_ticket_pos;\n"
"	insert-from-mylast-used-pos-here>\n"
"	return __ret;\n"
"}\n"
)







class mucseq(core.module.Translator):
	__lines = {}                     # lines for each thread
	__threadName = ['main']          # name of threads, as they are found in pthread_create(s) - the threads all have different names
	__threadIndex = {}               # index of the thread = value of threadcount when the pthread_create to that thread was discovered
	__threadCount = 0                # pthread create()s found so far

	__labelLine = {}                 # statement number where labels are defined [function, label]
	__gotoLine = {}                  # statement number where goto to labels appear [function, label]
	__maxInCompound = 0              # max label within a compound
	__labelLength = 55               # for labels to have all the same length, adding padding when needed
	__startChar = 't'                # special char to distinguish between labeled and non-labelled lines

	__stmtCount = -1                 # thread statement counter (to build thread labels)

	__currentThread = ''             # name of the current thread (also used to build thread labels)

	__threadbound = 0                # bound on the number of threads

	__firstThreadCreate = False      # set once the first thread creation is met
	__globalMemoryAccessed = False   # used to limit context-switch points (when global memory is not accessed, no need to insert them)

	__first = False
	__atomic = False                 # no context-switch points between atomic_start() and atomic_end()

	_bitwidth = {}                   # custom bitwidth for specific int variables, e.g. ['main','var'] = 4

	_deadlockcheck = False

	__explicitround = []             # explicit schedules restrictions
	
	
	error_label= '__VERIFIER_error()'
	
	string=""
		
	logAppend=""
		
	setParams=0
		
	NumLocks=10
	NumvLocks=10

	arrayWriteVars = {}
		#parser.printsymbols()
		#####
	lockVariable=0
		
		#self._inputFilename = filename
	verifier_atomic = 0	
	MaxThreadCreate=3
	nwrites=7
	ufor=10
	bitvector=17
	partialLoops = 0
	speedup = 0

		#self.num_assignment=0
	visitStarted=0
	global_parameters=[]  
	global_parameters2={} 
	equalToGlobalName={}  
		####Gildo: tolgo isBool
		#####self.isBool=[]
	isArray=[]
	isScalar=[]
	isInFuncCall=0
	suffixCall=""

	pthread_create_block = ""

	check_block = ""
	MEM_SIZE=24
	LOCK_SIZE = 0
	vLOCK_SIZE = 0
		
	variables=[]
	isInArrayOrStruct="" 
	whereInAssignment="" 
	inGlobalPointer=0
	localPointer=[]
		
	functionBlock1=""
	IsFakeFunct=0
	initializedGlobalVariables	= []
	labelFor=0
	MaxThreadCreateInLop=MaxThreadCreate
		
	initialization=""
	initializationNew=""
	_nwrites = nwrites
	_format = format	
	funcName = ['']  # names of all the functions (consider '' to be a special function to model global scope)
	global renameFunct
	renameFunct1=renameFunct	
	
	# this will set to True after parsing the first function definition (not declaration!)
	firstFunctionDefinitionDone = False

	# set to True while parsing void functions
	parsingVoidFunction = False

	# set to True while parsing typedef blocks 
	parsingTypedef = False

	# used to avoid inserting context switches in functions whose name starts with '__VERIFIER_atomic'
	parsingAtomic = False


		
	lines = []	
	unionDeclaration = 'union __CS__u {\n'
	
	# = True while parsing the subtree for a function declaration
	parsingFuncDecl = False

	# = True while parsing the subtree for a struct (or union) declaration
	parsingStruct = False

	# = True while parsing the main() function
	parsingMain = False

	# = True while parsing the condition block of a while loop
	parsingWhileCond = False

	# Set when parsing a statement with side effects (i.e., function call, assignment, unary op)
	parsingSideEffect = False



	copyVariableDeclaration = ''

	# The following union declaration will be used to keep
	# the old value of a global variable immediately before any complex assignment operation
	# (such as the ones with a function call in the Lvalue).
	# This value can be used thereafter to simulate when a context switch happens
	# while performing function calls from within the assignment,
	# to restore the original value of the variable with a single assignment statement
	# (C unions support this).

	# init expressions for global variables will be moved into this string and then 
	# printed inside the main() function
	globalInitStatements = ''
	
	
	currentFunct = '' # name of the function being parsed (if any)

	currentVarAssign = '' # name of the current variable used as a lvalue in an assignment statement

	currentStruct = ''
	structName = []
	currentAnonStructsCount = 0   # counts the number of anonymous structures (used to assign consecutive names)

	mainParametersDecl = ''     # parameters of the main() function to be transferred to thread 0.

	
		# TODO: True when the copyvar block etc. in the top of the main() function still
		# has to be added. We have to wait for all the declarations at the top of the main()
		# to show up before adding any assignment operations!
	append = True

		# The following variables are needed for handling the global variables in the original
		# source code.
	globalInitVarNodes = []  # all the initialised global variable nodes in a list

		# Statements start with indentation of self.indent_level spaces, using
		# the _make_indent method
		#
	indent_level = 0			# to keep track of the depth of the block {}
	INDENT_SPACING = '\t'	# ....

	pthread_create_block_static=""
		
	
	
	

	def init(self):
		self.addInputParam('rounds', 'round-robin schedules', 'r', '1', False)
		self.addInputParam('schedule', 'schedule restriction (example: 1,2:+:3)', 's', default='', optional=True)
		self.addInputParam('threads', 'max no. of thread creations (0 = auto)', 't', '0', False)
		self.addInputParam('deadlock', 'check for deadlock', '', default=False, optional=True)

		self.addOutputParam('bitwidth')
		self.addOutputParam('header')


	def loadfromstring(self, string, env):
		if self.getInputParamValue('deadlock') is not None:
			self._deadlockcheck = True

		threads = int(self.getInputParamValue('threads'))
		rounds = int(self.getInputParamValue('rounds'))
		backend = self.getInputParamValue('backend')


		self.__threadbound = threads

		super(self.__class__, self).loadfromstring(string, env)

		self.string=string

		
		if (('__VERIFIER_atomic' in string) or ('__CSEQ_atomic_' in string)):
			self.verifier_atomic = 1		

		self.output += "\n\n//atomico: %s\n\n" %(self.verifier_atomic)
		
		#header = self._make_header()
		
		self.wmm=0 #per vedere se ci sono loop
		if ('__VERIFIER_atomic_begin' in string) or ('__CSEQ_atomic__begin' in string):
			self.wmm=1 #per vedere se ci sono loop
		


		global pthread_create_block
		self.pthread_create_block_static = pthread_create_block_static
		
		'''da vedere
		if (parser.containsArray!="" and parser.containsArray.find("_Thread_local__COND")<0):
			self.pthread_create_block_static=pthread_create_block_static.replace("__CPROVER_assume((thread_pos< memory_notvalid) && (thw[thread_index][thread_pos] >=memory_notvalid) )","__CPROVER_assume((thw[thread_index][thread_pos] >=memory_notvalid) )")
		'''
		



		global errorBlock
		global renameFunct
		self.renameFunct1=renameFunct




		# Optimisation: remove code from cs() for conditional variables when not needed.
		if not 'pthread_cond' in string:
			self.output = self.output.replace('___XXXXX__assume(__CS_thread_lockedon[k][__CS_thread_index] == 0);', '/**/');

		
		
		header = self._make_header()

		
		
		
		self.output = header + core.utils.strip(self.output)		
		
		
		
		
		'''
		# Add the new main().
		self.output += self.__build_check_block(rounds)
		
		#self.output += self.Parser.printsymbols()
		self.logAppend=""
		for f in self.Parser.funcName:
			for v in self.Parser.varNames[f]:
				self.logAppend+="\n//%s:%s"%(v,f)
		
		self.output += self.logAppend
		'''


	def _make_header(self):
		# This block is added at the top of the output file.
		# All the function calls starting with '___XXXXX__' are place-holders and 
		# will be replaced later on, depending on the format chosen.
		# The placeholder <insert-include-statements-here> will be replaced with the original
		# #include lines (that we assume to be at the top of the input and without empty lines)
		# exactly as they were.
		#
		headerBlock = ''

		variables=self.variables
		pthread_condt_variables=[]
		if ('pthread_cond_wait' in self.string):
			for i in range (0, self.__threadbound):
				variables.append("lock_cond_"+str(i))

		#############		prima di atomic
		

		
		############
				
		headerBlock=""	
		#headerBlock+="//NumVLocks: %s\n"%(self.NumvLocks)

		
				
		for f in self.Parser.funcName:
			for v in self.Parser.varNames[f]:
				self.logAppend+="\n//%s:%s"%(v,f)
				if f == '':
					if self.Parser.varType['',v]=="pthread_mutex_t" or self.Parser.varType['',v]=="__cs_mutex_t":
						self.lockVariable=1
						continue
					if self.Parser.varKind['', v] == 'p':
						continue
					if  self.Parser.varType['',v].startswith('pthread_t'):
						continue
					
					if self.__isPointer(f,v) and not self.Parser.varType['',v].startswith("pthread_mutex_t"):
						#variables.append(v+"__valid")
						variables.append(v)
						
						'''GILDO: i puntatori sono da gestire
						for i_1 in range (0,16):
							variables.append(v+"__"+str(i_1))
							i_1=i_1+1
						'''
					elif self.Parser.varType['',v].startswith('struct '):
						struct_type=self.Parser.varType['',v][7:]
						for line in self.__explodeVariable(v):
							#print line+"-----"+self.Parser.varType['','queue.element']
							indexBracket = line.find('[')
							indexDot = line.find('.')
							line = line.replace('[', '__')
							line = line.replace(']', '')
							line = line.replace('.', '___')
							variables.append(line)
					elif (self.Parser.varArity[f, v]>0):
						arity_var=self.Parser.varArity[f, v]
						if (arity_var>0):
							#print v+"-----"+self.Parser.varType['',v]
							for line in self.__explodeVariable(v):
								indexBracket = line.find('[')
								indexDot = line.find('.')
								line = line.replace('[', '__')
								line = line.replace(']', '')
								line = line.replace('.', '___')
								'''
								Gildo: tolgo isBool
								if (self.Parser.varType['',v]=="_Bool"):
									self.isBool.append(line)
									#print line
								'''
								headerBlock+="//line[]: %s\n"%(line)
								variables.append(line)
					else:
						if self.Parser.varType['',v]=='pthread_cond_t':
							pthread_condt_variables.append(v)
						else:
							'''
							Gildo: tolgo isBool
							if (self.Parser.varType['',v]=="_Bool"):
								self.isBool.append(v)
							'''
							variables.append(v)

							
							
							
		if variables.__len__()==0:
			variables.append("at_least_one_global")
		'''
		if self.verifier_atomic:
			variables.append("__atomic")
		'''
		
			
		if self.verifier_atomic:
			self.LOCK_SIZE = (self.NumLocks * 2) + 1
		else:
			self.NumLocks=0
		if self.lockVariable:
			self.vLOCK_SIZE = (self.NumvLocks * 2) + 1
		else:
			self.NumvLocks=0
		NumVars=variables.__len__()
		if (self.wmm):
			self.MEM_SIZE_VARS = self._nwrites + 1
		else:
			self.MEM_SIZE_VARS = self._nwrites
		self.MEM_SIZE=1 + (self.NumLocks*2) + (self._nwrites * NumVars)
		MEM_SIZE=self.MEM_SIZE
		NumThreads=self.__threadbound
		self.ticket_index = MEM_SIZE
		NUM=0

		'''
		self.MEM_SIZE_VARS = str(math.ceil (self.MEM_SIZE / (variables.__len__() +1))).replace(".0","")
		NumVars=variables.__len__()
		self.MEM_SIZE=self._nwrites
		MEM_SIZE=self.MEM_SIZE
		NumThreads=self.__threadbound
		NUM=0
		'''
		
		
		tmpTerminated="{"
		for i in range(0, NumThreads):
			tmpTerminated+="0"
			if i<(NumThreads-1):
				tmpTerminated+=","
		tmpTerminated+="}"


		for item in variables:
			isArr=0
			'''
			for i in range(0, 10): 
				if (item.find("__%s"%i)>0):
					isArr=1
			'''
			for i in range(0, 10): 
				if (item.find("__0")>0):
					isArr=1
			if (isArr==1):
				#print "array: "+item
				self.isScalar.append(item)
				self.isArray.append(item)
				headerBlock+="//item: %s\n"%(item)
			else:
				#print "scalar: "+item
				self.isScalar.append(item)
				
					
		if (self.wmm==1):
			f = open('my-include/header_all_wmm.c')
		else:
			f = open('my-include/header_all.c')			
		lines = f.readlines()
		f.close()

		for line in lines:
			headerBlock+=line



			
		if (self.wmm == 0):
			#headerBlock = headerBlock.replace('<insert-MEM_SIZE-here>', str(MEM_SIZE))
			headerBlock = headerBlock.replace('<insert-LOCK_SIZE-here>', str(self.LOCK_SIZE))
			headerBlock = headerBlock.replace('<insert-vLOCK_SIZE-here>', str(self.vLOCK_SIZE))
		headerBlock = headerBlock.replace('<insert-NumThreads-here>', str(NumThreads))
							

		i=0
		s1 = ""
		##s2 = "//for each scalar variable..."
		for item in self.isScalar:			
			s1 += "\n#define %s %s"% (item, i)
			i=i+1

		##s1 = s2 + "\n" +s1
		#s1 += "\nfine scalar"
		#i=0
		#s1 = ""
		

		str_tmp=""
		'''
		for item in self.isArray:
			i1=item.find("___")
			i2=item.find("__0")
			min=self._min4(i1, i2, -1, -1)
			tmp_varname=item[:min]
			if min>=0 and min<500 and str_tmp!=tmp_varname:
				str_tmp=tmp_varname
				if (not self.__isScalar('',tmp_varname)):
					s1 += "\n#define1 %s %s"% (tmp_varname, i)	
				i=i+1				
			
			s1 += "\n#define %s %s"% (item, i)
			i=i+1
		'''
		s1 += "\n\n//for each variable we represent a MU composed by"
		for item in self.isScalar:			
			s1 += "\n//for variable %s"%(item)
			s1 += "\n#define %s_SIZE <%s-NWRITES>"% (item, item)

		
		
		
		

			
			
		#if self.verifier_atomic:
		#	s1 += "\n#define codeVar_atomic %s"% (i)

		if (self.isScalar.__len__()>0):
			headerBlock = headerBlock.replace('<insert-NumIntVar-here>', str(self.isScalar.__len__()))
		else:
			headerBlock = headerBlock.replace('<insert-NumIntVar-here>', 'NumVars')


		headerBlock = headerBlock.replace('<insert-bit-here>', str(self.bitvector))
		headerBlock = headerBlock.replace('<insert-define-global-variables-here>', s1)
		headerBlock = headerBlock.replace('<insert-NumVars-here>', str(NumVars))
		if (self.wmm == 0):
			headerBlock = headerBlock.replace('<insert-MEM_SIZE_VARS-here>', str(self.MEM_SIZE_VARS))
		headerBlock = headerBlock.replace('<insert-Terminated-here>', tmpTerminated)

		s1=""
		'''
		if self.verifier_atomic:
			s1  = "_Bool cannot_next_atomic_write[MaxNumThreads];\n"
			s1 += "_Bool visible[MEM_SIZE];"
		'''
		'''
		s1  = "_Bool cannot_next_atomic_write[MaxNumThreads];\n"
		s1 += "_Bool visible[MEM_SIZE];"
		'''
		if self.verifier_atomic:
			s1  += "\n__CS_typeM __ticket_atomic  [LOCK_SIZE+1];"
			s1  += "\n__CS_typeT __thread_id_atomic  [LOCK_SIZE];"
			s1  += "\n__CS_typeM __thw_atomic[MaxNumThreads][LOCK_SIZE];"
			s1  += "\n__CS_typeM __last_used_pos_of_atomic; "
			s1  += "\n__CS_typeM __memory_notvalid_of_atomic;"
	
		headerBlock = headerBlock.replace('<insert-atomic-declaration-here>', s1)

		s1=""
		if self.lockVariable:
			s1  += "\n__CS_typeM __ticket_lockV  [vLOCK_SIZE+1];"
			s1  += "\n__CS_typeT __thread_id_lockV  [vLOCK_SIZE];"
			s1  += "\n__CS_typeM __thw_lockV[MaxNumThreads][vLOCK_SIZE];"
			s1  += "\n__CS_typeM __last_used_pos_of_lockV; "
			s1  += "\n__CS_typeM __memory_notvalid_of_lockV;"
	
		headerBlock = headerBlock.replace('<insert-lockVariable-declaration-here>', s1)

		s1=""
		if self.lockVariable:
			f = open('my-include/locVars.c')			
			lines = f.readlines()
			f.close()
	
			for line in lines:
				s1+=line
	
		headerBlock = headerBlock.replace('<insert-locVars-here>', s1)

		
		s1 = ""
		if 'pthread_cond_wait' in self.string:
			s1 += "\n//pthread_cond_t"
			i=1
			for item in pthread_condt_variables:
				s1 += "\n#define %s %s"% (item, i)
				i=i+1
			s1 += "\n"
			s1 += "\n"

		headerBlock = headerBlock.replace('<insert-pthread_cond_wait-here>', s1)
		
		s1 = ""

		if self.verifier_atomic:
			f = open('my-include/atomic.c')
			lines = f.readlines()
			f.close()
			s1=""
			for line in lines:
				s1+=line

			if self.verifier_atomic:
				if (self.wmm==1):
					f = open('my-include/take_lock_atomic_wmm.c')
				else:
					f = open('my-include/take_lock_atomic.c')				
				lines = f.readlines()
				f.close()
				for line in lines:
					s1+=line

					
			'''
			Gildo: tolgo isBool
			if self.isBool.__len__()>0:
				f = open('my-include/atomicBool.c')
				lines = f.readlines()
				f.close()
				for line in lines:
					s1+=line
			'''
			
		headerBlock = headerBlock.replace('<insert-atomic-function-here>', s1)
		s1=""
		if self.verifier_atomic:
			#s1="intV atomicLast = Read_var_atomic();"
			#s1+="__CPROVER_assume((atomicLast==MaxNumThreads) || (atomicLast==thread_index) );"
			s1+="&& ( !(ticket_jump > ticket_pos) || (__visible[codeVar][jump]) )"
		headerBlock = headerBlock.replace('<insert-atomic-constrain-here>', s1)
			
		


		arrDecl = ""
		atomicArrDecl = ""
		if (self.isArray.__len__()>0):
			f = open('my-include/array.c')
			lines = f.readlines()
			f.close()
			for line in lines:
				arrDecl+=line
			if self.verifier_atomic:
				f = open('my-include/atomicArray.c')
				lines = f.readlines()
				f.close()
				for line in lines:
					atomicArrDecl+=line
		
		headerBlock = headerBlock.replace('<insert-array-declaration-here>', arrDecl)
		headerBlock = headerBlock.replace('<insert-atomic-array-here>', atomicArrDecl)

		
		
		
		#############		
		#headerBlock = headerBlock.replace('<insert-assume-atomic-here>', '')
		if self.verifier_atomic:
			headerBlock = headerBlock.replace('<insert-assume-atomic-here>', '__CPROVER_assume(visible[thread_pos]);')
		else:
			headerBlock = headerBlock.replace('<insert-assume-atomic-here>', '')
			
		############

		return headerBlock
		
	def __build_check_block(self, ROUNDS):
		self.check_block += "\n\nvoid guessMU(void){  "
		self.check_block +="\n "
		self.check_block +="\n "
		self.check_block +="\n//INITIALIZATION OF SHARED VARIABLES "
		self.check_block += self.initializationNew
		self.check_block +="\n//END INITIALIZATION OF SHARED VARIABLES\n"

		self.check_block +="\n__CS_typeM tmp_ticket_pos_terminated[MaxNumThreads];"
		for t in range(0,self._maxthreads):
			self.check_block +="\n	ticket_pos_terminated[%s] = tmp_ticket_pos_terminated[%s];" % (t,t)
			self.check_block +="\n	__CPROVER_assume((tmp_ticket_pos_terminated[%s] >= 0 ) && (tmp_ticket_pos_terminated[%s] < MEM_SIZE + NumVars ));" % (t,t)
		
		
		
		if (self.isArray.__len__()>0):
			self.check_block +="\nint values_tmp[MEM_SIZE]; "

		self.check_block +="\n__CS_typeM ticket_tmp[MEM_SIZE]; "
		self.check_block +="\n_Bool visible_tmp[MEM_SIZE]; "
		self.check_block +="\nintV __value_tmp[MEM_SIZE]; "
		self.check_block +="\n__CS_typeM  nondet_memory[NumVars]; "
		self.check_block +="\n__CS_typeM thread_tmp[MEM_SIZE]; "

		ticket_index=0
		self.check_block +="\n	//for each scalar variable we guess the MU"
		self.check_block +="\nint scalarVariables  = %s; "%(self.isScalar.__len__())
		if (self.isScalar.__len__()>0):
			tmp_index=0
			num_valid_write = " int num_valid_write = 0"

			if self.verifier_atomic:
				self.check_block +="\n	__CS_type  nondet___atomic;"
				self.check_block +="\n	__CPROVER_assume( (nondet___atomic>0) && (nondet___atomic <= LOCK_SIZE) );"
				self.check_block +="\n	__memory_notvalid_of_atomic = nondet___atomic;"
				self.check_block +="\n	__ticket_atomic[0] = 0;			"
			
			if self.lockVariable:
				self.check_block +="\n	__CS_type  nondet___lockV;"
				self.check_block +="\n	__CPROVER_assume( (nondet___lockV>0) && (nondet___lockV <= vLOCK_SIZE) );"
				self.check_block +="\n	__memory_notvalid_of_lockV = nondet___lockV;"
				self.check_block +="\n	__ticket_lockV[0] = 0;			"
			
			
			####self.check_block +=num_valid_write
			iVariable=0
			for item in self.isScalar:			
				self.check_block +="\n"
				self.check_block +="\n	//for variable %s: size: %s" % (item,int(self.arrayWriteVars[item]))
				self.check_block +="\n	__ticket[%s][0] = 0;"% (item)
				
				
				
				self.check_block +="\n	__memory_notvalid_of[%s] = nondet_memory[%s];"% (item, iVariable)
				iVariable=iVariable+1
				self.check_block +="\n	__CPROVER_assume( (__memory_notvalid_of[%s]>0) && (__memory_notvalid_of[%s] <= %s_SIZE) );"%(item,item,item)
				tmp_index=tmp_index+1
				self.check_block +="\n"
				
				for i in range(1, int(self.arrayWriteVars[item])+1):
					self.check_block +="\n	__thread_id[%s][%s] = thread_tmp[%s];" % (item,i, ticket_index)
					self.check_block +="\n	__visible[%s][%s] = visible_tmp[%s];" % (item,i, ticket_index)
					self.check_block +="\n	__CPROVER_assume((__thread_id[%s][%s] >= 0) && (__thread_id[%s][%s] < GuessedNumThreads));" %(item,i, item,i)
					self.check_block +="\n	__value[%s][%s] = __value_tmp[%s];" %(item,i, ticket_index)
					self.check_block +="\n	__ticket[%s][%s]=ticket_tmp[%s]; "%(item, i, ticket_index)
					self.check_block +="\n	__CPROVER_assume( (__ticket[%s][%s] < MEM_SIZE)"%(item, i)
					self.check_block +="\n	               && (__ticket[%s][%s]>__ticket[%s][%s])"%(item, i, item, i-1)
					self.check_block +="\n	               && (!__used_ticket[__ticket[%s][%s]]) );"%(item, i)
					self.check_block +="\n	__used_ticket[__ticket[%s][%s]] = 1;"%(item, i)
					self.check_block +="\n"
					ticket_index = ticket_index + 1


				self.check_block +="\n	//__ticket[%s][MEM_SIZE_VARS]=ticket_tmp[%s]; "%(item, ticket_index)
				self.check_block +="\n	__ticket[%s][%s_SIZE]=MEM_SIZE; "%(item,item)
				self.check_block +="\n//	__ticket[%s][0] = 0;"% (item)
				tmp_index=tmp_index+1
				self.check_block +="\n"
				
			if self.verifier_atomic:
				self.check_block +="\n	//for atomic locks"  
				self.check_block +="\n	__ticket_atomic[0] = 0;"
				for i in range(1, int(self.LOCK_SIZE)):
					if (i%2 == 0):
						self.check_block +="\n	__thread_id_atomic[%s] = __thread_id_atomic[%s];" % (i, i-1)
					else:						
						self.check_block +="\n	__thread_id_atomic[%s] = thread_tmp[%s];" % (i, ticket_index)
						self.check_block +="\n	__CPROVER_assume((__thread_id_atomic[%s] >= 0) && (__thread_id_atomic[%s] < GuessedNumThreads));" %(i, i)
					self.check_block +="\n	__ticket_atomic[%s]=ticket_tmp[%s]; "%(i, ticket_index)
					self.check_block +="\n	__CPROVER_assume( (__ticket_atomic[%s] < MEM_SIZE)"%(i)
					self.check_block +="\n	               && (__ticket_atomic[%s]>__ticket_atomic[%s])"%(i, i-1)
					self.check_block +="\n	               && (!__used_ticket[__ticket_atomic[%s]]) );"%(i)
					self.check_block +="\n	__used_ticket[__ticket_atomic[%s]] = 1;"%(i)
					self.check_block +="\n"
					ticket_index = ticket_index + 1


				#self.check_block +="\n	int ticket_index=%s; "%(ticket_index)
				self.ticket_index = ticket_index+1
				self.check_block +="\n	__ticket_atomic[LOCK_SIZE]=MEM_SIZE; "

			if self.lockVariable:
				self.check_block +="\n	//for variable locks"  
				self.check_block +="\n	__ticket_lockV[0] = 0;"
				for i in range(1, int(self.vLOCK_SIZE)):
					if (i%2 == 0):
						self.check_block +="\n	__thread_id_lockV[%s] = __thread_id_lockV[%s];" % (i, i-1)
					else:						
						self.check_block +="\n	__thread_id_lockV[%s] = thread_tmp[%s];" % (i, ticket_index)
						self.check_block +="\n	__CPROVER_assume((__thread_id_lockV[%s] >= 0) && (__thread_id_lockV[%s] < GuessedNumThreads));" %(i, i)
					self.check_block +="\n	__ticket_lockV[%s]=ticket_tmp[%s]; "%(i, ticket_index)
					self.check_block +="\n	__CPROVER_assume( (__ticket_lockV[%s] < MEM_SIZE)"%(i)
					self.check_block +="\n	               && (__ticket_lockV[%s]>__ticket_lockV[%s])"%(i, i-1)
					self.check_block +="\n	               && (!__used_ticket[__ticket_lockV[%s]]) );"%(i)
					self.check_block +="\n	__used_ticket[__ticket_lockV[%s]] = 1;"%(i)
					self.check_block +="\n"
					ticket_index = ticket_index + 1


				self.ticket_index = ticket_index+1
				self.check_block +="\n	__ticket_lockV[vLOCK_SIZE]=MEM_SIZE; "

			self.check_block +="\n	int ticket_index=%s; "%(ticket_index)
				
				
		else:
			self.check_block +="\nintV __memory_tmp[NumVars][MEM_SIZE]; "
		
		'''
		Gildo: tolgo isBool
		if (self.isBool.__len__()>0):
			self.check_block +="\n_Bool __memory_bool_tmp[%s][MEM_SIZE]; "%(self.isScalar.__len__());
		'''
		'''
		self.check_block +="\n"
		if self.verifier_atomic:
			self.check_block +="\n_Bool visible_tmp[MEM_SIZE];"
			self.check_block +="\nvisible[0] = 1;"
		'''
		
		MEM_SIZE=self.MEM_SIZE
		variables=self.variables
		#gen_i=1
		Nvars=variables.__len__();
		if (self.verifier_atomic):
			Nvars=Nvars+1
		
		



		'''
		GILDO: TODO per array
		self.check_block +="\n"
		self.check_block +="\n"
		if (self.isArray.__len__()>0):
			for i in reversed(xrange(1,MEM_SIZE)):
				#self.check_block +="\n__CPROVER_assume(next[ %s ] == ((tmp_variables[ var_name[%s] ]==0) ? MEM_SIZE : tmp_variables[ var_name[%s] ]));"%(i, i,i)
				self.check_block +="\nnext_write[ %s ] = (((first_write[ var_name[%s] ]==0) || (%s >= memory_notvalid) ) ? MEM_SIZE : first_write[ var_name[%s] ]);"%(i, i, i, i)
				#self.check_block +="\nnext[ %s ] = first_write[ var_name[%s] ];"%(i, i)
				#self.check_block +="\ntmp_variables[ var_name[%s] ] = %s;"%(i, i)
				self.check_block +="\nfirst_write[ var_name[%s] ] = %s;"%(i, i)

				#self.check_block +="\nnext_thread[ %s ] = first_thread[ thread[%s] ];"%(i, i)
				#self.check_block +="\nfirst_thread[ thread[%s] ] = %s;"%(i, i)
			self.check_block +="\nvar_name[ 0 ] = NumVars;"
			self.check_block +="\n"
			self.check_block +="\n"			
		self.check_block +="\n"
		self.check_block +="\n"
		'''

		self.check_block +="\n	/*for each scalar variable, for each thread:"
		self.check_block +="\n	at each position we calculate"
		self.check_block +="\n	what is the next write of that thread of that varable."
		self.check_block +="\n	*/"
		for item in self.isScalar:			
			self.check_block +="\n	//for variable %s" %(item)
			for t in range(0,self._maxthreads):
				self.check_block +="\n     __thw[%s][%s][%s]=MEM_SIZE;"%(item, t, int(self.arrayWriteVars[item]))
			for i in range(int(self.arrayWriteVars[item]+1)-1, 0,-1):
				for t in range(0,self._maxthreads):
					self.check_block +="\n    __thw[%s][%s][%s] =    (__thread_id[%s][%s] == %s) ? %s : __thw[%s][%s][%s] ; "%(item, t, i-1, item, i, t, i, item, t, i)
				self.check_block +="\n "
				
				
				
		if self.verifier_atomic:
			self.check_block +="\n	//for atomic locks"
			for t in range(0,self._maxthreads):
				self.check_block +="\n     __thw_atomic[%s][%s]=%s;"%(t, int(self.LOCK_SIZE)-1,self.LOCK_SIZE)
			for i in range(int(self.LOCK_SIZE)-1, 0,-1):
				for t in range(0,self._maxthreads):
					self.check_block +="\n    __thw_atomic[%s][%s] =    (__thread_id_atomic[%s] == %s) ? %s : __thw_atomic[%s][%s] ; "%(t, i-1, i, t, i, t, i)
				self.check_block +="\n "
				
		if self.lockVariable:
			self.check_block +="\n	//for variable locks"
			for t in range(0,self._maxthreads):
				self.check_block +="\n     __thw_lockV[%s][%s]=%s;"%(t, int(self.vLOCK_SIZE)-1,self.vLOCK_SIZE)
			for i in range(int(self.vLOCK_SIZE)-1, 0,-1):
				for t in range(0,self._maxthreads):
					self.check_block +="\n    __thw_lockV[%s][%s] =    (__thread_id_lockV[%s] == %s) ? %s : __thw_lockV[%s][%s] ; "%(t, i-1, i, t, i, t, i)
				self.check_block +="\n "
				
				
				
		self.check_block +="\n"
		self.check_block +="\n"
		self.check_block +="\n}" 

		return self.check_block


		
	def visit_Label(self, n):
		#if (n.name == 'ERROR'):
		
		#return n.name + ':\n' + self._generate_stmt(n.stmt)
		if (n.name == self.error_label) or (n.name == "ERROR"):

			tmp_errorBlock = errorBlock2
			if self.parsingAtomic == True:
				tmp_errorBlock = tmp_errorBlock.replace('<return_statement>', 'Release_lock__atomic_function();\t<return_statement>')			
			if self.parsingVoidFunction == True:
				return tmp_errorBlock.replace('<return_statement>', 'return') + self._generate_stmt(n.stmt)
			else:
				return tmp_errorBlock.replace('<return_statement>', 'return 0') + self._generate_stmt(n.stmt)
			
			#if self.parsingVoidFunction == True:
			#	return errorBlock.replace('<return_statement>', 'return') + self._generate_stmt(n.stmt)
			#else:
			#	return errorBlock.replace('<return_statement>', 'return 0') + self._generate_stmt(n.stmt)
			
		else:
			return n.name + ':\n' + self._generate_stmt(n.stmt)		
		


	def visit_ID(self, n):
		if self.setParams:
			return n.name
		
		nameVar=n.name
		if self.equalToGlobalName.has_key(self.currentFunct+"_"+n.name)==True:
			nameVar=self.equalToGlobalName[self.currentFunct+"_"+n.name]
			if self.IsFakeFunct==0:
				return nameVar
		
		if self.global_parameters2.has_key(self.currentFunct+"_"+n.name)==True:
			nameVar=self.global_parameters2[self.currentFunct+"_"+n.name]

			
		
		if self.__isGlobaVariable(n.name) and self.Parser.varType['',n.name].startswith('pthread_t'):
			return n.name
		
		
		

		if n.name in self.Parser.varNames[''] and self.visitStarted==0: 
			#tmp=n.name
			tmp=nameVar
			f=''

			if self.isInFuncCall:
				self.suffixCall+="___"+n.name
				return "<param-global-null>"
				


			if self.Parser.varArity[f, n.name]>0:
				tmp+="__0"
				if self.isInFuncCall and self.__isArray('', n.name):
					self.suffixCall=n.name
					return "0"
			'''
			Gildo: tolgo isBool
			if (tmp in self.isBool):
				return "Read_Bool("+tmp+")"				
			return "Read("+tmp+")"
			'''
			return "Read("+tmp+")"
		else: 
			return nameVar

	def __explodeVariable(self, v):
		blocks = []

		# 1: scalar variables
		#
		if self.Parser.varArity['',v] == 0  and not self.Parser.varType['',v].startswith('struct ') and not self.Parser.varType['',v].startswith('union '):
		## if self.Parser.varArity['',v] == 0  and not self.__isStruct('',v) and not self.Parser.varType['',v].startswith('union '):
			# print "> %s,%s  scalar, arity = %s" % ('',v,self.Parser.varArity['',v])
			blocks.extend([v])

		# 2: arrays
		#
		#elif self.Parser.varArity[f,v] > 0  and  not self.Parser.varType[f,v].startswith('struct ') :
		elif self.Parser.varArity['',v] > 0 and not self.Parser.varMallocd['',v] :
			# print "> %s,%s  array, arity = %s" % ('',v,self.Parser.varArity['',v])
			blocks.extend(self.__explodeArray(v, '', v))

		# 3: structs / unions
		#
		elif not self.Parser.varMallocd['',v]:
			# print "> %s,%s  struct, arity = %s" % ('',v,self.Parser.varArity['',v])
			blocks.extend(self.__explodeStruct(v, self.Parser.varType['', v][7:]))

		return blocks


	# Returns all possible tuples of indexes for a variable  v  from function  f.
	#
	# For example, given v[3][2], that is: (0,0), (0,1), (1,0), (1,1), (2,0), (2,1)
	#
	def __genTuples(self, f, v):
		lst = self.Parser.varSize[f,v]
		return reduce(lambda prev, b: [xs + [i] for xs in prev for i in range(0,b)], lst, [[]])


	# Returns all possible fields in a struct  s.
	#
	def __genFields(self, s):
		return self.Parser.varNames[s]


	# Checks whether variable  v  from function  f  is scalar. 
	#
	def __isScalar(self, f, v):
		if self.Parser.varArity[f, v] == 0  and not self.Parser.varType[f, v].startswith('struct ') and not self.Parser.varType[f, v].startswith('union '):
			return 1
		else:
			return 0


	# Return the type of the variable without spaces and modifiers (useful for symbol-table lookups).
	# For example:    'const char *'  ---->  'char'
	#
	def __getBasicType(self, f, v):
		# See what is the type the variable is referring to.
		# First we need to get rid of any type modifiers (e.g. 'const'),
		# then of pointer symbols (*'s) and spaces (' ') to get the basic type
		# for lookup in the list of typedefs.
		#
		basicType = self.Parser.varType[f, v]

		if basicType.startswith('const '): basicType = basicType[6:]

		if ' ' in basicType: basicType = basicType[:basicType.find(' ')]
		if '*' in basicType: basicType = basicType[:basicType.find('*')]

		return basicType		


	# Checks whether variable  v  from function  f  is of a type which refers to a previous typedef.
	# This is used, for example, to see if a given variable is a struct,
	# as the  struct  keyword might be hidden by a typedef (as they usually are!)  
	#
	def __isTypedef(self, f, v):
		if __getBasicType(f,v) in self.typedefs: return 1
		else: return 0


	# Checks whether variable  v  from function  f  is a struct.
	#
	def __isStruct(self, f, v):
		result = 0
		if (f,v) not in self.Parser.varType:
			return 0
		
		if  self.Parser.varType[f, v].startswith('struct '):
			result = 1

		return result


	# Returns the name of the struct a variable refers to, expanding typedefs if necessary.
	#
	def __getStructName(self, s, field):
		name = ''

		if  self.Parser.varType[f, v].startswith('struct '):
			name = self.Parser.varType[s, field][7:]
		return name


	# Checks whether variable  v  from function  f  is an array.
	#
	def __isArray(self, f, v):
		if (f,v) not in self.Parser.varArity:
			return 0
		if self.Parser.varArity[f,v] > 0: return 1
		else: return 0


	# Checks whether variable  v  from function  f  is an array.
	#
	def __isPointer(self, f, v):
		if (f,v) not in self.Parser.varType:
			return 0
		if self.Parser.varType[f,v].endswith('*'): return 1
		else: return 0


	# Recursively explode an array  f  from function  v  (see also __explodeStruct).
	#
	def __explodeArray(self, prefix, f, v):
		
		block = []

		# Arrays are exploded using any possible combination of indexes.
		for tuple in self.__genTuples(f,v):
			indexes = str(tuple).replace(', ', '][')

			if self.__isStruct(f, v):
				structName = self.__getStructName(f, v)
				block.extend(self.__explodeStruct(prefix+indexes, structName))
			else:
				block.extend([str(prefix+indexes)])

		return block


	# Recursively explode a struct  s  (see also __explodeArray).
	#
	def __explodeStruct(self, prefix, s):
		
		block = []

		# Struct are exploded using any possible field.
		for field in self.__genFields(s):
			if self.__isArray(s, field):
				block.extend(self.__explodeArray(prefix+'.'+field, s, field))
			elif self.__isStruct(s, field):
				structName = self.__getStructName(s, field)
				block.extend(self.__explodeStruct(prefix+'.'+field, structName))
			else:
				block.extend([prefix+'.'+field])

		return block


	def __isGlobaVariable(self, name):
		if name in self.Parser.varNames['']:  return 1 # only consider global variables
		else: return 0

	def visit_Struct(self, n):
		# Assigns a name to anonymous structs
		if n.name == None:
			n.name = '__CS_anonstruct_' + str(self.currentAnonStructsCount)
			self.currentAnonStructsCount += 1

		# This method is called more than once on the same struct,
		# the following is done only on the first time.
		#
		if n.name not in self.structName:
			self.currentStruct = n.name
			self.structName.append(n.name)
			self.Parser.varNames[self.currentStruct] = []

		oldParsingStruct = self.parsingStruct
		self.parsingStruct = True
		s = self._generate_struct_union(n, 'struct')
		self.parsingStruct = oldParsingStruct

		# Parsing  typedef struct
		'''
		if self.parsingTypedef: 
			print "    PARSING TYPEDEF STRUCT!!!!!!"
			print "       s: " + s 
			print "    name: " + str(n.name) + '\n\n\n'
		'''

		return s

			


	def visit_FuncDef(self, n):


		self.functionBlock1=""



		self.localPointer=[]

		self.currentFunct = n.decl.name


		#self.equalToGlobalName={}
		for v in self.Parser.varNames[self.currentFunct]:
			if self.__isGlobaVariable(v):
				self.equalToGlobalName[self.currentFunct+"_"+v]="__"+v



		self.funcName.append(n.decl.name)

		# Note: the function definition is in two parts:
		#       one is 'decl' and the other is 'body'
		decl = self.visit(n.decl)

		if n.decl.name in self.renameFunct1:
			decl = decl.replace (n.decl.name, "__"+n.decl.name+"1")
		
		
		
		
		if n.decl.name == 'main': self.parsingMain = True
		if n.decl.name.startswith('__VERIFIER_atomic') or n.decl.name.startswith('__CSEQ_atomic_'): self.parsingAtomic = True
		if (decl.startswith("void") or decl.startswith("inline void") ) and not decl.startswith("void *"): self.parsingVoidFunction = True
		else: self.parsingVoidFunction = False


		if self.firstFunctionDefinitionDone == False:
			if len(self.Parser.varNames['']) > self.Parser.extraGlovalVarCount:   
				self.unionDeclaration = self.unionDeclaration + '};\n\nunion __CS__u __CS_u;\n\n'

			self.firstFunctionDefinitionDone = True

		body = ''

		# The body is a Compound node
		if n.decl.name.startswith('__VERIFIER_atomic') or n.decl.name.startswith('__CSEQ_atomic_'): # no context switches in atomic functions
			'''
			jump_atomic  = ""
			jump_atomic += self._make_indent(1) + 'Jump_atomic();\n'
			jump_atomic += self._make_indent(1) + 'if (__CS_ret) return;\n'
			body += self.visit(n.body)
			body  = body.replace("Read(","Read_atomic(").replace("Write(","Write_atomic(") 
			i = body.find("{")+1
			body = body[:i]+"\n"+jump_atomic+body[i:]
			'''
			####################
			jump_atomic  = ""
			jump_atomic += self._make_indent(1) + 'Take_lock__atomic_function();\n'
			jump_atomic += self._make_indent(1) + 'if (__CS_ret) return;\n'
			body += self.visit(n.body)
			body  = body.replace("Read(","Read_atomic(").replace("Write(","Write_atomic(") 
			body  = body.replace("Read_Bool(","Read_Bool_atomic(").replace("Write_Bool(","Write_Bool_atomic(")
			body  = body.replace("Read_from_array(","Read_atomic_from_array(").replace("Write_from_array(","Write_atomic_from_array(")
			
			body  = body.replace("return","Release_lock__atomic_function(); return")
			
			#body  = body.replace("Read(","Read_atomic(")
			i = body.find("{")+1
			body = body[:i]+"\n"+jump_atomic+body[i:body.rfind('\n}')]+"\nRelease_lock__atomic_function();\n}"
			####################
			
			#body  = body.replace("{","{\n"+jump_atomic)
		elif self.parsingStruct:
			body += self.visit(n.body)
		else:
			# Add csBlocks as the last statement in each function.
			# This may be unrechable code if the last statement is a return, 
			# but that is fine.
			#
			if not self.parsingMain:
				body += self.visit(n.body)
				body = body[:body.rfind('\n}')]   # Eliminate the last closing braket for the function body compound.
				### body += '\n' + self._make_indent(1) + 'ddd---->' + csBlock + '}\n' 
				body += '\n' + self._make_indent(1) + '}\n' 
			else:
				body += self.visit(n.body)

		# The placeholder <return_statement> is changed to "return" or "return 0",
		# depending on whether the function is void.
		### functionBlock = decl + '\n{\n' + body + '}\n\n'
		functionBlock = decl + '\n' + body + '\n'

		#if decl.startswith("void") and not decl.startswith("void *"): # void function requests "return;"
		if self.parsingVoidFunction == True:
			functionBlock = functionBlock.replace("<return_statement>", "return")
		else: # non void functions request "return 0;"
			functionBlock = functionBlock.replace("<return_statement>", "return 0")

		if n.decl.name == 'main': self.parsingMain = False

		if n.decl.name.startswith('__VERIFIER_atomic') or n.decl.name.startswith('__CSEQ_atomic_'): self.parsingAtomic = False

		if n.decl.name == 'main':
			# Prepare the sequentialised main() function.
			#
			oldMainBlock = functionBlock[functionBlock.find('{')+2:]
			oldMainBlock = oldMainBlock[:oldMainBlock.rfind('}')]
			oldMainBlock = oldMainBlock.replace('main(', 'main_thread(', 1)

			#print "prima:\n\n"+functionBlock
			
			
			functionBlock = mainSimulationBlock


			''' 5.  Eventually, put all parts together.
			'''
			functionBlock = mainSimulationBlock
			
			
			
			str_tmp=""
			'''
			for item in self.variables:
				if item not in self.initializedGlobalVariables:
					if (item!="__atomic"):
						self.initialization += "\n__memory["+item+"][0] = 0;"
			'''
			

			functionBlock = functionBlock.replace('\t<insert-mainthread-here>\n', oldMainBlock)
			functionBlock = functionBlock.replace('\t<insert-main-parameters-decl-here>\n', self.mainParametersDecl);
			functionBlock = functionBlock.replace('\t<insert-initialization-here>\n', self.initialization);

		
		if self.parsingVoidFunction:
			functionBlock=functionBlock.replace("return 0;","return;")
		else:
			functionBlock=functionBlock.replace(" return;"," return 0;")
			functionBlock=functionBlock.replace("\treturn;","\treturn 0;")
			functionBlock=functionBlock.replace("\nreturn;","\nreturn 0;")
		functionBlock=functionBlock.replace("insert-end-thread-create-here>",self.__checkEndThread())
		return "\n"+self.functionBlock1+"\n"+functionBlock

	def __checkEndThread(self):
		end_thread_create = ""
		for item in self.isScalar:			
			#end_thread_create += "\n__CPROVER_assume((__last_used_pos_of[%s] < __memory_notvalid_of[%s]) && (__thw[%s][thread_index][__last_used_pos_of[%s]] >=__memory_notvalid_of[%s]) );"%(item,item,item,item,item)
			end_thread_create += "\n__CPROVER_assume(__thw[%s][thread_index][__last_used_pos_of[%s]] >=__memory_notvalid_of[%s]) ;"%(item,item,item)
		if (self.verifier_atomic):
			end_thread_create += "\n__CPROVER_assume(__thw_atomic[thread_index][__last_used_pos_of_atomic] >=__memory_notvalid_of_atomic) ;"
		if self.lockVariable:
			end_thread_create += "\n__CPROVER_assume(__thw_lockV[thread_index][__last_used_pos_of_lockV] >=__memory_notvalid_of_lockV) ;"
		return end_thread_create

	def __checkStartThread(self):
		start_thread_create = ""
		for item in self.isScalar:			
			start_thread_create += "\n__CPROVER_assume(__thw[%s][thread_index][0] > __last_used_pos_of[%s]);"%(item,item)
		if (self.verifier_atomic):
			start_thread_create += "\n__CPROVER_assume(__thw_atomic[thread_index][0] > __last_used_pos_of_atomic);"
		if self.lockVariable:
			start_thread_create += "\n__CPROVER_assume(__thw_lockV[thread_index][0] > __last_used_pos_of_lockV);"
		return start_thread_create

	def __MyLastUsedPos(self):
		tmpStr = ""
		tmpStr += "\n   __CS_typeM my__last_used_pos_of[NumVars];"
		if self.verifier_atomic:
			tmpStr += "\n   __CS_typeM my__last_used_pos_of_atomic = __last_used_pos_of_atomic;;"
		if self.lockVariable:
			tmpStr += "\n   __CS_typeM my__last_used_pos_of_lockV = __last_used_pos_of_lockV;"
		for item in self.isScalar:			
			tmpStr += "\n   my__last_used_pos_of[%s] = __last_used_pos_of[%s];" % (item, item)
		#if (self.verifier_atomic):
		#	tmpStr += "\n   my__last_used_pos_of_atomic = __last_used_pos_of_atomic;"
		return tmpStr

	def __FromMyLastUsedPos(self):
		tmpStr = ""
		for item in self.isScalar:			
			tmpStr += "\n   __last_used_pos_of[%s] = my__last_used_pos_of[%s];" % (item, item)
		if (self.verifier_atomic):
			tmpStr += "\n   __last_used_pos_of_atomic = my__last_used_pos_of_atomic;"
		if (self.lockVariable):
			tmpStr += "\n   __last_used_pos_of_lockV = my__last_used_pos_of_lockV;"
		return tmpStr			

	def visit_FuncCall(self, n):
		fref = self._parenthesize_unless_simple(n.name)

		# pthread_ primitives currenly not-handled will cause CSeq to quit.
		if fref in notHandledPrimitives:  # e.g. 'pthread_cond_wait', ...
			#print "UNKNOWN (code:02)\n"
			print("Conversion error:  use of '%s' is currently not handled." % fref)
			sys.exit(-1)

		if fref == 'fprintf': 
			return ''

		if (fref == self.error_label) or (fref == "__CSEQ_assert"):
			tmp_errorBlock = errorBlock
			#tmp_errorBlock = tmp_errorBlock.replace('<return_statement>', 'Release_lock__atomic_function();\t<return_statement>')			
			
			if self.parsingAtomic == True:
				tmp_errorBlock = tmp_errorBlock.replace('<return_statement>', 'Release_lock__atomic_function();\t<return_statement>')			
			
			if self.parsingVoidFunction == True:
				return tmp_errorBlock.replace('<return_statement>', 'return')# + self._generate_stmt(n.stmt)
			else:
				return tmp_errorBlock.replace('<return_statement>', 'return 0')# + self._generate_stmt(n.stmt)
		if fref == 'sscanf': 
			self.isInFuncCall=1
			self.visitStarted=1
			fref  = "Write("
			fref +=self.visit(n.args).split(',')[2].replace("&","")+", "
			fref +="(int)(*"+self.visit(n.args).split(',')[0]+"))"
			self.isInFuncCall=0
			self.visitStarted=0
			return fref
			
		# Maps the original pthread api calls to wSeq-simulated functions. 
		if fref == 'pthread_mutex_lock' or fref == '__cs_mutex_lock': 
			self.visitStarted=1
			#fref = '__pthread_mutex_lock'+'('+self.visit(n.args).replace("&","") + ');'
			fref = '__pthread_mutex_lock'+'();'
			fref += '\n '+self._make_indent()+'if (__CS_ret) return'
			self.visitStarted=0
			return fref
		if fref == 'pthread_mutex_unlock' or fref == '__cs_mutex_unlock': 
			self.visitStarted=1
			#fref = '__pthread_mutex_unlock'+'('+self.visit(n.args).replace("&","") + ');'
			fref = '__pthread_mutex_unlock'+'();'
			fref += '\n '+self._make_indent()+'if (__CS_ret) return'
			self.visitStarted=0
			return fref
		if fref == 'pthread_mutex_init' or fref == '__cs_mutex_init': 
			self.visitStarted=1
			#fref = '__pthread_mutex_init'+'('+self.visit(n.args).replace("&","") + ');'
			fref = '__pthread_mutex_init'+'();'
			fref += '\n '+self._make_indent()+'if (__CS_ret) return'
			self.visitStarted=0
			return fref
		if fref == 'pthread_mutex_destroy' or fref == '__cs_mutex_destroy' : 
			self.visitStarted=1
			#fref = '__pthread_mutex_destroy'+'('+self.visit(n.args).replace("&","") + ');'
			fref = '__pthread_mutex_destroy'+'();'
			fref += '\n '+self._make_indent()+'if (__CS_ret) return'
			self.visitStarted=0
			return fref
			
		if fref == 'pthread_join' or fref == '__cs_join' : fref = '__pthread_join'
		if fref == 'pthread_create' or fref == '__cs_create': 
			
			self.isInFuncCall=1
			self.visitStarted=1

		
			
			thread_Funct = self.visit(n.args).split(',')[2].replace("&","")[1:]
			nameFunc = "__pthread_create_"+thread_Funct
			if thread_Funct in self.renameFunct1: 
				nameFunc = "__pthread_create___"+thread_Funct+"1"

			
			#fref  = "if (nondet_int() || __CS_ret){__CS_ret=1; return 0;}\n"+nameFunc+"("
			fref  = nameFunc+"("
			fref +=self.visit(n.args).split(',')[0]+", "
			fref +=self.visit(n.args).split(',')[1]+", "
			fref +=self.visit(n.args).split(',')[3]+");"
			
			if self.pthread_create_block.find(nameFunc)<0:
				self.pthread_create_block += "int "+nameFunc

				

				if thread_Funct in self.renameFunct1:
					self.pthread_create_block += self.pthread_create_block_static.replace("<insert-thread-routine-here>","__"+thread_Funct+"1").replace("insert-start-thread-create-here>",self.__checkStartThread()).replace("insert-end-thread-create-here>",self.__checkEndThread())
					self.pthread_create_block = self.pthread_create_block.replace("insert-mylast-used-pos-here>",self.__MyLastUsedPos())
					self.pthread_create_block = self.pthread_create_block.replace("insert-from-mylast-used-pos-here>",self.__FromMyLastUsedPos())
				else: 
					self.pthread_create_block += self.pthread_create_block_static.replace("<insert-thread-routine-here>",thread_Funct).replace("insert-start-thread-create-here>",self.__checkStartThread()).replace("insert-end-thread-create-here>",self.__checkEndThread())
					self.pthread_create_block = self.pthread_create_block.replace("insert-mylast-used-pos-here>",self.__MyLastUsedPos())
					self.pthread_create_block = self.pthread_create_block.replace("insert-from-mylast-used-pos-here>",self.__FromMyLastUsedPos())
			
				
			
			self.isInFuncCall=0
			self.visitStarted=0
			fref=fref.replace("<param-global-null>","0")
			fref=fref.replace("&0","0")
			return fref
			

		if fref == 'pthread_cond_init' or fref == '__cs_cond_init': 
			self.visitStarted=1
			fref = '__pthread_cond_init'
			fref += '('+str(self.visit(n.args)).replace("&","")+');'
			self.visitStarted=0
			return fref;
		if fref == 'pthread_cond_wait' or fref == '__cs_cond_wait': 
			self.visitStarted=1
			fref  = '__pthread_cond_wait'
			fref += '(lock_cond_0+thread_index,'+str(self.visit(n.args)).replace("&","")+');'
			fref += '\n '+self._make_indent()+'if (__CS_ret) return;'
			self.visitStarted=0
			return fref;
		if fref == 'pthread_cond_signal' or fref == '__cs_cond_signal': 
			self.visitStarted=1
			fref = '__pthread_cond_signal'
			fref += '('+str(self.visit(n.args)).replace("&","")+', lock_cond_0);'
			fref += '\n '+self._make_indent()+'if (__CS_ret) return;'
			self.visitStarted=0
			return fref;

		if fref == 'pthread_exit' or fref == '__cs_exit':
			fref  = '//__pthread_exit(NULL);'
			#fref += '\n'+self._make_indent()+'if (__CS_ret) return;'
			#fref += '\n'+self._make_indent()+'__CS_ret=1; '
			#fref += '\n'+self._make_indent()+'terminated[thread_index]=1;'
			#fref += '\n'+self._make_indent()+'return;'
			return fref 

		if fref == 'printf':
			fref = ''
			return fref 

		if fref == 'assume': fref = '__CPROVER_assume'
		if fref == '__ESBMC_assume': fref = '__CPROVER_assume'
		if fref == '__VERIFIER_assume': fref = '__CPROVER_assume'
		if fref == '__CSEQ_assume': fref = '__CPROVER_assume'

		if fref == 'assert': fref = 'assert'
		if fref == '__ESBMC_assert': fref = 'assert'
		if fref == '__CSEQ_assert': fref = 'assert'
		#if fref == '__VERIFIER_assert': fref = 'assert'

		# Mapping of standard verifier function calls in the main()
		if fref == '__VERIFIER_nondet_int': fref = '___XXXXX__nondet_int'
		if fref == '__VERIFIER_assume': fref = '___XXXXX__assume'
		
		if fref == '__ESBMC_atomic_begin' or fref == '__VERIFIER_atomic_begin' or fref == '__CSEQ_atomic__begin' or fref == '__CS_atomic_begin':
			fref = 'Take_lock__atomic_function()'
			#fref = '//cseq: atomic section starts here '
			return fref;
			#fref = '//cseq: atomic section starts here '
			#fref = '\nTake_lock__atomic_function '
			#self.parsingAtomic = True
		
		if fref == '__ESBMC_atomic_end' or fref == '__VERIFIER_atomic_end' or fref == '__CSEQ_atomic_end' or fref == '__CS_atomic_end':
			fref = 'Release_lock__atomic_function()'
			#fref = '//cseq: atomic section stops here '
			return fref;
			#fref = '//cseq: atomic section stops here '
			#fref = '\nRelease_lock__atomic_function '
			#self.parsingAtomic = False 

			
		if fref in self.renameFunct1:
			fref="__"+fref

		if fref=="strcpy":
			tmp_args = self.visit(n.args).split(",")
			tmp_arg1 = tmp_args[0].replace("Read(","").replace(")","")
			tmp_decl_name = "strcpy_"+tmp_arg1
			if tmp_decl_name not in self.funcName:
				tmp_strcpy_block="int "+tmp_decl_name+"(const char *s)\n"
				tmp_strcpy_block+="{\n"
				tmp_strcpy_block+="	int i=0;\n"
				tmp_strcpy_block+="	Jump();\n"
				tmp_strcpy_block+="	while(s && *s++)\n"
				tmp_strcpy_block+="	{\n"
				tmp_strcpy_block+="		if (Read_atomic_from_array("+tmp_arg1+"__0+i) > Read_atomic_from_array("+tmp_arg1+")){__CS_ret=1; return 0;}\n"
				tmp_strcpy_block+="		Write_atomic_from_array ("+tmp_arg1+"__0+i, s[i]);\n"
				tmp_strcpy_block+="		i++;\n"
				tmp_strcpy_block+="	}\n"
				tmp_strcpy_block+="	return 0;\n"
				tmp_strcpy_block+="}\n"
				
				self.functionBlock1+="\n" + tmp_strcpy_block + '\n'
				self.funcName.append(tmp_decl_name)		

			return tmp_decl_name + "("+tmp_args[1]+");"
			
		self.isInFuncCall=1
		self.suffixCall=""
		tmp_declaration=self.visit(n.args)
		self.isInFuncCall=0
		notReplace=["__CPROVER_assume","__VERIFIER_assert","___XXXXX__nondet_int","__pthread_join","exit","malloc","assert","strcpy"]
		if self.suffixCall!="" and fref not in notReplace: 
			
			tmp_fref = fref 
			fref = fref+self.suffixCall+'('+tmp_declaration+ ')'
			
			self.visit_FuncDef_fake(self.Parser.funcNode[tmp_fref], fref)	
			fref=fref.replace("<param-global-null>","0")
			fref=fref.replace("&0","0")

			self.suffixCall=""
			return fref
			
		if fref.startswith('__VERIFIER_atomic') or fref.startswith('__CSEQ_atomic_'):
			#return fref + '(' + self.visit(n.args) + ');'+'\nif (nondet_int()	){__CS_ret=1; return 0;}\n'
			return fref + '(' + self.visit(n.args) + ');'

		'''
		if fref.startswith('__CPROVER_assume'):
			return 'if (nondet_int()	){__CS_ret=1; return 0;} ' + fref + '(' + self.visit(n.args) + ');\n'
		'''
		if (not (self.currentFunct.startswith('__VERIFIER_atomic')) and (not (self.currentFunct.startswith('__CSEQ_atomic_')))) and fref.startswith('__CPROVER_assume'):
			return 'if (nondet_int()	){__CS_ret=1; return 0;} ' + fref + '(' + self.visit(n.args) + ');\n'
			
			
		return fref + '(' + self.visit(n.args) + ')'



	def _min4(self, i1, i2, i3, i4):
		min=500
		#if i1>=0 and i2<min:
		if i1>=0 and i1<min:
			min=i1
		if i2>=0 and i2<min:
			min=i2
		if i3>=0 and i3<min:
			min=i3
		if i4>=0 and i4<min:
			min=i4
		return min

		

	def __first_ID(self, tmp):
		i1= tmp.find("->")
		i2= tmp.find("[")
		i3= tmp.find("___")
		i4= tmp.find("__0")
		min=self._min4(i1, i2, i3, i4)

		
		if min==500:
			tmp_varname=tmp
		else:
			tmp_varname=tmp[:min]
		return tmp_varname		
		
	def visit_UnaryOp(self, n):

		operand = self._parenthesize_unless_simple(n.expr)

		self.visitStarted=1
		tmp=self._parenthesize_unless_simple(n.expr)
		self.visitStarted=0

		tmp_varname=self.__first_ID(tmp)

		
	
		rval_str="1"
		s=""		
		
		if tmp_varname in self.Parser.varNames[''] or self.currentFunct+"__"+tmp_varname in self.global_parameters: # only consider global variables
			jumpYes=""
#			if self.parsingAtomic==False:
#				jumpYes="Jump();\n"+self._make_indent()
			jumpYes=""
			if n.op == 'p++':
				return jumpYes+'Write(%s, Read(%s)+ 1)' % (tmp, tmp)
			elif n.op == 'p--':
				return jumpYes+'Write(%s, Read(%s)- 1)' % (tmp, tmp)
			elif n.op == '--':
				return jumpYes+'Write(%s, Read(%s)- 1)' % (tmp, tmp)
			elif n.op == 'sizeof':
				return 'sizeof(%s)' % self.visit(n.expr)
			elif n.op == '*':
				return 'Read('+tmp_varname+')'
			else:
				if self.__isStruct('', tmp_varname) and self.isInFuncCall and n.op=="&":
					return '<param-global-null>' 
				return '%s%s' % (n.op, operand)
		else:
			return super(mucseq, self).visit_UnaryOp(n)



	def visit_Assignment(self, n):
	
		

		self.setParams=1
		rval_str=""
		tmp=tmp=str(self.visit(n.lvalue))
		if tmp.startswith("__cs_param_"):
			rval_str = self._parenthesize_if(n.rvalue, lambda n: isinstance(n, pycparser.c_ast.Assignment))
			self.setParams=0
			#self.logAppend += "\n//"+tmp+"="+rval_str
			if self.__isPointer('',rval_str) or self.__isArray('',rval_str):
				self.equalToGlobalName[self.currentFunct+"_"+tmp]=rval_str
				self.logAppend += "\n//"+tmp+"="+rval_str
				return ""
		self.setParams=0
		
		
		#self.whereInAssignment="r"
		self.inGlobalPointer=0
		rval_str = self._parenthesize_if(n.rvalue, lambda n: isinstance(n, pycparser.c_ast.Assignment))
		tmp_inGlobalPointer=self.inGlobalPointer
		self.inGlobalPointer=0
		#self.whereInAssignment=""


		#self.whereInAssignment="l"
		if self._is_simple_node(n.lvalue):
			self.visitStarted=1
			tmp=str(self.visit(n.lvalue))
			self.visitStarted=0
		else:
			tmp=str(self.visit(n.lvalue))		
		is_an_array = 0
		
		#print "prima"+tmp
		if tmp.startswith("Read_from_array"):
			is_an_array = 1
			tmp=tmp[16:]
			tmp=tmp[:len(tmp)-1]
		elif tmp.startswith("Read"):
			tmp=tmp[5:]
			tmp=tmp[:len(tmp)-1]
		elif tmp.startswith("*"):
			tmp=tmp[1:]
		#print "dopo"+tmp
			
		tmp_varname=self.__first_ID(tmp)


		
		
#		rval_str=rval_str.replace("Read(","Read_atomic(");
		
		if tmp_varname in self.Parser.varNames[''] or self.currentFunct+"_"+tmp_varname in self.global_parameters: # only consider global variables

			if rval_str.find("malloc")>=0:  
				if rval_str.find("__CS_pthread_mutex_t")>=0:
					return ""
				if rval_str.find("*")<0:
					return "Write("+tmp_varname+", " +tmp_varname+" + 1)"
				else: return "Write("+tmp_varname+", " +tmp_varname+"__0 + "+rval_str.split("*")[len(rval_str.split("*"))-1]		

			s=""

			
			
			if (self.speedup==1):
				#####speed up
				tmp=tmp.replace("Read(","Read_atomic(")
				if self.parsingAtomic==False:
					s="Jump();\n"+self._make_indent()



			
			if self.__isPointer('',tmp_varname):
				s+= "if (Read_atomic("+tmp+")>= Read_atomic("+tmp_varname+")){__CS_ret \\ 1; return 0;}\n"+self._make_indent()
				#print s
			
			
			
			
			#if (tmp_varname+"__0") in self.isArray:
			#non lo faccio entrare
			if 0 and ((is_an_array==1) or ((tmp_varname+"__0") in self.isArray)):
				s += 'Write_from_array(%s, %s %s)' % (tmp, n.op, rval_str)
				s = s.replace('+=', "Read_from_array("+tmp+")"+"+" )			
				s = s.replace('-=', "Read_from_array("+tmp+")"+"-" )			
				'''
				Gildo: tolgo isBool
				elif (tmp_varname in self.isBool):
					s += 'Write_Bool(%s, %s %s)' % (tmp, n.op, rval_str)
					s = s.replace('+=', "Read_Bool("+tmp+")"+"+" )			
					s = s.replace('-=', "Read_Bool("+tmp+")"+"-" )			
				'''
			else:
				if (self.speedup==1):
					#####speed up
					s += 'Write_atomic(%s, %s %s)' % (tmp, n.op, rval_str)
					s = s.replace('+=', "Read_atomic("+tmp+")"+"+" )			
					s = s.replace('-=', "Read_atomic("+tmp+")"+"-" )
				else:
					s += 'Write(%s, %s %s)' % (tmp, n.op, rval_str)
					s = s.replace('+=', "Read("+tmp+")"+"+" )			
					s = s.replace('-=', "Read("+tmp+")"+"-" )			

			s = s.replace(', =', ", " )			
			s = s.replace('(=', "(" )			
			s = s.replace('\\', "=" )			
		
		else:
			'''
			if rval_str.find(" malloc")>=0 or rval_str.find(")malloc")>=0:  
				print("malloc on local variables is currently not handled.")
				sys.exit(-1)
			'''	
			tmp_lvalue=self.visit(n.lvalue)
			if tmp_inGlobalPointer==1:
				if (rval_str.startswith("*((int *)")):
					rval_str=rval_str.replace("*((int *)", "Read(")
				elif tmp_lvalue not in self.localPointer:
					self.localPointer.append(tmp_lvalue)
			if tmp_lvalue.startswith("*((int *)"):
				tmp_lvalue=tmp_lvalue.replace("*((int *)","Write(").replace(")",", ")
				s='%s %s)' % (tmp_lvalue, rval_str)
			else:
				s = '%s %s %s' % (tmp_lvalue, n.op, rval_str)
			
			s=s.replace("(void *) (&","(void *) (")
		
		s = s.replace(");)","))")
		return s		