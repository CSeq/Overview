
               CSeq-MU    v. 0.4 
						  C-to-C Sequentialisation Tool
                          October 2015




*  Package contents *

README.txt               this file

mu-cseq.py               CSeq-MU command-line front-end
remaining *.py           CSeq-MU modules
my-include/*             include files (fine-grained schema)
my-include-grained/*     include files (coarse-grained schema)
core/                    CSeq core framework
modules/                 CSeq modules and configuration files

* Installation *

To install mu-CSeq, please follow the steps below:

    1. install the dependencies:
        Python 2.7.9
        PYCparser 2.14
        CBMC 5.2

    2. create a directory, suppose this is called  /workspace

    3. extract the entire package contents in  /workspace
    
    4. set execution (+x) permissions for *.py files

    5. copy or sym-link the CBMC binary file in  /workspace/cbmc,
       and all the other tools anywhere in the default search path.



* Usage (SV-COMP 2016) *

To run MU-CSeq use the following command-line from within the tool's installation directory:

./mu-cseq.py -i<file> --spec<specfile> --witness<errorpath>

where  <inputfile>  is the filename to be verified and  <specfile>  and  <errorpath>
are the two parameters specific for the competition.
