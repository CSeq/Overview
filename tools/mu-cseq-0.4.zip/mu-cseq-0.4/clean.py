#!/usr/bin/env python
CLEAN_VERSION = '0.1 2013.11.01'

"""

"""

import pycparser.c_parser, pycparser.c_ast, pycparser.c_generator
import utils
import os, sys, getopt, time


class Clean(object):
	__inputfilename = ''

	def __init__(self):
		pass

	def getversion(self):
		return CLEAN_VERSION

	def load(self, filename):
		self.__inputfilename = filename

	def save(self, filename, MaxThreadCreate):

		inp = open(self.__inputfilename,"r")
		outp = open(filename,"w")
		str1=""
		comma=0
		idStruct=""
		deleteUntilBranch=0
		isCil=0
		'''
		if utils.fileContains(self.__inputfilename, '__cil_'):
			isCil=1
		'''
		#MaxThreads=16
		MaxThreads=MaxThreadCreate

		str1=""
		comma=0
		idStruct=""
		deleteUntilBranch=0
		tmp_str_arr=""
		notStarted=0
		str2 ="#include <pthread.h>\n\n"
		for line in inp.readlines():
			if line.find("extern _Bool __VERIFIER_nondet_bool(void);")>=0:
				continue
			if line.find("extern void __VERIFIER_assume(int);")>=0:
				continue
			if line.find("extern void * __VERIFIER_nondet_pointer(void);")>=0:
				continue
			if line.find("extern void __VERIFIER_error() __attribute__ ((__noreturn__));")>=0:
				continue
			if line.find("extern void __VERIFIER_error() __attribute__ ((__noreturn__));")>=0:
				continue
			#if (line.startswith("void __") or line.startswith("int __")) and notStarted==0 and not line.startswith("void __VERIFIER_assert"):

			if (line.startswith("void __") or line.startswith("int __")) and notStarted==0:
				str2=str2+"\n"+line
				continue

			if line.startswith("extern"):
				notStarted=1
				if not line[len(line)-2]==";":
					comma=1
				else:
					comma=0
				str1=""
			else:
				#if comma==0:
				if comma==0 and not line.startswith("#line") and line.find("FILE *")<0:
					if line.startswith("__thread "):
						line=line.replace("__thread ","")
						tmp_str_arr=line.split(" ")[1]
						line=line.split(" ")[0]+" _Thread_local__"+tmp_str_arr+"["+str(MaxThreads)+"];\n"
					if line.find("for(;;)"):
						line = line.replace("for(;;)","while(1)")
					if line.find("for (;;)"):
						line = line.replace("for (;;)","while(1)")
					if line.find("for (;__VERIFIER_nondet_int();)"):
						line = line.replace("for (;__VERIFIER_nondet_int();)","while(__VERIFIER_nondet_int())")

					str1+=line
				else:
					if line[len(line)-2]==";":
						comma=0
		#str2+="#include <stddef.h>\n\n"
		str1=str2+str1

		if tmp_str_arr!="":
			if len(str(tmp_str_arr))>3:
				str1 = str1.replace(tmp_str_arr, "_Thread_local__"+tmp_str_arr+"[thread_index]")
			else:
				str1 = str1.replace(" "+tmp_str_arr+" ", " _Thread_local__"+tmp_str_arr+"[thread_index] ")
				str1 = str1.replace("!"+tmp_str_arr+" ", "!_Thread_local__"+tmp_str_arr+"[thread_index] ")
				str1 = str1.replace("("+tmp_str_arr+")", "(_Thread_local__"+tmp_str_arr+"[thread_index])")
			str1 = str1.replace("_Thread_local___Thread_local__"+tmp_str_arr+"[thread_index]["+str(MaxThreads)+"]","_Thread_local__"+tmp_str_arr+"["+str(MaxThreads)+"]")

		outp.write(str1)
		inp.close()
		outp.close()
