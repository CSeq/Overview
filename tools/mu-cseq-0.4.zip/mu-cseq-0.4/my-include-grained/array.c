////////////////////////////
int init_var[NumVars];
__CS_type first_write[NumVars];
int values[MEM_SIZE];  
__CS_type next_write[MEM_SIZE];  



int Read_atomic_from_array(__CS_type codeVar){

	if (__CS_ret) return;

	__CS_type jump;
	__CPROVER_assume( ( (jump <= thread_pos)) );

	//if (jump >= memory_notvalid ) {__CS_ret=1; return;}

	if  (first_write[codeVar]==0)  {return init_var[codeVar];}

	if (jump<thread_pos){
		__CPROVER_assume( ( (next_write[jump] > thread_pos)) );
	}else{
		if (( jump < first_write[codeVar] ) ) return init_var[codeVar];
		///////////////////////////__CPROVER_assume((jump<thw[thread_index][thread_pos]));  
	}
	//<insert-assume-jump-atomic-here>
	//__CPROVER_assume( (Read_atomic_atomic () == NumThreads) || (Read_atomic_atomic () == thread_index));

	__CPROVER_assume( (var_name[jump] == codeVar) );
	return (values[jump]);////////////////////////
}


void Write_atomic_from_array(__CS_type codeVar, int val){

  thread_pos++;
  __CPROVER_assume((thread_pos < memory_notvalid ) && (cannot_next_atomic_write[thread_index]==0));


  __CPROVER_assume (
           (var_name[thread_pos] == codeVar)
       &&  (values[thread_pos] == val)
       &&  (thread[thread_pos] == thread_index)
      ) ;
  cannot_next_atomic_write[thread_index]=visible[thread_pos];
}


int Read_from_array(__CS_type codeVar){

	if (__CS_ret) return;

	__CS_type jump;
	__CPROVER_assume( ( (jump < thw[thread_index][thread_pos])) );

	if (jump >= memory_notvalid ) {__CS_ret=1; return;}

	if  (first_write[codeVar]==0)  {return init_var[codeVar];}

	if (jump<thread_pos){
		__CPROVER_assume( ( (next_write[jump] > thread_pos)) );
	}else{
		if (( jump < first_write[codeVar] ) ) return init_var[codeVar];
		//__CPROVER_assume((jump<thw[thread_index][thread_pos]));  
		thread_pos=jump; 
	}
	//<insert-assume-jump-atomic-here>
//	__CPROVER_assume( (Read_atomic_atomic () == NumThreads) || (Read_atomic_atomic () == thread_index));

	__CPROVER_assume( (var_name[jump] == codeVar) );
	return (values[jump]);

}

void Write_from_array(__CS_type codeVar, int val){

	if (__CS_ret) return;

	thread_pos=thw[thread_index][thread_pos];
	if (thread_pos >= memory_notvalid ) {__CS_ret=1; return;}
	
	<insert-assume-atomic-here>

	__CPROVER_assume (
           (var_name[thread_pos] == codeVar)
       &&  (values[thread_pos] == val)
	) ;
}
/////////////////////////