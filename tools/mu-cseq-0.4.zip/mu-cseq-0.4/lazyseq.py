""" Lazy-CSeq Sequentialization module
	written by Omar Inverso, University of Southampton.
"""
VERSION = 'lazyseq-0.0-2015.07.18'   # CSeq-1.0 Release ASE2015
#VERSION = 'lazyseq-0.0-2015.07.16'   # main driver bug fixing (Truc)
#VERSION = 'lazyseq-0.0-2015.07.10'
#VERSION = 'lazyseq-0.0-2015.06.30'
#VERSION = 'lazyseq-0.0-2015.06.11'
#VERSION = 'labeler-0.0-2015.02.22'   # bugfix
#VERSION = 'labeler-0.0-2015.01.27'   # more efficient handling of mutexes
#VERSION = 'labeler-0.0-2015.01.17'   # small optimization
#VERSION = 'labeler-0.0-2015.01.12'   # back to CAV-style constraints in the main driver
#VERSION = 'labeler-0.0-2014.10.29'   # CSeq-1.0beta
#VERSION = 'labeler-0.0-2014.10.29'   # newseq-0.6c SVCOMP15
#VERSION = 'labeler-0.0-2014.10.26'   # newseq-0.6a
#VERSION = 'labeler-0.0-2014.10.15'
#VERSION = 'labeler-0.0-2014.06.26' (CSeq-Lazy-0.4)
#VERSION = 'labeler-0.0-2014.03.14' (CSeq-Lazy-0.3)
#VERSION = 'labeler-0.0-2014.02.25' (CSeq-Lazy-0.2)

"""

Transformation:
	implements the lazy sequentialization schema
	(see Inverso, Tomasco, Fischer, La Torre, Parlato, CAV'14)

Prerequisites:
	- all functions should have been inlined, except the main(), all thread functions, all __CSEQ_atomic_ functions, and function __CSEQ_assert
	- all loops should habe been unrolled
	- no two threads refers to the same thread function (use module duplicator.py)

TODO:
	- get rid of _init_scalar() (see ext. notes)
	- check the STOP() inserting mechanism
	- this schema assumes no mutex_lock() in main() - is this fine?

Changelog:
	2015.07.18  new --schedule parameter to set schedule restrictions (Omar)
	2015.07.15  changed visit of atomic function definitions (Truc,Omar)
	2015.07.10  no context switch between __CSEQ_atomic_begin() and __CSEQ_atomic_end()
	2015.06.30  major refactory (converted to stand-alone instrumentation, etc.)
	2015.04.23  __globalAccess()  was causing  if(cond)  blocks to disappear
	2015.02.22  __CSEQ_assume() without occurrences of shared vars produces no context switch points
	2015.01.27  using macros rather than functions to model pthread_mutex_lock/unlock() avoids using ptrs and thus yields faster analysis
	2014.01.17  main driver: first thread execution context must have length > 0 (faster analysis)
	2014.12.24  linemap (overrides the one provided by core.module)
				bugfixes, code maintenance
	2014.12.09  further code refactory to match the new organisation of the CSeq framework
	2014.10.29  bitvector encoding for all control variables (pc, pc_cs, ...)
				new main driver where guessed jump lenghts are all at the top (this allows inserting p.o.r. constraints right after them)
	2014.10.26  removed dead/commented-out/obsolete code
	2014.10.15  removed visit() and moved visit call-stack handling to module class (module.py)
	2014.06.26  improved backend-specific instrumentation
				added new backend Klee
	2014.03.14  further code refactory to match  module.Module  class interface
	2014.02.25  switched to  module.Module  base class for modules
	2014.01.19  fixed assert()s missing their stamps at the beginning

"""
import math, re
from time import gmtime, strftime
import pycparser.c_parser, pycparser.c_ast, pycparser.c_generator
import core.common, core.module, core.parser, core.utils, parsermu











notHandledPrimitives = [ 'pthread_mutex_trylock', 'pthread_mutex_timedlock', 'pthread_mutex_consistent']  # mutexes
notHandledPrimitives += ['pthread_cond_timedwait', 'pthread_cond_destroy'] # conditionals
notHandledPrimitives += ['free', 'calloc'] # dynamic memory allocation
renameFunct=["thread"]


class colors:
	BLACK = '\033[90m'
	RED = '\033[91m'
	GREEN = '\033[92m'
	YELLOW = '\033[93m'
	BLUE = '\033[94m'
	NO = '\033[0m'

mainSimulationBlock = (
"<insert-thread-create-block-here>"
"\n\nvoid *main_thread(int __cs_param_main_argc, char *__cs_param_main_argv[])\n"
"{\n"
"\t<insert-main-parameters-decl-here>\n"
"\t<insert-mainthread-here>\n"
"}\n"
"\n"
"\n"
"\n\n<insert-check-block-here>\n\n"

"\n"
"\n"
#"<insert-main-prototype-here>\n"
"\nint main(int argc, char **argv)\n"
"\n{"
"\n"
"\nGuessedNumThreads=nondet_int();"
"\n__CPROVER_assume(GuessedNumThreads<=MaxNumThreads);"
"\n"
"\n"
"\nguessMU();"
"\n"
"\n//ticket_pos=NumVars-1;"
"\n//cseq: simulation of the threads main"
"\nmain_thread(argc, argv);"
"\n  //__CPROVER_assume((thw[__cs_thread_index][thread_pos] >=memory_notvalid) );"
"\n  insert-end-thread-create-here>"
"\n  __CPROVER_assume(GuessedNumThreads==n_treads_createad);"
"\n"
"\n//cseq: Error check"
"\nassert(__CS_error != 1);"
"\n}"
)
exitBlock = (
"if (nondet_int()){__CS_ret=1; return 0;}\n"
)

errorBlock2 = (
"\tERROR: if (__CS_ret){ return 0;} \n"
"\t__CS_error = 1;  <return_statement>;\n "
)
errorBlock = (
"\tif (__CS_ret){ return 0;} "
"\t__CS_error = 1;  <return_statement> "
)


pthread_create_block_static1 = (
"(__CS_pthread_t *thread_id, void *attr, void *arg){\n"
"	if (__CS_ret) return 0;\n\n"
"	int __ret=0;\n"
"__CS_typeT my_thread_index;\n"
"__CS_typeM my_ticket_pos;\n"
"insert-mylast-used-pos-here>\n"
"\n"
"   if (MaxNumThreads==++number_threads) return 0;\n"
""
"	my_thread_index = __cs_thread_index; \n"
" 	my_ticket_pos   = ticket_pos;\n"
" 	__cs_thread_index = number_threads;\n"
"   n_treads_createad++;\n"
" 	insert-start-thread-create-here>\n"
"	if (nondet_int()){ __CS_ret=1; __ret=-1;}\n"
" 	else { <insert-thread-routine-here>( arg); }\n"
" 	*thread_id=__cs_thread_index;\n"
" 	//__CPROVER_assume((thw[__cs_thread_index][thread_pos] >=memory_notvalid) );\n"
" 	 	//__CPROVER_assume((thread_pos< memory_notvalid) && (thw[__cs_thread_index][thread_pos] >=memory_notvalid) );\n"
" 	insert-end-thread-create-here>\n"
" 	//if (__CS_ret==1) terminated[__cs_thread_index]=1;\n"
"	terminated[__cs_thread_index]=!__CS_ret;\n"
"	__CPROVER_assume(ticket_pos_terminated[__cs_thread_index]==ticket_pos);\n"
"	//sistemare thread_pos_terminated[__cs_thread_index]=ticket_pos;\n"
"	//ticket_pos_terminated[__cs_thread_index]=ticket_pos;\n"
" 	__CS_ret=0;\n"
" 	__cs_thread_index = my_thread_index;\n"
" 	ticket_pos   = my_ticket_pos;\n"
"	insert-from-mylast-used-pos-here>\n"
"	return __ret;\n"
"}\n"
)







class lazyseq(core.module.Translator):
	__lines = {}                     # lines for each thread
	__threadName = ['main']          # name of threads, as they are found in pthread_create(s) - the threads all have different names
	__threadIndex = {}               # index of the thread = value of threadcount when the pthread_create to that thread was discovered
	__threadCount = 0                # pthread create()s found so far

	__labelLine = {}                 # statement number where labels are defined [function, label]
	__gotoLine = {}                  # statement number where goto to labels appear [function, label]
	__maxInCompound = 0              # max label within a compound
	__labelLength = 55               # for labels to have all the same length, adding padding when needed
	__startChar = 't'                # special char to distinguish between labeled and non-labelled lines

	__stmtCount = -1                 # thread statement counter (to build thread labels)

	__currentThread = ''             # name of the current thread (also used to build thread labels)

	__threadbound = 0                # bound on the number of threads

	__firstThreadCreate = False      # set once the first thread creation is met
	__globalMemoryAccessed = False   # used to limit context-switch points (when global memory is not accessed, no need to insert them)

	__first = False
	__atomic = False                 # no context-switch points between atomic_start() and atomic_end()

	_bitwidth = {}                   # custom bitwidth for specific int variables, e.g. ['main','var'] = 4

	_deadlockcheck = False

	__explicitround = []             # explicit schedules restrictions
	
	


		
	
	
	

	def init(self):
		self.addInputParam('vlocks', 'max number of locks on variables', 'l', '0', False)
		self.addInputParam('nwrites', 'max number of writes for each variable', 'w', '7', False)
		self.addInputParam('mlocks', 'max number of memory locks', 'm', '0', False)
		self.addInputParam('bitvector', 'number of bits for integers', 'b', '17', False)
		self.addInputParam('threads', 'max no. of thread creations (0 = auto)', 't', '0', False)
		self.addInputParam('nmalloc', 'max no. of active malloc ', 'M', '0', False)
		self.addInputParam('npointers', 'max no. of pointers', 'P', '0', False)
		#self.addInputParam('deadlock', 'check for deadlock', '', default=False, optional=True)

		self.addOutputParam('bitwidth')
		self.addOutputParam('header')
		global pthread_create_block1
		self.pthread_create_block_static = pthread_create_block_static1
		
		
		self.error_label= '__VERIFIER_error()'
		
		self.string=""
			
		self.logAppend=""
			
		self.setParams=0
			
		self.NumLocks=10
		self.NumvLocks=10
	
		self.arrayWriteVars = {}
			#####
		self.lockVariable=0
			
			#self._inputFilename = filename
		self.verifier_atomic = 0	
		self.MaxThreadCreate=3
		self.nwrites=10
		self.ufor=10
		self.bitvector=0
		self.partialLoops = 0
		self.speedup = 0

			#self.num_assignment=0
		self.visitStarted=0
		#self.global_parameters=[]  
		self.global_parameters2={} 
		#self.equalToGlobalName={}  
			####Gildo: tolgo isBool
			#####self.isBool=[]
		self.isArray=[]
		self.isScalar=[]
		self.isInFuncCall=0
		self.suffixCall=""

		self.pthread_create_block = ""
		#pthread_create_block_static = ""

		self.check_block = ""
		self.MEM_SIZE=24
		self.LOCK_SIZE = 0
		self.vLOCK_SIZE = 0
			
		self.variables_arr=[]
		self.variables_locks=[]
		self.variables_arr_size = {}
		self.nScalars=0
		
		self.variables=[]		
		self.isInArrayOrStruct="" 
		self.whereInAssignment="" 
		#self.inGlobalPointer=0
		self.localPointer=[]
			
		self.functionBlock1=""   #fake functions
		self.IsFakeFunct=0
		#self.initializedGlobalVariables	= []
		#self.labelFor=0
		#self.MaxThreadCreateInLop=self.MaxThreadCreate
			
		#self.initialization=""
		self.initializationNew=""
		#self.nwrites = nwrites
		#self._format = format	
		self.funcName = ['']  # names of all the functions (consider '' to be a special function to model global scope)
		global renameFunct
		self.renameFunct1=renameFunct	
		
		# this will set to True after parsing the first function definition (not declaration!)
		self.firstFunctionDefinitionDone = False

		# set to True while parsing void functions
		self.parsingVoidFunction = False

		# set to True while parsing typedef blocks 
		self.parsingTypedef = False

		# used to avoid inserting context switches in functions whose name starts with '__VERIFIER_atomic'
		self.parsingAtomic = False


			
		self.lines = []	
		self.unionDeclaration = 'union __CS__u {\n'
		
		# = True while parsing the subtree for a function declaration
		self.parsingFuncDecl = False

		# = True while parsing the subtree for a struct (or union) declaration
		self.parsingStruct = False

		# = True while parsing the main() function
		self.parsingMain = False

		# = True while parsing the condition block of a while loop
		self.parsingWhileCond = False

		# Set when parsing a statement with side effects (i.e., function call, assignment, unary op)
		self.parsingSideEffect = False



		self.copyVariableDeclaration = ''

		# The following union declaration will be used to keep
		# the old value of a global variable immediately before any complex assignment operation
		# (such as the ones with a function call in the Lvalue).
		# This value can be used thereafter to simulate when a context switch happens
		# while performing function calls from within the assignment,
		# to restore the original value of the variable with a single assignment statement
		# (C unions support this).

		# init expressions for global variables will be moved into this string and then 
		# printed inside the main() function
		self.globalInitStatements = ''
		
		
		self.currentFunct = '' # name of the function being parsed (if any)

		self.currentVarAssign = '' # name of the current variable used as a lvalue in an assignment statement

		self.currentStruct = ''
		self.structName = []
		self.currentAnonStructsCount = 0   # counts the number of anonymous structures (used to assign consecutive names)

		self.mainParametersDecl = ''     # parameters of the main() function to be transferred to thread 0.

		
			# TODO: True when the copyvar block etc. in the top of the main() function still
			# has to be added. We have to wait for all the declarations at the top of the main()
			# to show up before adding any assignment operations!
		self.append = True

			# The following variables are needed for handling the global variables in the original
			# source code.
		self.globalInitVarNodes = []  # all the initialised global variable nodes in a list

			# Statements start with indentation of self.indent_level spaces, using
			# the _make_indent method
			#
		self.indent_level = 0			# to keep track of the depth of the block {}
		self.INDENT_SPACING = '\t'	# ....		
		
		self.wmm=0 #per vedere se ci sono loop
		
		self.wmmGildo=0    #cancellaloooooooooooooooo solo per il trick sui wmm
		self.countLock=0
		self.CountWrite=0	#dice se devo contare le write
		self.NumVars=1
		self.Parsermu = parsermu.Parsermu()
		self.Parsermu.load('inlined.i.c')		
		
		
		
		
		
		
		
		
		
		
		


	def loadfromstring(self, string, env):
		if self.getInputParamValue('deadlock') is not None:
			self._deadlockcheck = True

		threads = int(self.getInputParamValue('threads'))
		backend = self.getInputParamValue('backend')


		self.__threadbound = threads+1
		self.npointers=0
		self.nmalloc=0
		#self.nwrites =  int(env.paramvalues['writes'])
		
		if 'nwrites' in env.paramvalues: self.nwrites = int(env.paramvalues['nwrites'])
		if 'mlocks' in env.paramvalues: self.NumLocks=int(self.getInputParamValue('mlocks'))
		if 'vlocks' in env.paramvalues: self.NumvLocks=int(self.getInputParamValue('vlocks'))
		if 'bitvector' in env.paramvalues: self.bitvector=int(self.getInputParamValue('bitvector'))
		if 'npointers' in env.paramvalues: self.npointers=int(self.getInputParamValue('npointers'))
		if 'nmalloc' in env.paramvalues: self.nmalloc=int(self.getInputParamValue('nmalloc'))
		
		#self.nwrites=int(env.paramvalues['nwrites'])
		#self.NumLocks=int(self.getInputParamValue('mlocks'))
		#self.NumvLocks=int(self.getInputParamValue('vlocks'))
		
		#print self.writes
		super(self.__class__, self).loadfromstring(string, env)

		
		'''
		print "\n\nParsermu symbols"
		self.Parsermu.printsymbols()
		print "\n\nParser symbols"
		self.Parser.printsymbols()
		'''
		
		self.string=string
		if ('__VERIFIER_atomic_begin' in string) or ('__CSEQ_atomic__begin' in string):
			self.wmm=1 #per vedere se ci sono loop

		self.wmm=0 #per vedere se ci sono loop
		
		if (('__VERIFIER_atomic' in string) or ('__CSEQ_atomic_' in string)):
			self.verifier_atomic = 1		

		#self.output += "\n\n//atomico: %s\n\n" %(self.verifier_atomic)
		
		#header = self._make_header()
		#print "print_symbols\n"
		#self.Parser.printsymbols()
		#return		
		header = self._make_header()

		

		'''
		global pthread_create_block1
		self.pthread_create_block_static = pthread_create_block_static1
		print pthread_create_block_static
		'''
		
		'''da vedere
		if (parser.containsArray!="" and parser.containsArray.find("_Thread_local__COND")<0):
			self.pthread_create_block_static=pthread_create_block_static.replace("__CPROVER_assume((thread_pos< memory_notvalid) && (thw[__cs_thread_index][thread_pos] >=memory_notvalid) )","__CPROVER_assume((thw[__cs_thread_index][thread_pos] >=memory_notvalid) )")
		'''
		



		global errorBlock
		global renameFunct
		self.renameFunct1=renameFunct




		# Optimisation: remove code from cs() for conditional variables when not needed.
		if not 'pthread_cond' in string:
			self.output = self.output.replace('___XXXXX__assume(__CS_thread_lockedon[k][__CS_thread_index] == 0);', '/**/');

		
		

		
		self.output = self.output.replace('___XXXXX__nondet_int()', 'nondet_int()')
		self.output = self.output.replace('___XXXXX__assume', '__CPROVER_assume')
		self.output = self.output.replace('___XXXXX__assert', '__CPROVER_assert')
		self.output = self.output.replace('int ___XXXXX__dummyBlock1;\n', '');
		self.output = self.output.replace('int ___XXXXX__dummyBlock2;\n', '');
		self.output = self.output.replace('___XXXXX__FINAL_assert', 'assert');
		
		



		num_writes_variabile = 0
		max = 0
		for item in self.isScalar:			
			subStr = "Write(%s,"%(item)
			subStrLock = "lock("+item+")"
			tmpCount = self.output.count(	subStr, 0, len(self.output)) + self.output.count(subStrLock, 0, len(self.output))
			if tmpCount > max:
				max=tmpCount
			'''
			if (self.wmm==1):
				self.arrayWriteVars[item]=tmpCount
			else:
				self.arrayWriteVars[item]=self.MEM_SIZE_VARS-1
				#header=header.replace("<%s-NWRITES>"%(item),str(self.arrayWriteVars[item]))
			'''
			
			
			####devo cambiare la logica degli array
			#in wmm ci sono variabili che iniziano per __ e che non sono array
			if (  (tmpCount < self.MEM_SIZE_VARS) and (item.startswith("__") or ("__" not in item)) ):
				self.arrayWriteVars[item]=tmpCount
			else:
				self.arrayWriteVars[item]=self.MEM_SIZE_VARS-1
				#header=header.replace("<%s-NWRITES>"%(item),str(self.arrayWriteVars[item]))
						
			if self.CountWrite==0:
				self.arrayWriteVars[item]=self.MEM_SIZE_VARS-1

			'''
			per provare sigma
			if item!="array_index":
				self.arrayWriteVars[item]=2
			'''
			
			
			
			header=header.replace("<%s-NWRITES>"%(item),str(self.arrayWriteVars[item]+1))
			num_writes_variabile=num_writes_variabile + tmpCount
			#s=s.replace("<%s-NWRITES>"%(item),str(s.count(	subStr, 0, len(s))+1))
			#self.output +="\n//self.arrayWriteVars["+item+"]: "+str(tmpCount)
			header=header.replace("<%s-NWRITES>"%(item),str(self.arrayWriteVars[item]+1))

		#self.output +="\n//num_writes_variabile: "+str(num_writes_variabile)
		#self.output +="\n//max: "+str(max)

		tmpCount = self.output.count(	"Take_lock__atomic_function", 0, len(self.output))
		
		if (self.wmm==1):
			self.MEM_SIZE_VARS = max + 1
			self.LOCK_SIZE = ((tmpCount- 2) * 2)  + 1
			header = header.replace('<insert-LOCK_SIZE-here>', str(self.LOCK_SIZE))
			header = header.replace('<insert-MEM_SIZE_VARS-here>', str(self.MEM_SIZE_VARS))
			
		self.logAppend+="\n//numLocks=%s"%(self.countLock)	


		if (((self.countLock*2 )+1) < self.vLOCK_SIZE):
			self.vLOCK_SIZE = (self.countLock*2 )+1

		self.output = self.output.replace('<insert-vLOCK_SIZE-here>', str(self.vLOCK_SIZE))
		check_block  = self.__build_check_block()
		####self.build_check_blockNew()
		header = header.replace('<insert-MEM_SIZE-here>', str(self.ticket_index))
		
		s1=""
		if self.verifier_atomic:
			s1+="Read_var_atomic();"
		if self.lockVariable:
			#s1+="Read_var_lock();"
			for item in self.variables_locks:
				#variables.append(item)
				s1 += "\nRead_var_lock(%s);"% (item)
		header = header.replace('<insert-pthread_join-here>', s1)

		self.output=self.output.replace("&Read","Read")
		#evito che chiami la Read_from_array
		self.output=self.output.replace("Read_from_array","Read")
		#s=s.replace("Write_atomic","Write")

		self.output = self.output.replace("<insert-thread-create-block-here>", self.pthread_create_block)
		self.output = self.output.replace("<insert-check-block-here>",check_block)
		self.output = header + self.output
		##s=s.replace("<insert-read-write-functions-here>",self.build_read_write_block())
		self.output=self.output.replace("__VERIFIER","_cs___VERIFIER")
		self.output=self.output.replace("_cs___VERIFIER_error();","")
		'''
		num_writes_variabile="\n/*"
		for item in self.isScalar:			
			subStr = "Write("+item+","
			num_writes_variabile += "\n"+item +":" +str(s.count(	subStr, 0, len(s)))
		num_writes_variabile+="\n*/"
		'''
		#self.output = header + core.utils.strip(self.output)		
		
		self.output = self.output.replace("insert-mylast-used-pos-here>",self.__MyLastUsedPos())
		self.output = self.output.replace("insert-from-mylast-used-pos-here>",self.__FromMyLastUsedPos())
		self.output = self.output.replace("insert-start-thread-create-here>",self.__checkStartThread()).replace("insert-end-thread-create-here>",self.__checkEndThread())
		
		if (self.wmm == 0):
			#headerBlock = headerBlock.replace('<insert-MEM_SIZE-here>', str(MEM_SIZE))
			self.output = self.output.replace('<insert-LOCK_SIZE-here>', str(self.LOCK_SIZE))
			self.output = self.output.replace('<insert-vLOCK_SIZE-here>', str(self.vLOCK_SIZE))

		

		'''
		self.logAppend+="\n//global_parameters2"
		for p in self.global_parameters2:
			self.logAppend+="\n//"+p
			self.logAppend+="\n//"+self.global_parameters2[p]
		'''




		self.output += self.logAppend
		self.output = core.utils.strip(self.output)
		self.output = self.output.replace("extern void \n","")


		

		if (self.wmmGildo):
			self.output = self.output.replace("Read","Read_atomic")
			self.output = self.output.replace("Write","Write_atomic")


		
		
		
		
		'''
		# Add the new main().
		self.output += self.__build_check_block(rounds)
		
		#self.output += self.Parser.printsymbols()
		self.logAppend=""
		for f in self.Parser.funcName:
			for v in self.Parser.varNames[f]:
				self.logAppend+="\n//%s:%s"%(v,f)
		
		self.output += self.logAppend
		'''


	def _make_header(self):
		# This block is added at the top of the output file.
		# All the function calls starting with '___XXXXX__' are place-holders and 
		# will be replaced later on, depending on the format chosen.
		# The placeholder <insert-include-statements-here> will be replaced with the original
		# #include lines (that we assume to be at the top of the input and without empty lines)
		# exactly as they were.
		#
		headerBlock = ''

		variables=self.variables
		pthread_condt_variables=[]
		if ('pthread_cond_wait' in self.string):
			for i in range (0, self.__threadbound):
				variables.append("lock_cond_"+str(i))

		#############		prima di atomic
		

		
		############
				
		headerBlock=""	
		#headerBlock+="//NumVLocks: %s\n"%(self.NumvLocks)

		nPointers=0
		
		
		#self.logAppend +="\n/*\n"+self.Parser.printsymbols()+"*/"
		'''
		for struttura in self.premuseq.strutture:
			self.logAppend +="\n/*\n"+struttura+"*/"
		'''
		for f in self.Parser.funcName:
			for v in self.Parser.varNames[f]:
				#self.logAppend+="\n//variabili: %s:%s"%(v,f)
				if f == '':
					#self.logAppend+="\n//%s:%s--%s"%(v,f,self.Parser.varType['',v])
					if v.startswith("__cs_thread_local_"):
						#self.logAppend+="\n//locCond --- %s:%s ---- threads: %s"%(v,f,self.__threadbound)
						self.variables_arr.append(v+"_cs_arr_0")								
						#variables.append(v+"_cs_arr_0")
						#for i in range(0, self.__threadbound):
						#	variables.append(v+"__%s"%i)
						continue
					if self.Parser.varType['',v].startswith("__cs_t") or self.Parser.varType['',v].startswith ("pthread_t"):
						self.logAppend+="\n//__cs_t: "+v
						#self.logAppend+="\n//lockkkk %s:%s--%s"%(v,f,self.Parser.varType['',v])
						#self.lockVariable=1
						continue
					if self.Parser.varType['',v].startswith("pthread_mutex_t") or self.Parser.varType['',v].startswith ("__cs_mutex_t"):
						self.variables_locks.append("mutex_"+v)								
						#self.logAppend+="\n//lockkkk %s:%s--%s"%(v,f,self.Parser.varType['',v])
						#self.lockVariable=1
						continue
					if self.Parser.varKind['', v] == 'p':
						continue
					if  self.Parser.varType['',v].startswith('pthread_t'):
						continue
					
					#if self.__isPointer(f,v) and not self.Parser.varType['',v].startswith("pthread_mutex_t"):
					if self.__isPointer(f,v) and not self.Parser.varType['',v].startswith("pthread_mutex_t"):
						#variables.append(v+"__valid")
						nPointers=nPointers+1
						variables.append(v)
						#self.logAppend+=": Pointer"
						#MynPointers=MynPointers+1   #never used
						
						'''GILDO: i puntatori sono da gestire
						for i_1 in range (0,16):
							variables.append(v+"__"+str(i_1))
							i_1=i_1+1
						'''
					elif self.Parser.varType['',v].startswith('struct '):
						self.logAppend+="\n//strcuct   ---- %s:%s"%(v,f)
						struct_type=self.Parser.varType['',v][7:]
						for line in self.__explodeVariable(v):
							#print line+"-----"+self.Parser.varType['','queue.element']
							indexBracket = line.find('[')
							indexDot = line.find('.')
							line = line.replace('[', '_cs_arr_')
							line = line.replace(']', '')
							line = line.replace('.', '_cs_struct_')
							#variables.append(line)
							if "_cs_arr_0" in line:
								self.variables_arr.append(line)								
							else:
								variables.append(line)							
					elif (self.__isArray(f, v)):
					#elif (self.Parser.varArity[f, v]>0):
						#self.logAppend+=": Array"
						arity_var=self.Parser.varArity[f, v]
						if (arity_var>0):
							#print v+"-----"+self.Parser.varType['',v]
							for line in self.__explodeVariable(v):
								indexBracket = line.find('[')
								indexDot = line.find('.')
								line = line.replace('[', '_cs_arr_')
								line = line.replace(']', '')
								line = line.replace('.', '_cs_struct_')
								'''
								Gildo: tolgo isBool
								if (self.Parser.varType['',v]=="_Bool"):
									self.isBool.append(line)
									#print line
								'''
								headerBlock+="//line[]: %s\n"%(line)
								self.variables_arr.append(line)								
								break
					else:
						if self.Parser.varType['',v]=='pthread_cond_t':
							pthread_condt_variables.append(v)
						else:
							'''
							Gildo: tolgo isBool
							if (self.Parser.varType['',v]=="_Bool"):
								self.isBool.append(v)
							'''
							variables.append(v)

							
		self.nScalars = variables.__len__()

		if (nPointers==0 and self.variables_arr.__len__()==0):
			self.npointers=0
		
		for i in range(0, self.npointers):
			variables.append("_cs_pointer_%s"%i)
			
							
		#if (self.wmmGildo):
		if (self.countLock > 0):
			self.lockVariable=1							
		if variables.__len__()==0:
			variables.append("at_least_one_global")
		'''
		if self.verifier_atomic:
			variables.append("__atomic")
		'''
		
			
		if self.verifier_atomic:
			self.LOCK_SIZE = (self.NumLocks * 2) + 1
		else:
			self.NumLocks=0
		if self.lockVariable:
			self.vLOCK_SIZE = (self.NumvLocks * 2) + 1
		else:
			self.NumvLocks=0
		NumVars=variables.__len__()
		self.NumVars = NumVars
		if (self.wmm):
			self.MEM_SIZE_VARS = self.nwrites + 1
		else:
			self.MEM_SIZE_VARS = self.nwrites
		self.MEM_SIZE=1 + (self.NumLocks*2) + (self.nwrites * NumVars)
		MEM_SIZE=self.MEM_SIZE
		NumThreads=self.__threadbound
		self.ticket_index = MEM_SIZE
		NUM=0

		'''
		self.MEM_SIZE_VARS = str(math.ceil (self.MEM_SIZE / (variables.__len__() +1))).replace(".0","")
		NumVars=variables.__len__()
		self.MEM_SIZE=self.nwrites
		MEM_SIZE=self.MEM_SIZE
		NumThreads=self.__threadbound
		NUM=0
		'''
		
		
		tmpTerminated="{"
		for i in range(0, NumThreads):
			tmpTerminated+="0"
			if i<(NumThreads-1):
				tmpTerminated+=","
		tmpTerminated+="}"


		for item in variables:
			isArr=0
			'''
			for i in range(0, 10): 
				if (item.find("__%s"%i)>0):
					isArr=1
			'''
			for i in range(0, 10): 
				if (item.find("_cs_arr_0")>0):
					isArr=1
			if (isArr==1):
				#print "array: "+item
				self.isScalar.append(item)
				self.isArray.append(item)
				headerBlock+="//item: %s\n"%(item)
			else:
				#print "scalar: "+item
				self.isScalar.append(item)
				
					
		if (self.wmm==1):
			f = open('my-include/header_all_wmm.c')
		else:
			f = open('my-include/header_all.c')			
		lines = f.readlines()
		f.close()

		for line in lines:
			headerBlock+=line

		if (self.npointers>0):
			f = open('my-include/pointer.c')
			lines = f.readlines()
			f.close()

			for line in lines:
				headerBlock+=line


			headerBlock = headerBlock.replace('<insert-npointers-here>', str(self.npointers))
			

		if (self.nmalloc>0):
			f = open('my-include/myMalloc.c')
			lines = f.readlines()
			f.close()

			for line in lines:
				headerBlock+=line


			headerBlock = headerBlock.replace('<insert-nmalloc-here>', str(self.nmalloc))


		headerBlock = headerBlock.replace('<insert-NumThreads-here>', str(NumThreads))
							

		i=0
		s1 = ""
		##s2 = "//for each scalar variable..."
		for item in self.isScalar:			
			s1 += "\n#define %s %s"% (item, i)
			i=i+1

		i=0
		s1+="\n//locks"
		for item in self.variables_locks:
			#variables.append(item)
			s1 += "\n#define %s %s"% (item, i)
			i=i+1
		##s1 = s2 + "\n" +s1
		#s1 += "\nfine scalar"
		#i=0
		#s1 = ""
		i=0
		for item in self.variables_arr:
			#variables.append(item)
			s1+="\nintV %s;  //scalari: %s\n"%(item,self.nScalars)

			

			
		str_tmp=""
		'''
		for item in self.isArray:
			i1=item.find("___")
			i2=item.find("_cs_arr_0")
			min=self._min4(i1, i2, -1, -1)
			tmp_varname=item[:min]
			if min>=0 and min<500 and str_tmp!=tmp_varname:
				str_tmp=tmp_varname
				if (not self.__isScalar('',tmp_varname)):
					s1 += "\n#define1 %s %s"% (tmp_varname, i)	
				i=i+1				
			
			s1 += "\n#define %s %s"% (item, i)
			i=i+1
		'''
		s1 += "\n\n//for each variable we represent a MU composed by"
		for item in self.isScalar:			
			s1 += "\n//for variable %s"%(item)
			s1 += "\n#define %s_SIZE <%s-NWRITES>"% (item, item)

		
		
		
		

			
			
		#if self.verifier_atomic:
		#	s1 += "\n#define codeVar_atomic %s"% (i)

		if (self.isScalar.__len__()>0):
			headerBlock = headerBlock.replace('<insert-NumIntVar-here>', str(self.isScalar.__len__()))
		else:
			headerBlock = headerBlock.replace('<insert-NumIntVar-here>', 'NumVars')


		headerBlock = headerBlock.replace('<insert-bit-here>', str(self.bitvector))
		headerBlock = headerBlock.replace('<insert-define-global-variables-here>', s1)
		headerBlock = headerBlock.replace('<insert-NumVars-here>', str(variables.__len__()))
		#headerBlock = headerBlock.replace('<insert-NumMemoryUnwinding-here>', str(NumVars))
		if (self.wmm == 0):
			headerBlock = headerBlock.replace('<insert-MEM_SIZE_VARS-here>', str(self.MEM_SIZE_VARS))
		headerBlock = headerBlock.replace('<insert-Terminated-here>', tmpTerminated)

		s1=""
		'''
		if self.verifier_atomic:
			s1  = "_Bool cannot_next_atomic_write[MaxNumThreads];\n"
			s1 += "_Bool visible[MEM_SIZE];"
		'''
		'''
		s1  = "_Bool cannot_next_atomic_write[MaxNumThreads];\n"
		s1 += "_Bool visible[MEM_SIZE];"
		'''
		if self.verifier_atomic:
			s1  += "\n__CS_typeM __ticket_atomic  [LOCK_SIZE+1];"
			s1  += "\n__CS_typeT __thread_id_atomic  [LOCK_SIZE];"
			s1  += "\n__CS_typeM __thw_atomic[MaxNumThreads][LOCK_SIZE];"
			s1  += "\n__CS_typeM __last_used_pos_of_atomic; "
			s1  += "\n__CS_typeM __memory_notvalid_of_atomic;"
	
		headerBlock = headerBlock.replace('<insert-atomic-declaration-here>', s1)

		s1=""
		if self.lockVariable:
			s1  += "\n__CS_typeM __ticket_lockV [%s][vLOCK_SIZE+1];"%(self.variables_locks.__len__())
			s1  += "\n__CS_typeT __thread_id_lockV  [%s][vLOCK_SIZE];"%(self.variables_locks.__len__())
			s1  += "\n__CS_typeM __thw_lockV[%s][MaxNumThreads][vLOCK_SIZE];"%(self.variables_locks.__len__())
			s1  += "\n__CS_typeM __last_used_pos_of_lockV[%s]; "%(self.variables_locks.__len__())
			s1  += "\n__CS_typeM __memory_notvalid_of_lockV[%s];"%(self.variables_locks.__len__())
	
		headerBlock = headerBlock.replace('<insert-lockVariable-declaration-here>', s1)

		s1=""
		if self.lockVariable:
			f = open('my-include/locVars.c')			
			lines = f.readlines()
			f.close()
	
			for line in lines:
				s1+=line
	
		headerBlock = headerBlock.replace('<insert-locVars-here>', s1)

		
		s1 = ""
		if 'pthread_cond_wait' in self.string:
			s1 += "\n//pthread_cond_t"
			i=1
			for item in pthread_condt_variables:
				s1 += "\n#define %s %s"% (item, i)
				i=i+1
			s1 += "\n"
			s1 += "\n"

		headerBlock = headerBlock.replace('<insert-pthread_cond_wait-here>', s1)
		
		s1 = ""

		if self.verifier_atomic:
			f = open('my-include/atomic.c')
			lines = f.readlines()
			f.close()
			s1=""
			for line in lines:
				s1+=line

			if self.verifier_atomic:
				if (self.wmm==1):
					f = open('my-include/take_lock_atomic_wmm.c')
				else:
					f = open('my-include/take_lock_atomic.c')				
				lines = f.readlines()
				f.close()
				for line in lines:
					s1+=line

					
			'''
			Gildo: tolgo isBool
			if self.isBool.__len__()>0:
				f = open('my-include/atomicBool.c')
				lines = f.readlines()
				f.close()
				for line in lines:
					s1+=line
			'''
			
		headerBlock = headerBlock.replace('<insert-atomic-function-here>', s1)
		s1=""
		if self.verifier_atomic:
			#s1="intV atomicLast = Read_var_atomic();"
			#s1+="__CPROVER_assume((atomicLast==MaxNumThreads) || (atomicLast==__cs_thread_index) );"
			s1+="&& ( !(ticket_jump > ticket_pos) || (__visible[codeVar][jump]) )"
		headerBlock = headerBlock.replace('<insert-atomic-constrain-here>', s1)
			
		


		arrDecl = ""
		atomicArrDecl = ""
		if (self.isArray.__len__()>0):
			f = open('my-include/array.c')
			lines = f.readlines()
			f.close()
			for line in lines:
				arrDecl+=line
			if self.verifier_atomic:
				f = open('my-include/atomicArray.c')
				lines = f.readlines()
				f.close()
				for line in lines:
					atomicArrDecl+=line
		
		headerBlock = headerBlock.replace('<insert-array-declaration-here>', arrDecl)
		headerBlock = headerBlock.replace('<insert-atomic-array-here>', atomicArrDecl)

		
		
		
		#############		
		#headerBlock = headerBlock.replace('<insert-assume-atomic-here>', '')
		if self.verifier_atomic:
			headerBlock = headerBlock.replace('<insert-assume-atomic-here>', '__CPROVER_assume(visible[thread_pos]);')
		else:
			headerBlock = headerBlock.replace('<insert-assume-atomic-here>', '')
			
		############

		return headerBlock
		
	def __build_check_block(self):
		self.check_block += "\n\nvoid guessMU(void){  "
		self.check_block +="\n "
		self.check_block +="\n "
		self.check_block +="\n//INITIALIZATION OF SHARED VARIABLES "
		self.check_block += self.initializationNew
		self.check_block +="\n//END INITIALIZATION OF SHARED VARIABLES\n"

		self.check_block +="\n__CS_typeM tmp_ticket_pos_terminated[MaxNumThreads];"
		for t in range(0,self.__threadbound):
			self.check_block +="\n	ticket_pos_terminated[%s] = tmp_ticket_pos_terminated[%s];" % (t,t)
			self.check_block +="\n	__CPROVER_assume((tmp_ticket_pos_terminated[%s] >= 0 ) && (tmp_ticket_pos_terminated[%s] < MEM_SIZE + NumVars ));" % (t,t)
		limiteIndirizzo = 500
		if (self.npointers>0):
			self.check_block +="\n\n	//Pointers"
			self.check_block +="\n	intV address_tmp[NumVars];"
			for i in range(0, int(self.NumVars)):
				self.check_block +="\n	address[%s]=address_tmp[%s];"%(i,i)
				if (i>0):
					self.check_block +="\n	__CPROVER_assume( address[%s] > address[%s] );"%(i,i-1)
				#self.check_block +="\n	__CPROVER_assume( address[NumVars-1] < %s );"%(limiteIndirizzo)
			self.check_block +="\n	__CPROVER_assume( address[0] > 0 );"
			###### per provare sigma self.check_block +="\n	__CPROVER_assume( address[%s] < 50 );"%(self.NumVars-1)
					
					
					
					
					
					
					
		if (self.npointers>0) and (self.nmalloc>0):
			self.check_block +="\n\n	//Malloc"
			self.check_block +="\n	intV mallocP_tmp[NumMalloc+1];"
			for i in range(0, int(self.nmalloc)):
				self.check_block +="\n	mallocP[%s]=mallocP_tmp[%s];"%(i,i)
				if (i>0):
					self.check_block +="\n	__CPROVER_assume( mallocP[%s] > mallocP[%s] );"%(i,i-1)
				#self.check_block +="\n	__CPROVER_assume( mallocP[NumMalloc] < %s );"%(limiteIndirizzo)
			self.check_block +="\n	__CPROVER_assume( mallocP[0] > address[%s] );"%(self.nScalars-1)
				
		
		self.check_block +="\n"
		
		if (self.isArray.__len__()>0):
			self.check_block +="\nint values_tmp[MEM_SIZE]; "

		self.check_block +="\n__CS_typeM ticket_tmp[MEM_SIZE]; "
		self.check_block +="\n_Bool visible_tmp[MEM_SIZE]; "
		self.check_block +="\nintV __value_tmp[MEM_SIZE]; "
		self.check_block +="\n__CS_typeM  nondet_memory[NumVars]; "
		self.check_block +="\n__CS_typeM thread_tmp[MEM_SIZE]; "

		ticket_index=0
		self.check_block +="\n	//for each scalar variable we guess the MU"
		#self.check_block +="\nint scalarVariables  = %s; "%(self.isScalar.__len__())
		#print "da __build_check_block- scalar:%s" %(self.isScalar.__len__())
		if (self.isScalar.__len__()>0):
			tmp_index=0
			#num_valid_write = " int num_valid_write = 0"

			if self.verifier_atomic:
				self.check_block +="\n	__CS_type  nondet___atomic;"
				self.check_block +="\n	__CPROVER_assume( (nondet___atomic>0) && (nondet___atomic <= LOCK_SIZE) );"
				self.check_block +="\n	__memory_notvalid_of_atomic = nondet___atomic;"
				self.check_block +="\n	__ticket_atomic[0] = 0;			"
			'''
			if self.lockVariable:
				self.check_block +="\n	__CS_type  nondet___lockV;"
				self.check_block +="\n	__CPROVER_assume( (nondet___lockV>0) && (nondet___lockV <= vLOCK_SIZE) );"
				self.check_block +="\n	__memory_notvalid_of_lockV = nondet___lockV;"
				self.check_block +="\n	__ticket_lockV[0] = 0;			"
			'''

			if self.lockVariable:
				self.check_block +="\n	__CS_type  nondet___lockV[%s];"%(self.variables_locks.__len__())
				i=0
				for item in self.variables_locks:
					self.check_block +="\n	__CPROVER_assume( (nondet___lockV[%s]>0) && (nondet___lockV[%s] <= vLOCK_SIZE) );"%(i,i)
					self.check_block +="\n	__memory_notvalid_of_lockV[%s] = nondet___lockV[%s];"%(item,i)
					self.check_block +="\n	__ticket_lockV[%s][0] = 0;			"%(item)
					i=i+1


				
			for item in self.variables_arr:
				tot_size = 1
				if "__cs_thread_local_COND" in item:
					self.check_block +="\n	%s = MyMalloc(MaxNumThreads+2);"%(item)
				else:
					self.check_block +="\n	%s = MyMalloc(%s);"%(item,self.variables_arr_size[item])
				
					'''
					item_tmp = item.replace("_cs_arr_0","")
					for size in self.Parser.varSize['', item_tmp]:
						tot_size = tot_size * size
					self.check_block +="\n	%s = MyMalloc(%s);"%(item,tot_size)
					'''
			####self.check_block +=num_valid_write
			iVariable=0
			for item in self.isScalar:			
				self.check_block +="\n"
				self.check_block +="\n	//for variable %s: size: %s" % (item,int(self.arrayWriteVars[item]))
				self.check_block +="\n	__ticket[%s][0] = 0;"% (item)

				item_tmp = item.replace("_cs_arr_0","")
				if self.__isArray('',item_tmp):


					tot_size = 1
					for size in self.Parser.varSize['', item_tmp]:
						tot_size = tot_size * size

					#size_tmp = size_tmp.replace("[","").replace("]","")
					#self.check_block +="\n\n	intV address_%s = MyMalloc(%s);"% (item, tot_size)
					'''
					self.check_block +="\n	__CPROVER_assume( address[%s] == MyMalloc(%s) );"%(item,tot_size)
					self.check_block +="\n	__CPROVER_assume( address[%s+1] > address[%s]+%s );"%(item,item,tot_size)
					'''
					self.check_block +="\n	__value[%s][0] = MyMalloc(%s);"%(item,tot_size)
					self.check_block +="\n	__CPROVER_assume( __value[%s][0] > address[%s] );"%(item,item)
					
					
				
				
				
				self.check_block +="\n	__memory_notvalid_of[%s] = nondet_memory[%s];"% (item, iVariable)
				iVariable=iVariable+1
				self.check_block +="\n	__CPROVER_assume( (__memory_notvalid_of[%s]>0) && (__memory_notvalid_of[%s] <= %s_SIZE) );"%(item,item,item)
				tmp_index=tmp_index+1
				self.check_block +="\n"
				
				for i in range(1, int(self.arrayWriteVars[item])+1):
					self.check_block +="\n	__thread_id[%s][%s] = thread_tmp[%s];" % (item,i, ticket_index)
					self.check_block +="\n	__visible[%s][%s] = visible_tmp[%s];" % (item,i, ticket_index)
					self.check_block +="\n	__CPROVER_assume((__thread_id[%s][%s] >= 0) && (__thread_id[%s][%s] < GuessedNumThreads));" %(item,i, item,i)
					self.check_block +="\n	__value[%s][%s] = __value_tmp[%s];" %(item,i, ticket_index)
					self.check_block +="\n	__ticket[%s][%s]=ticket_tmp[%s]; "%(item, i, ticket_index)
					self.check_block +="\n	__CPROVER_assume( (__ticket[%s][%s] < MEM_SIZE)"%(item, i)
					self.check_block +="\n	               && (__ticket[%s][%s]>__ticket[%s][%s])"%(item, i, item, i-1)
					self.check_block +="\n	               && (!__used_ticket[__ticket[%s][%s]]) );"%(item, i)
					self.check_block +="\n	__used_ticket[__ticket[%s][%s]] = 1;"%(item, i)
					self.check_block +="\n"
					ticket_index = ticket_index + 1


				self.check_block +="\n	//__ticket[%s][MEM_SIZE_VARS]=ticket_tmp[%s]; "%(item, ticket_index)
				self.check_block +="\n	__ticket[%s][%s_SIZE]=MEM_SIZE; "%(item,item)
				self.check_block +="\n//	__ticket[%s][0] = 0;"% (item)
				tmp_index=tmp_index+1
				self.check_block +="\n"
				
			if self.verifier_atomic:
				self.check_block +="\n	//for atomic locks"  
				self.check_block +="\n	__ticket_atomic[0] = 0;"
				for i in range(1, int(self.LOCK_SIZE)):
					if (i%2 == 0):
						self.check_block +="\n	__thread_id_atomic[%s] = __thread_id_atomic[%s];" % (i, i-1)
					else:						
						self.check_block +="\n	__thread_id_atomic[%s] = thread_tmp[%s];" % (i, ticket_index)
						self.check_block +="\n	__CPROVER_assume((__thread_id_atomic[%s] >= 0) && (__thread_id_atomic[%s] < GuessedNumThreads));" %(i, i)
					self.check_block +="\n	__ticket_atomic[%s]=ticket_tmp[%s]; "%(i, ticket_index)
					self.check_block +="\n	__CPROVER_assume( (__ticket_atomic[%s] < MEM_SIZE)"%(i)
					self.check_block +="\n	               && (__ticket_atomic[%s]>__ticket_atomic[%s])"%(i, i-1)
					self.check_block +="\n	               && (!__used_ticket[__ticket_atomic[%s]]) );"%(i)
					self.check_block +="\n	__used_ticket[__ticket_atomic[%s]] = 1;"%(i)
					self.check_block +="\n"
					ticket_index = ticket_index + 1


				#self.check_block +="\n	int ticket_index=%s; "%(ticket_index)
				self.ticket_index = ticket_index+1
				self.check_block +="\n	__ticket_atomic[LOCK_SIZE]=MEM_SIZE; "

			if self.lockVariable:
				self.check_block +="\n	//for variable locks"  
				for item in self.variables_locks:
					self.check_block +="\n	__ticket_lockV[%s][0] = 0;"%(item)
					for i in range(1, int(self.vLOCK_SIZE)):
						if (i%2 == 0):
							self.check_block +="\n	__thread_id_lockV[%s][%s] = __thread_id_lockV[%s][%s];" % (item,i,item, i-1)
						else:						
							self.check_block +="\n	__thread_id_lockV[%s][%s] = thread_tmp[%s];" % (item, i, ticket_index)
							self.check_block +="\n	__CPROVER_assume((__thread_id_lockV[%s][%s] >= 0) && (__thread_id_lockV[%s][%s] < GuessedNumThreads));" %(item, i, item, i)
						self.check_block +="\n	__ticket_lockV[%s][%s]=ticket_tmp[%s]; "%(item, i, ticket_index)
						self.check_block +="\n	__CPROVER_assume( (__ticket_lockV[%s][%s] < MEM_SIZE)"%(item, i)
						self.check_block +="\n	               && (__ticket_lockV[%s][%s]>__ticket_lockV[%s][%s])"%(item, i, item, i-1)
						self.check_block +="\n	               && (!__used_ticket[__ticket_lockV[%s][%s]]) );"%(item,i)
						self.check_block +="\n	__used_ticket[__ticket_lockV[%s][%s]] = 1;"%(item, i)
						self.check_block +="\n"
						ticket_index = ticket_index + 1


					self.ticket_index = ticket_index+1
					self.check_block +="\n	__ticket_lockV[%s][vLOCK_SIZE]=MEM_SIZE; "%(item)

			self.check_block +="\n	int ticket_index=%s; "%(ticket_index)
				
				
		else:
			self.check_block +="\nintV __memory_tmp[NumVars][MEM_SIZE]; "
		
		'''
		Gildo: tolgo isBool
		if (self.isBool.__len__()>0):
			self.check_block +="\n_Bool __memory_bool_tmp[%s][MEM_SIZE]; "%(self.isScalar.__len__());
		'''
		'''
		self.check_block +="\n"
		if self.verifier_atomic:
			self.check_block +="\n_Bool visible_tmp[MEM_SIZE];"
			self.check_block +="\nvisible[0] = 1;"
		'''
		
		MEM_SIZE=self.MEM_SIZE
		variables=self.variables
		#gen_i=1
		'''
		Nvars=variables.__len__();
		if (self.verifier_atomic):
			Nvars=Nvars+1
		'''
		



		'''
		GILDO: TODO per array
		self.check_block +="\n"
		self.check_block +="\n"
		if (self.isArray.__len__()>0):
			for i in reversed(xrange(1,MEM_SIZE)):
				#self.check_block +="\n__CPROVER_assume(next[ %s ] == ((tmp_variables[ var_name[%s] ]==0) ? MEM_SIZE : tmp_variables[ var_name[%s] ]));"%(i, i,i)
				self.check_block +="\nnext_write[ %s ] = (((first_write[ var_name[%s] ]==0) || (%s >= memory_notvalid) ) ? MEM_SIZE : first_write[ var_name[%s] ]);"%(i, i, i, i)
				#self.check_block +="\nnext[ %s ] = first_write[ var_name[%s] ];"%(i, i)
				#self.check_block +="\ntmp_variables[ var_name[%s] ] = %s;"%(i, i)
				self.check_block +="\nfirst_write[ var_name[%s] ] = %s;"%(i, i)

				#self.check_block +="\nnext_thread[ %s ] = first_thread[ thread[%s] ];"%(i, i)
				#self.check_block +="\nfirst_thread[ thread[%s] ] = %s;"%(i, i)
			self.check_block +="\nvar_name[ 0 ] = NumVars;"
			self.check_block +="\n"
			self.check_block +="\n"			
		self.check_block +="\n"
		self.check_block +="\n"
		'''

		self.check_block +="\n	/*for each scalar variable, for each thread:"
		self.check_block +="\n	at each position we calculate"
		self.check_block +="\n	what is the next write of that thread of that varable."
		self.check_block +="\n	*/"
		for item in self.isScalar:			
			self.check_block +="\n	//for variable %s" %(item)
			for t in range(0,self.__threadbound):
				self.check_block +="\n     __thw[%s][%s][%s]=MEM_SIZE;"%(item, t, int(self.arrayWriteVars[item]))
			for i in range(int(self.arrayWriteVars[item]+1)-1, 0,-1):
				for t in range(0,self.__threadbound):
					self.check_block +="\n    __thw[%s][%s][%s] =    (__thread_id[%s][%s] == %s) ? %s : __thw[%s][%s][%s] ; "%(item, t, i-1, item, i, t, i, item, t, i)
				self.check_block +="\n "
				
				
				
		if self.verifier_atomic:
			self.check_block +="\n	//for atomic locks"
			for t in range(0,self.__threadbound):
				self.check_block +="\n     __thw_atomic[%s][%s]=%s;"%(t, int(self.LOCK_SIZE)-1,self.LOCK_SIZE)
			for i in range(int(self.LOCK_SIZE)-1, 0,-1):
				for t in range(0,self.__threadbound):
					self.check_block +="\n    __thw_atomic[%s][%s] =    (__thread_id_atomic[%s] == %s) ? %s : __thw_atomic[%s][%s] ; "%(t, i-1, i, t, i, t, i)
				self.check_block +="\n "
				
		if self.lockVariable:
			self.check_block +="\n	//for variable locks"
			for item in self.variables_locks:
				for t in range(0,self.__threadbound):
					self.check_block +="\n     __thw_lockV[%s][%s][%s]=%s;"%(item, t, int(self.vLOCK_SIZE)-1,self.vLOCK_SIZE)
				for i in range(int(self.vLOCK_SIZE)-1, 0,-1):
					for t in range(0,self.__threadbound):
						self.check_block +="\n    __thw_lockV[%s][%s][%s] =    (__thread_id_lockV[%s][%s] == %s) ? %s : __thw_lockV[%s][%s][%s] ; "%(item, t, i-1, item, i, t, i, item, t, i)
					self.check_block +="\n "
				
				
				
		self.check_block +="\n"
		self.check_block +="\n"
		self.check_block +="\n}" 

		return self.check_block


		
	def visit_Label(self, n):
		#if (n.name == 'ERROR'):
		
		#return n.name + ':\n' + self._generate_stmt(n.stmt)
		if (n.name == self.error_label) or (n.name == "ERROR"):

			tmp_errorBlock = errorBlock2
			if self.parsingAtomic == True:
				tmp_errorBlock = tmp_errorBlock.replace('<return_statement>', 'Release_lock__atomic_function();\t<return_statement>')			
			if self.parsingVoidFunction == True:
				return tmp_errorBlock.replace('<return_statement>', 'return') + self._generate_stmt(n.stmt)
			else:
				return tmp_errorBlock.replace('<return_statement>', 'return 0') + self._generate_stmt(n.stmt)
			
			#if self.parsingVoidFunction == True:
			#	return errorBlock.replace('<return_statement>', 'return') + self._generate_stmt(n.stmt)
			#else:
			#	return errorBlock.replace('<return_statement>', 'return 0') + self._generate_stmt(n.stmt)
			
		else:
			return n.name + ':\n' + self._generate_stmt(n.stmt)		
		


	def visit_ID(self, n):
		if self.setParams:
			return n.name
		
		nameVar=n.name
		'''
		if self.equalToGlobalName.has_key(self.currentFunct+"_"+n.name)==True:
			nameVar=self.equalToGlobalName[self.currentFunct+"_"+n.name]
			if self.IsFakeFunct==0:
				return nameVar
		'''
		if self.global_parameters2.has_key(self.currentFunct+"_"+n.name)==True:
			nameVar=self.global_parameters2[self.currentFunct+"_"+n.name]
			#self.logAppend += "\n//namevar: "+self.global_parameters2[self.currentFunct+"_"+n.name]+"---"+self.currentFunct+"_"+n.name

			
		
		if self.__isGlobaVariable(n.name) and self.Parser.varType['',n.name].startswith('pthread_t'):
			return n.name
		
		
		

		if n.name in self.Parser.varNames[''] and self.visitStarted==0: 
			#tmp=n.name
			tmp=nameVar
			f=''

			if self.isInFuncCall:
				self.suffixCall+="___"+n.name
				return "<param-global-null>"
				


			if self.Parser.varArity[f, n.name]>0:
				tmp+="_cs_arr_0"
				if self.isInFuncCall and self.__isArray('', n.name):
					self.suffixCall=n.name
					return "0"
			'''
			Gildo: tolgo isBool
			if (tmp in self.isBool):
				return "Read_Bool("+tmp+")"				
			return "Read("+tmp+")"
			'''
			if tmp.endswith("_cs_arr_0"):
				return "address["+tmp+"]"
			return "Read("+tmp+")"
			
		else: 
			return nameVar

	def __explodeVariable(self, v):
		blocks = []

		# 1: scalar variables
		#
		if self.Parser.varArity['',v] == 0  and not self.Parser.varType['',v].startswith('struct ') and not self.Parser.varType['',v].startswith('union '):
		## if self.Parser.varArity['',v] == 0  and not self.__isStruct('',v) and not self.Parser.varType['',v].startswith('union '):
			# print "> %s,%s  scalar, arity = %s" % ('',v,self.Parser.varArity['',v])
			blocks.extend([v])

		# 2: arrays
		#
		#elif self.Parser.varArity[f,v] > 0  and  not self.Parser.varType[f,v].startswith('struct ') :
		elif self.Parser.varArity['',v] > 0 and not self.Parser.varMallocd['',v] :
			# print "> %s,%s  array, arity = %s" % ('',v,self.Parser.varArity['',v])
			blocks.extend(self.__explodeArray(v, '', v))

		# 3: structs / unions
		#
		elif not self.Parser.varMallocd['',v]:
			# print "> %s,%s  struct, arity = %s" % ('',v,self.Parser.varArity['',v])
			blocks.extend(self.__explodeStruct(v, self.Parser.varType['', v][7:]))

		return blocks


	# Returns all possible tuples of indexes for a variable  v  from function  f.
	#
	# For example, given v[3][2], that is: (0,0), (0,1), (1,0), (1,1), (2,0), (2,1)
	#
	def __genTuples(self, f, v):
		lst = self.Parser.varSize[f,v]
		return reduce(lambda prev, b: [xs + [i] for xs in prev for i in range(0,b)], lst, [[]])


	# Returns all possible fields in a struct  s.
	#
	def __genFields(self, s):
		return self.Parser.varNames[s]


	# Checks whether variable  v  from function  f  is scalar. 
	#
	def __isScalar(self, f, v):
		if self.__isGlobaVariable(v) and not self.__isArray('',v) and not self.__isPointer('',v) and not self.__isStruct('',v):
			return 1
		else:
			return 0
		'''	
		if self.Parser.varArity[f, v] == 0  and not self.Parser.varType[f, v].startswith('struct ') and not self.Parser.varType[f, v].startswith('union '):
			return 1
		else:
			return 0
		'''

	# Return the type of the variable without spaces and modifiers (useful for symbol-table lookups).
	# For example:    'const char *'  ---->  'char'
	#
	def __getBasicType(self, f, v):
		# See what is the type the variable is referring to.
		# First we need to get rid of any type modifiers (e.g. 'const'),
		# then of pointer symbols (*'s) and spaces (' ') to get the basic type
		# for lookup in the list of typedefs.
		#
		basicType = self.Parser.varType[f, v]

		if basicType.startswith('const '): basicType = basicType[6:]

		if ' ' in basicType: basicType = basicType[:basicType.find(' ')]
		if '*' in basicType: basicType = basicType[:basicType.find('*')]

		return basicType		


	# Checks whether variable  v  from function  f  is of a type which refers to a previous typedef.
	# This is used, for example, to see if a given variable is a struct,
	# as the  struct  keyword might be hidden by a typedef (as they usually are!)  
	#
	def __isTypedef(self, f, v):
		if __getBasicType(f,v) in self.typedefs: return 1
		else: return 0


	# Checks whether variable  v  from function  f  is a struct.
	#
	def __isStruct(self, f, v):
		result = 0
		if (f,v) not in self.Parser.varType:
			return 0
		
		if  self.Parser.varType[f, v].startswith('struct '):
			result = 1

		return result


	# Returns the name of the struct a variable refers to, expanding typedefs if necessary.
	#
	def __getStructName(self, s, field):
		name = ''

		#if  self.Parser.varType[f, v].startswith('struct '):
		if  self.parser.varType[s, field].startswith('struct '):
			name = self.Parser.varType[s, field][7:]
		return name


	# Checks whether variable  v  from function  f  is an array.
	#
	def __isArray(self, f, v):
		'''
		if not self.Parser.MuArrayList.has_key(f):
			f=''
			self.logAppend+="\n// Arityyyyyyy:  "+str(self.Parser.varArity[f,v])
	
		if v in self.Parser.MuArrayList[f]: return 1
		else: return 0
		'''
		if (f,v) not in self.Parser.varArity:
			return 0
		if self.Parser.varArity[f,v] > 0: return 1
		else: return 0
		


	# Checks whether variable  v  from function  f  is an array.
	#
	def __isPointer(self, f, v):
		'''
		f1=str(f)
		if v in self.Parser.MuPointerList[f]: return 1
		else: return 0
		'''
		#self.logAppend+="\n\\var: "+v
		#self.logAppend+="\n\\f: "+f
		if (f,v) not in self.Parser.varType:
			return 0
		if self.Parser.varType[f,v].endswith('*'): return 1
		else: return 0
		

	# Recursively explode an array  f  from function  v  (see also __explodeStruct).
	#
	def __explodeArray(self, prefix, f, v):
		
		block = []

		# Arrays are exploded using any possible combination of indexes.
		for tuple in self.__genTuples(f,v):
			indexes = str(tuple).replace(', ', '][')

			if self.__isStruct(f, v):
				structName = self.__getStructName(f, v)
				block.extend(self.__explodeStruct(prefix+indexes, structName))
			else:
				block.extend([str(prefix+indexes)])
		element_arr = []
		i=1
		item_0=""
		for item in block:
			#self.logAppend+="\n\n//__explodeArray: "+ item
			'''
			element_arr.append(item)
			break
			'''
			if i==1:
				item_0 = item
				element_arr.append(item)
			i=i+1

		item_0 = item_0.replace('[', '_cs_arr_')
		item_0 = item_0.replace(']', '')
		item_0 = item_0.replace('.', '_cs_struct_')		
		#self.logAppend+="\n\n//__explodeArray: size of %s = %s " %(item_0,i)
		
		self.variables_arr_size[item_0]=i
					
		return element_arr


	# Recursively explode a struct  s  (see also __explodeArray).
	#
	def __explodeStruct(self, prefix, s):
		
		block = []
		self.logAppend += "\n//in explode:::: "+s
		for f1 in self.Parsermu.structName:
			#self.logAppend += "\n//for "+f1.name
			if f1.name ==s:
				self.logAppend += "\n// sono uguali "+f1.name
				f = f1
				s = f
				
		
		self.logAppend += "\n// dopo sono uguali: "+f.name
		for v in self.Parser.varNames[f]:
			self.logAppend += "\n\n/*id" + str(self.Parser.varID[f,v]) + "  "
			self.logAppend += "'" + str(v) + "'  "
			self.logAppend += "\n         "				
			self.logAppend += "type '" + self.Parser.varType[f, v] + "'  "
			self.logAppend += "kind '" + self.Parser.varKind[f, v] + "'  "
			self.logAppend += "arity '" + str(self.Parser.varArity[f, v]) + "'  "
			self.logAppend += "\n         "				
			self.logAppend += "size '" + str(self.Parser.varSize[f, v]) + "'  "
			#self.logAppend += "mallocd '" + str(self.varMallocd[f,v]) + "'  "
			self.logAppend += "\n         "				
			self.logAppend += "ref '" + str(self.Parser.varReferenced[f, v]) + "'  "
			self.logAppend += "\n         "				
			self.logAppend += "deref '" + str(self.Parser.varDeReferenced[f, v]) + "'  "
			self.logAppend += "\n         "				
			self.logAppend += "occurs '" + str(self.Parser.varOccurrence[f, v]) + "'  */"
		
		'''
		for field in self.__genFields(f):
			self.logAppend+="\n//structName: "+field
			if self.__isArray(f, field):
				block.extend(self.__explodeArray(prefix+'.'+field, f, field))
			elif self.__isStruct(f, field):
				structName = self.__getStructName(f, field)
				block.extend(self.__explodeStruct(prefix+'.'+field, structName))
			else:
				block.extend([prefix+'.'+field])

		'''
			
		# Struct are exploded using any possible field.
		for field in self.__genFields(s):
			#self.logAppend += "\n// field: "+field
			if self.__isArray(s, field):
				block.extend(self.__explodeArray(prefix+'.'+field, s, field))
			elif self.__isStruct(s, field):
				structName = self.__getStructName(s, field)
				block.extend(self.__explodeStruct(prefix+'.'+field, structName))
			else:
				block.extend([prefix+'.'+field])

		return block


	def __isGlobaVariable(self, name):
		if name in self.Parser.varNames['']:  return 1 # only consider global variables
		else: return 0

	def visit_Struct(self, n):
		# Assigns a name to anonymous structs
		if n.name == None:
			n.name = '__CS_anonstruct_' + str(self.currentAnonStructsCount)
			self.currentAnonStructsCount += 1

		# This method is called more than once on the same struct,
		# the following is done only on the first time.
		#
		if n.name not in self.structName:
			self.currentStruct = n.name
			self.structName.append(n.name)
			self.Parser.varNames[self.currentStruct] = []

		oldParsingStruct = self.parsingStruct
		self.parsingStruct = True
		s = self._generate_struct_union(n, 'struct')
		self.parsingStruct = oldParsingStruct

		# Parsing  typedef struct
		'''
		if self.parsingTypedef: 
			print "    PARSING TYPEDEF STRUCT!!!!!!"
			print "       s: " + s 
			print "    name: " + str(n.name) + '\n\n\n'
		'''

		return s

			


	def visit_FuncDef(self, n):


		self.functionBlock1=""



		self.localPointer=[]

		self.currentFunct = n.decl.name


		'''
		#self.equalToGlobalName={}
		for v in self.Parser.varNames[self.currentFunct]:
			if self.__isGlobaVariable(v):
				self.equalToGlobalName[self.currentFunct+"_"+v]="__"+v
		'''


		self.funcName.append(n.decl.name)

		# Note: the function definition is in two parts:
		#       one is 'decl' and the other is 'body'
		decl = self.visit(n.decl)

		if n.decl.name in self.renameFunct1:
			decl = decl.replace (n.decl.name, "__"+n.decl.name+"1")
		
		
		
		
		if n.decl.name == 'main': self.parsingMain = True
		if n.decl.name.startswith('__VERIFIER_atomic') or n.decl.name.startswith('__CSEQ_atomic_'): self.parsingAtomic = True
		if (decl.startswith("void") or decl.startswith("inline void") ) and not decl.startswith("void *"): self.parsingVoidFunction = True
		else: self.parsingVoidFunction = False


		if self.firstFunctionDefinitionDone == False:
			if len(self.Parser.varNames['']) > self.Parser.extraGlovalVarCount:   
				self.unionDeclaration = self.unionDeclaration + '};\n\nunion __CS__u __CS_u;\n\n'

			self.firstFunctionDefinitionDone = True

		body = ''

		# The body is a Compound node
		if n.decl.name.startswith('__VERIFIER_atomic') or n.decl.name.startswith('__CSEQ_atomic_'): # no context switches in atomic functions
			'''
			jump_atomic  = ""
			jump_atomic += self._make_indent(1) + 'Jump_atomic();\n'
			jump_atomic += self._make_indent(1) + 'if (__CS_ret) return;\n'
			body += self.visit(n.body)
			body  = body.replace("Read(","Read_atomic(").replace("Write(","Write_atomic(") 
			i = body.find("{")+1
			body = body[:i]+"\n"+jump_atomic+body[i:]
			'''
			####################
			jump_atomic  = ""
			jump_atomic += self._make_indent(1) + 'Take_lock__atomic_function();\n'
			jump_atomic += self._make_indent(1) + 'if (__CS_ret) return;\n'
			body += self.visit(n.body)
			body  = body.replace("Read(","Read_atomic(").replace("Write(","Write_atomic(") 
			body  = body.replace("Read_Bool(","Read_Bool_atomic(").replace("Write_Bool(","Write_Bool_atomic(")
			body  = body.replace("Read_from_array(","Read_atomic_from_array(").replace("Write_from_array(","Write_atomic_from_array(")
			
			body  = body.replace("return","Release_lock__atomic_function(); return")
			
			#body  = body.replace("Read(","Read_atomic(")
			i = body.find("{")+1
			body = body[:i]+"\n"+jump_atomic+body[i:body.rfind('\n}')]+"\nRelease_lock__atomic_function();\n}"
			####################
			
			#body  = body.replace("{","{\n"+jump_atomic)
		elif self.parsingStruct:
			body += self.visit(n.body)
		else:
			# Add csBlocks as the last statement in each function.
			# This may be unrechable code if the last statement is a return, 
			# but that is fine.
			#
			if not self.parsingMain:
				body += self.visit(n.body)
				body = body[:body.rfind('\n}')]   # Eliminate the last closing braket for the function body compound.
				### body += '\n' + self._make_indent(1) + 'ddd---->' + csBlock + '}\n' 
				body += '\n' + self._make_indent(1) + '}\n' 
			else:
				body += self.visit(n.body)

		# The placeholder <return_statement> is changed to "return" or "return 0",
		# depending on whether the function is void.
		### functionBlock = decl + '\n{\n' + body + '}\n\n'
		functionBlock = decl + '\n' + body + '\n'

		#if decl.startswith("void") and not decl.startswith("void *"): # void function requests "return;"
		if self.parsingVoidFunction == True:
			functionBlock = functionBlock.replace("<return_statement>", "return")
		else: # non void functions request "return 0;"
			functionBlock = functionBlock.replace("<return_statement>", "return 0")

		if n.decl.name == 'main': self.parsingMain = False

		if n.decl.name.startswith('__VERIFIER_atomic') or n.decl.name.startswith('__CSEQ_atomic_'): self.parsingAtomic = False

		if n.decl.name == 'main':
			# Prepare the sequentialised main() function.
			#
			oldMainBlock = functionBlock[functionBlock.find('{')+2:]
			oldMainBlock = oldMainBlock[:oldMainBlock.rfind('}')]
			oldMainBlock = oldMainBlock.replace('main(', 'main_thread(', 1)

			#print "prima:\n\n"+functionBlock
			
			
			functionBlock = mainSimulationBlock


			''' 5.  Eventually, put all parts together.
			'''
			functionBlock = mainSimulationBlock
			
			
			
			str_tmp=""
			'''
			for item in self.variables:
				if item not in self.initializedGlobalVariables:
					if (item!="__atomic"):
						self.initialization += "\n__memory["+item+"][0] = 0;"
			'''
			

			functionBlock = functionBlock.replace('\t<insert-mainthread-here>\n', oldMainBlock)
			functionBlock = functionBlock.replace('\t<insert-main-parameters-decl-here>\n', self.mainParametersDecl);
			#functionBlock = functionBlock.replace('\t<insert-initialization-here>\n', self.initialization);

		
		if self.parsingVoidFunction:
			functionBlock=functionBlock.replace("return 0;","return;")
		else:
			functionBlock=functionBlock.replace(" return;"," return 0;")
			functionBlock=functionBlock.replace("\treturn;","\treturn 0;")
			functionBlock=functionBlock.replace("\nreturn;","\nreturn 0;")
		#functionBlock=functionBlock.replace("insert-end-thread-create-here>",self.__checkEndThread())
		return "\n"+self.functionBlock1+"\n"+functionBlock

	def __checkEndThread(self):
		end_thread_create = ""
		for item in self.isScalar:			
			#end_thread_create += "\n__CPROVER_assume((__last_used_pos_of[%s] < __memory_notvalid_of[%s]) && (__thw[%s][__cs_thread_index][__last_used_pos_of[%s]] >=__memory_notvalid_of[%s]) );"%(item,item,item,item,item)
			end_thread_create += "\n__CPROVER_assume(__thw[%s][__cs_thread_index][__last_used_pos_of[%s]] >=__memory_notvalid_of[%s]) ;"%(item,item,item)
		if (self.verifier_atomic):
			end_thread_create += "\n__CPROVER_assume(__thw_atomic[__cs_thread_index][__last_used_pos_of_atomic] >=__memory_notvalid_of_atomic) ;"
		if self.lockVariable:
			for item in self.variables_locks:
				end_thread_create += "\n__CPROVER_assume(__thw_lockV[%s][__cs_thread_index][__last_used_pos_of_lockV[%s]] >=__memory_notvalid_of_lockV[%s]) ;"%(item,item,item)
		return end_thread_create

	def __checkStartThread(self):
		start_thread_create = ""
		for item in self.isScalar:			
			start_thread_create += "\n__CPROVER_assume(__thw[%s][__cs_thread_index][0] > __last_used_pos_of[%s]);"%(item,item)
		if (self.verifier_atomic):
			start_thread_create += "\n__CPROVER_assume(__thw_atomic[__cs_thread_index][0] > __last_used_pos_of_atomic);"
		if self.lockVariable:
			for item in self.variables_locks:
				start_thread_create += "\n__CPROVER_assume(__thw_lockV[%s][__cs_thread_index][0] > __last_used_pos_of_lockV[%s]);"%(item,item)
		return start_thread_create

	def __MyLastUsedPos(self):
		tmpStr = ""
		tmpStr += "\n   __CS_typeM my__last_used_pos_of[NumVars];"
		if self.verifier_atomic:
			tmpStr += "\n   __CS_typeM my__last_used_pos_of_atomic = __last_used_pos_of_atomic;;"
		if self.lockVariable:
			tmpStr += "\n   __CS_typeM my__last_used_pos_of_lockV[%s];"% (self.variables_locks.__len__())
			for item in self.variables_locks:
				tmpStr += "\n   my__last_used_pos_of_lockV[%s] = __last_used_pos_of_lockV[%s];"% (item,item)
		#print "da __MyLastUsedPos- scalar:%s" %(self.isScalar.__len__())
		for item in self.isScalar:			
			tmpStr += "\n   my__last_used_pos_of[%s] = __last_used_pos_of[%s];" % (item, item)
		#if (self.verifier_atomic):
		#	tmpStr += "\n   my__last_used_pos_of_atomic = __last_used_pos_of_atomic;"
		return tmpStr

	def __FromMyLastUsedPos(self):
		tmpStr = ""
		for item in self.isScalar:			
			tmpStr += "\n   __last_used_pos_of[%s] = my__last_used_pos_of[%s];" % (item, item)
		if (self.verifier_atomic):
			tmpStr += "\n   __last_used_pos_of_atomic = my__last_used_pos_of_atomic;"
		if (self.lockVariable):
			for item in self.variables_locks:
				tmpStr += "\n  __last_used_pos_of_lockV[%s] = my__last_used_pos_of_lockV[%s];"% (item,item)
		return tmpStr			

	def visit_FuncCall(self, n):
		fref = self._parenthesize_unless_simple(n.name)

		# pthread_ primitives currenly not-handled will cause CSeq to quit.
		if fref in notHandledPrimitives:  # e.g. 'pthread_cond_wait', ...
			#print "UNKNOWN (code:02)\n"
			print("Conversion error:  use of '%s' is currently not handled." % fref)
			sys.exit(-1)

		if fref == 'fprintf': 
			return ''
		'''
		if (fref == "__CSEQ_atomic_assert") :
			tmp_errorBlock = "\n Take_lock__atomic_function();"
			tmp_errorBlock += "\n if (!("+self.visit(n.args)+")){\n"
			tmp_errorBlock += "\n     " + errorBlock +"\n"
			tmp_errorBlock += "\n}"
			tmp_errorBlock += "\n Release_lock__atomic_function();"
			tmp_errorBlock = tmp_errorBlock.replace('Read', 'Read_atomic')			
			if self.parsingVoidFunction == True:
				return tmp_errorBlock.replace('<return_statement>', 'return;')# + self._generate_stmt(n.stmt)
			else:
				return tmp_errorBlock.replace('<return_statement>', 'return 0;')# + self._generate_stmt(n.stmt)
		'''	
		if (fref == "__CSEQ_assert"):
			tmp_errorBlock = "\n if (!("+self.visit(n.args)+")){\n" + errorBlock +"\n}"
			#tmp_errorBlock = tmp_errorBlock.replace('<return_statement>', 'Release_lock__atomic_function();\t<return_statement>')			
			
			if self.parsingAtomic == True:
				tmp_errorBlock = tmp_errorBlock.replace('<return_statement>', 'Release_lock__atomic_function();\t<return_statement>')			
			
			if self.parsingVoidFunction == True:
				return tmp_errorBlock.replace('<return_statement>', 'return;')# + self._generate_stmt(n.stmt)
			else:
				return tmp_errorBlock.replace('<return_statement>', 'return 0;')# + self._generate_stmt(n.stmt)
			
			
		if (fref == self.error_label) or (fref == "__CSEQ_assert"):
			tmp_errorBlock = errorBlock
			#tmp_errorBlock = tmp_errorBlock.replace('<return_statement>', 'Release_lock__atomic_function();\t<return_statement>')			
			
			if self.parsingAtomic == True:
				tmp_errorBlock = tmp_errorBlock.replace('<return_statement>', 'Release_lock__atomic_function();\t<return_statement>')			
			
			if self.parsingVoidFunction == True:
				return tmp_errorBlock.replace('<return_statement>', 'return')# + self._generate_stmt(n.stmt)
			else:
				return tmp_errorBlock.replace('<return_statement>', 'return 0')# + self._generate_stmt(n.stmt)
		if fref == 'sscanf': 
			self.isInFuncCall=1
			self.visitStarted=1
			fref  = "Write("
			fref +=self.visit(n.args).split(',')[2].replace("&","")+", "
			fref +="(int)(*"+self.visit(n.args).split(',')[0]+"))"
			self.isInFuncCall=0
			self.visitStarted=0
			return fref
			
		# Maps the original pthread api calls to wSeq-simulated functions. 
		if fref == 'pthread_mutex_lock' or fref == '__cs_mutex_lock': 
			self.visitStarted=1
			self.countLock+=1
			idMutex = self.visit(n.args).replace("&","")
			if self.__isGlobaVariable(idMutex):  
				idMutex = "mutex_"+idMutex
			fref = '__pthread_mutex_lock'+'('+idMutex + ');'
			#fref = '__pthread_mutex_lock'+'();'
			fref += '\n '+self._make_indent()+'if (__CS_ret) return'
			self.visitStarted=0
			return fref
		if fref == 'pthread_mutex_unlock' or fref == '__cs_mutex_unlock': 
			self.visitStarted=1
			#fref = '__pthread_mutex_unlock'+'('+self.visit(n.args).replace("&","") + ');'
			idMutex = self.visit(n.args).replace("&","")
			if self.__isGlobaVariable(idMutex):  
				idMutex = "mutex_"+idMutex
			fref = '__pthread_mutex_unlock'+'('+idMutex + ');'
			#fref = '__pthread_mutex_unlock'+'();'
			fref += '\n '+self._make_indent()+'if (__CS_ret) return'
			self.visitStarted=0
			return fref
		if fref == 'pthread_mutex_init' or fref == '__cs_mutex_init': 
			self.visitStarted=1
			#fref = '__pthread_mutex_init'+'('+self.visit(n.args).replace("&","") + ');'
			parameters = self.visit(n.args).replace("&","").split(',')
			idMutex = parameters[0]
			#self.logAppend+="\n//globale: %s"%(idMutex)
			fref =""
			if self.__isGlobaVariable(idMutex):  
				#self.logAppend+="\n//globale: %s"%(idMutex)
				fref = '__pthread_mutex_init'+'(mutex_'+idMutex + ', '+parameters[1]+');'
			else:
				fref = '__pthread_mutex_init'+'('+parameters[0] + ', '+parameters[1]+');'
			#fref = '__pthread_mutex_init'+'();'
			#fref += '\n '+self._make_indent()+'if (__CS_ret) return'
			self.visitStarted=0
			return fref
		if fref == 'pthread_mutex_destroy' or fref == '__cs_mutex_destroy' : 
			self.visitStarted=1
			#fref = '__pthread_mutex_destroy'+'('+self.visit(n.args).replace("&","") + ');'
			#fref = '__pthread_mutex_destroy'+'();'
			idMutex = self.visit(n.args).replace("&","")
			if self.__isGlobaVariable(idMutex):  
				idMutex = "mutex_"+idMutex
			fref = '__pthread_mutex_destroy'+'('+idMutex + ');'
			#fref += '\n '+self._make_indent()+'if (__CS_ret) return'
			self.visitStarted=0
			return fref
			
		if fref == 'pthread_join' or fref == '__cs_join' : fref = '__pthread_join'
		if fref == 'pthread_create' or fref == '__cs_create': 
			
			self.isInFuncCall=1
			self.visitStarted=1

		
			
			thread_Funct = self.visit(n.args).split(',')[2].replace("&","")[1:]
			nameFunc = "__pthread_create_"+thread_Funct
			if thread_Funct in self.renameFunct1: 
				nameFunc = "__pthread_create___"+thread_Funct+"1"
			#print "\nthreadFunc="+thread_Funct
			#print "\nnameFunc="+nameFunc
			#print "\n"+self.pthread_create_block
			
			
			
			#fref  = "if (nondet_int() || __CS_ret){__CS_ret=1; return 0;}\n"+nameFunc+"("
			fref  = nameFunc+"("
			fref +=self.visit(n.args).split(',')[0]+", "
			fref +=self.visit(n.args).split(',')[1]+", "
			fref +=self.visit(n.args).split(',')[3]+");"
			
			if self.pthread_create_block.find(nameFunc)<0:
				self.pthread_create_block += "\nint "+nameFunc

				

				if thread_Funct in self.renameFunct1:
					self.pthread_create_block += self.pthread_create_block_static.replace("<insert-thread-routine-here>","__"+thread_Funct+"1")
					#self.pthread_create_block += self.pthread_create_block_static.replace("<insert-thread-routine-here>","__"+thread_Funct+"1").replace("insert-start-thread-create-here>",self.__checkStartThread()).replace("insert-end-thread-create-here>",self.__checkEndThread())
					#self.pthread_create_block = self.pthread_create_block.replace("insert-mylast-used-pos-here>",self.__MyLastUsedPos())
					#self.pthread_create_block = self.pthread_create_block.replace("insert-from-mylast-used-pos-here>",self.__FromMyLastUsedPos())
				else: 
					self.pthread_create_block += self.pthread_create_block_static.replace("<insert-thread-routine-here>",thread_Funct)
					#self.pthread_create_block = self.pthread_create_block.replace("insert-mylast-used-pos-here>",self.__MyLastUsedPos())
					#self.pthread_create_block = self.pthread_create_block.replace("insert-from-mylast-used-pos-here>",self.__FromMyLastUsedPos())
				#print self.pthread_create_block_static

				
			
			self.isInFuncCall=0
			self.visitStarted=0
			fref=fref.replace("<param-global-null>","0")
			fref=fref.replace("&0","0")
			return fref
			

		if fref == 'pthread_cond_init' or fref == '__cs_cond_init': 
			self.visitStarted=1
			fref = '__pthread_cond_init'
			fref += '('+str(self.visit(n.args)).replace("&","")+');'
			self.visitStarted=0
			return fref;
		if fref == 'pthread_cond_wait' or fref == '__cs_cond_wait': 
			self.visitStarted=1
			fref  = '__pthread_cond_wait'
			fref += '(lock_cond_0+__cs_thread_index,'+str(self.visit(n.args)).replace("&","")+');'
			fref += '\n '+self._make_indent()+'if (__CS_ret) return;'
			self.visitStarted=0
			return fref;
		if fref == 'pthread_cond_signal' or fref == '__cs_cond_signal': 
			self.visitStarted=1
			fref = '__pthread_cond_signal'
			fref += '('+str(self.visit(n.args)).replace("&","")+', lock_cond_0);'
			fref += '\n '+self._make_indent()+'if (__CS_ret) return;'
			self.visitStarted=0
			return fref;

		if fref == 'pthread_exit' or fref == '__cs_exit':
			fref  = '//__pthread_exit(NULL);'
			#fref += '\n'+self._make_indent()+'if (__CS_ret) return;'
			#fref += '\n'+self._make_indent()+'__CS_ret=1; '
			#fref += '\n'+self._make_indent()+'terminated[__cs_thread_index]=1;'
			#fref += '\n'+self._make_indent()+'return;'
			return fref 

		if fref == 'printf':
			fref = ''
			return fref 

		if fref == 'assume': fref = '__CPROVER_assume'
		if fref == '__ESBMC_assume': fref = '__CPROVER_assume'
		if fref == '__VERIFIER_assume': fref = '__CPROVER_assume'
		if fref == '__CSEQ_assume': fref = '__CPROVER_assume'

		if fref == 'assert': fref = 'assert'
		if fref == '__ESBMC_assert': fref = 'assert'
		if fref == '__CSEQ_assert': fref = 'assert'
		if fref == '__cs_safe_malloc': fref = 'malloc'
		#if fref == '__VERIFIER_assert': fref = 'assert'

		# Mapping of standard verifier function calls in the main()
		if fref == '__VERIFIER_nondet_int': fref = '___XXXXX__nondet_int'
		if fref == '__VERIFIER_assume': fref = '___XXXXX__assume'
		
		if fref == '__ESBMC_atomic_begin' or fref == '__VERIFIER_atomic_begin' or fref == '__CSEQ_atomic_begin' or fref == '__CS_atomic_begin':
			fref = 'Take_lock__atomic_function()'
			fref = '__pthread_mutex_lock()'
			self.countLock+=1			
			#fref = '//cseq: atomic section starts here '
			return fref;
			#fref = '//cseq: atomic section starts here '
			#fref = '\nTake_lock__atomic_function '
			#self.parsingAtomic = True
		
		if fref == '__ESBMC_atomic_end' or fref == '__VERIFIER_atomic_end' or fref == '__CSEQ_atomic_end' or fref == '__CS_atomic_end':
			fref = 'Release_lock__atomic_function()'
			fref = '__pthread_mutex_unlock()'
			#fref = '//cseq: atomic section stops here '
			return fref;
			#fref = '//cseq: atomic section stops here '
			#fref = '\nRelease_lock__atomic_function '
			#self.parsingAtomic = False 

			
		if fref in self.renameFunct1:
			fref="__"+fref

		if fref=="strcpy":
			tmp_args = self.visit(n.args).split(",")
			tmp_arg1 = tmp_args[0].replace("Read(","").replace(")","")
			tmp_decl_name = "strcpy_"+tmp_arg1
			if tmp_decl_name not in self.funcName:
				tmp_strcpy_block="int "+tmp_decl_name+"(const char *s)\n"
				tmp_strcpy_block+="{\n"
				tmp_strcpy_block+="	int i=0;\n"
				#tmp_strcpy_block+="	if (nondet_int()) {return 0;}\n"
				tmp_strcpy_block+="	Jump();\n"
				tmp_strcpy_block+="	while(s[i])\n"
				tmp_strcpy_block+="	{\n"
				tmp_strcpy_block+="		//if (Read_atomic_from_array("+tmp_arg1+"_cs_arr_0+i) > Read_atomic_from_array("+tmp_arg1+")){__CS_ret=1; return 0;}\n"
				tmp_strcpy_block+="		Write_ptr (Read_atomic("+tmp_arg1+")+i, s[i]);\n"
				tmp_strcpy_block+="		i++;\n"
				tmp_strcpy_block+="	}\n"
				tmp_strcpy_block+="	return 1;\n"
				tmp_strcpy_block+="}\n"
				
				self.functionBlock1+="\n" + tmp_strcpy_block + '\n'
				self.funcName.append(tmp_decl_name)		

			return tmp_decl_name + "("+tmp_args[1]+");"


		self.isInFuncCall=1
		self.suffixCall=""
		tmp_declaration=self.visit(n.args)
		self.isInFuncCall=0
		notReplace=["__CPROVER_assume","__VERIFIER_assert","___XXXXX__nondet_int","__pthread_join","exit","malloc","assert","strcpy","__cs_safe_malloc","ldv_assert"]
		if self.suffixCall!="" and fref not in notReplace: 
			
			tmp_fref = fref 
			fref = fref+self.suffixCall+'('+tmp_declaration+ ')'
			
			self.visit_FuncDef_fake(self.Parser.funcASTNode[tmp_fref], fref)	
			fref=fref.replace("<param-global-null>","0")
			fref=fref.replace("&0","0")

			self.suffixCall=""
			return fref
		
		if fref.startswith('__VERIFIER_atomic') or fref.startswith('__CSEQ_atomic_'):
			#return fref + '(' + self.visit(n.args) + ');'+'\nif (nondet_int()	){__CS_ret=1; return 0;}\n'
			return fref + '(' + self.visit(n.args) + ');'

		'''
		if fref.startswith('__CPROVER_assume'):
			return 'if (nondet_int()	){__CS_ret=1; return 0;} ' + fref + '(' + self.visit(n.args) + ');\n'
		'''
		if (not (self.currentFunct.startswith('__VERIFIER_atomic')) and (not (self.currentFunct.startswith('__CSEQ_atomic_')))) and fref.startswith('__CPROVER_assume'):
			return 'if (nondet_int()	){__CS_ret=1; return 0;} ' + fref + '(' + self.visit(n.args) + ');\n'
			
			
		return fref + '(' + self.visit(n.args) + ')'



	def _min4(self, i1, i2, i3, i4):
		min=500
		#if i1>=0 and i2<min:
		if i1>=0 and i1<min:
			min=i1
		if i2>=0 and i2<min:
			min=i2
		if i3>=0 and i3<min:
			min=i3
		if i4>=0 and i4<min:
			min=i4
		return min

		

	def __first_ID(self, tmp):
		i1= tmp.find("->")
		i2= tmp.find("[")
		i3= tmp.find("_cs_struct_")
		i4= tmp.find("_cs_arr_0")
		min=self._min4(i1, i2, i3, i4)

		
		if min==500:
			tmp_varname=tmp
		else:
			tmp_varname=tmp[:min]
		return tmp_varname		



	def visit_UnaryOp(self, n):

		operand = self._parenthesize_unless_simple(n.expr)

		self.visitStarted=1
		tmp=self._parenthesize_unless_simple(n.expr)
		self.visitStarted=0

		tmp_varname=tmp

		
			
		
		if n.op == '*':
				#self.logAppend+="\n\n//operator *::"+tmp_varname+"---"+self.whereInAssignment
				if self.whereInAssignment=="r" or self.whereInAssignment=="":
					#self.logAppend+="\n\n//destra di assign:"+tmp_varname
					if self.__isScalar('',tmp_varname) and self.parsingAtomic==True:
						return 'Read_atomic('+tmp_varname+')'
					if self.__isPointer('',tmp_varname):
						return 'Read_ptr(Read('+tmp_varname+'))'
					#self.logAppend+="\n//"+'Read_ptr('+tmp_varname+')'
					#return 'Read_ptr('+tmp_varname+')'
			
				if self.whereInAssignment=="l":
					if self.__isPointer('',tmp_varname):
						return 'Write_ptr(Read('+tmp_varname+'))'
					if self.__isScalar('',tmp_varname) and self.parsingAtomic==True:
						return 'Write_atomic('+tmp_varname+')'
					if self.__isScalar('',tmp_varname):
						return 'Write('+tmp_varname+')'
					#return 'Write_ptr('+tmp_varname+')'
			
			
				#return 'Read_ptr('+tmp_varname+')'
				#return 'Read('+tmp_varname+')'
		elif n.op == '&':
				#self.logAppend+="\n\n//operator &::"+tmp_varname+"---"+self.whereInAssignment
				if self.whereInAssignment=="r":
					if self.__isScalar('',tmp_varname):
						return 'address['+tmp_varname+']'		
		
					return tmp_varname.replace("Read_ptr(address","(address")
		
	
		tmp_varname=self.__first_ID(tmp)
		rval_str="1"
		s=""		
		
		#if tmp_varname in self.Parser.varNames[''] or self.currentFunct+"__"+tmp_varname in self.global_parameters: # only consider global variables
		if tmp_varname in self.Parser.varNames['']: # only consider global variables
			jumpYes=""
#			if self.parsingAtomic==False:
#				jumpYes="Jump();\n"+self._make_indent()
			jumpYes=""
			if n.op == 'p++':
				return jumpYes+'Write(%s, Read(%s)+ 1)' % (tmp, tmp)
			elif n.op == 'p--':
				return jumpYes+'Write(%s, Read(%s)- 1)' % (tmp, tmp)
			elif n.op == '--':
				return jumpYes+'Write(%s, Read(%s)- 1)' % (tmp, tmp)
			elif n.op == 'sizeof':
				return 'sizeof(%s)' % self.visit(n.expr)
			else:
				if self.__isStruct('', tmp_varname) and self.isInFuncCall and n.op=="&":
					return '<param-global-null>' 
				return '%s%s' % (n.op, operand)
		else:
			return super(lazyseq, self).visit_UnaryOp(n)
		
		
	'''		
	def visit_UnaryOp(self, n):

		operand = self._parenthesize_unless_simple(n.expr)

		self.visitStarted=1
		tmp=self._parenthesize_unless_simple(n.expr)
		self.visitStarted=0

		tmp_varname=self.__first_ID(tmp)

		
	
		rval_str="1"
		s=""		
		
		#if tmp_varname in self.Parser.varNames[''] or self.currentFunct+"__"+tmp_varname in self.global_parameters: # only consider global variables
		if tmp_varname in self.Parser.varNames['']: # only consider global variables
			jumpYes=""
#			if self.parsingAtomic==False:
#				jumpYes="Jump();\n"+self._make_indent()
			jumpYes=""
			if n.op == 'p++':
				return jumpYes+'Write(%s, Read(%s)+ 1)' % (tmp, tmp)
			elif n.op == 'p--':
				return jumpYes+'Write(%s, Read(%s)- 1)' % (tmp, tmp)
			elif n.op == '--':
				return jumpYes+'Write(%s, Read(%s)- 1)' % (tmp, tmp)
			elif n.op == 'sizeof':
				return 'sizeof(%s)' % self.visit(n.expr)
			elif n.op == '*':
				self.logAppend+="\n\n//operator *::"+tmp_varname+"---"+self.whereInAssignment
				if self.whereInAssignment=="r":
					self.logAppend+="\n\n//destra di assign:"+tmp_varname
					if self.__isPointer('',tmp_varname):
						return 'Read_ptr(Read('+tmp_varname+'))'
					return 'Read_ptr('+tmp_varname+')'
			
				if self.whereInAssignment=="l":
					if self.__isPointer('',tmp_varname):
						return 'Write_ptr(Read('+tmp_varname+'))'
			
			
				#return 'Read_ptr('+tmp_varname+')'
				#return 'Read('+tmp_varname+')'
			elif n.op == '&':
				self.logAppend+="\n\n//operator &::"+tmp_varname+"---"+self.whereInAssignment
				if self.whereInAssignment=="r":
					if self.__isScalar('',tmp_varname):
						return 'address['+tmp_varname+']'
			else:
				if self.__isStruct('', tmp_varname) and self.isInFuncCall and n.op=="&":
					return '<param-global-null>' 
				return '%s%s' % (n.op, operand)
		else:
			return super(lazyseq, self).visit_UnaryOp(n)

	'''

	def visit_Assignment(self, n):
	
		self.setParams=1
		rval_str_noVisit=""
		self.whereInAssignment="l"
		#self.logAppend+="\n//prima visita sx"
		tmp=str(self.visit(n.lvalue))
		self.whereInAssignment="r"
		#self.logAppend+="\n//prima visita dx"
		rval_str_noVisit = self._parenthesize_if(n.rvalue, lambda n: isinstance(n, pycparser.c_ast.Assignment))
		if tmp.startswith("__cs_param_"):
			#rval_str_noVisit = self._parenthesize_if(n.rvalue, lambda n: isinstance(n, pycparser.c_ast.Assignment))
			#self.setParams=0
			#self.logAppend += "\n//"+tmp+"="+rval_str_noVisit
			if self.__isPointer('',rval_str_noVisit) or self.__isArray('',rval_str_noVisit):
				#self.equalToGlobalName[self.currentFunct+"_"+tmp]=rval_str_noVisit
				self.global_parameters2[self.currentFunct+"_"+tmp]=rval_str_noVisit
				#self.logAppend += "\n//"+tmp+"="+rval_str_noVisit
				return ""
		self.setParams=0
		
		
		self.whereInAssignment="r"
		#self.inGlobalPointer=0
		#self.logAppend+="\n//seconda visita dx"
		rval_str = self._parenthesize_if(n.rvalue, lambda n: isinstance(n, pycparser.c_ast.Assignment))
		#tmp_inGlobalPointer=self.inGlobalPointer
		#self.inGlobalPointer=0
		#self.whereInAssignment=""

		#self.logAppend +=  "\n//assignment: "+tmp+"="+rval_str_noVisit+";"

		self.whereInAssignment="l"
		#self.logAppend+="\n//seconda visita sx"
		if self._is_simple_node(n.lvalue):
			self.visitStarted=1
			tmp=str(self.visit(n.lvalue))
			self.visitStarted=0
		else:
			tmp=str(self.visit(n.lvalue))		
		is_an_array = 0
		
		#print "prima"+tmp
		if tmp.startswith("Read_from_array"):
			is_an_array = 1
			tmp=tmp[16:]
			tmp=tmp[:len(tmp)-1]
		elif tmp.startswith("Read"):
			tmp=tmp[5:]
			tmp=tmp[:len(tmp)-1]
		elif tmp.startswith("*"):
			tmp=tmp[1:]
		#print "dopo"+tmp
			
		tmp_varname=self.__first_ID(tmp)
		#self.logAppend+="\n//assignment: "+rval_str_noVisit
		'''
		if rval_str_noVisit.startswith("&") and self.__isScalar('',rval_str_noVisit.startswith("&")):
				rval_str="address[%s]"%rval_str_noVisit.replace("&","")
		elif rval_str_noVisit.startswith("*") and self.__isPointer('',rval_str_noVisit.startswith("*")):
			rval_str="Read_ptr(%s,0)"%rval_str_noVisit.replace("*","")
		'''
		
		
		
		'''
		if self.__isPointer('',rval_str_noVisit) or rval_str_noVisit.startswith("&") or self.__isArray('',rval_str_noVisit):
			self.logAppend +=  "\n//dentro:  "+tmp+"="+rval_str_noVisit.replace("&","")+";"
			tmp_rval = rval_str_noVisit.replace("&","")
			#if it is a scalar global variable
			#example: p=&i; --> Write (p, address[i]);  --- where i is a scalar global variable and p is a global pointer
			if self.__isGlobaVariable(tmp_rval) and not self.__isArray('',tmp_rval) and not self.__isPointer('',tmp_rval):
				rval_str="address[%s]"%tmp_rval
			tmp_rval = rval_str_noVisit.replace("*","")
			if self.__isPointer('',tmp_rval):
		'''

		
		
#		rval_str=rval_str.replace("Read(","Read_atomic(");
		
		#if tmp_varname in self.Parser.varNames[''] or self.currentFunct+"_"+tmp_varname in self.global_parameters: # only consider global variables
		if tmp_varname in self.Parser.varNames['']: # only consider global variables

			if rval_str.find("malloc")>=0:  
				if rval_str.find("__CS_pthread_mutex_t")>=0 or rval_str_noVisit.find("__cs_mutex_t *")>=0:
					return ""
				if rval_str.find("*")<0:
					return "Write("+tmp_varname+", " +tmp_varname+" + 1)"
				else: return "Write("+tmp_varname+", MyMalloc("+rval_str.split("*")[len(rval_str.split("*"))-1]+")"		
				#else: return "Write("+tmp_varname+", " +tmp_varname+"_cs_arr_0 + "+rval_str.split("*")[len(rval_str.split("*"))-1]		

			s=""

			
			
			if (self.speedup==1):
				#####speed up
				tmp=tmp.replace("Read(","Read_atomic(")
				if self.parsingAtomic==False:
					s="Jump();\n"+self._make_indent()



			'''
			important
			if self.__isPointer('',tmp_varname):
				s+= "if (Read_atomic("+tmp+")>= Read_atomic("+tmp_varname+")){__CS_ret \\ 1; return 0;}\n"+self._make_indent()
				#print s
			'''
			
			
			
			#if (tmp_varname+"_cs_arr_0") in self.isArray:
			#non lo faccio entrare
			if 0 and ((is_an_array==1) or ((tmp_varname+"_cs_arr_0") in self.isArray)):
				s += 'Write_from_array(%s, %s %s)' % (tmp, n.op, rval_str)
				s = s.replace('+=', "Read_from_array("+tmp+")"+"+" )			
				s = s.replace('-=', "Read_from_array("+tmp+")"+"-" )			
				'''
				Gildo: tolgo isBool
				elif (tmp_varname in self.isBool):
					s += 'Write_Bool(%s, %s %s)' % (tmp, n.op, rval_str)
					s = s.replace('+=', "Read_Bool("+tmp+")"+"+" )			
					s = s.replace('-=', "Read_Bool("+tmp+")"+"-" )			
				'''
			else:
				if (self.speedup==1):
					#####speed up
					s += 'Write_atomic(%s, %s %s)' % (tmp, n.op, rval_str)
					s = s.replace('+=', "Read_atomic("+tmp+")"+"+" )			
					s = s.replace('-=', "Read_atomic("+tmp+")"+"-" )
				else:
					s += 'Write(%s, %s %s)' % (tmp, n.op, rval_str)
					s = s.replace('+=', "Read("+tmp+")"+"+" )			
					s = s.replace('-=', "Read("+tmp+")"+"-" )			

			s = s.replace(', =', ", " )			
			s = s.replace('(=', "(" )			
			s = s.replace('\\', "=" )			
		
		else:
			'''
			if rval_str.find(" malloc")>=0 or rval_str.find(")malloc")>=0:  
				print("malloc on local variables is currently not handled.")
				sys.exit(-1)
			'''	
			tmp_lvalue=self.visit(n.lvalue)
			'''
			if tmp_inGlobalPointer==1:
				if (rval_str.startswith("*((int *)")):
					rval_str=rval_str.replace("*((int *)", "Read(")
				elif tmp_lvalue not in self.localPointer:
					self.localPointer.append(tmp_lvalue)
			'''
			if tmp_lvalue.startswith("*((int *)"):
				tmp_lvalue=tmp_lvalue.replace("*((int *)","Write(").replace(")",", ")
				s='%s %s)' % (tmp_lvalue, rval_str)
			else:
				s = '%s %s %s' % (tmp_lvalue, n.op, rval_str)
			
			s=s.replace("(void *) (&","(void *) (")
		
		s = s.replace(");)","))") #reorder benchmark...
		
		'''
		if tmp.startswith("Write_ptr("):
			s = s.replace(") =",",") #reorder...
			s +=')'
		'''
		if tmp.startswith("Write"):
			s = s.replace(") =",",") #reorder...
			s +=')'
		
		#self.logAppend+="\n//esco da assignment"
		self.whereInAssignment=""
		
		return s		
		
	def visit_Decl(self, n, no_type=False):
		initExpression = ''
		#self.lastDeclarationL = ''
		#self.lastDeclarationR = ''

		


		
		
		# no_type is used when a Decl is part of a DeclList, where the type is
		# explicitly only for the first declaration in a list.
		#
		s = n.name if no_type else self._generate_decl(n)
		### print "NEW DECLARATION %s TYPE:%s\n" % (n.name, n.type)
		
		#if self.currentFunct=="scull_open" and n.name=="__i":
		#	print "decl="+ n.name + "\ns="+s
		
		n_name=n.name
		
		
		'''
		if self.equalToGlobalName.has_key(self.currentFunct+"_"+n.name)==True:
			#print "decl="+ n.name + "------s="+self.equalToGlobalName[n.name]
			s=s[:len(s)-len(n.name)] + self.equalToGlobalName[self.currentFunct+"_"+n.name]
			n_name=self.equalToGlobalName[self.currentFunct+"_"+n.name]			
			#print "decl="+ n.name 
		'''
		

		# Transform global variables into arrays.
		# If already the original variable is an array, add another dimention.
		#
		if self.indent_level < 1 and self.parsingFuncDecl == False and 'FuncDecl' not in str(n.type) and 'Struct' not in str(n.type) and 'Union' not in str(n.type):
			self.indent_level+=1
			indent = self._make_indent();
			self.indent_level-=1

			if s.find(' '+n_name+'[') == -1: s = s 
			else: s = s.replace(' '+n_name+'[', ' '+n_name+'[')

			# Remove the  static  modifier before global variables,
			# or in a struct that'll give syntax error.
			self.unionDeclaration += indent + s.replace('static ', '') + ';\n'

			# Dynamically allocated memory assigned to pointers..
			dynSize = ''

			'''
			if self.__isPointer(self.currentFunct,n_name): #### TODO the var here must be GLOBAL!!!
				s2 = s.replace(' *'+n_name, ' *__CS_cp_'+n_name)
			else:
				s2 = s.replace(' '+n_name, ' __CS_cp_'+n_name)
			
			self.copyVariableDeclaration += indent + s2 + ';'+ dynSize +'\n'
			'''




		#self.lastDeclarationL = s

		
		
		
		if n.bitsize: s += ' : ' + self.visit(n.bitsize)

		if n.init:
			if not (self.indent_level < 1 and self.parsingFuncDecl == False and 'FuncDecl' not in str(n.type) and 'Struct' not in str(n.type) and 'Union' not in str(n.type)):
				bracketR = bracketL = ''
			else:
				bracketL = '{'
				bracketR = '}'

				
			if isinstance(n.init, pycparser.c_ast.ExprList): s += ' = {' + bracketL + self.visit(n.init) + bracketR + '}'
			else: s += ' = ' + bracketL + self.visit(n.init) + bracketR
			
			if self.__isGlobaVariable(n_name):
				if (self.visit(n.init)!="0"):
					self.initializationNew+="\n__value["+n_name+"][0] = "				
					#self.initialization+="\n__memory["+n_name+"][0] = "				
					if isinstance(n.init, pycparser.c_ast.ExprList): 
						#self.initialization += self.visit(n.init) + ')'
						self.initializationNew += self.visit(n.init) + ')'
					else: 
						#self.initialization += self.visit(n.init) + ';'
						self.initializationNew += self.visit(n.init) + ';'
					#self.initializedGlobalVariables.append(n_name)				
					s=""

		#s=s.replace('[__CS_ROUNDS]','')


			
		if self.__isGlobaVariable(n_name) and not self.Parser.varType['',n_name].startswith('pthread_t'):
			s=""
				
				
		self.lastDeclaration = s

		return s		
		
	def visit_ArrayRef(self, n):
		tmp_isInArrayOrStruct=self.isInArrayOrStruct
		self.isInArrayOrStruct="a"
		arrref = self._parenthesize_unless_simple(n.name)


		tmp_visitStarted=self.visitStarted
		self.visitStarted=1
		tmp=self.__first_ID(self._parenthesize_unless_simple(n.name))
		self.visitStarted=tmp_visitStarted

		ret=""
		#if tmp not in self.Parser.varNames[''] and self.currentFunct+"_"+tmp not in self.global_parameters: # only consider global variables
		if tmp not in self.Parser.varNames['']: # only consider global variables
			ret = arrref + '[' + self.visit(n.subscript) + ']'
		elif self.__isGlobaVariable(tmp) and self.Parser.varType['',tmp].startswith('pthread_t'):
			ret = arrref + '[' + self.visit(n.subscript) + ']'
		elif self.__isPointer('',tmp):
			ret = 'Read_ptr(Read('+tmp + ') +' + self.visit(n.subscript)+')'
			#self.logAppend+="\n//pointer"+tmp
			if self.whereInAssignment=="r":
				ret = 'Read_ptr(Read('+tmp + ') +' + self.visit(n.subscript)+')'
				#ret = 'Read_ptr(Read('+arrref + '_cs_arr_0)+' + self.visit(n.subscript)+')'
			if self.whereInAssignment=="l":
				ret = 'Write_ptr(Read('+tmp + ') +' + self.visit(n.subscript)+')'
			
		elif self.visitStarted==0:
			self.visitStarted=1
			arrref = self._parenthesize_unless_simple(n.name)
			self.visitStarted=0
			#ret = "Read("+arrref + '_cs_arr_0+' + self.visit(n.subscript) + ')'
			ret = 'Read_ptr('+arrref + '_cs_arr_0 +' + self.visit(n.subscript)+')'
			#ret = arrref + '_cs_arr_0+' + self.visit(n.subscript)
			if self.whereInAssignment=="r":
				ret = 'Read_ptr('+arrref + '_cs_arr_0 +' + self.visit(n.subscript)+')'
				#ret = 'Read_ptr(Read('+arrref + '_cs_arr_0)+' + self.visit(n.subscript)+')'
			if self.whereInAssignment=="l":
				ret = 'Write_ptr('+arrref + '_cs_arr_0 +' + self.visit(n.subscript)+')'
				#ret = 'Write_ptr(Read('+arrref + '_cs_arr_0)+' + self.visit(n.subscript)+')'
		else:
			self.visitStarted=0
			ret = arrref + '_cs_arr_0+' + self.visit(n.subscript)
			if self.whereInAssignment=="r":
				ret = 'Read_ptr('+arrref + '_cs_arr_0 +' + self.visit(n.subscript)+')'
				#ret = 'Read_ptr(Read('+arrref + '_cs_arr_0)+' + self.visit(n.subscript)+')'
			if self.whereInAssignment=="l":
				ret = 'Write_ptr('+arrref + '_cs_arr_0 +' + self.visit(n.subscript)+')'
				#ret = 'Write_ptr(Read('+arrref + '_cs_arr_0)+' + self.visit(n.subscript)+')'

		self.isInArrayOrStruct=tmp_isInArrayOrStruct
		return ret
		

	def visit_StructRef(self, n):
		tmp_isInArrayOrStruct=self.isInArrayOrStruct
		self.isInArrayOrStruct="a"

		sref = self._parenthesize_unless_simple(n.name)


		tmp_visitStarted=self.visitStarted
		self.visitStarted=1
		tmp=self.__first_ID(self._parenthesize_unless_simple(n.name))
		self.visitStarted=tmp_visitStarted

		ret = ""
		#if tmp not in self.Parser.varNames[''] and self.currentFunct+"_"+tmp not in self.global_parameters: # only consider global variables
		if tmp not in self.Parser.varNames['']: # only consider global variables
			ret = sref + n.type + self.visit(n.field)
		elif self.__isGlobaVariable(tmp) and self.Parser.varType['',tmp].startswith('pthread_t'):
			ret = sref + n.type + self.visit(n.field)
		elif self.visitStarted==0:
			self.visitStarted=1
			sref = self._parenthesize_unless_simple(n.name)
			self.visitStarted=0
			ret = "Read("+sref + "_cs_struct_" + self.visit(n.field)+")"
		else:
			self.visitStarted=0
			ret = sref + "_cs_struct_" + self.visit(n.field)

		self.isInArrayOrStruct=tmp_isInArrayOrStruct
		return ret

	def visit_FuncDef_fake(self, n, fCall):
		

		tmp_currentFunct=self.currentFunct
		tmp_parsingAtomic=self.parsingAtomic
		
		tmpNewFakeFunct=n.decl.name+self.suffixCall
		if n.decl.name.startswith('__VERIFIER_atomic') or n.decl.name.startswith('__CSEQ_atomic_'): self.parsingAtomic = True
		self.IsFakeFunct=1
		if tmpNewFakeFunct in self.funcName:
			self.currentFunct = tmp_currentFunct
			self.parsingAtomic = tmp_parsingAtomic
			return



		#self.localPointer=[]

		self.currentFunct = n.decl.name
		#self.logAppend+="\n//start function: "+self.currentFunct
		#self.logAppend+="\n//fCall: "+fCall

		decl = self.visit(n.decl).replace(n.decl.name, tmpNewFakeFunct)
		#self.logAppend+="\n\n//decl: "+decl
		#self.logAppend+="\n//fCall: "+fCall
		
		#print decl
		

		'''
		#self.equalToGlobalName={}
		for v in self.Parser.varNames[self.currentFunct]:
			if self.__isGlobaVariable(v):
				self.equalToGlobalName[tmpNewFakeFunct+"_"+v]="__"+v
				self.logAppend+="\nparameter is global variable: "+tmpNewFakeFunct+"_"+v+"----"+self.equalToGlobalName[tmpNewFakeFunct+"_"+v]
				#print "\nparameter is global variable: "+tmpNewFakeFunct+"_"+v+"----"+self.equalToGlobalName[tmpNewFakeFunct+"_"+v]
		'''

				
				
				
		tmpArrParamCall = fCall.split(",")
		iCount=1
		iCount2=1
		#self.logAppend+="\n//suffix-call: "+self.suffixCall
		for x in tmpArrParamCall:
			if x.find("<param-global-null>")>=0:
				iCount1=1
				for v in self.Parser.varNames[self.currentFunct]:
					if self.Parser.varKind[self.currentFunct, v]=='p' and iCount1==iCount:
						#self.logAppend +="\n//var: "+v
						#self.logAppend +="\n//self.suffixCall: "+self.suffixCall.split("___")[iCount2]
						self.global_parameters2[tmpNewFakeFunct+"_"+v]=self.suffixCall.split("___")[iCount2]
						iCount2+=1
					
					iCount1+=1
			iCount+=1
			
		

		originalCurrentFunct = self.currentFunct
		self.currentFunct = tmpNewFakeFunct
		body = self.visit(n.body)
		
		
		self.funcName.append(self.currentFunct)		
		if n.decl.name.startswith('__VERIFIER_atomic') or n.decl.name.startswith('__CSEQ_atomic_'): # no context switches in atomic functions
			'''
			jump_atomic  = ""
			jump_atomic += self._make_indent(1) + 'Jump_atomic();\n'
			jump_atomic += self._make_indent(1) + 'if (__CS_ret) return;\n'
			body  = body.replace("Read(","Read_atomic(").replace("Write(","Write_atomic(") 
			i = body.find("{")+1
			body = body[:i]+"\n"+jump_atomic+body[i:]
			'''
			
			##################
			jump_atomic  = ""
			jump_atomic += self._make_indent(1) + 'Take_lock__atomic_function();\n'
			jump_atomic += self._make_indent(1) + 'if (__CS_ret){ return;}\n'
			body  = body.replace("Read(","Read_atomic(").replace("Write(","Write_atomic(")
			body  = body.replace("Read_Bool(","Read_Bool_atomic(").replace("Write_Bool(","Write_Bool_atomic(")
			body  = body.replace("Read_from_array(","Read_atomic_from_array(").replace("Write_from_array(","Write_atomic_from_array(")
			
			#body  = body.replace("Read(","Read_atomic(")
			i = body.find("{")+1
			body = body[:i]+"\n"+jump_atomic+body[i:body.rfind('\n}')-3]+"\nRelease_lock__atomic_function();\n}"
			################

			

		body = body.replace("__cs_param_"+originalCurrentFunct,"__cs_param_"+tmpNewFakeFunct)
		self.functionBlock1+="\n" + decl + '\n' + body + '\n'
		#self.logAppend+="\n//end function: "+self.currentFunct
		#self.logAppend+="\n/*body: "+self.functionBlock1+"*/"

		self.IsFakeFunct=0
		self.currentFunct=tmp_currentFunct
		self.parsingAtomic = tmp_parsingAtomic
		return			