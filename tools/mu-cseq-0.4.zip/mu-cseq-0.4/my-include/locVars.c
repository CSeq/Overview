intV Read_var_lock(__cs_mutex_t _cs_mLock){
	__CS_typeM jump;
	
	if ((__CS_ret) || ( jump >= __memory_notvalid_of_lockV[_cs_mLock] )) {__CS_ret=1; return;}
	
	__CS_typeM ticket_jump = __ticket_lockV[_cs_mLock][jump];
    __CPROVER_assume( (jump<__thw_lockV[_cs_mLock][__cs_thread_index][__last_used_pos_of_lockV[_cs_mLock]] )
				&& (__ticket_lockV[_cs_mLock][jump+1]>ticket_pos)			
				//<insert-atomic-constrain-here>
				);						
						/*&& ( !(ticket_jump > ticket_pos) || (__visible[codeVar][jump]) )*/

	ticket_pos = (ticket_jump > ticket_pos) ? ticket_jump : ticket_pos;
	/*<insert-atomic-constrain-here>*/

	//return (__value_lockV[jump]);

}
void Write_var_lock(__cs_mutex_t _cs_mLock){
	if (__CS_ret) return;
	
	__CS_typeM last_pos = __thw_lockV[_cs_mLock][__cs_thread_index][__last_used_pos_of_lockV[_cs_mLock]];
	
	if (last_pos >= __memory_notvalid_of_lockV[_cs_mLock] ) {__CS_ret=1; return;}
	__last_used_pos_of_lockV[_cs_mLock]=last_pos;

	
	__CPROVER_assume (
				(__ticket_lockV[_cs_mLock][last_pos] > ticket_pos)
			//&&  (__value_lockV[last_pos] == val)
		) ;
	ticket_pos=__ticket_lockV[_cs_mLock][last_pos];

}

intV __pthread_mutex_init(__cs_mutex_t _cs_mLock, int ignoreMe){
return;
   /* if (number_threads>0){
		Write(__m, MaxNumThreads);
		//if ((__memory[__m][thread_pos-1]>MaxNumThreads)){__CS_ret=1; return -1;}
	}
   return nondet_int();*/
}


//intV __pthread_mutex_lock(intV __m){
intV __pthread_mutex_lock(__cs_mutex_t _cs_mLock){
Write_var_lock(_cs_mLock);
/*	Write(__m, 1);
	if (__CS_ret) return;	
	__CPROVER_assume ((__value[__m][__last_used_pos_of[__m]-1]==0));
   return nondet_int();*/
} 


//intV __pthread_mutex_unlock(intV __m){
intV __pthread_mutex_unlock(__cs_mutex_t _cs_mLock){
Write_var_lock(_cs_mLock);
/*	Write(__m, 0);
	if (__CS_ret) return;
	__CPROVER_assume ((__value[__m][__last_used_pos_of[__m]-1]==1));
   return 0;
*/
}

intV __pthread_mutex_destroy(__cs_mutex_t _cs_mLock){
}