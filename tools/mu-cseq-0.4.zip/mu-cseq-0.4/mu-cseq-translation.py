#!/usr/bin/env python
FRAMEWORK_VERSION = '0.0 2013.09.18'

#!/usr/bin/env python
import sys, getopt, os.path     # std imports
from pycparser import parse_file, c_parser
import merger, parser, clean, translator, translatorgrained, utils    # cseq-specific imports


def usage(cmd, errormsg):
    print "MU-CSeq   |   C sequentialiser"
    print "    0.2   |   April 2014\n"

    print "Usage:"
    print "   -h, --help                         display this help screen\n"
    print "   -i<filename>, --input=<filename>   read input from given filename"
    print "   -t<X>, --threads<X>                 set max threads (default: 5)"
    print "   -w<X>                              set max number of writes\n"
    print "   -f<X>, --ufor<X>                   set max for loop unwind (default: 1,  overrides unwind setting)\n"
    print "   --error_label ERROR                specification-filename contains the specification to be verified for a program\n"
    print "   --partial-loops                    permit paths with partial loops\n"
    print "   example:  %s -i benchmarks/fib_bench_longest_true.i  -w 23 -f 12 -t 12 --error_label ERROR --partial-loops\n" % cmd

    print errormsg + '\n'
    sys.exit(1)


def main(args):
    cmd = args[0]

    try:
        opts, args = getopt.getopt(sys.argv[1:], "hi:o:t:w:f:b:e:l:m:D:a:s:", ["help", "input=", "output=", "threads", "nwrites", "ufor", "bit", "error_label=", "partial-loops", "MaxThreadCreate=", "debug","speedup","schema="])
    except getopt.GetoptError, err:
        usage(cmd, 'error: ' +str(err))

    inputfile = outputfile = ''

    # Set default conversion parameters
    format = 'cbmc'
    threads = 10
    rounds = 10
    ufor = 12
    bit=32
    partialLoops = 0
    MaxThreadCreate=3
    speedup = 1


    debug = detail = False

    # Set conversion parameters & options from command-line
    for o, a in opts:
        if o == "-v": verbose = True
        elif o in ("-h", "--help"):
            usage(cmd,'')
            return
        elif o in ("-e", "--error_label"): error_label = a
        elif o in ("-l", "--partial-loops"): partialLoops = 1
        elif o in ("-D", "--debug"): debug = True
        elif o in ("-d", "--detail"): detail = True
        elif o in ("-i", "--input"): inputfile = a
        elif o in ("-o", "--output"): outputfile = a
        #elif o in ("-f", "--format"): format = a
        elif o in ("-t", "--threads"): threads = int(a)
        elif o in ("-f", "--ufor"): ufor = int(a)
        elif o in ("-b", "--bit"): bit = int(a)
        elif o in ("-w", "--nwrites"): nwrites = int(a)
        elif o in ("-m", "--MaxThreadCreate"): MaxThreadCreate = int(a)
        elif o in ("-a", "--speedup"): speedup = int(a)
        elif o in ("-s", "--schema"): schema = a
        else: assert False, "unhandled option"

    # Check parameters
    if inputfile == '': usage(cmd, 'error: input file name not specified')
    if not os.path.isfile(inputfile): usage(cmd, 'error: unable to open input file (%s)' % inputfile)
    if format not in ('esbmc', 'cbmc', 'llbmc'): usage(cmd, 'error: output format (%s) not supported' % format)



    # Step 0:
    '''
    if schema=="b":
        Clean = cleangrained.Clean()
    else:
        Clean = clean.Clean()
    '''
    Clean = clean.Clean() #bisogna prendere le prime righe nei wmm
    Clean.load(inputfile)
    Clean.save(inputfile+'.1', threads)

    # Perform the code-to-code translation
    # Step 1: merge all the input source files
    Merger = merger.Merger()
    Merger.load(inputfile+'.1')
    Merger.save(inputfile+'.2')
    ###print inputfileStage2.getversion()








    # Step 2: parse the merged input file
    Parser = parser.Parser()
    Parser.load(inputfile+'.2')
    #Parser.printsymbols()
    Parser.save(inputfile+'.3')
    ##Parser.show()
    ##  inputfileStage3.printsymbols()




    numThreadCreate = Parser.numThreadCreate


    if numThreadCreate == -1:
        if threads==0:
            threads = 16
    else:
        threads = numThreadCreate
    '''
    print "schema="+str(schema)
    print "numThreadCreate="+str(numThreadCreate)
    print "createInFor="+str(Parser.createInFor)
    print "numLoops="+str(Parser.numLoops)
    print "countAssignment="+str(Parser.countAssignment)
    return
    '''
    '''
    print numThreadCreate
    print threads
    return
    '''
    #return

    # Step 3: translate
    #Translator = translator.Translator(inputfile+'.3', nwrites, threads, format, detail, ufor, error_label, Parser)


    #print "array"+str(Parser.containsArray)
    #return
    unwind=1
    nwrites=23
    if (Parser.numLoops==0 and Parser.countAssignment>30) or (Parser.createInFor==1 and Parser.containsArray==""): #schema b
        nwrites=2
        MaxThreadCreate=0
        speedup=1
        ufor=52
        threads=52

        if numThreadCreate != -1:
            threads = numThreadCreate

        '''
        print "schema="+str(schema)
        print "numThreadCreate="+str(numThreadCreate)
        print "createInFor="+str(Parser.createInFor)
        print "numLoops="+str(Parser.numLoops)
        print "countAssignment="+str(Parser.countAssignment)
        print "MaxThreadCreate="+str(MaxThreadCreate)
        print "threads="+str(threads)
        return
        '''
        Translator = translatorgrained.Translator(inputfile+'.3', nwrites, threads, format, detail, ufor, error_label, partialLoops, MaxThreadCreate, Parser, speedup)
    else:
        speedup = 0

        if (Parser.containsArray!="" and Parser.containsArray.find("_Thread_local__COND")<0):
            nwrites=25
            ufor=2
            speedup = 0
            MaxThreadCreate=0
            unwind=2

        '''
        print "numThreadCreate="+str(numThreadCreate)
        print "createInFor="+str(Parser.createInFor)
        print "numLoops="+str(Parser.numLoops)
        print "countAssignment="+str(Parser.countAssignment)
        print "containsArray="+str(Parser.containsArray)
        print "MaxThreadCreate="+str(MaxThreadCreate)
        print "threads="+str(threads)
        return
        '''
        Translator = translator.Translator(inputfile+'.3', nwrites, threads, format, detail, ufor, error_label, partialLoops, MaxThreadCreate, Parser,speedup)
    Translator.save(inputfile+'.4.c')
    Translator.show()
    #Translator.show_mio()
    logfilename=outputfile
    parsingcheck = outputfile + '.err'
    #cmdline = 'ulimit -Sv 10000000; timeout 850 ./cbmc --unwind '+str(unwind)+' --no-unwinding-assertions ' + inputfile+'.4.c' + ' > ' + logfilename
    cmdline = './cbmc --unwind '+str(unwind)+' --no-unwinding-assertions ' + inputfile+'.4.c' + ' > ' + logfilename + ' 2> ' + parsingcheck

    #print cmdline
    #return

    os.system(cmdline)

    with open(parsingcheck) as checkfile:
        err = checkfile.read()
        if 'PARSING ERROR' in err:
            os.system('echo \'UNKNOWN\' > %s' % logfilename)

    #os.system('rm '+inputfile+'.1')
    #os.system('rm '+inputfile+'.2')
    #os.system('rm '+inputfile+'.3')
    #os.system('rm '+inputfile+'.4.c')


if __name__ == "__main__":
    main(sys.argv[0:])

