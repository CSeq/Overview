""" Lazy-CSeq
    thread Duplicator module

    written by Omar Inverso, University of Southampton.
"""
VERSION = 'duplicator-0.0-2015.07.15'
#VERSION = 'duplicator-0.0-2015.07.13'
#VERSION = 'duplicator-0.0-2015.07.08'
#VERSION = 'duplicator-0.0-2015.06.23'
#VERSION = 'duplicator-0.0-2014.12.24'    # CSeq-1.0beta
#VERSION = 'duplicator-0.0-2014.10.26'    # CSeq-Lazy-0.6: newseq-0.6a, newseq-0.6c, SVCOMP15
#VERSION = 'duplicator-0.0-2014.10.15'
#VERSION = 'duplicator-0.0-2014.03.14' (CSeq-Lazy-0.4)
#VERSION = 'duplicator-0.0-2014.02.25' (CSeq-Lazy-0.2)
"""

Last step to produce a bounded program (see CAV2014)
after running inliner+unroller on the input.

This module works on unfolded programs, and
it duplicates the functions used multiple times to create a thread,
so that each thread creation refers to a distinct function.

The number of copies is the number of times that the function
is used as an argument to pthread_create().

The copies share the body, and
the name of the function is indexed by adding a trailing counter.

The calls to pthread_create() are updated accordingly.

For example,
    the following input code:
        thread() { ... }

        pthread_create(thread);
        pthread_create(thread);

    will generate:
        thread_0() { ... }
        thread_1() { ... }

        pthread_create(thread_0);
        pthread_create(thread_1);

Prerequisites:
    the input is completely unfolded, needs inliner+unroller first.

TODO:
    - replace the quick hacks in visit_FuncDef() with proper AST-based implementation
    - visit_FuncDef() visit the same AST multiple times - inefficient..
    - re-implement AST-based prototype cloning

Changelog:
	2015.07.15  fixed linemapping not working for non-thread functions (e.g. atomic functions) (Truc,Omar)
    2015.07.13  fixed linemapping not working from the 2nd copy of a thread onwards (Omar)
    2015.06.23  re-implemented 3rd parameter extraction from the call to pthread_create()
    2014.12.09  further code refactory to match the new organisation of the CSeq framework
    2014.10.26  removed dead/commented-out/obsolete code
    2014.10.15  removed visit() and moved visit call-stack handling to module class (module.py)
    2014.03.14  further code refactory to match  module.Module  class interface
    2014.02.25  switched to  module.Module  base class for modules

"""

import re
import pycparser.c_parser, pycparser.c_ast, pycparser.c_generator
import core.common, core.module, core.parser, core.utils


class premuseq(core.module.Translator):
	num=1
	global_parameters2={} 
	replaced=[]
	append=""
	###strutture = []   
	#cs_threads = [] 
	cs_threads=""	
	
	def init(self):
		self.addOutputParam('cs_threads')           # no. of thread creations (statically determined)
	def loadfromstring(self, string, env):
		super(self.__class__, self).loadfromstring(string, env)
		if ("struct my_data __cs_local_main_data;" in self.output):
			self.output = self.output.replace("struct my_data __cs_local_main_data;","")
			self.output = self.output.replace("struct my_data __cs_local_main_data1;", "struct my_data __cs_local_main_data;")
		else:
			self.output = self.output.replace("struct my_data __cs_local_main_data1;", "")
		self.setOutputParam('cs_threads', self.cs_threads)
		#self.output += self.append
		#self.Parser.printsymbols()

	def visit_ID(self, n):
		nameVar = n.name
		if self.global_parameters2.has_key(n.name)==True:
			nameVar=self.global_parameters2[n.name]
		return nameVar
	
	def visit_FuncDef(self, n):
		self.global_parameters2={} 
		self.replaced=[]
		self.append += "\nsono in visit_FuncDef: "+n.decl.name
		localToglobalStruct = ""
		if self.num==1:
			localToglobalStruct = "struct my_data __cs_local_main_data1;\n"
		self.num=self.num+1
		superFuncDef = super(self.__class__, self).visit_FuncDef(n)
		for item in self.replaced:
			superFuncDef = superFuncDef.replace("(*"+item+")",item)
		'''
		if n.decl.name =="main":
			str=""
			for item in self.cs_threads:
				str+=item+";\n"
			superFuncDef = superFuncDef.replace ("{","{\n"+str,1)
		'''
		return localToglobalStruct + superFuncDef
		
		
	def visit_Assignment(self, n):
	
		tmp=str(self.visit(n.lvalue))
		#self.logAppend+="\n//prima visita dx"
		rval_str_noVisit = self._parenthesize_if(n.rvalue, lambda n: isinstance(n, pycparser.c_ast.Assignment))
		if tmp.startswith("__cs_param_") and rval_str_noVisit.startswith("&"):
			#comment += "\n/*"+tmp+"="+rval_str_noVisit+"*/"
			self.global_parameters2[tmp]=rval_str_noVisit.replace("&","")
			self.replaced.append(rval_str_noVisit.replace("&",""))
			return ""
		if rval_str_noVisit.startswith("(struct my_data *)"):
			#comment += "\n/*"+tmp+"="+rval_str_noVisit+"*/"
			self.global_parameters2[tmp]="__cs_local_main_data"
			self.replaced.append("__cs_local_main_data")
			return ""
		return super(self.__class__, self).visit_Assignment(n)
		

	def visit_Decl(self, n, no_type=False):
		pippo = super(self.__class__, self).visit_Decl(n)
		if n.name is not None:
			if self.num==1 and pippo.startswith("__cs_t "):
				self.append += "\nsono in visitDecl: "+n.name
				self.append += "\npippo: "+pippo
				#self.cs_threads.append(pippo.replace("__cs_t ", "__cs_t _cs_pthread_"))
				self.cs_threads+="\n"+pippo.replace("__cs_t ", "__cs_t _cs_pthread_")+";"
				return ""
		return pippo

		
	'''
		
	def visit_Struct(self, n):
		if n not in self.strutture:
			self.strutture.append(n)
		self.append += "\n+++++++visito struttura: "+n.name
		pippo=super(self.__class__, self).visit_Struct(n)
		self.append += "\n*****pioppo: "+pippo
		self.append += "\n------fine visito struttura: "
		
		return pippo
		
	def visit_StructRef(self, n):
		sref = self._parenthesize_unless_simple(n.name)

		#oldVisitingField = self.visitingField
		self.visitingField = True

		field = self.visit(n.field)

		#self.visitingField = oldVisitingField
		self.append += "\nvisito visit_StructRef:" +sref + n.type + field
		

		return super(self.__class__, self).visit_StructRef(n)
		
		
	def visit_Decl(self, n, no_type=False):
		pippo = super(self.__class__, self).visit_Decl(n)
		if n.name is not None:
			self.append += "\nsono in visitDecl: "+n.name
			self.append += "\npippo: "+pippo
		return pippo
		
	'''