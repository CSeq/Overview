_Bool Read_Bool_atomic(__CS_typeM codeVar){
	return (__memory_bool[codeVar][thread_pos]);
}
void Write_Bool_atomic(__CS_typeV codeVar, _Bool val){

	thread_pos++;
	__CPROVER_assume((thread_pos < memory_notvalid ) && (cannot_next_atomic_write[thread_index]==0));


	__CPROVER_assume (
			   (var_name[thread_pos] == codeVar)
		   &&  (__memory_bool[codeVar][thread_pos] == val)
		   &&  (thread[thread_pos] == thread_index)
	) ;
	cannot_next_atomic_write[thread_index]=visible[thread_pos];
}