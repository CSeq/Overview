#include <stdlib.h>
#include <pthread.h>


#define MEM_SIZE <insert-MEM_SIZE-here>
#define NumVars <insert-NumVars-here>
#define MaxNumThreads <insert-NumThreads-here>
 

//start global variables
<insert-define-global-variables-here>
//end global variables
 
 
 
#define __CS_type unsigned char

/*
#define __CS_typeM unsigned char
#define __CS_typeV unsigned char
#define __CS_typeT unsigned char
*/

#define __CS_typeM unsigned __CPROVER_bitvector[<insert-type-typeM-here>]
#define __CS_typeV unsigned __CPROVER_bitvector[<insert-type-typeV-here>]
#define __CS_typeT unsigned __CPROVER_bitvector[<insert-type-typeT-here>]



#define __CS_pthread_t unsigned char
#define __CS_pthread_mutex_t unsigned char
#define __CS_pthread_cond_t unsigned char
 
 
 

// shared memory

<insert-atomic-declaration-here>




int __memory[<insert-NumIntVar-here>][MEM_SIZE]; 
<insert-bool-declaration-here>
__CS_typeV var_name[MEM_SIZE];
__CS_typeT thread[MEM_SIZE];  
__CS_typeM thw[MaxNumThreads][MEM_SIZE];


__CS_typeM thread_pos; 
__CS_typeM memory_notvalid;

//<insert-defMax-here>
 
 __CS_typeT n_treads_createad=1;

_Bool __CS_error = 0;                                              //cseq: set whenever an error is found and checked after thread-wrapping
int __CS_ret = 0; 
_Bool terminated[MaxNumThreads]=<insert-Terminated-here>;		//viene settato ad 1 solo se il thread viene terminato
  int GuessedNumThreads;
__CS_typeM thread_pos_terminated[MaxNumThreads]=<insert-Terminated-here>;		//ultimo thread_pos



//cseq: handling of the status of the threads 
__CS_typeT thread_index;                                           //cseq: currently running thread ranging in [1..max+1], 1 being main()
__CS_typeT number_threads;



void Jump(){
	__CS_typeM jump;
	
	__CPROVER_assume(jump<thw[thread_index][thread_pos] && (jump >= thread_pos));
	if (( jump >= memory_notvalid ) || (__CS_ret) ) {__CS_ret=1; return;}
	thread_pos=jump;
 
}


<insert-array-declaration-here>
<insert-atomic-array-here>


int Read_atomic(__CS_typeV codeVar){
	return (__memory[codeVar][thread_pos]);
}



void Write_atomic(__CS_typeV codeVar, int val){

  thread_pos++;
  __CPROVER_assume((thread_pos < memory_notvalid ) && (cannot_next_atomic_write[thread_index]==0));


  __CPROVER_assume (
           (var_name[thread_pos] == codeVar)
       &&  (__memory[codeVar][thread_pos] == val)
       &&  (thread[thread_pos] == thread_index)
      ) ;
  cannot_next_atomic_write[thread_index]=visible[thread_pos];
}

<insert-atomic-function-here>


void __VERIFIER_error(){}
unsigned int __VERIFIER_nondet_uint(){
int _x;
__CPROVER_assume(_x>=0);
return _x;
}

<insert-pthread_cond_wait-here>




<insert-bool-function-here>


int Read(__CS_typeV codeVar){
	__CS_typeM jump;
	
	if (__CS_ret) return;
	__CPROVER_assume(jump<thw[thread_index][thread_pos] && (jump >= thread_pos));
 
	thread_pos=jump;
 
	//<insert-assume-atomic-here>

	if ( thread_pos >= memory_notvalid ) {__CS_ret=1;}
	return (__memory[codeVar][thread_pos]);
}


void Write(__CS_typeV codeVar, int val){

	if (__CS_ret) return;

	thread_pos=thw[thread_index][thread_pos];
	if (thread_pos >= memory_notvalid ) {__CS_ret=1; return;}
	
	<insert-assume-atomic-here>

	__CPROVER_assume (
           (var_name[thread_pos] == codeVar)
       &&  (__memory[codeVar][thread_pos] == val)
	) ;
}
int nondet_int();
int __pthread_mutex_init(int __m, __CS_type ignoreMe){

    if (number_threads>0){
		Write(__m, 0);
		if ((__memory[__m][thread_pos-1]>MaxNumThreads)){__CS_ret=1; return -1;}
	}
   return nondet_int();
}
_Bool nondet_bool();
int __pthread_mutex_lock(int __m){

	Write(__m, thread_index+1);
	if ((__memory[__m][thread_pos-1]!=0)){__CS_ret=1; return -1;}
   return nondet_int();
} 


int __pthread_mutex_unlock(int __m){
	Write(__m, 0);
	if ((__memory[__m][thread_pos-1]!=(thread_index+1))){__CS_ret=1; return -1;}

   return 0;

} 


int __pthread_mutex_destroy(int __m){
}

int __pthread_cond_wait(__CS_typeV codeVar, __CS_type cond, int __m){

   //Unlock the mutex passed as a parameter
   __pthread_mutex_unlock(__m);
   if (__CS_ret) return -1;

   //Set lock_cond_ (thread_index) to cond.
   __CPROVER_assume((thread_pos+1)==thw[thread_index][thread_pos]);
   Write(codeVar, cond);

   //Waiting until  'lock_cond_ (thread_index) != cond.'
   if (Read(codeVar)==cond){__CS_ret=1; return -1;}

   //Once condition has occurred, lock on the mutex __m
   __pthread_mutex_lock(__m);
   if (__CS_ret) return -1;
   return nondet_int();

} 


void __pthread_cond_init( __CS_type cond,  __CS_type ignoreMe){return;}


int __pthread_cond_signal( __CS_type cond, __CS_type lock_cond_base){

   int i1;
   for (i1=lock_cond_base; i1<lock_cond_base+MaxNumThreads; i1++){
       if (Read(i1)==cond){
           __CPROVER_assume((thread_pos+1)==thw[thread_index][thread_pos]);
           Write(i1, NumVars);
        }
   }
   return nondet_int();

} 


int __pthread_join( __CS_pthread_t t1, __CS_type p){
  if (nondet_int()) {__CS_ret=1; return;}
  Jump();
   __CPROVER_assume((terminated[t1]==0) && (thread_pos >= thread_pos_terminated[t1]));

   return 0;
}
int __pthread_create_thread1(__CS_pthread_t *thread_id, void *attr, void *arg);
int __pthread_create_thread2(__CS_pthread_t *thread_id, void *attr, void *arg);
int __pthread_create_thread3(__CS_pthread_t *thread_id, void *attr, void *arg);
