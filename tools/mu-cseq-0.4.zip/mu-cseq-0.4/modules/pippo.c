typedef int _____STARTSTRIPPINGFROMHERE_____;
typedef int __cs_cond_t;
typedef int __cs_mutex_t;
typedef int __cs_t;
typedef int size_t;
typedef int __gnuc_va_list;
typedef int __int8_t;
typedef int __uint8_t;
typedef int __int16_t;
typedef int __uint16_t;
typedef int __int_least16_t;
typedef int __uint_least16_t;
typedef int __int32_t;
typedef int __uint32_t;
typedef int __int_least32_t;
typedef int __uint_least32_t;
typedef int _LOCK_T;
typedef int _LOCK_RECURSIVE_T;
typedef int _off_t;
typedef int __dev_t;
typedef int __uid_t;
typedef int __gid_t;
typedef int _off64_t;
typedef int _fpos_t;
typedef int _ssize_t;
typedef int wint_t;
typedef int _mbstate_t;
typedef int _flock_t;
typedef int _iconv_t;
typedef int __ULong;
typedef int __FILE;
typedef int ptrdiff_t;
typedef int wchar_t;
typedef int __off_t;
typedef int __pid_t;
typedef int __loff_t;
typedef int u_char;
typedef int u_short;
typedef int u_int;
typedef int u_long;
typedef int ushort;
typedef int uint;
typedef int clock_t;
typedef int time_t;
typedef int daddr_t;
typedef int caddr_t;
typedef int ino_t;
typedef int off_t;
typedef int dev_t;
typedef int uid_t;
typedef int gid_t;
typedef int pid_t;
typedef int key_t;
typedef int ssize_t;
typedef int mode_t;
typedef int nlink_t;
typedef int fd_mask;
typedef int _types_fd_set;
typedef int clockid_t;
typedef int timer_t;
typedef int useconds_t;
typedef int suseconds_t;
typedef int FILE;
typedef int fpos_t;
typedef int cookie_read_function_t;
typedef int cookie_write_function_t;
typedef int cookie_seek_function_t;
typedef int cookie_close_function_t;
typedef int cookie_io_functions_t;
typedef int div_t;
typedef int ldiv_t;
typedef int lldiv_t;
typedef int sigset_t;
typedef int _sig_func_ptr;
typedef int sig_atomic_t;
typedef int __tzrule_type;
typedef int __tzinfo_type;
typedef int mbstate_t;
typedef int sem_t;
typedef int pthread_t;
typedef int pthread_attr_t;
typedef int pthread_mutex_t;
typedef int pthread_mutexattr_t;
typedef int pthread_cond_t;
typedef int pthread_condattr_t;
typedef int pthread_key_t;
typedef int pthread_once_t;
typedef int pthread_rwlock_t;
typedef int pthread_rwlockattr_t;
typedef int pthread_spinlock_t;
typedef int pthread_barrier_t;
typedef int pthread_barrierattr_t;
typedef int int8_t;
typedef int uint8_t;
typedef int int16_t;
typedef int uint16_t;
typedef int int32_t;
typedef int uint32_t;
typedef int int64_t;
typedef int uint64_t;
typedef _Bool bool;
typedef int va_list;
typedef int _____STOPSTRIPPINGFROMHERE_____;
extern void __VERIFIER_error();
int __VERIFIER_nondet_int(void);
;
;
struct device
{
char unused;
};
struct A
{
int a;
int b;
};
struct my_data
{
__cs_mutex_t lock;
struct device dev;
struct A shared;
};
struct device *my_dev;
struct my_data __cs_local_main_data;
void *my_callback_0(void *__cs_param_my_callback_arg)
{
struct my_data *__cs_local_my_callback_data;
const struct device *__cs_local_my_callback___mptr;
__cs_local_my_callback___mptr = my_dev;
;
__cs_mutex_lock(&__cs_local_main_data.lock);
__cs_local_main_data.shared.a = 1;
__cs_local_main_data.shared.b = __cs_local_main_data.shared.b + 1;
__cs_mutex_unlock(&__cs_local_main_data.lock);
__exit_my_callback:
		;
__cs_exit(0);
}
void *my_callback_1(void *__cs_param_my_callback_arg)
{
struct my_data *__cs_local_my_callback_data;
const struct device *__cs_local_my_callback___mptr;
__cs_local_my_callback___mptr = my_dev;
;
__cs_mutex_lock(&__cs_local_main_data.lock);
__cs_local_main_data.shared.a = 1;
__cs_local_main_data.shared.b = __cs_local_main_data.shared.b + 1;
__cs_mutex_unlock(&__cs_local_main_data.lock);
__exit_my_callback:
		;
__cs_exit(0);
}
int main(void)
{
__cs_t t1;
__cs_t t2;
int __cs_local_main_ret;
static int __cs_retval__my_drv_init_1;
		{
__cs_retval__my_drv_init_1 = 0;
goto __exit__my_drv_init_1;
__exit__my_drv_init_1:
				;
		}
__cs_local_main_ret = __cs_retval__my_drv_init_1;
_Bool __cs_local_main___cs_tmp_if_cond_2;
__cs_local_main___cs_tmp_if_cond_2 = __cs_local_main_ret == 0;
if (__cs_local_main___cs_tmp_if_cond_2)
		{
int __cs_local_main_probe_ret;

static int __cs_retval__my_drv_probe_1;
				{
static struct my_data *__cs_param_my_drv_probe_data;
;
__cs_mutex_init(&__cs_local_main_data.lock, (void *) 0);
__cs_local_main_data.shared.a = 0;
__cs_local_main_data.shared.b = 0;
						{
static int __cs_param_ldv_assert_expression;
__cs_param_ldv_assert_expression = __cs_local_main_data.shared.a == 0;
_Bool __cs_local_ldv_assert___cs_tmp_if_cond_0;
__cs_local_ldv_assert___cs_tmp_if_cond_0 = !__cs_param_ldv_assert_expression;
if (__cs_local_ldv_assert___cs_tmp_if_cond_0)
								{
__CSEQ_assert(0);
								}
								;
goto __exit__ldv_assert_1;
__exit__ldv_assert_1:
								;
						}
						{
static int __cs_param_ldv_assert_expression;
__cs_param_ldv_assert_expression = __cs_local_main_data.shared.b == 0;
_Bool __cs_local_ldv_assert___cs_tmp_if_cond_0;
__cs_local_ldv_assert___cs_tmp_if_cond_0 = !__cs_param_ldv_assert_expression;
if (__cs_local_ldv_assert___cs_tmp_if_cond_0)
								{
__CSEQ_assert(0);
								}
								;
goto __exit__ldv_assert_2;
__exit__ldv_assert_2:
								;
						}
int __cs_local_my_drv_probe_res;
__cs_local_my_drv_probe_res = __VERIFIER_nondet_int();
_Bool __cs_local_my_drv_probe___cs_tmp_if_cond_1;
__cs_local_my_drv_probe___cs_tmp_if_cond_1 = __cs_local_my_drv_probe_res;
if (__cs_local_my_drv_probe___cs_tmp_if_cond_1)
						{
goto exit;
						}
my_dev = &__cs_local_main_data.dev;
__cs_create(&t1, (void *) 0, my_callback_0, (void *) 0);
__cs_create(&t2, (void *) 0, my_callback_1, (void *) 0);
__cs_retval__my_drv_probe_1 = 0;
goto __exit__my_drv_probe_1;
exit:
__cs_mutex_destroy(&__cs_local_main_data.lock);
__cs_retval__my_drv_probe_1 = -1;
goto __exit__my_drv_probe_1;
__exit__my_drv_probe_1:
						;
				}
__cs_local_main_probe_ret = __cs_retval__my_drv_probe_1;
_Bool __cs_local_main___cs_tmp_if_cond_3;
__cs_local_main___cs_tmp_if_cond_3 = __cs_local_main_probe_ret == 0;
if (__cs_local_main___cs_tmp_if_cond_3)
				{
						{
static struct my_data *__cs_param_my_drv_disconnect_data;
;
void *__cs_local_my_drv_disconnect_status;
__cs_join(t1, &__cs_local_my_drv_disconnect_status);
__cs_join(t2, &__cs_local_my_drv_disconnect_status);
__cs_mutex_destroy(&__cs_local_main_data.lock);
__exit__my_drv_disconnect_1:
								;
						}
						{
static int __cs_param_ldv_assert_expression;
__cs_param_ldv_assert_expression = __cs_local_main_data.shared.a == 1;
_Bool __cs_local_ldv_assert___cs_tmp_if_cond_0;
__cs_local_ldv_assert___cs_tmp_if_cond_0 = !__cs_param_ldv_assert_expression;
if (__cs_local_ldv_assert___cs_tmp_if_cond_0)
								{
__CSEQ_assert(0);
								}
								;
goto __exit__ldv_assert_3;
__exit__ldv_assert_3:
								;
						}
						{
static int __cs_param_ldv_assert_expression;
__cs_param_ldv_assert_expression = __cs_local_main_data.shared.b == 2;
_Bool __cs_local_ldv_assert___cs_tmp_if_cond_0;
__cs_local_ldv_assert___cs_tmp_if_cond_0 = !__cs_param_ldv_assert_expression;
if (__cs_local_ldv_assert___cs_tmp_if_cond_0)
								{
__CSEQ_assert(0);
								}
								;
goto __exit__ldv_assert_4;
__exit__ldv_assert_4:
								;
						}
				}
				{
goto __exit__my_drv_cleanup_1;
__exit__my_drv_cleanup_1:
						;
				}
__cs_local_main_data.shared.a = -1;
__cs_local_main_data.shared.b = -1;
				{
static int __cs_param_ldv_assert_expression;
__cs_param_ldv_assert_expression = __cs_local_main_data.shared.a == (-1);
_Bool __cs_local_ldv_assert___cs_tmp_if_cond_0;
__cs_local_ldv_assert___cs_tmp_if_cond_0 = !__cs_param_ldv_assert_expression;
if (__cs_local_ldv_assert___cs_tmp_if_cond_0)
						{
__CSEQ_assert(0);
						}
						;
goto __exit__ldv_assert_5;
__exit__ldv_assert_5:
						;
				}
				{
static int __cs_param_ldv_assert_expression;
__cs_param_ldv_assert_expression = __cs_local_main_data.shared.b == (-1);
_Bool __cs_local_ldv_assert___cs_tmp_if_cond_0;
__cs_local_ldv_assert___cs_tmp_if_cond_0 = !__cs_param_ldv_assert_expression;
if (__cs_local_ldv_assert___cs_tmp_if_cond_0)
						{
__CSEQ_assert(0);
						}
						;
goto __exit__ldv_assert_6;
__exit__ldv_assert_6:
						;
				}
		}
goto __exit_main;
__exit_main:
		;
__cs_exit(0);
}

sono in visitDecl: t1
pippo: __cs_t t1
sono in visitDecl: t2
pippo: __cs_t t2
sono in visit_FuncDef: my_callback_0
sono in visit_FuncDef: my_callback_1
sono in visit_FuncDef: main
