#!/usr/bin/env python
SEQUENTIALIZER_VERSION = 'wSeq 0.1 2013.10.30'

"""
	to handle here:

"""

import pycparser.c_parser, pycparser.c_ast, pycparser.c_generator
from time import gmtime, strftime
import getopt, sys, os.path
import parser, utils
import math


notHandledPrimitives = [ 'pthread_mutex_trylock', 'pthread_mutex_timedlock', 'pthread_mutex_consistent']  # mutexes
notHandledPrimitives += ['pthread_cond_timedwait', 'pthread_cond_destroy'] # conditionals
notHandledPrimitives += ['free', 'calloc'] # dynamic memory allocation
renameFunct=["thread"]


class colors:
	BLACK = '\033[90m'
	RED = '\033[91m'
	GREEN = '\033[92m'
	YELLOW = '\033[93m'
	BLUE = '\033[94m'
	NO = '\033[0m'

mainSimulationBlock = (
"<insert-thread-create-block-here>"
"\n\nvoid *main_thread(int argc, char *argv[])\n"
"{\n"
"\t<insert-main-parameters-decl-here>\n"
"\t<insert-mainthread-here>\n"
"}\n"
"\n"
"\n"
"\n\n<insert-check-block-here>\n\n"

"\n"
"\n"
#"<insert-main-prototype-here>\n"
"\nint main(int argc, char **argv)\n"
"\n{"
"\n"
"\nGuessedNumThreads=nondet_int();"
"\n__CPROVER_assume(GuessedNumThreads<=MaxNumThreads);"
"\n"
"\n"
"\ncheck1();"
"\n"
"\n"
"\n//cseq: simulation of the threads main"
"\nmain_thread(argc, argv);"
"\n  //__CPROVER_assume((thw[thread_index][thread_pos] >=memory_notvalid) );"
"\n  __CPROVER_assume(GuessedNumThreads==n_treads_createad);"
"\n "
"\n <insert-checkFinale-here>"
"\n "
"\n//cseq: Error check"
"\nassert(__CS_error != 1);"
"\n}"
)
exitBlock = (
"if (nondet_int()){__CS_ret=1; return 0;}\n"
)

errorBlock = (
"ERROR: if (__CS_ret) return 0; \n"
"\t\t__CS_error = 1;   Release_lock__atomic_function(); __CS_ret = 1; <return_statement>;\n "
)
errorBlock1 = (
"\tif (__CS_ret) return 0; "
"\t__CS_error = 1;  <return_statement> "
)


pthread_create_block_static = (
"(__CS_pthread_t *thread_id, void *attr, void *arg){\n"
"	int __ret=0;\n"
"__CS_typeT my_thread_index;\n"
"__CS_type my_thread_pos;\n"
"\n"
"   if (MaxNumThreads==++number_threads) return 0;\n"
""
"	my_thread_index = thread_index; \n"
" 	my_thread_pos   = thread_pos;\n"
" 	thread_index = number_threads;\n"
"   n_treads_createad++;\n"
" 	//__CPROVER_assume(thw[thread_index][0] > thread_pos);\n"
" 	<insert-thread-routine-here>( arg); \n"
" 	*thread_id=thread_index;\n"
" 	//__CPROVER_assume((thw[thread_index][thread_pos] >=memory_notvalid) );\n"
" 	if (__CS_ret==1) terminated[thread_index]=1;\n"
"	thread_pos_terminated[thread_index]=thread_pos;\n"
" 	__CS_ret=0;\n"
" 	thread_index = my_thread_index;\n"
" 	thread_pos   = my_thread_pos;\n"
"	return __ret;\n"
"}\n"
)




class Translator(pycparser.c_generator.CGenerator):
	""" Uses the same visitor pattern as pycparser.c_ast.NodeVisitor, but modified to
		return a value from each visit method, using string accumulation in
		generic_visit.
	"""
	def __init__(self, filename, nwrites, maxthreads, format, detail, ufor, error_label, partialLoops, MaxThreadCreate, parser, atomicRead):
		self.ast = pycparser.parse_file(filename)

		#self.ast.show()

		self.parser = parser

		#parser.printsymbols()
		#####
		self._inputFilename = filename
		self.atomicRead=atomicRead
		self.atomicRead=0
		self.verifier_atomic = 0
		if not utils.fileContains(self._inputFilename, 'while') and not utils.fileContains(self._inputFilename, 'for (') and not utils.fileContains(self._inputFilename, 'BCSP_PnpAdd'):
			self.atomicRead = 1

		if atomicRead==0:
			self.atomicRead = 0

		if self.atomicRead==1:
			self.verifier_atomic = 1
		if utils.fileContains(self._inputFilename, '__VERIFIER_atomic'):
			self.verifier_atomic = 1
		self.schema=""

		#print "atomicRead"+str(atomicRead)
		self.ufor=ufor
		self.error_label= error_label
		self.partialLoops = partialLoops

		self.num_assignment=0
		self.visitStarted=0
		self.global_parameters=[]
		self.global_parameters2={}
		self.equalToGlobalName={}
		self.isBool=[]
		self.isArray=[]
		self.isScalar=[]
		self.isInFuncCall=0
		self.suffixCall=""

		global pthread_create_block
		self.pthread_create_block_static = pthread_create_block_static

		self.pthread_create_block = ""

		self.check_block = ""
		self.MEM_SIZE=24
		self.variables=[]
		self.isInArrayOrStruct=""
		self.whereInAssignment=""
		self.inGlobalPointer=0
		self.localPointer=[]

		self.functionBlock1=""
		self.IsFakeFunct=0
		self.initializedGlobalVariables	= []
		global renameFunct
		self.renameFunct=renameFunct
		self.labelFor=0
		self.MaxThreadCreateInLop=MaxThreadCreate

		self.initialization=""
		self._CSeq_version = SEQUENTIALIZER_VERSION
		self._maxthreads = maxthreads
		#self._maxrounds = maxrounds
		self._nwrites = nwrites
		self._format = format


		global errorBlock
		self.detail = detail


		self.str_to_replace = ""
		self.str_with_replace = ""



		self.currentFunct = '' # name of the function being parsed (if any)
		self.funcName = ['']  # names of all the functions (consider '' to be a special function to model global scope)

		self.currentVarAssign = '' # name of the current variable used as a lvalue in an assignment statement

		self.currentStruct = ''
		self.structName = []
		self.currentAnonStructsCount = 0   # counts the number of anonymous structures (used to assign consecutive names)

		self.mainParametersDecl = ''     # parameters of the main() function to be transferred to thread 0.


		# TODO: True when the copyvar block etc. in the top of the main() function still
		# has to be added. We have to wait for all the declarations at the top of the main()
		# to show up before adding any assignment operations!
		self.append = True

		# The following variables are needed for handling the global variables in the original
		# source code.
		self.globalInitVarNodes = []  # all the initialised global variable nodes in a list

		# Statements start with indentation of self.indent_level spaces, using
		# the _make_indent method
		#
		self.indent_level = 0			# to keep track of the depth of the block {}
		self.INDENT_SPACING = '\t'	# ....

		# = True while parsing the subtree for a function declaration
		self.parsingFuncDecl = False

		# = True while parsing the subtree for a struct (or union) declaration
		self.parsingStruct = False

		# = True while parsing the main() function
		self.parsingMain = False

		# = True while parsing the condition block of a while loop
		self.parsingWhileCond = False

		# Set when parsing a statement with side effects (i.e., function call, assignment, unary op)
		self.parsingSideEffect = False


		# Declarations have always one of the following two forms:
		#		 <lastDeclarationL> = <lastDeclarationR>;   when there is an init expression
		#			   OR
		#		 <lastDeclarationL>;   when there is no init expression
		self.lastDeclarationL = ''
		self.lastDeclarationR = ''
		self.lastDeclaration = ''

		self.copyVariableDeclaration = ''

		# The following union declaration will be used to keep
		# the old value of a global variable immediately before any complex assignment operation
		# (such as the ones with a function call in the Lvalue).
		# This value can be used thereafter to simulate when a context switch happens
		# while performing function calls from within the assignment,
		# to restore the original value of the variable with a single assignment statement
		# (C unions support this).
		self.unionDeclaration = 'union __CS__u {\n'

		# init expressions for global variables will be moved into this string and then
		# printed inside the main() function
		self.globalInitStatements = ''

		# this will set to True after parsing the first function definition (not declaration!)
		self.firstFunctionDefinitionDone = False

		# set to True while parsing void functions
		self.parsingVoidFunction = False

		# set to True while parsing typedef blocks
		self.parsingTypedef = False

		# set to False when we still have to add to the main() the memcmp block,
		# and set to True when that has been done
		self.memcmpBlockGenerated = False

		# used to avoid inserting context switches in functions whose name starts with '__VERIFIER_atomic'
		self.parsingAtomic = False

		#
		self.currentInputCoord = ''
		self.currentInputLineNumber = -1
		self.currentOutputLineNumber = -1

		self.lines = []

		# Put all the sequentialised code into s.
		s = self.visit(self.ast)

		# Optimisation: remove code from cs() for conditional variables when not needed.
		if not utils.fileContains(self._inputFilename, 'pthread_cond'):
			s = s.replace('___XXXXX__assume(__CS_thread_lockedon[k][__CS_thread_index] == 0);', '/**/');

		# Specific back-end calls. Replace the placeholders to instrument the output file.
		if self._format == 'esbmc':
			s = s.replace('___XXXXX__nondet_int()', 'nondet_int()')
			s = s.replace('___XXXXX__assume', '__ESBMC_assume')
			s = s.replace('___XXXXX__assert', '__ESBMC_assert')
			s = s.replace('int ___XXXXX__dummyBlock1;\n', '');
			s = s.replace('int ___XXXXX__dummyBlock2;\n', '');
			s = s.replace('___XXXXX__FINAL_assert', 'assert');
		elif self._format == 'cbmc':
			s = s.replace('___XXXXX__nondet_int()', 'nondet_int()')
			s = s.replace('___XXXXX__assume', '__CPROVER_assume')
			s = s.replace('___XXXXX__assert', '__CPROVER_assert')
			s = s.replace('int ___XXXXX__dummyBlock1;\n', '');
			s = s.replace('int ___XXXXX__dummyBlock2;\n', '');
			s = s.replace('___XXXXX__FINAL_assert', 'assert');
		elif self._format == 'llbmc':
			s = s.replace('___XXXXX__nondet_int()', '__llbmc_nondef_int()')
			s = s.replace('___XXXXX__assume', '__llbmc_assume')
			s = s.replace('___XXXXX__assert', '__llbmc_assert')
			s = s.replace('int ___XXXXX__dummyBlock1;\n', '');
			s = s.replace('int ___XXXXX__dummyBlock2;\n', '');
			s = s.replace('___XXXXX__FINAL_assert', 'assert');
		elif self._format == 'poirot':
			s = s.replace('___XXXXX__nondet_int()', 'poirot_nondet()')
			s = s.replace('___XXXXX__assume', '__hv_assume')
			s = s.replace('___XXXXX__assert', 'POIROT_ASSERT')
			s = s.replace('int ___XXXXX__dummyBlock1;\n', '');
			s = s.replace('int ___XXXXX__dummyBlock2;\n', '');
			s = s.replace('___XXXXX__FINAL_assert', 'POIROT_ASSERT');
		elif self._format == 'cpachecker':
			s = s.replace('___XXXXX__nondet_int()', 'nondet_int()')
			s = s.replace('___XXXXX__assume', '__CS_CPA_ASSUME')
			s = s.replace('___XXXXX__assert', '__CS_ASSERT')  # <------
			s = s.replace('int ___XXXXX__dummyBlock1;\n', 'void __CS_CPA_ASSERT(int expression) { if (!expression) { ERROR: goto ERROR; } return; }\n');
			s = s.replace('int ___XXXXX__dummyBlock2;\n', 'void __CS_CPA_ASSUME(int expression) { if (!expression) { LOOP: goto LOOP; } return; }\n');
			s = s.replace('___XXXXX__FINAL_assert', '__CS_CPA_ASSERT');

		# Insert all missing chunks of code by replacing the last placeholders.
		s = s.replace("<insert-backend-here>", self._format)
		s = s.replace('<insert-main-args-here>\n', self.mainParametersDecl)
		s = s.replace('<insert-date-here>', strftime("%Y-%m-%d %H:%M:%S", gmtime()))
		s = s.replace('<insert-union-here>', self.unionDeclaration)

		self.s = utils.strip(s)


	def _make_indent(self, delta=0):
		return (self.indent_level+delta) * self.INDENT_SPACING


	def _make_header(self):
		# This block is added at the top of the output file.
		# All the function calls starting with '___XXXXX__' are place-holders and
		# will be replaced later on, depending on the format chosen.
		# The placeholder <insert-include-statements-here> will be replaced with the original
		# #include lines (that we assume to be at the top of the input and without empty lines)
		# exactly as they were.
		#
		headerBlock = ''

		variables=self.variables
		pthread_condt_variables=[]
		if utils.fileContains(self._inputFilename, 'pthread_cond_wait'):
			for i in range (0, self._maxthreads):
				variables.append("lock_cond_"+str(i))

		#############		prima di atomic
		'''
		if self.verifier_atomic:
			variables.append("__atomic")
		'''
		############

		#self.numExplodeArray=16
		self.numExplodeArray=1
		for f in self.parser.funcName:
			for v in self.parser.varNames[f]:
				if f == '':
					if self.parser.varKind['', v] == 'p':
						continue
					if  self.parser.varType['',v].startswith('pthread_t'):
						continue

					if self.__isPointer(f,v) and not self.parser.varType['',v].startswith("pthread_mutex_t"):
						#variables.append(v+"__valid")
						for i_1 in range (0,self.numExplodeArray):
							variables.append(v+"__"+str(i_1))
							i_1=i_1+1
					elif self.parser.varType['',v].startswith('struct '):
						struct_type=self.parser.varType['',v][7:]
						for line in self.__explodeVariable(v):
							#print line+"-----"+self.parser.varType['','queue.element']
							indexBracket = line.find('[')
							indexDot = line.find('.')
							line = line.replace('[', '__')
							line = line.replace(']', '')
							line = line.replace('.', '___')
							variables.append(line)
					elif (self.parser.varArity[f, v]>0):
						arity_var=self.parser.varArity[f, v]
						if (arity_var>0):
							#print v+"-----"+self.parser.varType['',v]
							for line in self.__explodeVariable(v):
								indexBracket = line.find('[')
								indexDot = line.find('.')
								line = line.replace('[', '__')
								line = line.replace(']', '')
								line = line.replace('.', '___')
								'''
								if (self.parser.varType['',v]=="_Bool"):
									self.isBool.append(line)
									#print line
								'''
								variables.append(line)
					else:
						if self.parser.varType['',v]=='pthread_cond_t':
							pthread_condt_variables.append(v)
						else:
							#print v+"-----"+self.parser.varType['',v]
							'''
							if (self.parser.varType['',v]=="_Bool"):
								self.isBool.append(v)
								#print v
							'''
							variables.append(v)







		if variables.__len__()==0:
			variables.append("at_least_one_global")
		self.MEM_SIZE=self._nwrites
		MEM_SIZE=self.MEM_SIZE
		NumThreads=self._maxthreads
		NUM=0
		NumVars=variables.__len__()


		tmpTerminated="{"
		for i in range(0, NumThreads):
			tmpTerminated+="0"
			if i<(NumThreads-1):
				tmpTerminated+=","
		tmpTerminated+="}"


		for item in variables:
			isArr=0
			for i in range(0, 10):
				if (item.find("__%s"%i)>0):
					isArr=1
			if (isArr==1):
				self.isArray.append(item)
			else:
				self.isScalar.append(item)

		f = open('my-include-grained/header-grained.c')
		lines = f.readlines()
		f.close()
		headerBlock=""
		for line in lines:
			headerBlock+=line
		headerBlock = headerBlock.replace('<insert-MEM_SIZE-here>', str(MEM_SIZE))
		headerBlock = headerBlock.replace('<insert-NumThreads-here>', str(NumThreads))

		arrayCopy="void  array_copy(__CS_type thpos){\n\n"
		for item in variables:
			arrayCopy +="\n     ArrInContext[%s] = __memory[thpos][%s];" % (item, item)

		arrayCopy +="\n}"
		headerBlock = headerBlock.replace('<insert-array_copy-here>', arrayCopy)


		arrayEqual="_Bool  array_equal(){\n\n"
		arrayEqual+="__CPROVER_assume(1"
		for item in variables:
			arrayEqual +="\n     && (updatedVars[thread_pos][%s] == __memory[thread_pos][%s])" % (item, item)

		arrayEqual +="\n);"
		arrayEqual +="\nreturn 1;"
		arrayEqual +="\n}"
		headerBlock = headerBlock.replace('<insert-array_equal-here>', arrayEqual)


		#headerBlock = headerBlock.replace('<insert-type-variables-here>', str(math.ceil (math.log( NumVars + 1 ))))

		headerBlock = headerBlock.replace('<insert-type-type-here>', str(math.ceil (math.log( MEM_SIZE+1,2)+2)).replace(".0",""))
		headerBlock = headerBlock.replace('<insert-type-typeV-here>', str(math.ceil (math.log( NumVars+1,2))).replace(".0",""))
		headerBlock = headerBlock.replace('<insert-type-typeT-here>', str(math.ceil (math.log( NumThreads+1,2))).replace(".0",""))


		'''
		headerBlock = headerBlock.replace('<insert-type-typeV-here>', str(round (math.log( NumVars,2) + 1)).replace(".0",""))
		headerBlock = headerBlock.replace('<insert-type-typeT-here>', str(round (math.log( NumThreads,2)+1)).replace(".0",""))
		'''







		i=0
		s1 = ""
		str_tmp=""
		for item in self.isScalar:

			i1=item.find("___")
			i2=item.find("__0")
			min=self._min4(i1, i2, -1, -1)
			tmp_varname=item[:min]
			if min>=0 and min<500 and str_tmp!=tmp_varname:
				str_tmp=tmp_varname
				s1 += "\n#define %s %s"% (tmp_varname, i)

			s1 += "\n#define %s %s"% (item, i)
			i=i+1

		#i=0
		#s1 = ""
		str_tmp=""
		for item in self.isArray:
			i1=item.find("___")
			i2=item.find("__0")
			min=self._min4(i1, i2, -1, -1)
			tmp_varname=item[:min]
			if min>=0 and min<500 and str_tmp!=tmp_varname:
				str_tmp=tmp_varname
				s1 += "\n#define %s %s"% (tmp_varname, i)

			s1 += "\n#define %s %s"% (item, i)
			i=i+1









		#if self.verifier_atomic:
		#	s1 += "\n#define codeVar_atomic %s"% (i)


		headerBlock = headerBlock.replace('<insert-NumIntVar-here>', str(self.isScalar.__len__()))


		headerBlock = headerBlock.replace('<insert-define-global-variables-here>', s1)
		headerBlock = headerBlock.replace('<insert-NumVars-here>', str(NumVars))
		headerBlock = headerBlock.replace('<insert-Terminated-here>', tmpTerminated)

		s1=""
		if self.verifier_atomic:
			s1  = "_Bool cannot_next_atomic_write[MaxNumThreads];\n"
			s1 += "_Bool visible[MEM_SIZE];"

		headerBlock = headerBlock.replace('<insert-atomic-declaration-here>', s1)


		s1 = ""
		if utils.fileContains(self._inputFilename, 'pthread_cond_wait'):
			s1 += "\n//pthread_cond_t"
			i=1
			for item in pthread_condt_variables:
				s1 += "\n#define %s %s"% (item, i)
				i=i+1
			s1 += "\n"
			s1 += "\n"

		headerBlock = headerBlock.replace('<insert-pthread_cond_wait-here>', s1)










		#############
		#headerBlock = headerBlock.replace('<insert-assume-atomic-here>', '')
		if self.verifier_atomic:
			headerBlock = headerBlock.replace('<insert-assume-atomic-here>', '__CPROVER_assume(visible[thread_pos]);')
		else:
			headerBlock = headerBlock.replace('<insert-assume-atomic-here>', '')

		############
		if self.schema=="2":
			if self.verifier_atomic:
				headerBlock = headerBlock.replace('<insert-assume-threadpos-atomic-here>', '__CPROVER_assume(visible[thread_pos]);')
				headerBlock = headerBlock.replace('<insert-assume-jump-atomic-here>', '__CPROVER_assume(visible[jump]);')
			else:
				headerBlock = headerBlock.replace('<insert-assume-threadpos-atomic-here>', '')
				headerBlock = headerBlock.replace('<insert-assume-jump-atomic-here>', '')


		return headerBlock


	def _getCurrentCoords(self, item):
		return ''
		return '/*cseq:coords '+ str(item.coord) +' */\n'

	def build_check_block(self):


		self.check_block = "void check1(void){  "
		self.check_block +="\n "
		self.check_block +="\n "
		self.check_block +="\n//INITIALIZATION OF SHARED VARIABLES "
		self.check_block +="\n"+self.initialization+"\n"

		#############
		#if self.verifier_atomic:
		#	self.check_block +="\n\t__atomic[0] = 0;\n"
		#############



		self.check_block +="\n\n//END INITIALIZATION OF SHARED VARIABLES"

		if (self.isArray.__len__()>0):
			self.check_block +="\nintV values_tmp[MEM_SIZE]; "



		self.check_block +="\nintV __memory_tmp[MEM_SIZE][NumVars]; "
		#self.check_block +="\nint __memory_tmp[NumVars][MEM_SIZE]; "

		#self.check_block +="\nint __memory_bool_tmp[%s][MEM_SIZE]; "%self.isBool.__len__();
		''' tolto combe bool
		if (self.isBool.__len__()>0):
			self.check_block +="\n_Bool __memory_bool_tmp[%s][MEM_SIZE]; "%(self.isScalar.__len__());
			#self.check_block +="\n_Bool __memory_bool_tmp[NumVars][MEM_SIZE]; "
		'''
		#self.check_block +="\n_Bool atomic_tmp[MEM_SIZE];"
		self.check_block +="\n"
		self.check_block +="\n__CS_type  nondet;"
		self.check_block +="\n__CPROVER_assume( (nondet>0) && (nondet <= MEM_SIZE) );"
		self.check_block +="\nmemory_notvalid = nondet;"
		self.check_block +="\n"
		'''
		if self.verifier_atomic:
			self.check_block +="\n_Bool visible_tmp[MEM_SIZE];"
			self.check_block +="\nvisible[0] = 1;"
		'''
		MEM_SIZE=self.MEM_SIZE
		variables=self.variables
		#gen_i=1
		Nvars=variables.__len__();
		'''   non serve piu'
		if (self.verifier_atomic):
			Nvars=Nvars+1
		'''


		for i in range(0, MEM_SIZE):
			for item in variables:
				self.check_block +="\n     __memory[%s][%s] = __memory_tmp[%s][%s];" % (i,item,i, item)
				if i>0:
					self.check_block +="\n     updatedVars[%s][%s] = __memory[%s][%s];" % (i,item,i-1, item)
			self.check_block +="\n "


		self.check_block +="\n"
		self.check_block +="\n"


		self.check_block +="\n"
		self.check_block +="\n"
		self.check_block +="\n}"

	def build_check_block3(self):


		self.check_block = "void check1(void){  "
		self.check_block +="\n "
		self.check_block +="\n "
		self.check_block +="\n//INITIALIZATION OF SHARED VARIABLES "
		self.check_block +="\n"+self.initialization+"\n"

		#############
		#if self.verifier_atomic:
		#	self.check_block +="\n\t__atomic[0] = 0;\n"
		#############



		self.check_block +="\n\n//END INITIALIZATION OF SHARED VARIABLES"

		if (self.isArray.__len__()>0):
			self.check_block +="\nintV values_tmp[MEM_SIZE]; "



		self.check_block +="\nintV __memory_tmp[MEM_SIZE][NumVars]; "
		#self.check_block +="\nint __memory_tmp[NumVars][MEM_SIZE]; "

		#self.check_block +="\nint __memory_bool_tmp[%s][MEM_SIZE]; "%self.isBool.__len__();
		''' tolto combe bool
		if (self.isBool.__len__()>0):
			self.check_block +="\n_Bool __memory_bool_tmp[%s][MEM_SIZE]; "%(self.isScalar.__len__());
			#self.check_block +="\n_Bool __memory_bool_tmp[NumVars][MEM_SIZE]; "
		'''
		self.check_block +="\n__CS_typeV var_name_tmp[MEM_SIZE];"
		self.check_block +="\n__CS_typeT thread_tmp[MEM_SIZE];"
		#self.check_block +="\n_Bool atomic_tmp[MEM_SIZE];"
		self.check_block +="\n"
		self.check_block +="\n__CS_type  nondet;"
		self.check_block +="\n__CPROVER_assume( (nondet>0) && (nondet <= MEM_SIZE) );"
		self.check_block +="\nmemory_notvalid = nondet;"
		self.check_block +="\n"
		'''
		if self.verifier_atomic:
			self.check_block +="\n_Bool visible_tmp[MEM_SIZE];"
			self.check_block +="\nvisible[0] = 1;"
		'''
		MEM_SIZE=self.MEM_SIZE
		variables=self.variables
		#gen_i=1
		Nvars=variables.__len__();
		'''   non serve piu'
		if (self.verifier_atomic):
			Nvars=Nvars+1
		'''

		self.check_block +="\n		thread[0] = MaxNumThreads;"

		for i in range(0, MEM_SIZE):
			'''
			self.check_block +="\n//		var_name[%s] = var_name_tmp[%s];" % (i,i)
			self.check_block +="\n//		__CPROVER_assume((var_name[%s] >= 0 ) && (var_name[%s] < %s ));" % (i,i,Nvars)
			'''
			self.check_block +="\n		thread[%s] = thread_tmp[%s];" % (i,i)
			self.check_block +="\n		__CPROVER_assume((thread[%s] >= 0) && (thread[%s] < GuessedNumThreads) && (thread[%s] != thread[%s]) );" % (i,i,i,i-1)
			'''
			if (self.isArray.__len__()>0):
				self.check_block +="\n		values[%s] = values_tmp[%s];" % (i,i)
			'''
			for item in variables:
				#self.check_block +="\n		int p%s;"%(gen_i)
				''' tolto combe bool
				if (item not in self.isArray):
					if (item in self.isBool):
						self.check_block +="\n     __memory_bool[%s][%s] = __memory_bool_tmp[%s][%s];" % (item,i, item,i)
					else:
						self.check_block +="\n     __memory[%s][%s] = __memory_tmp[%s][%s];" % (item,i, item,i)
				'''
				self.check_block +="\n     __memory[%s][%s] = __memory_tmp[%s][%s];" % (i,item,i, item)
				if i>0:
					self.check_block +="\n     updatedVars[%s][%s] = __memory[%s][%s];" % (i,item,i-1, item)





			'''
			###############
			if self.verifier_atomic:
				self.check_block +="\n     visible[%s] = visible_tmp[%s];" % (i,i)
				#self.check_block +="\n		__CPROVER_assume((__atomic[%s] <=  NumThreads));" % (i)
				#self.check_block +="\n		__CPROVER_assume( thread[%s] ==  (  (__atomic[%s] <  NumThreads) ? __atomic[%s] : thread[%s]));"%(i,i,i,i)
			###############
			'''


			self.check_block +="\n "


		self.check_block +="\n"
		self.check_block +="\n"


		'''
		if (self.isArray.__len__()>0):
			for i in reversed(xrange(1,MEM_SIZE)):
				#self.check_block +="\n__CPROVER_assume(next[ %s ] == ((tmp_variables[ var_name[%s] ]==0) ? MEM_SIZE : tmp_variables[ var_name[%s] ]));"%(i, i,i)
				self.check_block +="\nnext[ %s ] = (((first_write[ var_name[%s] ]==0) || (%s >= memory_notvalid) ) ? MEM_SIZE : first_write[ var_name[%s] ]);"%(i, i, i, i)
				#self.check_block +="\nnext[ %s ] = first_write[ var_name[%s] ];"%(i, i)
				#self.check_block +="\ntmp_variables[ var_name[%s] ] = %s;"%(i, i)
				self.check_block +="\nfirst_write[ var_name[%s] ] = %s;"%(i, i)

				#self.check_block +="\nnext_thread[ %s ] = first_thread[ thread[%s] ];"%(i, i)
				#self.check_block +="\nfirst_thread[ thread[%s] ] = %s;"%(i, i)
			self.check_block +="\nvar_name[ 0 ] = NumVars;"
			self.check_block +="\n"
			self.check_block +="\n"
		'''


		self.check_block +="\n"
		self.check_block +="\n"
		self.check_block +="\n}"



	def build_check_block2(self):


		self.check_block = "void check1(void){  "
		self.check_block +="\n "
		self.check_block +="\n "
		self.check_block +="\n//INITIALIZATION OF SHARED VARIABLES "
		self.check_block +="\n"+self.initialization+"\n"

		#############
		#if self.verifier_atomic:
		#	self.check_block +="\n\t__atomic[0] = 0;\n"
		#############



		self.check_block +="\n\n//END INITIALIZATION OF SHARED VARIABLES"
		self.check_block +="\nint values_tmp[MEM_SIZE]; "

		self.check_block +="\n__CS_typeV var_name_tmp[MEM_SIZE];"
		self.check_block +="\n__CS_typeT thread_tmp[MEM_SIZE];"
		#self.check_block +="\n_Bool atomic_tmp[MEM_SIZE];"
		self.check_block +="\n"
		self.check_block +="\n__CS_type  nondet;"
		self.check_block +="\n__CPROVER_assume( (nondet>0) && (nondet <= MEM_SIZE) );"
		self.check_block +="\nmemory_notvalid = nondet;"
		self.check_block +="\n"
		if self.verifier_atomic:
			self.check_block +="\n_Bool visible_tmp[MEM_SIZE];"
			self.check_block +="\nvisible[0] = 1;"

		MEM_SIZE=self.MEM_SIZE
		variables=self.variables
		#gen_i=1
		Nvars=variables.__len__();
		if (self.verifier_atomic):
			Nvars=Nvars+1

		for i in range(1, MEM_SIZE):
			self.check_block +="\n		var_name[%s] = var_name_tmp[%s];" % (i,i)
			self.check_block +="\n		__CPROVER_assume((var_name[%s] >= 0 ) && (var_name[%s] < %s ));" % (i,i,Nvars)
			self.check_block +="\n		thread[%s] = thread_tmp[%s];" % (i,i)
			self.check_block +="\n		__CPROVER_assume((thread[%s] >= 0) && (thread[%s] < GuessedNumThreads));" % (i,i)
			self.check_block +="\n		values[%s] = values_tmp[%s];" % (i,i)

			###############
			if self.verifier_atomic:
				self.check_block +="\n     visible[%s] = visible_tmp[%s];" % (i,i)
				#self.check_block +="\n		__CPROVER_assume((__atomic[%s] <=  NumThreads));" % (i)
				#self.check_block +="\n		__CPROVER_assume( thread[%s] ==  (  (__atomic[%s] <  NumThreads) ? __atomic[%s] : thread[%s]));"%(i,i,i,i)
			###############



			self.check_block +="\n "
		self.check_block +="\n"
		self.check_block +="\n"
		for i in reversed(xrange(1,MEM_SIZE)):
			#self.check_block +="\n__CPROVER_assume(next[ %s ] == ((tmp_variables[ var_name[%s] ]==0) ? MEM_SIZE : tmp_variables[ var_name[%s] ]));"%(i, i,i)
			self.check_block +="\nnext[ %s ] = (((first_write[ var_name[%s] ]==0) || (%s >= memory_notvalid) ) ? MEM_SIZE : first_write[ var_name[%s] ]);"%(i, i, i, i)
			#self.check_block +="\nnext[ %s ] = first_write[ var_name[%s] ];"%(i, i)
			#self.check_block +="\ntmp_variables[ var_name[%s] ] = %s;"%(i, i)
			self.check_block +="\nfirst_write[ var_name[%s] ] = %s;"%(i, i)

			#self.check_block +="\nnext_thread[ %s ] = first_thread[ thread[%s] ];"%(i, i)
			#self.check_block +="\nfirst_thread[ thread[%s] ] = %s;"%(i, i)
		self.check_block +="\nvar_name[ 0 ] = NumVars;"
		self.check_block +="\n"
		self.check_block +="\n"
		for t in range(0,self._maxthreads):
			self.check_block +="\n     thw[%s][%s]=MEM_SIZE;"%(t, MEM_SIZE-1)
		for i in range(MEM_SIZE-1, 0,-1):
			for t in range(0,self._maxthreads):
				self.check_block +="\n    thw[%s][%s] =    (thread[%s] == %s) ? %s : thw[%s][%s] ; "%(t, i-1,  i, t, i, t, i)
			self.check_block +="\n "
		self.check_block +="\n"
		self.check_block +="\n"
		self.check_block +="\n}"

	def build_check_block1(self):
		return


	def visit_Constant(self, n):
		'''
		if (self.whereInAssignment=="r") and (self.inGlobalPointer==1):
			return "("+n.value+"/4)"
		'''
		return n.value



	def visit_ID(self, n):

		nameVar=n.name
		if self.equalToGlobalName.has_key(self.currentFunct+"_"+n.name)==True:
			nameVar=self.equalToGlobalName[self.currentFunct+"_"+n.name]
			if self.IsFakeFunct==0:
				return nameVar

		if self.global_parameters2.has_key(self.currentFunct+"_"+n.name)==True:
			nameVar=self.global_parameters2[self.currentFunct+"_"+n.name]



		if self.__isGlobaVariable(n.name) and self.parser.varType['',n.name].startswith('pthread_t'):
			return n.name




		if n.name in self.parser.varNames[''] and self.visitStarted==0:
			#tmp=n.name
			tmp=nameVar
			f=''

			if self.isInFuncCall:
				self.suffixCall+="___"+n.name
				return "<param-global-null>"



			if self.parser.varArity[f, n.name]>0:
				tmp+="__0"
				if self.isInFuncCall and self.__isArray('', n.name):
					self.suffixCall=n.name
					return "0"
			#print "Read---"+tmp
			if (tmp in self.isBool):
				return "Read_Bool("+tmp+")"
			return "Read("+tmp+")"
		else:
			return nameVar



	def visit_ArrayRef(self, n):
		tmp_isInArrayOrStruct=self.isInArrayOrStruct
		self.isInArrayOrStruct="a"
		arrref = self._parenthesize_unless_simple(n.name)


		tmp_visitStarted=self.visitStarted
		self.visitStarted=1
		tmp=self.__first_ID(self._parenthesize_unless_simple(n.name))
		self.visitStarted=tmp_visitStarted

		ret=""
		if tmp not in self.parser.varNames[''] and self.currentFunct+"_"+tmp not in self.global_parameters: # only consider global variables
			ret = arrref + '[' + self.visit(n.subscript) + ']'
		elif self.__isGlobaVariable(tmp) and self.parser.varType['',tmp].startswith('pthread_t'):
			ret = arrref + '[' + self.visit(n.subscript) + ']'
		elif self.visitStarted==0:
			self.visitStarted=1
			arrref = self._parenthesize_unless_simple(n.name)
			self.visitStarted=0
			#ret = "Read("+arrref + '__0+' + self.visit(n.subscript) + ')'
			ret = "Read_from_array("+arrref + '__0+' + self.visit(n.subscript) + ')'
		else:
			self.visitStarted=0
			ret = arrref + '__0+' + self.visit(n.subscript)

		self.isInArrayOrStruct=tmp_isInArrayOrStruct
		return ret


	def visit_StructRef(self, n):
		tmp_isInArrayOrStruct=self.isInArrayOrStruct
		self.isInArrayOrStruct="a"

		sref = self._parenthesize_unless_simple(n.name)


		tmp_visitStarted=self.visitStarted
		self.visitStarted=1
		tmp=self.__first_ID(self._parenthesize_unless_simple(n.name))
		self.visitStarted=tmp_visitStarted

		ret = ""
		if tmp not in self.parser.varNames[''] and self.currentFunct+"_"+tmp not in self.global_parameters: # only consider global variables
			ret = sref + n.type + self.visit(n.field)
		elif self.__isGlobaVariable(tmp) and self.parser.varType['',tmp].startswith('pthread_t'):
			ret = sref + n.type + self.visit(n.field)
		elif self.visitStarted==0:
			self.visitStarted=1
			sref = self._parenthesize_unless_simple(n.name)
			self.visitStarted=0
			ret = "Read("+sref + "___" + self.visit(n.field)+")"
		else:
			self.visitStarted=0
			ret = sref + "___" + self.visit(n.field)

		self.isInArrayOrStruct=tmp_isInArrayOrStruct
		return ret




	def visit_IfOld(self, n):
		s = 'if ('
		if n.cond: s += self.visit(n.cond).replace(";","").replace('\n '+self._make_indent()+'if (__CS_ret) return',"")
		s += ')\n'
		s += self._generate_stmt(n.iftrue, add_indent=True)
		if n.iffalse:
			s += self._make_indent() + 'else\n'
			s += self._generate_stmt(n.iffalse, add_indent=True)


		return s


	def visit_If(self, n):
		s = 'if ('
		if n.cond: s += self.visit(n.cond).replace(";","").replace('\n '+self._make_indent()+'if (__CS_ret) return',"").replace("if (nondet_int() || __CS_ret){__CS_ret=1 return 0}\n","")
		s += ')\n'
		p = self._generate_stmt(n.iftrue, add_indent=True)
		if ((p.strip().startswith("{"))==False): s+= self._make_indent() + "{\n";
		s += p
		if n.iffalse:
			if ((p.strip().startswith("{"))==False): s += self._make_indent() + '}else\n'
			else: s += self._make_indent() + 'else\n'
			s += self._generate_stmt(n.iffalse, add_indent=True)
		if ((p.strip().startswith("{"))==False): s+= self._make_indent() + "}\n";


		return s



	def visit_FuncCall(self, n):
		fref = self._parenthesize_unless_simple(n.name)

		# pthread_ primitives currenly not-handled will cause CSeq to quit.
		if fref in notHandledPrimitives:  # e.g. 'pthread_cond_wait', ...
			#print "UNKNOWN (code:02)\n"
			print("Conversion error:  use of '%s' is currently not handled." % fref)
			sys.exit(-1)

		if fref == 'fprintf':
			return ''


		if (fref == self.error_label):
			tmp_errorBlock = errorBlock1
			tmp_errorBlock = tmp_errorBlock.replace('<return_statement>', 'Release_lock__atomic_function();\t<return_statement>')
			'''
			if self.parsingAtomic == True:
				tmp_errorBlock = tmp_errorBlock.replace('<return_statement>', 'Release_lock__atomic_function();\t<return_statement>')
			'''
			if self.parsingVoidFunction == True:
				return tmp_errorBlock.replace('<return_statement>', 'return')# + self._generate_stmt(n.stmt)
			else:
				return tmp_errorBlock.replace('<return_statement>', 'return 0')# + self._generate_stmt(n.stmt)


		if fref == '__VERIFIER_atomic_begin': return 'Take_lock__atomic_function()'
		if fref == '__VERIFIER_atomic_end': return 'Release_lock__atomic_function()'

		if fref == 'sscanf':
			self.isInFuncCall=1
			self.visitStarted=1
			fref  = "Write("
			fref +=self.visit(n.args).split(',')[2].replace("&","")+", "
			fref +="(int)(*"+self.visit(n.args).split(',')[0]+"))"
			self.isInFuncCall=0
			self.visitStarted=0
			return fref

		# Maps the original pthread api calls to wSeq-simulated functions.
		if fref == 'pthread_mutex_lock':
			self.visitStarted=1
			self.parsingAtomic = True
			fref = '__pthread_mutex_lock'+'('+self.visit(n.args).replace("&","") + ');'
			fref += '\n '+self._make_indent()+'if (__CS_ret) return'
			self.visitStarted=0
			return fref
		if fref == 'pthread_mutex_unlock':
			self.visitStarted=1
			fref = '__pthread_mutex_unlock'+'('+self.visit(n.args).replace("&","") + ');'
			fref += '\n '+self._make_indent()+'if (__CS_ret) return'
			self.parsingAtomic = False
			self.visitStarted=0
			return fref
		if fref == 'pthread_mutex_init':
			self.visitStarted=1
			fref = '__pthread_mutex_init'+'('+self.visit(n.args).replace("&","") + ');'
			fref += '\n '+self._make_indent()+'if (__CS_ret) return'
			self.visitStarted=0
			return fref
		if fref == 'pthread_mutex_destroy':
			self.visitStarted=1
			fref = '__pthread_mutex_destroy'+'('+self.visit(n.args).replace("&","") + ');'
			fref += '\n '+self._make_indent()+'if (__CS_ret) return'
			self.visitStarted=0
			return fref

		if fref == 'pthread_join': fref = '__pthread_join'
		if fref == 'pthread_create':

			self.isInFuncCall=1
			self.visitStarted=1



			thread_Funct = self.visit(n.args).split(',')[2].replace("&","")[1:]
			nameFunc = "__pthread_create_"+thread_Funct
			if thread_Funct in self.renameFunct:
				nameFunc = "__pthread_create___"+thread_Funct+"1"


			#fref  = "if (nondet_int() || __CS_ret){__CS_ret=1; return 0;}\n"+nameFunc+"("
			fref  = nameFunc+"("
			fref +=self.visit(n.args).split(',')[0]+", "
			fref +=self.visit(n.args).split(',')[1]+", "
			fref +=self.visit(n.args).split(',')[3]+");"

			if self.pthread_create_block.find(nameFunc)<0:
				self.pthread_create_block += "int "+nameFunc
				if thread_Funct in self.renameFunct:
					self.pthread_create_block += pthread_create_block_static.replace("<insert-thread-routine-here>","__"+thread_Funct+"1")
				else: self.pthread_create_block += pthread_create_block_static.replace("<insert-thread-routine-here>",thread_Funct)
			self.isInFuncCall=0
			self.visitStarted=0
			fref=fref.replace("<param-global-null>","0")
			fref=fref.replace("&0","0")
			return fref


		if fref == 'pthread_cond_init':
			self.visitStarted=1
			fref = '__pthread_cond_init'
			fref += '('+str(self.visit(n.args)).replace("&","")+');'
			self.visitStarted=0
			return fref;
		if fref == 'pthread_cond_wait':
			self.visitStarted=1
			fref  = '__pthread_cond_wait'
			fref += '(lock_cond_0+thread_index,'+str(self.visit(n.args)).replace("&","")+');'
			fref += '\n '+self._make_indent()+'if (__CS_ret) return;'
			self.visitStarted=0
			return fref;
		if fref == 'pthread_cond_signal':
			self.visitStarted=1
			fref = '__pthread_cond_signal'
			fref += '('+str(self.visit(n.args)).replace("&","")+', lock_cond_0);'
			fref += '\n '+self._make_indent()+'if (__CS_ret) return;'
			self.visitStarted=0
			return fref;

		if fref == 'pthread_exit':
			fref  = '//__pthread_exit(NULL);'
			fref += '\n'+self._make_indent()+'if (__CS_ret) return;'
			fref += '\n'+self._make_indent()+'__CS_ret=1; '
			fref += '\n'+self._make_indent()+'terminated[thread_index]=0;'
			fref += '\n'+self._make_indent()+'return;'
			return fref

		if fref == 'printf':
			fref = ''
			return fref

		if fref == 'assume': fref = '__CPROVER_assume'
		if fref == '__ESBMC_assume': fref = '__CPROVER_assume'
		if fref == '__VERIFIER_assume': fref = '__CPROVER_assume'


		if fref == 'assert': fref = 'assert'
		if fref == '__ESBMC_assert': fref = 'assert'
		# if fref == '__VERIFIER_assert': fref = 'assert'

		# Mapping of standard verifier function calls in the main()
		if fref == '__VERIFIER_nondet_int': fref = '___XXXXX__nondet_int'
		if fref == '__VERIFIER_assume': fref = '___XXXXX__assume'

		if fref == '__ESBMC_atomic_begin' or fref == '__VERIFIER_atomic_begin' or fref == '__CS_atomic_begin' or fref == '_cs___VERIFIER_atomic_begin':
			fref = '//cseq: atomic section starts here '
			self.parsingAtomic = True

		if fref == '__ESBMC_atomic_end' or fref == '__VERIFIER_atomic_end' or fref == '__CS_atomic_end' or fref == '_cs___VERIFIER_atomic_end':
			fref = '//cseq: atomic section stops here '
			self.parsingAtomic = False


		if fref in self.renameFunct:
			fref="__"+fref

		if fref=="strcpy":
			tmp_args = self.visit(n.args).split(",")
			tmp_arg1 = tmp_args[0].replace("Read(","").replace(")","")
			tmp_decl_name = "strcpy_"+tmp_arg1
			if tmp_decl_name not in self.funcName:
				tmp_strcpy_block="int "+tmp_decl_name+"(const char *s)\n"
				tmp_strcpy_block+="{\n"
				tmp_strcpy_block+="	int i=0;\n"
				tmp_strcpy_block+="	Jump();\n"
				tmp_strcpy_block+="	while(s && *s++)\n"
				tmp_strcpy_block+="	{\n"
				tmp_strcpy_block+="		if (Read_atomic("+tmp_arg1+"__0+i) > Read_atomic("+tmp_arg1+")){__CS_ret=1; return 0;}\n"
				tmp_strcpy_block+="		Write_atomic ("+tmp_arg1+"__0+i, s[i]);\n"
				tmp_strcpy_block+="		i++;\n"
				tmp_strcpy_block+="	}\n"
				tmp_strcpy_block+="	return 0;\n"
				tmp_strcpy_block+="}\n"

				self.functionBlock1+="\n" + tmp_strcpy_block + '\n'
				self.funcName.append(tmp_decl_name)

			return tmp_decl_name + "("+tmp_args[1]+");"

		self.isInFuncCall=1
		self.suffixCall=""
		tmp_declaration=self.visit(n.args)
		self.isInFuncCall=0
		notReplace=["__CPROVER_assume","__VERIFIER_assert","___XXXXX__nondet_int","__pthread_join","exit","malloc","assert","strcpy","__VERIFIER_atomic_assert"]
		if self.suffixCall!="" and fref not in notReplace:

			tmp_fref = fref
			fref = fref+self.suffixCall+'('+tmp_declaration+ ')'

			self.visit_FuncDef_fake(self.parser.funcNode[tmp_fref], fref)
			fref=fref.replace("<param-global-null>","0")
			fref=fref.replace("&0","0")

			self.suffixCall=""
			return fref

		if fref.startswith('__VERIFIER_atomic'):
			#return fref + '(' + self.visit(n.args) + ');'+'\nif (nondet_int()	){__CS_ret=1; return 0;}\n'
			return fref + '(' + self.visit(n.args) + ');'

		if fref.startswith('__CPROVER_assume'):
			return 'if (nondet_int()	){__CS_ret=1; return 0;} ' + fref + '(' + self.visit(n.args) + ');\n'


		return fref + '(' + self.visit(n.args) + ')'



	def _min4(self, i1, i2, i3, i4):
		min=500
		#if i1>=0 and i2<min:
		if i1>=0 and i1<min:
			min=i1
		if i2>=0 and i2<min:
			min=i2
		if i3>=0 and i3<min:
			min=i3
		if i4>=0 and i4<min:
			min=i4
		return min



	def __first_ID(self, tmp):
		i1= tmp.find("->")
		i2= tmp.find("[")
		i3= tmp.find("___")
		i4= tmp.find("__0")
		min=self._min4(i1, i2, i3, i4)


		if min==500:
			tmp_varname=tmp
		else:
			tmp_varname=tmp[:min]
		return tmp_varname

	def visit_UnaryOp(self, n):

		operand = self._parenthesize_unless_simple(n.expr)

		self.visitStarted=1
		tmp=self._parenthesize_unless_simple(n.expr)
		self.visitStarted=0

		tmp_varname=self.__first_ID(tmp)



		rval_str="1"
		s=""

		if tmp_varname in self.parser.varNames[''] or self.currentFunct+"__"+tmp_varname in self.global_parameters: # only consider global variables
			jumpYes=""
#			if self.parsingAtomic==False:
#				jumpYes="Jump();\n"+self._make_indent()
			jumpYes=""
			if n.op == 'p++':
				return jumpYes+'Write(%s, Read(%s)+ 1)' % (tmp, tmp)
			elif n.op == 'p--':
				return jumpYes+'Write(%s, Read(%s)- 1)' % (tmp, tmp)
			elif n.op == '--':
				return jumpYes+'Write(%s, Read(%s)- 1)' % (tmp, tmp)
			elif n.op == 'sizeof':
				return 'sizeof(%s)' % self.visit(n.expr)
			elif n.op == '*':
				return 'Read('+tmp_varname+')'
			else:
				if self.__isStruct('', tmp_varname) and self.isInFuncCall and n.op=="&":
					return '<param-global-null>'
				return '%s%s' % (n.op, operand)
		else:
			return super(Translator, self).visit_UnaryOp(n)



	def visit_Assignment(self, n):


		self.whereInAssignment="r"
		self.inGlobalPointer=0
		rval_str = self._parenthesize_if(n.rvalue, lambda n: isinstance(n, pycparser.c_ast.Assignment))
		tmp_inGlobalPointer=self.inGlobalPointer
		self.inGlobalPointer=0
		self.whereInAssignment=""



		self.whereInAssignment="l"
		if self._is_simple_node(n.lvalue):
			self.visitStarted=1
			tmp=str(self.visit(n.lvalue))
			self.visitStarted=0
		else:
			tmp=str(self.visit(n.lvalue))



		is_an_array = 0

		#print "prima"+tmp
		if tmp.startswith("Read_from_array"):
			is_an_array = 1
			tmp=tmp[16:]
			tmp=tmp[:len(tmp)-1]
		elif tmp.startswith("Read"):
			tmp=tmp[5:]
			tmp=tmp[:len(tmp)-1]
		elif tmp.startswith("*"):
			tmp=tmp[1:]
		#print "dopo"+tmp

		tmp_varname=self.__first_ID(tmp)




#		rval_str=rval_str.replace("Read(","Read_atomic(");

		if tmp_varname in self.parser.varNames[''] or self.currentFunct+"_"+tmp_varname in self.global_parameters: # only consider global variables

			if rval_str.find("malloc")>=0:
				if rval_str.find("__CS_pthread_mutex_t")>=0:
					return ""
				if rval_str.find("*")<0:
					#return "if (nondet_int()) {Write("+tmp_varname+"__valid, " +tmp_varname+"__0 + 1)"
					return "if (nondet_int()) Write("+tmp_varname+", " +tmp_varname+" + 1)"
				#else: return "if (nondet_int()) Write("+tmp_varname+"__valid, " +tmp_varname+"__0 + "+rval_str.split("*")[len(rval_str.split("*"))-1]
				else: return "if (nondet_int()) Write("+tmp_varname+", " +tmp_varname+"__0 + "+rval_str.split("*")[len(rval_str.split("*"))-1]

			s=""


			if self.__isPointer('',tmp_varname):
				self.str_to_replace = "Read_atomic("+tmp_varname+")"
				self.str_with_replace = rval_str.replace("&","")
				#print self.str_to_replace+ " ----- "+ self.str_with_replace


			'''tolto per i puntatori
			if self.__isPointer('',tmp_varname):
				s+= "if (Read_atomic("+tmp+")>= Read_atomic("+tmp_varname+")){__CS_ret \\ 1; return 0;}\n"+self._make_indent()
				#print s
			'''

#			s += 'Write_atomic(%s, %s %s)' % (tmp, n.op, rval_str)
#			s = s.replace('+=', "Read_atomic("+tmp+")"+"+" )
#			s = s.replace('-=', "Read_atomic("+tmp+")"+"-" )



			#if (tmp_varname+"__0") in self.isArray:
			if (is_an_array==1) or ((tmp_varname+"__0") in self.isArray):
				s += 'Write_from_array(%s, %s %s)' % (tmp, n.op, rval_str)
				s = s.replace('+=', "Read_from_array("+tmp+")"+"+" )
				s = s.replace('-=', "Read_from_array("+tmp+")"+"-" )
			else:
				if self.atomicRead==0:
					'''
					s += 'Write(%s, %s %s)' % (tmp, n.op, rval_str)
					s = s.replace('+=', "Read("+tmp+")"+"+" )
					s = s.replace('-=', "Read("+tmp+")"+"-" )
					'''
					if self.parsingAtomic==True:
						rval_str=rval_str.replace("Read(","Read_atomic(")
						'''
						if self.parsingAtomic==False:
							s="Jump();\n"+self._make_indent()
						'''
						s += 'Write_atomic(%s, %s %s)' % (tmp, n.op, rval_str)
						s = s.replace('+=', "Read_atomic("+tmp+")"+"+" )
						s = s.replace('-=', "Read_atomic("+tmp+")"+"-" )
					else:
						s += 'Write(%s, %s %s)' % (tmp, n.op, rval_str)
						s = s.replace('+=', "Read("+tmp+")"+"+" )
						s = s.replace('-=', "Read("+tmp+")"+"-" )
				else:
					rval_str=rval_str.replace("Read(","Read_atomic(")
					'''
					if self.parsingAtomic==False:
						s="Jump();\n"+self._make_indent()
					'''
					s += 'Write_atomic(%s, %s %s)' % (tmp, n.op, rval_str)
					s = s.replace('+=', "Read_atomic("+tmp+")"+"+" )
					s = s.replace('-=', "Read_atomic("+tmp+")"+"-" )

			#print  tmp_varname+"---"+s+"------"+tmp


			s = s.replace(', =', ", " )
			s = s.replace('\\', "=" )

		else:
			'''
			if rval_str.find(" malloc")>=0 or rval_str.find(")malloc")>=0:
				print("malloc on local variables is currently not handled.")
				sys.exit(-1)
			'''
			tmp_lvalue=self.visit(n.lvalue)
			if tmp_inGlobalPointer==1:
				if (rval_str.startswith("*((int *)")):
					rval_str=rval_str.replace("*((int *)", "Read(")
				elif tmp_lvalue not in self.localPointer:
					self.localPointer.append(tmp_lvalue)
			if tmp_lvalue.startswith("*((int *)"):
				tmp_lvalue=tmp_lvalue.replace("*((int *)","Write(").replace(")",", ")
				s='%s %s)' % (tmp_lvalue, rval_str)
			else:
				s = '%s %s %s' % (tmp_lvalue, n.op, rval_str)

			s=s.replace("(void *) (&","(void *) (")


		return s


	def visit_IdentifierType(self, n):
		# Change 'pthread_mutex_t' to 'int' and so on,
		# put here everything type specific from pthread api that needs to be
		# mapped into 'fake' CSeq types for simulation!
		#
		if n.names[0] == 'pthread_t': n.names[0] = '__CS_pthread_t'
		if n.names[0] == 'pthread_mutex_t': n.names[0] = '__CS_pthread_mutex_t'
		if n.names[0] == 'pthread_cond_t': n.names[0] = '__CS_pthread_cond_t'

		### tm = ''.join(n.names)
		### print "VARIABLE TYPE: " +tm+ '\n'

		return ' '.join(n.names)


	def visit_Decl(self, n, no_type=False):
		initExpression = ''
		self.lastDeclarationL = ''
		self.lastDeclarationR = ''






		# no_type is used when a Decl is part of a DeclList, where the type is
		# explicitly only for the first declaration in a list.
		#
		s = n.name if no_type else self._generate_decl(n)
		### print "NEW DECLARATION %s TYPE:%s\n" % (n.name, n.type)

		#if self.currentFunct=="scull_open" and n.name=="__i":
		#	print "decl="+ n.name + "\ns="+s

		n_name=n.name


		if self.equalToGlobalName.has_key(self.currentFunct+"_"+n.name)==True:
			#print "decl="+ n.name + "------s="+self.equalToGlobalName[n.name]
			s=s[:len(s)-len(n.name)] + self.equalToGlobalName[self.currentFunct+"_"+n.name]
			n_name=self.equalToGlobalName[self.currentFunct+"_"+n.name]
			#print "decl="+ n.name



		# Transform global variables into arrays.
		# If already the original variable is an array, add another dimention.
		#
		if self.indent_level < 1 and self.parsingFuncDecl == False and 'FuncDecl' not in str(n.type) and 'Struct' not in str(n.type) and 'Union' not in str(n.type):
			self.indent_level+=1
			indent = self._make_indent();
			self.indent_level-=1

			if s.find(' '+n_name+'[') == -1: s = s
			else: s = s.replace(' '+n_name+'[', ' '+n_name+'[')

			# Remove the  static  modifier before global variables,
			# or in a struct that'll give syntax error.
			self.unionDeclaration += indent + s.replace('static ', '') + ';\n'

			# Dynamically allocated memory assigned to pointers..
			dynSize = ''

			if self.__isPointer(self.currentFunct,n_name): #### TODO the var here must be GLOBAL!!!
				s2 = s.replace(' *'+n_name, ' *__CS_cp_'+n_name)
			else:
				s2 = s.replace(' '+n_name, ' __CS_cp_'+n_name)

			self.copyVariableDeclaration += indent + s2 + ';'+ dynSize +'\n'




		self.lastDeclarationL = s




		if n.bitsize: s += ' : ' + self.visit(n.bitsize)

		if n.init:
			if not (self.indent_level < 1 and self.parsingFuncDecl == False and 'FuncDecl' not in str(n.type) and 'Struct' not in str(n.type) and 'Union' not in str(n.type)):
				bracketR = bracketL = ''
			else:
				bracketL = '{'
				bracketR = '}'


			if isinstance(n.init, pycparser.c_ast.ExprList): s += ' = {' + bracketL + self.visit(n.init) + bracketR + '}'
			else: s += ' = ' + bracketL + self.visit(n.init) + bracketR

			if self.__isGlobaVariable(n_name):
				if (self.visit(n.init)!="0"):
					self.initialization+="\nupdatedVars[0]["+n_name+"] = "
					if isinstance(n.init, pycparser.c_ast.ExprList): self.initialization += self.visit(n.init) + ')'
					else: self.initialization += self.visit(n.init) + ';'
					self.initializedGlobalVariables.append(n_name)
					s=""

		#s=s.replace('[__CS_ROUNDS]','')



		if self.__isGlobaVariable(n_name) and not self.parser.varType['',n_name].startswith('pthread_t'):
			s=""


		self.lastDeclaration = s

		return s


	def visit_FuncDef_fake(self, n, fCall):


		tmp_currentFunct=self.currentFunct
		tmp_parsingAtomic=self.parsingAtomic

		tmpNewFakeFunct=n.decl.name+self.suffixCall
		if n.decl.name.startswith('__VERIFIER_atomic'): self.parsingAtomic = True
		self.IsFakeFunct=1
		if tmpNewFakeFunct in self.funcName:
			self.currentFunct = tmp_currentFunct
			self.parsingAtomic = tmp_parsingAtomic
			return



		self.localPointer=[]

		self.currentFunct = n.decl.name

		decl = self.visit(n.decl).replace(n.decl.name, tmpNewFakeFunct)

		#print decl


		#self.equalToGlobalName={}
		for v in self.parser.varNames[self.currentFunct]:
			if self.__isGlobaVariable(v):
				self.equalToGlobalName[tmpNewFakeFunct+"_"+v]="__"+v
				#print "\nparameter is global variable: "+tmpNewFakeFunct+"_"+v+"----"+self.equalToGlobalName[tmpNewFakeFunct+"_"+v]





		tmpArrParamCall = fCall.split(",")
		iCount=1
		iCount2=1
		for x in tmpArrParamCall:
			if x.find("<param-global-null>")>=0:
				iCount1=1
				for v in self.parser.varNames[self.currentFunct]:
					if self.parser.varKind[self.currentFunct, v]=='p' and iCount1==iCount:
						self.global_parameters2[tmpNewFakeFunct+"_"+v]=self.suffixCall.split("___")[iCount2]
						iCount2+=1

					iCount1+=1
			iCount+=1




		self.currentFunct = tmpNewFakeFunct
		body = self.visit(n.body)


		self.funcName.append(self.currentFunct)
		if n.decl.name.startswith('__VERIFIER_atomic'): # no context switches in atomic functions
			'''
			jump_atomic  = ""
			jump_atomic += self._make_indent(1) + 'Jump_atomic();\n'
			jump_atomic += self._make_indent(1) + 'if (__CS_ret) return;\n'
			body  = body.replace("Read(","Read_atomic(").replace("Write(","Write_atomic(")
			i = body.find("{")+1
			body = body[:i]+"\n"+jump_atomic+body[i:]
			'''

			##################
			jump_atomic  = ""
			if not n.decl.name.startswith('__VERIFIER_atomic_end'):
				jump_atomic += self._make_indent(1) + 'Take_lock__atomic_function();\n'
				jump_atomic += self._make_indent(1) + 'if (__CS_ret) return;\n'
			body  = body.replace("Read(","Read_atomic(").replace("Write(","Write_atomic(")
			body  = body.replace("Read_Bool(","Read_Bool_atomic(").replace("Write_Bool(","Write_Bool_atomic(")
			body  = body.replace("Read_from_array(","Read_atomic_from_array(").replace("Write_from_array(","Write_atomic_from_array(")



			if not n.decl.name.startswith('__VERIFIER_atomic_begin'):
				body  = body.replace("return;","Release_lock__atomic_function(); return;")

			#body  = body.replace("Read(","Read_atomic(")
			i = body.find("{")+1
			body = body[:i]+"\n"+jump_atomic+body[i:body.rfind('\n}')-3]+"\nRelease_lock__atomic_function();\n}"
			################




		self.functionBlock1+="\n" + decl + '\n' + body + '\n'

		self.IsFakeFunct=0
		self.currentFunct=tmp_currentFunct
		self.parsingAtomic = tmp_parsingAtomic
		return




	def visit_FuncDef(self, n):


		self.functionBlock1=""



		self.localPointer=[]

		self.currentFunct = n.decl.name


		#self.equalToGlobalName={}
		for v in self.parser.varNames[self.currentFunct]:
			if self.__isGlobaVariable(v):
				self.equalToGlobalName[self.currentFunct+"_"+v]="__"+v



		self.funcName.append(n.decl.name)

		# Note: the function definition is in two parts:
		#       one is 'decl' and the other is 'body'
		decl = self.visit(n.decl)

		if n.decl.name in self.renameFunct:
			decl = decl.replace (n.decl.name, "__"+n.decl.name+"1")




		if n.decl.name == 'main': self.parsingMain = True
		if n.decl.name.startswith('__VERIFIER_atomic'): self.parsingAtomic = True
		if (decl.startswith("void") or decl.startswith("inline void") ) and not decl.startswith("void *"): self.parsingVoidFunction = True
		else: self.parsingVoidFunction = False


		if self.firstFunctionDefinitionDone == False:
			if len(self.parser.varNames['']) > self.parser.extraGlovalVarCount:
				self.unionDeclaration = self.unionDeclaration + '};\n\nunion __CS__u __CS_u;\n\n'

			self.firstFunctionDefinitionDone = True

		body = ''

		# The body is a Compound node
		if n.decl.name.startswith('__VERIFIER_atomic'): # no context switches in atomic functions
			'''
			jump_atomic  = ""
			jump_atomic += self._make_indent(1) + 'Jump_atomic();\n'
			jump_atomic += self._make_indent(1) + 'if (__CS_ret) return;\n'
			body += self.visit(n.body)
			body  = body.replace("Read(","Read_atomic(").replace("Write(","Write_atomic(")
			i = body.find("{")+1
			body = body[:i]+"\n"+jump_atomic+body[i:]
			'''
			####################
			jump_atomic  = ""
			if not n.decl.name.startswith('__VERIFIER_atomic_end'):
				jump_atomic += self._make_indent(1) + 'Take_lock__atomic_function();\n'
				jump_atomic += self._make_indent(1) + 'if (__CS_ret) return;\n'
			body += self.visit(n.body)
			body  = body.replace("Read(","Read_atomic(").replace("Write(","Write_atomic(")
			body  = body.replace("Read_Bool(","Read_Bool_atomic(").replace("Write_Bool(","Write_Bool_atomic(")
			body  = body.replace("Read_from_array(","Read_atomic_from_array(").replace("Write_from_array(","Write_atomic_from_array(")
			#body  = body.replace("Read(","Read_atomic(")
			i = body.find("{")+1
			if not n.decl.name.startswith('__VERIFIER_atomic_begin'):
				body  = body.replace("return;","Release_lock__atomic_function(); return;")
			body = body[:i]+"\n"+jump_atomic+body[i:body.rfind('\n}')]+"\nRelease_lock__atomic_function();\n}"
			####################

			#body  = body.replace("{","{\n"+jump_atomic)
		elif self.parsingStruct:
			body += self.visit(n.body)
		else:
			# Add csBlocks as the last statement in each function.
			# This may be unrechable code if the last statement is a return,
			# but that is fine.
			#
			if not self.parsingMain:
				body += self.visit(n.body)
				body = body[:body.rfind('\n}')]   # Eliminate the last closing braket for the function body compound.
				### body += '\n' + self._make_indent(1) + 'ddd---->' + csBlock + '}\n'
				body += '\n' + self._make_indent(1) + '}\n'
			else:
				body += self.visit(n.body)

		# The placeholder <return_statement> is changed to "return" or "return 0",
		# depending on whether the function is void.
		### functionBlock = decl + '\n{\n' + body + '}\n\n'
		functionBlock = decl + '\n' + body + '\n'

		#if decl.startswith("void") and not decl.startswith("void *"): # void function requests "return;"
		if self.parsingVoidFunction == True:
			functionBlock = functionBlock.replace("<return_statement>", "return")
		else: # non void functions request "return 0;"
			functionBlock = functionBlock.replace("<return_statement>", "return 0")

		if n.decl.name == 'main': self.parsingMain = False

		if n.decl.name.startswith('__VERIFIER_atomic'): self.parsingAtomic = False

		if n.decl.name == 'main':
			# Prepare the sequentialised main() function.
			#
			oldMainBlock = functionBlock[functionBlock.find('{')+2:]
			oldMainBlock = oldMainBlock[:oldMainBlock.rfind('}')]
			oldMainBlock = oldMainBlock.replace('main(', 'main_thread(', 1)

			#print "prima:\n\n"+functionBlock


			functionBlock = mainSimulationBlock


			''' 5.  Eventually, put all parts together.
			'''
			functionBlock = mainSimulationBlock



			str_tmp=""
			'''
			for item in self.variables:
				if item not in self.initializedGlobalVariables:
					if (item!="__atomic"):
						self.initialization += "\n__memory["+item+"][0] = 0;"
			'''


			functionBlock = functionBlock.replace('\t<insert-mainthread-here>\n', oldMainBlock)
			functionBlock = functionBlock.replace('\t<insert-main-parameters-decl-here>\n', self.mainParametersDecl);
			functionBlock = functionBlock.replace('\t<insert-initialization-here>\n', self.initialization);


		if self.parsingVoidFunction:
			functionBlock=functionBlock.replace("return 0;","return;")
		else:
			functionBlock=functionBlock.replace(" return;"," return 0;")
			functionBlock=functionBlock.replace("\treturn;","\treturn 0;")
			functionBlock=functionBlock.replace("\nreturn;","\nreturn 0;")

		return "\n"+self.functionBlock1+"\n"+functionBlock


	def visit_FileAST(self, n):
		s = ''
		header = self._make_header()

		self.currentOutputLineNumber = header.count('\n')-1


		for ext in n.ext:
			if isinstance(ext, pycparser.c_ast.FuncDef): s += self.visit(ext)
			else: s += self.visit(ext) + ';\n'


		if self.schema=="":
			self.build_check_block()
		'''
		if self.schema=="1":
			self.build_check_block1()
		if self.schema=="2":
			self.build_check_block2()
		if self.schema=="3":
			self.build_check_block3()
		'''
		s=s.replace("&Read","Read")
		#s=s.replace("Write_atomic","Write")

		if self._format=="esbmc":
			s=s.replace("check();","check1();")

		if self.schema=="2":
			s=s.replace("Read_Bool","Read")
			s=s.replace("Write_Bool","Write")

		s=s.replace("Read_Bool","Read")
		s=s.replace("Write_Bool","Write")
		s=s.replace("Write_from_array","Write")
		s=s.replace("Read_from_array","Read")

		#s=s.replace("Read(__unbuffered_p0_EAX$read_delayed_var)","Read(y)")
		#s=s.replace("Read(__unbuffered_p1_EAX$read_delayed_var)","Read(x)")
		s=s.replace(self.str_to_replace, self.str_with_replace)




		checkFinale=""
		for i in range (0, self._nwrites):
			checkFinale+="__CPROVER_assume(isClosed[%s] | %s>=memory_notvalid);\n"%(i,i)

		s=s.replace("<insert-checkFinale-here>", checkFinale)



		s = header + s.replace("<insert-thread-create-block-here>", self.pthread_create_block).replace("<insert-check-block-here>",self.check_block)
		s=s.replace("__VERIFIER","_cs___VERIFIER")
		s=s.replace(";;",";")
		s=s.replace("\n;","")
		s=s.replace("\n\t;","")
		return s


	def visit_Compound(self, n):

		s = self._make_indent() + '{\n'
		self.indent_level += 1

		if n.block_items:
			for stmt in n.block_items:
				newStmt = self._getCurrentCoords(stmt) + self._generate_stmt(stmt)
				s += newStmt

		self.indent_level -= 1

		s += self._make_indent() + '}\n'
		return s


	def visit_Return(self, n):
		if self.parsingMain == True:
			return ''

		s = 'return'
		if n.expr: s += ' ' + self.visit(n.expr)
		return s + ';'


	def visit_While(self, n):
		#
		# How do we check for side effects?
		#
		# At the beginning of visiting the while condition block (  while(....) ),
		# self.parsingSideEffect is reset.
		# If after visiting the condition block it has been set, then it means
		# that it contains at least an assignment statement, a unary op or a function call.
		# If after visiting the condition block it is still not set,
		# it means that no assignment stmts, unary ops or function call are present.
		# The flag is in fact set by visit_... methods for each of these ast nodes.
		#
		self.parsingSideEffect = False

		s = 'while ('
		if n.cond: s += self.visit(n.cond)
		#if self.parsingSideEffect: s += ' SIDE EFFECT HERE '
		#else: s+= ' NO SE HERE '
		s += ')\n'

		#t = self._generate_stmt(n.stmt, add_indent=True)
		t = exitBlock+"\n"+self._make_indent()+self._generate_stmt(n.stmt, add_indent=True)


		if not t.startswith(self._make_indent()+ ('{\n')):      # add brakets for single non parenthesised statements after if
			t = self._make_indent() + '{\n' + t + self._make_indent() + '}\n'


		bodyWithoutBlankSpaces=t.replace(" ","").replace("\n","").replace("\t","").replace(";","")

		# When the while condition has no side effects,
		# and the while block is either the empty statement (;) or the empty block ({}),
		# the following transformation is done:
		#
		#     while (cond) {}    --->     assume(!cond);
		#
		#if not self.parsingSideEffect and (type(n.stmt) in (pycparser.c_ast.EmptyStatement,) or not n.stmt.block_items or bodyWithoutBlankSpaces=="{}"):
		if not self.parsingSideEffect and bodyWithoutBlankSpaces=="{}":
			s = s.replace('while (', '___XXXXX__assume(!(', 1)
			s = s[:len(s)-2] + '));\n'
			t = ''

		'''
		if self.currentFunct=="main" and (s.find("while (1)")>=0  or s.find("while(__VERIFIER_nondet_int())")):
			s=""
			for _z in range (0,self.MaxThreadCreateInLop):
				s+=t.replace("{","").replace("}","")
			return s
		'''
		#if s.find("while (1)")>=0:
		#if self.currentFunct=="main" and (s.find("while (1)")>=0  or s.find("while(__VERIFIER_nondet_int())")):
		'''
		if self.currentFunct=="main" and (t.find("pthread_create")>=0):
			s=""
			self.labelFor=self.labelFor+1
			str_lab="exitWhile"+str(self.labelFor)
			tmp_count=1
			for _z in range (0,self.MaxThreadCreateInLop):
				str_lab_while="labelWhile"+str(self.labelFor)+"_"+str(tmp_count)+":\n"
				s += str_lab_while
				tmp_count+=1
				if (tmp_count<=self.MaxThreadCreateInLop):
					str_lab_while_next="labelWhile"+str(self.labelFor)+"_"+str(tmp_count)+";\n"
				else:
					str_lab_while_next=str_lab
				s += self._generate_stmt(n.stmt, add_indent=True).replace("break","goto "+str_lab)
				s = s.replace("continue","goto "+str_lab_while_next)
			s+=self._make_indent()+ "if (nondet_int()	){__CS_ret=1; return -1;}\n"
			s+=self._make_indent()+ "__CPROVER_assume(0);\n"
			s += self._make_indent()+str_lab+':;\n'
			return s
		'''
		s += t

		return s


	def visit_For(self, n):
		if self.ufor==0:
			return super(Translator, self).visit_For(n)
		else:
			s = ''
			self.labelFor=self.labelFor+1
			str_lab="exitFor"+str(self.labelFor)
			if n.init: s += self.visit(n.init)+';'
			for iter in range(0,self.ufor):
				if n.cond: s += '\n'+self._make_indent()+'if(!( ' + self.visit(n.cond)+") ) goto "+str_lab+';\n'
				s += self._generate_stmt(n.stmt, add_indent=True).replace("break","goto "+str_lab)
				if n.next: s += self._make_indent()+ self.visit(n.next)
				s += ';\n'

			if self.partialLoops==0:
				tmp_cond=self.visit(n.cond)
				if (tmp_cond==""):
					tmp_cond="1"
				s+=self._make_indent()+"__CPROVER_assume(!("+ tmp_cond +") && (__CS_ret==0));\n"
			s += self._make_indent()+str_lab+':;\n'

			return s


	def visit_Label(self, n):
		#if (n.name == 'ERROR'):
		if (n.name == self.error_label):

			tmp_errorBlock = errorBlock
			if self.parsingAtomic == True:
				tmp_errorBlock = tmp_errorBlock.replace('<return_statement>', 'Release_lock__atomic_function();\t<return_statement>')
			if self.parsingVoidFunction == True:
				return tmp_errorBlock.replace('<return_statement>', 'return') + self._generate_stmt(n.stmt)
			else:
				return tmp_errorBlock.replace('<return_statement>', 'return 0') + self._generate_stmt(n.stmt)
			'''
			if self.parsingVoidFunction == True:
				return errorBlock.replace('<return_statement>', 'return') + self._generate_stmt(n.stmt)
			else:
				return errorBlock.replace('<return_statement>', 'return 0') + self._generate_stmt(n.stmt)
			'''
		else:
			return n.name + ':\n' + self._generate_stmt(n.stmt)


	def visit_Struct(self, n):
		# Assigns a name to anonymous structs
		if n.name == None:
			n.name = '__CS_anonstruct_' + str(self.currentAnonStructsCount)
			self.currentAnonStructsCount += 1

		# This method is called more than once on the same struct,
		# the following is done only on the first time.
		#
		if n.name not in self.structName:
			self.currentStruct = n.name
			self.structName.append(n.name)
			self.parser.varNames[self.currentStruct] = []

		oldParsingStruct = self.parsingStruct
		self.parsingStruct = True
		s = self._generate_struct_union(n, 'struct')
		self.parsingStruct = oldParsingStruct

		# Parsing  typedef struct
		'''
		if self.parsingTypedef:
			print "    PARSING TYPEDEF STRUCT!!!!!!"
			print "       s: " + s
			print "    name: " + str(n.name) + '\n\n\n'
		'''

		return s


	def visit_Union(self, n):
		oldParsingStruct = self.parsingStruct
		self.parsingStruct = True
		s = self._generate_struct_union(n, 'union')
		self.parsingStruct = oldParsingStruct

		return s


	def _generate_stmt(self, n, add_indent=False):
		""" Generation from a statement node. This method exists as a wrapper
			for individual visit_* methods to handle different treatment of
			some statements in this context.
		"""
		typ = type(n)
		if add_indent: self.indent_level += 1
		indent = self._make_indent()
		if add_indent: self.indent_level -= 1

		ret = ""

		##if typ not in (c_ast.Decl,) and self.parsingTypedef == False and self.parsingMain == False and self.parsingAtomic == False and self.parsingStruct == False:
		if typ not in (pycparser.c_ast.Decl,) and self.parsingTypedef == False and self.parsingAtomic == False and self.parsingStruct == False:
			if typ in (pycparser.c_ast.EmptyStatement,):
				ret = indent + self.visit(n) + '\n'
			elif typ in (
					pycparser.c_ast.Decl, pycparser.c_ast.Assignment, pycparser.c_ast.Cast, pycparser.c_ast.UnaryOp,
					pycparser.c_ast.BinaryOp, pycparser.c_ast.TernaryOp, pycparser.c_ast.FuncCall, pycparser.c_ast.ArrayRef,
					pycparser.c_ast.StructRef):
				# These can also appear in an expression context so no semicolon
				# is added to them automatically
				#
				### return indent +'(a)' + cs + indent + self.visit(n) + ';\n'


				tmp_stm=indent +  '\n'+ indent + self.visit(n) + ';\n'




				ret = indent +  '\n'+ indent + self.visit(n) + ';\n'
			elif typ in (pycparser.c_ast.Compound,):
				# No extra indentation required before the opening brace of a
				# compound - because it consists of multiple lines it has to
				# compute its own indentation.
				#


				cmp = self.visit(n)


				#cmp = cmp[:cmp.rfind('\n')]  # Do it twice to get rid of both the last two '\n' and the last '}'
				#cmp = cmp[:cmp.rfind('\n')]

				cmp += '\n' + self._make_indent(1) + '\n'


				#cmp += self._make_indent() + '}'

				ret = cmp
			else:
				ret = indent + '\n' + indent + self.visit(n) + ';\n'
		else:
			if typ in (
				pycparser.c_ast.Decl, pycparser.c_ast.Assignment, pycparser.c_ast.Cast, pycparser.c_ast.UnaryOp,
				pycparser.c_ast.BinaryOp, pycparser.c_ast.TernaryOp, pycparser.c_ast.FuncCall, pycparser.c_ast.ArrayRef,
				pycparser.c_ast.StructRef):
				# These can also appear in an expression context so no semicolon
				# is added to them automatically
				#
				ret = indent + self.visit(n) + ';\n'
			elif typ in (pycparser.c_ast.Compound,):
				# No extra indentation required before the opening brace of a
				# compound - because it consists of multiple lines it has to
				# compute its own indentation.
				#
				ret = self.visit(n)
			else:
				ret = indent + self.visit(n) + ';\n'



		#if ret.find(","): print ret
		return ret

	def _generate_decl(self, n):
		""" Generation from a Decl node.
		"""
		s = ''

		# use flags to keep track through recursive calls of what is being parsed (START)
		if 'FuncDecl' in str(n.type):
			oldParsingFuncDecl = self.parsingFuncDecl
			self.parsingFuncDecl = True
			self.CurrentFunct = n.name
			###self.parser.varNames[self.currentFunct] = []

		if 'Struct' in str(n.type): self.parsingStruct = True

		if n.funcspec: s = ' '.join(n.funcspec) + ' '
		if n.storage: s += ' '.join(n.storage) + ' '

		s += self._generate_type(n.type)

		# use flags to keep track through recursive calls of what is being parsed (END)
		if 'FuncDecl' in str(n.type):
			### self.parsingFuncDecl = False
			self.parsingFuncDecl = oldParsingFuncDecl
			self.CurrentFunct = ''

		if 'Struct' in str(n.type): self.parsingStruct = False

		# Initialisation of global variables:
		#
		#	 self.indent_level < 1  is to identify the block depth (we want depth to be = 0)
		#	 self.parsingFuncDecl == False  is to exclude variable declaration within function prototypes
		#	'FuncDecl' not in str(n.type)  is to exclude declaration of global function prototypes (at block level 0)
		#
		if self.indent_level < 1 and self.parsingFuncDecl == False and 'FuncDecl' not in str(n.type):
			# if the global var is initialised, we save its associated node in the AST,
			# so to perform the initialisation later on from within the main()
			if 'None' != str(n.init):  # there is an init expression for the var (e.g. int x = 0;)
				self.globalInitVarNodes.append(n)

		return s


	'''

        Methods not from parent class

	'''
	def save(self, filename):
		outfile = open(filename,"w")
		outfile.write(self.s)
		outfile.close()


	def show(self):
		if self._format=="esbmc": self.show_esbmc()
		else: print self.s



	def show_esbmc(self):
		print self.s.replace("__CPROVER_assume","__ESBMC_assume")

	'''

        Internal functions.

	'''

	# Output the assert statements for global variables (excluding dynamically allocated, symbolic-sized vars).
	#
	def __explodeVariable(self, v):
		blocks = []

		# 1: scalar variables
		#
		if self.parser.varArity['',v] == 0  and not self.parser.varType['',v].startswith('struct ') and not self.parser.varType['',v].startswith('union '):
		## if self.parser.varArity['',v] == 0  and not self.__isStruct('',v) and not self.parser.varType['',v].startswith('union '):
			# print "> %s,%s  scalar, arity = %s" % ('',v,self.parser.varArity['',v])
			blocks.extend([v])

		# 2: arrays
		#
		#elif self.parser.varArity[f,v] > 0  and  not self.parser.varType[f,v].startswith('struct ') :
		elif self.parser.varArity['',v] > 0 and not self.parser.varMallocd['',v] :
			# print "> %s,%s  array, arity = %s" % ('',v,self.parser.varArity['',v])
			blocks.extend(self.__explodeArray(v, '', v))

		# 3: structs / unions
		#
		elif not self.parser.varMallocd['',v]:
			# print "> %s,%s  struct, arity = %s" % ('',v,self.parser.varArity['',v])
			blocks.extend(self.__explodeStruct(v, self.parser.varType['', v][7:]))

		return blocks


	# Returns all possible tuples of indexes for a variable  v  from function  f.
	#
	# For example, given v[3][2], that is: (0,0), (0,1), (1,0), (1,1), (2,0), (2,1)
	#
	def __genTuples(self, f, v):
		lst = self.parser.varSize[f,v]
		return reduce(lambda prev, b: [xs + [i] for xs in prev for i in range(0,b)], lst, [[]])


	# Returns all possible fields in a struct  s.
	#
	def __genFields(self, s):
		return self.parser.varNames[s]


	# Checks whether variable  v  from function  f  is scalar.
	#
	def __isScalar(self, f, v):
		if self.parser.varArity[f, v] == 0  and not self.parser.varType[f, v].startswith('struct ') and not self.parser.varType[f, v].startswith('union '):
			return 1
		else:
			return 0


	# Return the type of the variable without spaces and modifiers (useful for symbol-table lookups).
	# For example:    'const char *'  ---->  'char'
	#
	def __getBasicType(self, f, v):
		# See what is the type the variable is referring to.
		# First we need to get rid of any type modifiers (e.g. 'const'),
		# then of pointer symbols (*'s) and spaces (' ') to get the basic type
		# for lookup in the list of typedefs.
		#
		basicType = self.parser.varType[f, v]

		if basicType.startswith('const '): basicType = basicType[6:]

		if ' ' in basicType: basicType = basicType[:basicType.find(' ')]
		if '*' in basicType: basicType = basicType[:basicType.find('*')]

		return basicType


	# Checks whether variable  v  from function  f  is of a type which refers to a previous typedef.
	# This is used, for example, to see if a given variable is a struct,
	# as the  struct  keyword might be hidden by a typedef (as they usually are!)
	#
	def __isTypedef(self, f, v):
		if __getBasicType(f,v) in self.typedefs: return 1
		else: return 0


	# Checks whether variable  v  from function  f  is a struct.
	#
	def __isStruct(self, f, v):
		result = 0
		if (f,v) not in self.parser.varType:
			return 0

		if  self.parser.varType[f, v].startswith('struct '):
			result = 1

		return result


	# Returns the name of the struct a variable refers to, expanding typedefs if necessary.
	#
	def __getStructName(self, s, field):
		name = ''

		if  self.parser.varType[f, v].startswith('struct '):
			name = self.parser.varType[s, field][7:]
		return name


	# Checks whether variable  v  from function  f  is an array.
	#
	def __isArray(self, f, v):
		if (f,v) not in self.parser.varArity:
			return 0
		if self.parser.varArity[f,v] > 0: return 1
		else: return 0


	# Checks whether variable  v  from function  f  is an array.
	#
	def __isPointer(self, f, v):
		if (f,v) not in self.parser.varType:
			return 0
		if self.parser.varType[f,v].endswith('*'): return 1
		else: return 0


	# Recursively explode an array  f  from function  v  (see also __explodeStruct).
	#
	def __explodeArray(self, prefix, f, v):

		block = []

		# Arrays are exploded using any possible combination of indexes.
		for tuple in self.__genTuples(f,v):
			indexes = str(tuple).replace(', ', '][')

			if self.__isStruct(f, v):
				structName = self.__getStructName(f, v)
				block.extend(self.__explodeStruct(prefix+indexes, structName))
			else:
				block.extend([str(prefix+indexes)])

		return block


	# Recursively explode a struct  s  (see also __explodeArray).
	#
	def __explodeStruct(self, prefix, s):

		block = []

		# Struct are exploded using any possible field.
		for field in self.__genFields(s):
			if self.__isArray(s, field):
				block.extend(self.__explodeArray(prefix+'.'+field, s, field))
			elif self.__isStruct(s, field):
				structName = self.__getStructName(s, field)
				block.extend(self.__explodeStruct(prefix+'.'+field, structName))
			else:
				block.extend([prefix+'.'+field])

		return block


	def __isGlobaVariable(self, name):
		if name in self.parser.varNames['']:  return 1 # only consider global variables
		else: return 0

