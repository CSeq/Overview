void Take_lock__atomic_function(){
	Jump();
if (__CS_ret) return;	
	cannot_next_atomic_write[thread_index]=0;
	__CPROVER_assume(visible[thread_pos]);

}



void Release_lock__atomic_function(){
	__CPROVER_assume((visible[thread_pos]) && (thread_pos < memory_notvalid ));
}
