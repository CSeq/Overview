#include <stdlib.h>
#include <pthread.h>


#define MEM_SIZE <insert-MEM_SIZE-here>
#define NumVars <insert-NumVars-here>
#define MaxNumThreads <insert-NumThreads-here>
 
#define  intV __CPROVER_bitvector[7]

<insert-define-global-variables-here>
 
 
 



/*
#define __CS_type unsigned char
#define __CS_typeV unsigned char
#define __CS_typeT unsigned char
*/ 


//#define __CS_type unsigned __CPROVER_bitvector[<insert-type-type-here>]
#define __CS_type unsigned char
#define __CS_typeV unsigned __CPROVER_bitvector[<insert-type-typeV-here>]
#define __CS_typeT unsigned __CPROVER_bitvector[<insert-type-typeT-here>]



#define __CS_pthread_t unsigned char
#define __CS_pthread_mutex_t unsigned char
#define __CS_pthread_cond_t unsigned char
 
 

// shared memory

//intV __memory[<insert-NumIntVar-here>][MEM_SIZE]; 

_Bool __VERIFIER_nondet_bool(){
	_Bool _cs_tmp_val;
	return (_cs_tmp_val);
}
intV __VERIFIER_nondet_pointer(){
	intV _cs_tmp_val;
	return (_cs_tmp_val);
}

intV __memory[MEM_SIZE][NumVars]; 
intV updatedVars[MEM_SIZE][NumVars]; 
_Bool isClosed[MEM_SIZE];


void __VERIFIER_error(){}
//<insert-bool-declaration-here>
__CS_typeV var_name[MEM_SIZE];
__CS_typeT thread[MEM_SIZE];  
//__CS_type thw[MaxNumThreads][MEM_SIZE];


__CS_type thread_pos; 
__CS_type memory_notvalid;

//<insert-defMax-here>
 
 __CS_typeT n_treads_createad=1;

_Bool __CS_error = 0;                                              //cseq: set whenever an error is found and checked after thread-wrapping
_Bool __CS_ret = 0; 
_Bool terminated[MaxNumThreads]=<insert-Terminated-here>;		//viene settato ad 1 solo se il thread viene terminato
  __CS_typeT GuessedNumThreads;
__CS_type thread_pos_terminated[MaxNumThreads]=<insert-Terminated-here>;		//ultimo thread_pos



//cseq: handling of the status of the threads 
__CS_typeT thread_index;                                           //cseq: currently running thread ranging in [1..max+1], 1 being main()
__CS_typeT number_threads;



void Jump(){
	__CS_type jump;
	
	__CPROVER_assume(jump >= thread_pos);
	if (( jump >= memory_notvalid ) || (__CS_ret) ) {__CS_ret=1; return;}
	thread_pos=jump;
 
}
_Bool nondet_0();
_Bool nondet_1();
intV nondet_int();
_Bool nondet_bool();

;
<insert-array_equal-here>





void Take_lock__atomic_function(){
if (__CS_ret) return;	

	__CS_type jump;
	
	__CPROVER_assume( (jump >= thread_pos));
	if (( jump >= memory_notvalid ) || (__CS_ret) ) {__CS_ret=1; return;}
	thread_pos=jump;
	__CPROVER_assume(!isClosed[thread_pos]);
	
}



void Release_lock__atomic_function(){
	//__CPROVER_assume (isInContext && atomicMode);
    //atomicMode=0;
if (__CS_ret) return;	
	if (nondet_int()){
		isClosed[thread_pos]=1;
		array_equal();
		//__CPROVER_assume(__CPROVER_array_equal(ArrInContext[0], __memory[thread_pos]));
	}
}







intV Read_atomic(__CS_type codeVar){
	//__CPROVER_assume (isInContext);
	return (updatedVars[thread_pos][codeVar]);
}



void Write_atomic(__CS_type codeVar, int val){
	//__CPROVER_assume (isInContext);
	__CPROVER_assume(val<64);//6 bits: only for the competition	
  	updatedVars[thread_pos][codeVar] = val;
}




intV __VERIFIER_nondet_uint(){
intV _x;
__CPROVER_assume(_x>=0);
return _x;
}

<insert-pthread_cond_wait-here>

intV Read(__CS_type codeVar){
	
	if (__CS_ret) return;
	//se mi trovo in un contesto leggo dall'array ausiliario, altrimenti la read rimane uguale a prima
	__CS_type jump;

	__CPROVER_assume( (jump >= thread_pos));
	if ( jump >= memory_notvalid  ) {__CS_ret=1; return;}
	thread_pos=jump;

	return updatedVars[thread_pos][codeVar];

}


void Write(__CS_type codeVar, int val){
if (__CS_ret) return;	
	__CPROVER_assume(val<64);//6 bits: only for the competition	

	__CS_type jump;
	
	__CPROVER_assume( (jump >= thread_pos));
	if ( jump >= memory_notvalid  ) {__CS_ret=1; return;}
	thread_pos=jump;

	__CPROVER_assume(!isClosed[thread_pos]);
	
	
	updatedVars[thread_pos][codeVar] = val; 
	//se non sono in una verifier_atomic function, non deterministicamente scelgo se terminare il contesto
	//if (atomicMode==0 && nondet_int()){ 
	if (nondet_int()){
		isClosed[thread_pos]=1;
		array_equal();
		//__CPROVER_assume(__CPROVER_array_equal(ArrInContext[0], __memory[thread_pos]));
	}
}
intV __pthread_mutex_init(intV __m, int val){}



intV __pthread_mutex_lock(intV __m){
Take_lock__atomic_function();
	if ((Read_atomic(__m)!=0)){__CS_ret=1; return -1;}
	Write_atomic(__m, thread_index+1);
   
   //Release_lock__atomic_function();
   return 0;
} 


intV __pthread_mutex_unlock(intV __m){
Take_lock__atomic_function();
	if ((Read_atomic(__m)!=(thread_index+1))){__CS_ret=1; return -1;}
	Write_atomic(__m, 0);
   
   Release_lock__atomic_function();

   return 0;

} 


intV __pthread_mutex_destroy(intV __m){
}


void __pthread_cond_init( __CS_type cond,  __CS_type ignoreMe){return;}


intV __pthread_join( __CS_pthread_t t1, __CS_type p){
  if (nondet_int()) {__CS_ret=1; return;}
  Jump();
   __CPROVER_assume((terminated[t1]==0) && (thread_pos >= thread_pos_terminated[t1]));

   return 0;
}

