#!/usr/bin/env python
MERGER_VERSION = '0.1 2013.11.01'

"""

"""

import pycparser.c_parser, pycparser.c_ast, pycparser.c_generator
import utils
import os, sys, getopt, time


class Merger(object):
	__inputfilename = ''

	def __init__(self):
		pass

	def getversion(self):
		return MERGER_VERSION

	def load(self, filename):
		self.__inputfilename = filename

	def save(self, filename):
		cmdline = 'cpp -I ./core/include -E -C ' + self.__inputfilename + ' > ' + filename
		os.system(cmdline)
