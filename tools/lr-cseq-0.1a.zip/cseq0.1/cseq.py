"""

    CSeq:  C Sequentialiser

           Converts from multi-thread C to sequentialised C



    Package contents:
        - convert2.py this file (to convert a given .C concurrent file into its .C sequentialised version
        - fake_include/ directory for fake header files
        - maketests.py to generate tests for all .C files in a given path


    Requirements:
        - ESBMC
        - PYCparser


	Features not implemented yet:
        - See global variable 'notHandledPrimitives' below.

        - pthread_mutex_init() just does a return 0, so it will not work when mutex initialisation is needed

        - pthread_mutex_destroy() just does return 0, is that ok??

        - pthread_join() and pthread_exit() handling return values from threads

		- variable scope to distinguish between global and local variables with the same name

		- dynamic memory allocation (malloc) of global variables

        - global multidimensional arrays (only scalar variables and vectors handled at the moment).


    Assumptions on the original C code (such assumptions will not be checked for!):
        00. The global variables in the original source code are either scalar or vectors.
            Arrays of more than one dimensions are not handled at the moment and an error will be thrown.

        01. There are no variables named MAXROUND, MAXTHREAD and so on
           (see code generated from sequentialisation)

        02. No local variable has the same name of a global variable
           (handling of the variable scope is not implemented yet)

        03. All calls to pthread_join() have the last parameter set to 0 or NULL
           (at the moment we don't handle the return value from the thread we are joining)

        04. All calls to pthread_exit() have the parameter set to 0 or NULL
           (which means that the exiting thread does not want to return anything)

        05. The file has the following structure: 1. global var declaration | 2. function definition | 3. main(),
            therefore:
                - the declarations (of both variables and functions) are at the top of the input source file
                - the main() function is at the bottom of the input source file
                - the function definitions are between the declarations and the main()
                - no declaration on global variables occurs between function definitions

        06. Assignment statements in for loops "for (i = <expr>; i<k; i++)"  are such that <expr> is simple, e.g. "i = 6";

        07. The main() function returns an int (int main(......))
 

    Todo:
        - Now we insert the code 'csBlock' to simulate context switches before and after each statements,
          this should rather be done only with statements that access to global variables.

        - Compute automatically the values for the parameters -u -r -t


    Conversion of variables:
        - local variables are unchanged
        - global variables are treated as follows:
             - global declaration statements such as "int x;" are changed to "int x[MAXROUND];"
             - global declaration statements with an init expression such as "int x = 0;" are changed to "int x[MAXROUND] = {0};"



    Credits:
        Eli Bendersky (PYCparser) - this code was written starting from c_generator.py and c-to-c in the PYCparser package


"""


# from __future__ import print_function
from pycparser import parse_file, c_parser, c_ast
import getopt, sys

# This is not required if you've installed pycparser into
# your site-packages/ with setup.py
#
sys.path.extend(['.', '..'])
sys.path.append('.')


class colors:
    BLACK = '\033[90m'
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    NO = '\033[0m'

csBlock1 = (
"cs1(); if (__cseq_ret) <return_statement>;"
)

csBlock2 = (
"cs2(); if (__cseq_ret) <return_statement>;"
)


# The converter will throw an error and terminate if any of the following function calls are found.
# Put here everything not handled correctly at the moment!
notHandledPrimitives = ['pthread_cond_wait', 'pthread_cond_init', 'pthread_cond_signal']

postMainBlock = (
#"\t//-----Deadlock check\n"
#"\tth0 = nondet_int();\n"
#"\t__ESBMC_assume((0<th0) && (th0<=thread_index));\n"
#"\tth = th0;\n"
#"\n"
#"\tfor (__i=0; __i<MAXTHREAD; __i++)\n"
#"\t{\n"
#"\t\tif (__i > thread_index) break;\n"
#"\t\tif (depends_on[th][MAXROUND-1] == 0) break;\n"
#"\t\tth = depends_on[th][MAXROUND-1];\n"
#"\t\tassert(th != th0);\n"
#"\t}\n"
#"\n"
"\t//-----Error check\n"
"\tassert(__cseq_error != 1);\n"
)

# This block will be added at the top of the main() function
preMainBlock = (
"\t//-----Needed for deadlock check at the bottom\n"
"\tint th, th0;\n"
"\n"
"\t//-----Index variable to be used in loops at the bottom\n"
"\tint __i;\n"
)

errorBlock = (
#"ERROR: __cseq_error = ret = 1;\n"
"ERROR: __cseq_error = 1; __cseq_ret = 2; <return_statement>;\n"
)

pthreadExitBlock = (
"\t__cseq_ret = 2;\n"
"\t<return_statement>;\n"
)

# This block will be added at the top of the output sequentialised file
headerBlock =  (
"#include <assert.h>\n"
"#include <memory.h>\n"
"#include <pthread.h>\n"
"#include <stdio.h>\n"
"#include <stdlib.h>\n"
"\n"
"//----max no. of rounds to be considered\n"
"#define MAXROUND <set-maxround-here>\n"
"\n"
"//----max no of threads that the program can create\n"
"#define MAXTHREAD <set-maxthread-here>\n"
"\n"
"//----to keep track of the current executing thread\n"
"int thread_index;\n"
"\n"
"//----status of each thread (0 means 'terminated', 1 means 'not terminated'\n"
"int thread_status[MAXTHREAD+1];\n"
"\n"
"//----index of the current round being simulated\n"
"int __cseq_round;\n"
"\n"
"//----error from assert statement\n"
"int __cseq_error;\n"
"\n"
"//----used to handle context switches (and more) between function calls\n"
"int __cseq_ret=0;\n"
"\n"
"//----function declarations\n"
"int nondet_int();\n"
"\n"
"void cs1(void)\n"
"{\n"
"    int casualContextSwitch;\n"
"\n"
"	casualContextSwitch = nondet_int();\n"
"\n"
"	if (casualContextSwitch && (__cseq_round == MAXROUND-1)) {\n"
"		__cseq_ret=1;  //----last round reached\n"
"    } \n"
"}\n"
"\n"
"void cs2(void)\n"
"{\n"
"	int C2S_k;\n"
"	int casualContextSwitch;\n"
"\n"
"	casualContextSwitch = nondet_int();\n"
"	C2S_k = nondet_int();\n"
"\n"
"	__ESBMC_assume( C2S_k > 0 );\n"
"	__ESBMC_assume( C2S_k < MAXROUND );\n"
"\n"
"	if (casualContextSwitch && (__cseq_round < MAXROUND -1)) {\n"
"		__ESBMC_assume( __cseq_round+C2S_k > 0 );\n"
"		__ESBMC_assume( __cseq_round+C2S_k < MAXROUND );\n"
"\n"
"		__cseq_round = __cseq_round + C2S_k;\n"
"	}\n"
"}\n"
"\n"
"//-----Acquire lock\n"
"int __pthread_mutex_lock(int *lock)\n"
"{\n"
"\tif(*lock == 0) *lock = thread_index;\n"
"\telse\n"
"\t{\n"
"\t\t__cseq_ret = 1;\n"
"\t}\n"
"\n"
"\treturn 0;\n"
"}\n"
"\n"
"//-----Release lock\n"
"int __pthread_mutex_unlock(int *lock)\n"
"{\n"
"\tif(*lock != thread_index) __cseq_error = __cseq_ret = 1; \n"
"\telse *lock = 0;\n"
"\n"
"\treturn 0;\n"
"}\n"
"\n"
"void __CSEQ_assert(int expr)\n"
"{\n"
"\tif (!expr) __cseq_error = __cseq_ret = 1;\n"
"\treturn;\n"
"}\n"
"\n"
"void __CSEQ_assume(int expr)\n"
"{\n"
"\tif (!expr) __cseq_ret = 1;\n"
"\treturn;\n"
"}\n"
"\n"
"int __pthread_mutex_init(int *mutex, const pthread_mutexattr_t *attr) { return 0; }\n"
"\n"
"int __pthread_mutex_destroy(int *mutex) { return 0; } \n"
"\n"
"int __pthread_join(int thread, void **value_ptr)\n"
"{\n" 
"\t__ESBMC_assume((thread_status[thread]) == 2);\n"
"\treturn 0;\n"
"}\n"
"\n"
"int __pthread_create(int *id1, const pthread_attr_t *attr,  void *(*t1)(void*), void *arg)\n"
"\t{\n"
"\tthread_index += 1;\n"
"\t*id1 = thread_index;\n"
"\tint fresh;\n"
"\tif (fresh && (thread_index < MAXTHREAD))\n"
"\t{\n"
"\t\t__cseq_ret = 0;\n"
"\t\t__cseq_round = 0;\n"
"\t\tt1(arg);\n"
"\t\tif (__cseq_ret==1) thread_status[thread_index] = 1;\n"
"\t\telse thread_status[thread_index] = 2;\n"
"\t}\n"
"\t__cseq_round = MAXROUND-1;\n"
"\treturn 0;\n"
"}\n"
)


____oldPthreadCreate =(
"int __pthread_create(int *id1, const pthread_attr_t *attr,  void *(*t1)(void*), void *arg) {\n"
"\tint fresh;\n"
#"\tfresh = nondet_int();\n"
"\tif (fresh && (thread_index < MAXTHREAD))\n"
###"\tif (thread_index < MAXTHREAD)\n"
"\t{\n"
"\t\tthread_index += 1;\n"
"\t\t*id1 = thread_index;\n"
"\t\t__cseq_ret = 0;\n"
"\t\t__cseq_round = 0;\n"
"\t\tt1(arg);\n"
"\t\tif (__cseq_ret==1) thread_status[thread_index] = 1;\n"
"\t\telse thread_status[thread_index] = 2;\n"
"\t}\n"
"\t__cseq_round = MAXROUND-1;\n"
"\treturn 0;\n"
"}\n"
"\n"
)

class CSequentialiser(object):
    """ Uses the same visitor pattern as c_ast.NodeVisitor, but modified to
        return a value from each visit method, using string accumulation in 
        generic_visit.
    """
    def __init__(self, ast, maxrounds, maxthreads):
        self.output = ''

        # The following variables are needed for handling the global variables in the original
        # source code.
        self.globalInitVarNodes = []  # all the initialised global variable nodes in a list
        self.globalVarName = []       # all the global variable names in a list
        self.globalVarDecl = {}       # all the global variable declarations in a dict (used to check array size)
        self.globalVarArity = {}      # arity  of global variables (0 if scalar type)
        self.globalVarSize = {}       # size of global variables as declared (e.g. "int x[10];") 
        
        # Statements start with indentation of self.indent_level spaces, using
        # the _make_indent method
        #
        self.indent_level = 0            # to keep track of the depth of the block {}
        self.INDENT_SPACING = "     "    # ....

        # set debugMode to True or False to enable / disable debug        
        self.debugMode = False

        if self.debugMode:
            self.declMarkerA = colors.GREEN + '[' + colors.NO
            self.declMarkerB = colors.GREEN + ']' + colors.NO
            self.typeMarkerA = colors.YELLOW + '{' + colors.NO
            self.typeMarkerB = colors.YELLOW + '}' + colors.NO
            self.stmtMarkerA = colors.RED + '<' + colors.NO
            self.stmtMarkerB = colors.RED + '>' + colors.NO
            self.structMarkerA = colors.BLACK + '<' + colors.NO
            self.structMarkerB = colors.BLACK + '>' + colors.NO
        else:
            self.declMarkerA = ''
            self.declMarkerB = ''
            self.typeMarkerA = ''
            self.typeMarkerB = ''
            self.stmtMarkerA = ''
            self.stmtMarkerB = ''
            self.structMarkerA = ''
            self.structMarkerB = ''

        # = True while parsing the subtree for a function declaration
        self.parsingFuncDecl = False

        # = True while parsing the main() function
        self.parsingMain = False

        # Declarations have always one of the following two forms: 
        #         <lastDeclarationL> = <lastDeclarationR>;   when there is an init expression
        #               OR
        #         <lastDeclarationL>;   when there is no init expression
        self.lastDeclarationL = ''
        self.lastDeclarationR = ''
        self.lastDeclaration = ''

        self.copyVariableDeclaration = ''

        # The following union declaration will be used to keep
        # the old value of a global variable immediately before any complex assignment operation
        # (such as the ones with a function call in the Lvalue). This value might be used
        # thereafter to simulate when a context switch happens while performing function calls
        # from within the assignment, to restore the original value of the variable.
        self.unionDeclaration = 'union _u {\n'

        # init expressions for global variables will be moved into this string and then 
        # printed inside the main() function
        self.globalInitStatements = ''
 
        # this will set to True after parsing the first function definition (not declaration)
        self.firstFunctionDefinitionDone = False

        # set to True while parsing void functions
        self.parsingVoidFunction = False

        # set to True while parsing typedef blocks 
        self.parsingTypedef = False

        self._maxthreads = maxthreads
        self._maxrounds = maxrounds

        # set to False when we still have to add to the main() the memcmp block,
        # and set to True when that has been done 
        self.memcmpBlockGenerated = False

        # used to avoid inserting csBlock() blocks in functions which name starts with '__VERIFIER_atomic'
        self.parsingAtomic = False


    def _make_indent(self):
        return self.indent_level * self.INDENT_SPACING


    def _make_header(self):
        headerBlock2 = headerBlock.replace("\t", self.INDENT_SPACING)
        headerBlock3 = headerBlock2.replace("<set-maxround-here>", str(self._maxrounds))
        headerBlock4 = headerBlock3.replace("<set-maxthread-here>", str(self._maxthreads))

        return headerBlock4


    def visit(self, node):
        method = 'visit_' + node.__class__.__name__
        if self.debugMode: print self._make_indent() + "calling method: " + method + '\n'
        return getattr(self, method, self.generic_visit)(node)

    
    def generic_visit(self, node):
        #~ print('generic:', type(node))
        if node is None: return ''
        else: return ''.join(self.visit(c) for c in node.children())

    
    def visit_Constant(self, n):
        return n.value

        
    def visit_ID(self, n):
        # global variables are changed to arrays,
        # for example the expression (a + b == 0) is changed to (a[__cseq_round] + b == 0)
        # if a is global and b is local.
        if n.name in self.globalVarName: return n.name + '[__cseq_round]'
        else: return n.name


    def visit_ArrayRef(self, n):
        arrref = self._parenthesize_unless_simple(n.name)
        return arrref + '[' + self.visit(n.subscript) + ']'


    def visit_StructRef(self, n):
        sref = self._parenthesize_unless_simple(n.name)
        return sref + n.type + self.visit(n.field)


    def visit_FuncCall(self, n):
        fref = self._parenthesize_unless_simple(n.name)

        # currenly not-handled pthread_ primitives will cause the converter to quit
        if fref in notHandledPrimitives:  # e.g. 'pthread_cond_wait', ...
            print "UNKNOWN (code:02)\n"
            ## print("Conversion error:  the source file contains '%s' which is not supported yet!\n" % fref)
            sys.exit(-1)

        if fref == 'pthread_mutex_lock': fref = '__pthread_mutex_lock'
        if fref == 'pthread_mutex_unlock': fref = '__pthread_mutex_unlock'
        if fref == 'pthread_mutex_init': fref = '__pthread_mutex_init'
        if fref == 'pthread_mutex_destroy': fref = '__pthread_mutex_destroy'
        if fref == 'pthread_join': fref = '__pthread_join'
        if fref == 'pthread_create': fref = '__pthread_create'

        if fref == 'pthread_exit':
            fref = "//-----Translation for " + fref + '(' + self.visit(n.args) + ')' + '\n'
            pthreadExitBlock2 = pthreadExitBlock.replace('\t', self.INDENT_SPACING)

            if self.parsingVoidFunction == True:
                pthreadExitBlock3 = pthreadExitBlock2.replace('<return_statement>', "return")
            else:
                pthreadExitBlock3 = pthreadExitBlock2.replace('<return_statement>', "return 0")

            fref = fref + pthreadExitBlock3 + self._make_indent()
            return fref

        if self.parsingMain == False:
            if fref == 'assume': fref = '__CSEQ_assume'
            if fref == '__ESBMC_assume': fref = '__CSEQ_assume'
            if fref == '__VERIFIER_assume': fref = '__CSEQ_assume'

            if fref == 'assert': fref = '__CSEQ_assert'
            if fref == '__ESBMC_assert': fref = '__CSEQ_assert'
            if fref == '__VERIFIER_assert': fref = '__CSEQ_assert'

        if fref == '__VERIFIER_nondet_int': fref == '__ESBMC_nondet_int'

        return fref + '(' + self.visit(n.args) + ')'


    def visit_UnaryOp(self, n):
        operand = self._parenthesize_unless_simple(n.expr)
        if n.op == 'p++':
            return '%s++' % operand
        elif n.op == 'p--':
            return '%s--' % operand
        elif n.op == 'sizeof':
            # Always parenthesize the argument of sizeof since it can be 
            # a name.
            return 'sizeof(%s)' % self.visit(n.expr)
        else:
            return '%s%s' % (n.op, operand)


    def visit_BinaryOp(self, n):
        lval_str = self._parenthesize_if(n.left, 
                            lambda d: not self._is_simple_node(d))
        rval_str = self._parenthesize_if(n.right, 
                            lambda d: not self._is_simple_node(d))
        return '%s %s %s' % (lval_str, n.op, rval_str)
    

    def visit_Assignment(self, n):
        rval_str = self._parenthesize_if(
                            n.rvalue, 
                            lambda n: isinstance(n, c_ast.Assignment))
        
        preAssignment = ''
        postAssignment = ''

        # the assignment statements for global variables have to be treated differently 
        # when the Rvalue is not a constant or a simple expression
        if type(n.lvalue) == c_ast.ID:
            if n.lvalue.name in self.globalVarName: # only consider global variables
                # if the rvalue of the assignment statement is not a constant then while executing it
                # a context switch might happen.
                if type(n.rvalue) != c_ast.Constant:
                    preAssignment = '//-----Translation for the assignment statement "%s %s %s", case 2\n' % (self.visit(n.lvalue), n.op, rval_str) 
                    preAssignment += self._make_indent() + 'u.%s = %s;' % (self.visit(n.lvalue), self.visit(n.lvalue))
                    postAssignment = ';\n' + self._make_indent() + 'if (__cseq_ret) ' + self.visit(n.lvalue) + '= u.' + self.visit(n.lvalue)
        
        return preAssignment + '\n' + self._make_indent() + '%s %s %s' % (self.visit(n.lvalue), n.op, rval_str) + postAssignment


    def visit_IdentifierType(self, n):
        # change 'pthread_mutex_t' to 'int'
        if n.names[0] == 'pthread_mutex_t': n.names[0] = 'int'

        ### tm = ''.join(n.names)
        ### print "VARIABLE TYPE: " +tm+ '\n'

        return ' '.join(n.names)

    
    def visit_Decl(self, n, no_type=False):
        initExpression = ''
        self.lastDeclarationL = ''
        self.lastDeclarationR = ''

        # no_type is used when a Decl is part of a DeclList, where the type is
        # explicitly only for the first declaration in a list.
        #
        s = n.name if no_type else self._generate_decl(n)

        s2 = ''

        if self.indent_level < 1 and self.parsingFuncDecl == False and 'FuncDecl' not in str(n.type):
            self.indent_level+=1
            indent = self._make_indent();
            self.indent_level-=1
            
            self.unionDeclaration += indent + s.replace('static ', '') + ';\n'
            
            ## print "*********** LEFT HAND SIDE OF DECLARATION FOR  %s  IS  %s\n" % (n.name, s)

            if s.find(' '+n.name+'[') == -1:
                s3 = s.replace(' *'+n.name+'[', ' *copy_'+n.name+'[') 
                s2 = s3.replace('static ', '') ## static gets removed from local variables newly introduced in the main()
            else:
                s3 = s.replace(' '+n.name+'[', ' copy_'+n.name+'[') ########
                s2 = s3.replace('static ', '') ## static gets removed from local variables newly introduced in the main() 

            self.copyVariableDeclaration += indent + s2 + ';\n'

        ### print "*********** LEFT HAND SIDE OF DECLARATION FOR  %s  IS  %s\n" % (n.name, s2)
        self.lastDeclarationL = s

        if n.bitsize: s += ' : ' + self.visit(n.bitsize)

        if n.init:
            # Add {} brackets when the declaration statement refers to a global variable with an init expression.
            # Example: int x = 0; ---->  int x[MAXROUND] = {0}. 
            if not (self.indent_level < 1 and self.parsingFuncDecl == False and 'FuncDecl' not in str(n.type)):
                bracketR = bracketL = ''
            else:
                bracketL = '{'
                bracketR = '}'

            if isinstance(n.init, c_ast.ExprList): s += ' = {' + bracketL + self.visit(n.init) + bracketR + '}'
            else: s += ' = ' + bracketL + self.visit(n.init) + bracketR

        ### print ">>>>> VISITING DECLARATION END %s\n" % n.name

        self.lastDeclaration = s

        return s.replace('pthread_t ', 'int ')


    
    def visit_DeclList(self, n):
        s = self.visit(n.decls[0])
        if len(n.decls) > 1:
            s += ', ' + ', '.join(self.visit_Decl(decl, no_type=True) 
                                    for decl in n.decls[1:])
        return s

    
    def visit_Typedef(self, n):
        s = ''
        if n.storage: s += ' '.join(n.storage) + ' '

        self.parsingTypedef = True
        s += self._generate_type(n.type)
        self.parsingTypedef = False

        return s

    
    def visit_Cast(self, n):
        s = '(' + self._generate_type(n.to_type) + ')' 
        return s + ' ' + self._parenthesize_unless_simple(n.expr)

    
    def visit_ExprList(self, n):
        visited_subexprs = []
        for expr in n.exprs:
            if isinstance(expr, c_ast.ExprList):
                visited_subexprs.append('{' + self.visit(expr) + '}')
            else:
                visited_subexprs.append(self.visit(expr))
        return ', '.join(visited_subexprs)
    

    def visit_Enum(self, n):
        s = 'enum'
        if n.name: s += ' ' + n.name
        if n.values:
            s += ' {'
            for i, enumerator in enumerate(n.values.enumerators):
                s += enumerator.name
                if enumerator.value: 
                    s += ' = ' + self.visit(enumerator.value)
                if i != len(n.values.enumerators) - 1: 
                    s += ', '
            s += '}'
        return s
        

    def visit_FuncDef(self, n):
        # The function definition will be split is in two parts:
        # one is 'decl' and the other is 'body'

        decl = self.visit(n.decl)

        if n.decl.name == 'main':
            self.parsingMain = True

        if n.decl.name.startswith('__VERIFIER_atomic'):
            self.parsingAtomic = True

        if decl.startswith("void") and not decl.startswith("void *"):
            self.parsingVoidFunction = True
        else:
            self.parsingVoidFunction = False

        # before printing the first function definition, print the union _u containing the global variable names
        if self.firstFunctionDefinitionDone == False:
            decl = self.unionDeclaration + '};\n\nunion _u u;\n\n' + decl
            self.firstFunctionDefinitionDone = True

        body = ''

        # The body is a Compound node
        if n.decl.name == "main": # treat the main() differently in order to add code at the top and bottom
            body += self.copyVariableDeclaration + '\n'

            body += self.INDENT_SPACING + "//-----For each global variable x, copy into x[1...MAXROUND] <--- copy_x[1..MAXROUND].\n"
            body += self.INDENT_SPACING + "//-----This is used to fill global variables with non-initialised data.\n"

            ########### do the thing!   memcpyForBlock <i>
            # for each global variable....
            for varName in self.globalVarName:
                # case 1: memcpy block for scalar global variables
                if self.globalVarSize[varName] == -1: 
                    for i in range(1, self._maxrounds):
                        body += self.INDENT_SPACING + varName + '[' + str(i) + '] = copy_' + varName + '[' + str(i) + '];\n'
                # case 2: memcpy block for global arrays with arity 1 (>1 not supported yet!)
                else:
                    for i in range(1, self._maxrounds):
                        for j in range (0, int(self.globalVarSize[varName])):
                             body += self.INDENT_SPACING + varName + '[' + str(i) + ']['+ str(j) +'] = copy_' + varName + '[' + str(i) + ']['+ str(j) +'];\n'

            body += '\n'
            body += preMainBlock.replace('\t', self.INDENT_SPACING) + '\n' 
            body += self.visit(n.body) + '\n'
         
            body += postMainBlock.replace('\t', self.INDENT_SPACING)
        else:
            if n.decl.name.startswith('__VERIFIER_atomic'): # no csBlock in atomic functions, like in the main()
                body += self.visit(n.body)
            else:
                body += self.INDENT_SPACING +csBlock1 +'\n'
                body += self.INDENT_SPACING +csBlock2 +'\n'
                body += self.visit(n.body)

        # The placeholder <return_statement> is changed to "return" or "return 0" depending on
        # whether the function is void
        functionBlock = decl + '\n{\n' + body + '}\n\n'

        #if decl.startswith("void") and not decl.startswith("void *"): # void function requests "return;"
        if self.parsingVoidFunction == True:
            functionBlock2 = functionBlock.replace("<return_statement>", "return")
        else: # non void functions request "return 0;"
            functionBlock2 = functionBlock.replace("<return_statement>", "return 0")

        if n.decl.name == 'main':
            self.parsingMain = False

        if n.decl.name.startswith('__VERIFIER_atomic'):
            self.parsingAtomic = False


        return functionBlock2


    def visit_FileAST(self, n):
        s = ''
        for ext in n.ext:
            if isinstance(ext, c_ast.FuncDef):
                s += self.visit(ext)
            else:
                s += self.visit(ext) + ';\n'

        return self._make_header() + s


    def visit_Compound(self, n):
        #s = self._make_indent() + '{\n'
        s = ''
        finalS = ''


        self.indent_level += 1
        ''' original code!
        if n.block_items:
            s += ''.join(self._generate_stmt(stmt) for stmt in n.block_items)
        '''
        if n.block_items:
            for i, subBlock in enumerate(n.block_items or []):
                finalS += self._generate_stmt(subBlock)

        self.indent_level -= 1


        # When parsing the main() we need to find out the last __pthread_create() call
        # and _only_after_it_ add the additional memcmp() block!
        #
        # To do so, we keep 3 strings: s, remainingS and finalS.
        # s = the code generated so far in the main()
        # finalS = the full code that is generated in the main()
        # remainingS = finalS - s = the text that is to be generated after s
        #
        # every time we generate text for a statement (when we put it into nextSubBlock)
        # we check whether remainingS contains a call to __pthread_create. This way
        # we can find out which __pthread_create() 
        if self.parsingMain and self.indent_level == 0:
            self.indent_level += 1
            if n.block_items:
                for i, subBlock in enumerate(n.block_items or []):
                    nextSubBlock = self._generate_stmt(subBlock)
                    s += nextSubBlock
                    remainingS = finalS[len(s):]

                    if '__pthread_create(' not in remainingS and self.memcmpBlockGenerated == False:
                        self.memcmpBlockGenerated = True
                        #### print "PARSING:\n<<<<%s>>>>\nRESIAUDL:<<<<%s>>>> LAST ONE!!!!!\n" % (nextSubBlock, remainingS)

                        memcmpBlock = '\n'
                        memcmpBlock += self.INDENT_SPACING + "//-----For each global variable x, check that x[0...MAXROUND-1] == copy_x[1..MAXROUND]\n"
                        # for each global variable....
                        for varName in self.globalVarName:
                            # case 1: memcmp block for scalar global variables
                            if self.globalVarSize[varName] == -1: 
                                for i in range(1, self._maxrounds):
                                    memcmpBlock += self.INDENT_SPACING + "__ESBMC_assume(" + varName + '[' + str(i-1) + '] == copy_' + varName + '[' + str(i) + ']);\n'
                            # case 2: memcmp block for global arrays with arity 1 (>1 not supported yet!)
                            else:
                                for i in range(1, self._maxrounds):
                                    for j in range (0, int(self.globalVarSize[varName])):
                                         memcmpBlock += self.INDENT_SPACING + "__ESBMC_assume(" + varName + '[' + str(i-1) + ']['+ str(j) +'] == copy_' + varName + '[' + str(i) + ']['+ str(j) +']);\n'
                        memcmpBlock += '\n'
                        s += memcmpBlock
            self.indent_level -= 1
        else: s = finalS


        #s += self._make_indent() + '}\n'
        return s

    
    def visit_EmptyStatement(self, n):
        return ';'

    
    def visit_ParamList(self, n):
        return ', '.join(self.visit(param) for param in n.params)


    def visit_Return(self, n):
        if self.parsingMain == True:
            return ''

        s = 'return'
        if n.expr: s += ' ' + self.visit(n.expr)
        return s + ';'


    def visit_Break(self, n):
        return 'break;'

        
    def visit_Continue(self, n):
        return 'continue;'

    
    def visit_TernaryOp(self, n):
        s = self.visit(n.cond) + ' ? '
        s += self.visit(n.iftrue) + ' : '
        s += self.visit(n.iffalse)
        return s
    

    def visit_If(self, n):
        s = 'if ('
        if n.cond: s += self.visit(n.cond)
        s += ')\n'
        s += self._generate_stmt(n.iftrue, add_indent=True)
        if n.iffalse: 
            s += self._make_indent() + 'else\n'
            s += self._generate_stmt(n.iffalse, add_indent=True)
        return s
    

    def visit_For(self, n):
        s = 'for ('
        if n.init: s += self.visit(n.init)
        s += ';'
        if n.cond: s += ' ' + self.visit(n.cond)
        s += ';'
        if n.next: s += ' ' + self.visit(n.next)
        s += ')\n'
        s += self._generate_stmt(n.stmt, add_indent=True)
        return s


    def visit_While(self, n):
        s = 'while ('
        if n.cond: s += self.visit(n.cond)
        s += ')\n'
        s += self._generate_stmt(n.stmt, add_indent=True)
        return s


    def visit_DoWhile(self, n):
        s = 'do\n'
        s += self._generate_stmt(n.stmt, add_indent=True)
        s += self._make_indent() + 'while ('
        if n.cond: s += self.visit(n.cond)
        s += ');'
        return s


    def visit_Switch(self, n):
        s = 'switch (' + self.visit(n.cond) + ')\n'
        s += self._generate_stmt(n.stmt, add_indent=True)
        return s

    
    def visit_Case(self, n):
        s = 'case ' + self.visit(n.expr) + ':\n'
        s += self._generate_stmt(n.stmts, add_indent=True) ######### OMAR: shouldn't be 'n.stmts'???
        return s

    
    def visit_Default(self, n):
        return 'default:\n' + self._generate_stmt(n.stmts, add_indent=True) ######## OMAR: shouldn't be 'n.stmts'???


    def visit_Label(self, n):
        if (n.name == 'ERROR'):
            if self.parsingMain == False: # not parsing the main() function 
                if self.parsingVoidFunction == True:
                    return errorBlock.replace('<return_statement>', 'return') + self._generate_stmt(n.stmt)
                else:
                    return errorBlock.replace('<return_statement>', 'return 0') + self._generate_stmt(n.stmt)
            else:  # parsing the main() function
                return errorBlock.replace('<return_statement>', 'assert(0)') + self._generate_stmt(n.stmt)
        else:
            return n.name + ':\n' + self._generate_stmt(n.stmt)

        '''
        if (n.name == 'ERROR'):
            return errorBlock + self._generate_stmt(n.stmt)
        else:
            return n.name + ':\n' + self._generate_stmt(n.stmt)
        '''

    def visit_Goto(self, n):
        return 'goto ' + n.name + ';'


    def visit_EllipsisParam(self, n):
        return '...'


    def visit_Struct(self, n):
        return self._generate_struct_union(n, 'struct')


    def visit_Typename(self, n):
        return self._generate_type(n.type)

        
    def visit_Union(self, n):
        return self._generate_struct_union(n, 'union')


    def visit_NamedInitializer(self, n):
        s = ''
        for name in n.name:
            if isinstance(name, c_ast.ID):
                s += '.' + name.name
            elif isinstance(name, c_ast.Constant):
                s += '[' + name.value + ']'
        s += ' = ' + self.visit(n.expr)
        return s


    def _generate_struct_union(self, n, name):
        """ Generates code for structs and unions. name should be either 
            'struct' or union.
        """
        s = name + ' ' + (n.name or '')
        if n.decls:
            s += '\n'
            s += self._make_indent() 
            self.indent_level += 1
            s += '{\n'
            for decl in n.decls:
                s += self._generate_stmt(decl)
            self.indent_level -= 1
            s += self._make_indent() + '}'
        return self.structMarkerA + s + self.structMarkerB


    def _generate_stmt(self, n, add_indent=False):
        """ Generation from a statement node. This method exists as a wrapper
            for individual visit_* methods to handle different treatment of 
            some statements in this context.
        """
        indent = self._make_indent()

        if add_indent:
            s1 = indent + '{\n'
            s2 = indent + '}\n'
        else:
            s1 = ''
            s2 = ''

        typ = type(n)


        if add_indent: self.indent_level += 1
        indent = self._make_indent()
        if add_indent: self.indent_level -= 1


        cs = ''
        cs_after = ''


        if self.parsingTypedef == False and self.parsingMain == False and self.parsingAtomic == False:
            if add_indent: 
                cs = indent + csBlock1 +'\n' + indent + csBlock2 +'\n'

            cs_after = indent + csBlock1 + '\n' + indent + csBlock2 + '\n'

        if typ in ( 
                c_ast.Decl, c_ast.Assignment, c_ast.Cast, c_ast.UnaryOp,
                c_ast.BinaryOp, c_ast.TernaryOp, c_ast.FuncCall, c_ast.ArrayRef,
                c_ast.StructRef):
            # These can also appear in an expression context so no semicolon
            # is added to them automatically
            #
            if add_indent: self.indent_level += 1
            indent = self._make_indent()

            s = s1 + cs + indent + self.visit(n) +';\n' + cs_after + s2
            if add_indent: self.indent_level -= 1

            return self.stmtMarkerA + s + self.stmtMarkerB
        elif typ in (c_ast.Compound,):
            # No extra indentation required before the opening brace of a 
            # compound - because it consists of multiple lines it has to 
            # compute its own indentation.
            #
            return self.stmtMarkerA + s1 + cs + self.visit(n) + s2  + self.stmtMarkerB
        else: # if, for, while...
            if add_indent: self.indent_level += 1
            indent = self._make_indent()

            s = s1 + cs + indent + self.visit(n) + '\n' + s2

            if add_indent: self.indent_level -= 1

            return self.stmtMarkerA + s + self.stmtMarkerB


    def _generate_decl(self, n):
        """ Generation from a Decl node.
        """
        if self.debugMode == True:
            ### s = self.declMarkerA +'('+ str(self.indent_level) +')' + str(n.type)
            s = self.declMarkerA
        else: s = ''



        # use flags to keep track through recursive calls of what is being parsed (START)
        if 'FuncDecl' in str(n.type):
            self.parsingFuncDecl = True
            ### print "PARSING FUNCTION DECL %s\n END" % n.name

        if 'Decl' in str(n.type):
            self.parsingDecl = True
            ### print "PARSING DECLARATION START %s\n" % n.name


        if n.funcspec: s = ' '.join(n.funcspec) + ' '
        if n.storage: s += ' '.join(n.storage) + ' '


        '''
        if 'FuncDecl' in str(n.type):
            if self.parsingMain == True: s += 'MAIN MAIN MAin....\n'
            else: s += 'no main no main .....\n'
        '''

        if self.debugMode == True: s += self._generate_type(n.type) + self.declMarkerB
        else: s += self._generate_type(n.type)



        # use flags to keep track through recursive calls of what is being parsed (END)
        if 'FuncDecl' in str(n.type):
            self.parsingFuncDecl = False

        if 'Decl' in str(n.type):
            self.parsingDecl = False
            ### print "PARSING DECLARATION END %s\n" % n.name


        # initialisation of global variables:
        #
        #     self.indent_level < 1  is to identify the block depth (we want depth to be = 0)
        #     self.parsingFuncDecl == False  is to exclude variable declaration within function prototypes
        #    'FuncDecl' not in str(n.type)  is to exclude declaration of global function prototypes (at block level 0)
        #
        if self.indent_level < 1 and self.parsingFuncDecl == False and 'FuncDecl' not in str(n.type):
            # if the global var is initialised, we save its associated node in the AST, 
            # so to perform the initialisation later on from within the main()
            if 'None' != str(n.init):  # there is an init expression for the var (e.g. int x = 0;)
                self.globalInitVarNodes.append(n)
            
            # put all the global variable names in a list,
            # store their declaration statement, their arity and their size in separate dicts
            # (at the moment only arity <= 1 is supported, that is scalar variables and monodimensional arrays!)
            self.globalVarName.append(n.name)
            self.globalVarDecl[n.name] = s;
            self.globalVarArity[n.name] = s.count('[')
            self.globalVarSize[n.name] = s[s.find("[")+1:s.find("]")] if self.globalVarArity[n.name]>0 else -1

            # multidimensional global variables are not supported yet 
            if self.globalVarArity[n.name] > 1:   # check that the relevant variable has no more than 1 original dimension
                print "UNKNOWN (code:01)\n"
                print "Conversion error:  global array '%s' has arity %s,\n                   global arrays with arity > 1 are not supported yet.\n" % (self.globalVarDecl[n.name],self.globalVarArity[n.name])
                sys.exit(-1)
            #else:
            #    print "Variable %s has arity %s and size %s\n" % (n.name, self.globalVarDecl[n.name].count('['), self.globalVarSize[n.name])


            # static variables are not supported yet
            '''
            if 'static ' in s:
                print "UNKNOWN (code:03)\n"
                print "Conversion error:  variable '%s' is static,\n                   static variables are not supported yet.\n" % (self.globalVarDecl[n.name])
                sys.exit(-1)
            '''

            ### print "GLOBAL VARIABLE TYPE: " + str(n.type) + '\n'
            #### print "GLOBAL VARIABLE NAME: " + str(n.name) + '\n'

            ### print "dichiarazione var %s IS %s\n" % (n.name, s)

            s = s.replace(' '+n.name, ' '+n.name+'[MAXROUND]')
            s = s.replace(' *'+n.name, ' *'+n.name+'[MAXROUND]')

        return s
    

    def _generate_type(self, n, modifiers=[]):
        """ Recursive generation from a type node. n is the type node. 
            modifiers collects the PtrDecl, ArrayDecl and FuncDecl modifiers 
            encountered on the way down to a TypeDecl, to allow proper
            generation from it.
        """
        typ = type(n)
        ### print(n, modifiers, len(modifiers))
        
        if typ == c_ast.TypeDecl:
            s = '' + self.typeMarkerA
            if n.quals: s += ' '.join(n.quals) + ' '
            s += self.visit(n.type)
            
            nstr = n.declname if n.declname else ''
            # Resolve modifiers.
            # Wrap in parens to distinguish pointer to array and pointer to
            # function syntax.
            #
            for i, modifier in enumerate(modifiers):
                if isinstance(modifier, c_ast.ArrayDecl):
                    if (i != 0 and isinstance(modifiers[i - 1], c_ast.PtrDecl)):
                        nstr = '(' + nstr + ')'
                    nstr += '[' + self.visit(modifier.dim) + ']'
                elif isinstance(modifier, c_ast.FuncDecl):
                    if (i != 0 and isinstance(modifiers[i - 1], c_ast.PtrDecl)):
                        nstr = '(' + nstr + ')'
                    nstr += '(' + self.visit(modifier.args) + ')'
                elif isinstance(modifier, c_ast.PtrDecl):
                    if modifier.quals:
                        nstr = '* %s %s' % (' '.join(modifier.quals), nstr)
                    else:
                        nstr = '*' + nstr

            if nstr: s += ' ' + nstr
            return s + self.typeMarkerB
        elif typ == c_ast.Decl:
            return self.typeMarkerA + self._generate_decl(n.type) + self.typeMarkerB
        elif typ == c_ast.Typename:
            return self.typeMarkerA + self._generate_type(n.type) + self.typeMarkerB
        elif typ == c_ast.IdentifierType:
            return self.typeMarkerA + ' '.join(n.names) + ' ' + self.typeMarkerB
        elif typ in (c_ast.ArrayDecl, c_ast.PtrDecl, c_ast.FuncDecl):
            ###### if typ == c_ast.ArrayDecl: print "ARRAY DECL!!!! %s\n" % n.dim.value ## array value
            return self.typeMarkerA + self._generate_type(n.type, modifiers + [n]) + self.typeMarkerB
        else:
            return self.typeMarkerA + self.visit(n) + self.typeMarkerB


    def _parenthesize_if(self, n, condition):
        """ Visits 'n' and returns its string representation, parenthesized
            if the condition function applied to the node returns True.
        """
        s = self.visit(n)
        if condition(n): return '(' + s + ')'
        else: return s


    def _parenthesize_unless_simple(self, n):
        """ Common use case for _parenthesize_if
        """
        return self._parenthesize_if(n, lambda d: not self._is_simple_node(d))


    def _is_simple_node(self, n):
        """ Returns True for nodes that are "simple" - i.e. nodes that always
            have higher precedence than operators.
        """
        return isinstance(n,(c_ast.Constant, c_ast.ID, c_ast.ArrayRef, c_ast.StructRef, c_ast.FuncCall))















































''' 
    strip()  -  Strips every line in the given string
                from the line with '_____STARTSTRIPPINGFROMHERE_____' as substring
                to the one with '_____STOPSTRIPPINGFROMHERE_____' as substring.

                Lines are identified by '\n'
'''
def strip(s):
    s2 = ''
    status = 0

    for line in s.split('\n'):
        if '_____STARTSTRIPPINGFROMHERE_____' in line:
            status = 1
            continue;

        if '_____STOPSTRIPPINGFROMHERE_____' in line:
            status = 2
            continue;

        if status == 0 or status == 2: s2 += line + '\n'

    return s2


''' 
    sequentialise()  -  Generates the sequentialised version for the given .C source file

'''
def sequentialise(filename, cppargs, maxrounds, maxthreads):
    # generate AST
    ast = parse_file(filename, use_cpp=True, cpp_args=cppargs)

    # generate the sequentialised representation for the input code
    generator = CSequentialiser(ast, maxrounds, maxthreads)

    # put all the sequentialised code into s
    s = generator.visit(ast)

    # strip it from every line coming from the fake_includes introduces by PYCparser
    print (strip(s))

    return 0



#------------------------------------------------------------------------------

def usage():
    print "CSeq:   C sequentialiser\n"

    print "Usage:"
    print "   -h, --help    display this help screen\n"
    print "   -t<X>, --threads<X>    set maxthread for the sequentialisation (default: 5)"
    print "   -r<X>, --rounds<X>    set maxround for the sequentialisation (default: 10)"
    print "   -u<X>, --unwind<X>    set loop unwinding parameter (default: 12)"
    print "   -i<filename>, --input=filename   read input from the filename\n"
    print "   -o<filename>, --output=filename   write output to the filename\n"
    print "   example:  -i input-c-file.c  --output=output-c-file.c -t3 -r 6 -u25\n"





def main():
    try:
        opts, args = getopt.getopt(sys.argv[1:], "hi:o:u:t:r:", ["help", "input=", "output=", "unwind=", "threads=","rounds="])
    except getopt.GetoptError, err:
        # print help information and exit:
        usage()
        print "error: " +str(err) # will print something like "option -a not recognized"
        sys.exit(2)

    inputfile = ''
    outputfile = ''
    unwind = ''
    threads = ''
    rounds = ''

    for o, a in opts:
        if o == "-v":
            verbose = True
        elif o in ("-h", "--help"):
            usage()
            sys.exit()
        elif o in ("-i", "--input"):
            inputfile = a
        elif o in ("-o", "--output"):
            outputfile = a
        elif o in ("-u", "--unwind"):
            unwind = a
        elif o in ("-t", "--threads"):
            threads = int(a)
        elif o in ("-r", "--rounds"):
            rounds = int(a)
        else:
            assert False, "unhandled option"

    if inputfile == '':
        usage()
        print "error: input file name not specified\n"
        sys.exit(2)


    # set default values if needed
    if unwind == '': unwind = 12
    if threads == '': threads = 5
    if rounds == '': rounds = 10

    '''
    print "threads: %s\n" % threads
    print "rounds: %s\n" % rounds
    print "unwind: %s\n" % unwind
    '''

    # sequentialise(inputfile, r'-I/home/user/sequentialisation/fake_libc_include', rounds, threads)
    sequentialise(inputfile, r'-Ifake_libc_include', rounds, threads)


if __name__ == "__main__":
    main()
    '''
	if len(sys.argv) > 1:
		#translate_to_ast(sys.argv[1])
		sequentialise(sys.argv[1], r'-I/home/user/sequentialisation/fake_libc_include', 2, 2) # rounds, threads
	else:
		print("Usage: %s <filename-to-convert> <extra-path-to-include-files>")
    '''

