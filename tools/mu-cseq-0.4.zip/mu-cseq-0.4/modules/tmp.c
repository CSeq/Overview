#include <stdlib.h>
#include <pthread.h>

#define LOCK_SIZE 11
#define vLOCK_SIZE 0

//#define NUM_WRITES <insert-NUM_WRITES-here>

#define MEM_SIZE 44
#define MEM_SIZE_VARS 12
#define NumVars 3
#define MaxNumThreads 3
#define NumAddresses <insert-npointers-here>
#define NumMalloc <insert-nmalloc-here>
 
#define  intV unsigned __CPROVER_bitvector[16]
//#define  intV unsigned int
#define __CS_type unsigned char
#define  __cs_t unsigned __CPROVER_bitvector[16]
//#define  __cs_t unsigned int


#define __CS_typeM unsigned char
#define __CS_typeV unsigned char
#define __CS_typeT unsigned char

/*
#define __CS_typeM unsigned __CPROVER_bitvector[<insert-type-typeM-here>]
#define __CS_typeV unsigned __CPROVER_bitvector[<insert-type-typeV-here>]
#define __CS_typeT unsigned __CPROVER_bitvector[<insert-type-typeT-here>]
*/

#define __CS_pthread_t unsigned char
#define __CS_pthread_mutex_t unsigned char
#define __CS_pthread_cond_t unsigned char

//start global variables

#define value 0
#define inc_flag 1
#define dec_flag 2

//for each variable we represent a MU composed by
//for variable value
#define value_SIZE 12
//for variable inc_flag
#define inc_flag_SIZE 12
//for variable dec_flag
#define dec_flag_SIZE 12
//end global variables
 
 
// shared memory


__CS_typeM __ticket_atomic  [LOCK_SIZE+1];
__CS_typeT __thread_id_atomic  [LOCK_SIZE];
__CS_typeM __thw_atomic[MaxNumThreads][LOCK_SIZE];
__CS_typeM __last_used_pos_of_atomic; 
__CS_typeM __memory_notvalid_of_atomic;


//for each variable "i" we represent a MU composed by
intV __value[NumVars] [MEM_SIZE_VARS]; //value written at variable i
__CS_typeM __ticket [NumVars] [MEM_SIZE_VARS+1]; //Unique ticket assigned to the write opereation
__CS_typeT __thread_id [NumVars] [MEM_SIZE_VARS]; //Which thread writes variable i
__CS_typeT __visible [NumVars] [MEM_SIZE_VARS]; //it is not in a locked memory position
__CS_typeM __thw[NumVars][MaxNumThreads][MEM_SIZE_VARS]; //next write of each thread for i 
__CS_typeM __last_used_pos_of[NumVars]; //last used pos of i
__CS_typeM __memory_notvalid_of[NumVars]; //last valid write pos of i


//Gildo: tolgo isBool
//<insert-bool-declaration-here>
//__CS_typeT thread[MEM_SIZE];  
//__CS_typeM thw[MaxNumThreads][MEM_SIZE];


__CS_typeM ticket_pos; //greatest ticket number encountered during the simulation
_Bool __used_ticket[MEM_SIZE+NumVars+3]; //used by guessing in order to guarantee that each ticket is unique



//<insert-defMax-here>
 
 __CS_typeT n_treads_createad=1;

_Bool __CS_error = 0;                                              //cseq: set whenever an error is found and checked after thread-wrapping
intV __CS_ret = 0; 
_Bool terminated[MaxNumThreads];//={0,0,0};		//viene settato ad 1 solo se il thread viene terminato
  intV GuessedNumThreads;
__CS_typeM ticket_pos_terminated[MaxNumThreads]={0,0,0};		//last ticket_pos



//cseq: handling of the status of the threads 
__CS_typeT __cs_thread_index;                                           //cseq: currently running thread ranging in [1..max+1], 1 being main()
__CS_typeT number_threads;

__CPROVER_bitvector[1] nondet_0(){__CPROVER_bitvector[1] pippo; return pippo;};
__CPROVER_bitvector[1] nondet_1(){__CPROVER_bitvector[1] pippo; return pippo;};
_Bool nondet_bool(){_Bool pippo; return pippo;};

intV Read_atomic(__CS_typeV codeVar);
intV Read_var_atomic();
void Write_var_atomic();

//<insert-read-write-functions-here>
intV Read(__CS_typeV codeVar){
	__CS_typeM jump;
	
	if ((__CS_ret) || ( jump >= __memory_notvalid_of[codeVar] )) {__CS_ret=1; return;}
	
	__CS_typeM ticket_jump = __ticket[codeVar][jump];
    __CPROVER_assume( (jump<__thw[codeVar][__cs_thread_index][__last_used_pos_of[codeVar]] )
				&& (__ticket[codeVar][jump+1]>ticket_pos)			
				&& ( !(ticket_jump > ticket_pos) || (__visible[codeVar][jump]) )
				);						
						/*&& ( !(ticket_jump > ticket_pos) || (__visible[codeVar][jump]) )*/

	ticket_pos = (ticket_jump > ticket_pos) ? ticket_jump : ticket_pos;
	/*&& ( !(ticket_jump > ticket_pos) || (__visible[codeVar][jump]) )*/

	return (__value[codeVar][jump]);

}
void Write(__CS_typeV codeVar, intV val){
	if (__CS_ret) return;
	
	__CS_typeM last_pos = __thw[codeVar][__cs_thread_index][__last_used_pos_of[codeVar]];
	
	if (last_pos >= __memory_notvalid_of[codeVar] ) {__CS_ret=1; return;}
	__last_used_pos_of[codeVar]=last_pos;

	
	__CPROVER_assume (
				(__ticket[codeVar][last_pos] > ticket_pos)
			&&  (__value[codeVar][last_pos] == val)
		) ;
	ticket_pos=__ticket[codeVar][last_pos];
	/*&& ( !(ticket_jump > ticket_pos) || (__visible[codeVar][jump]) )*/

}
intV nondet_int();

/*
intV Read_atomic(__CS_typeV codeVar){
	//return (__value[codeVar][jump]);
	return (__value[codeVar][__last_used_pos_of[codeVar]]);
}
*/
_Bool nondet_bool();





intV __pthread_join( __CS_pthread_t t1, __CS_type __p){
//  return;
__CS_typeV v;
__CPROVER_assume(v<NumVars);
  if (nondet_int()) {__CS_ret=1; return;}
  Read(v);
  Read_var_atomic();
  //Read_var_lock();
  
   __CPROVER_assume((terminated[t1]) && (ticket_pos >= ticket_pos_terminated[t1]));

}

intV Read_atomic(__CS_typeV codeVar){
	__CS_typeM jump;
	
	if ((__CS_ret) || ( jump >= __memory_notvalid_of[codeVar] )) {__CS_ret=1; return;}
	
    __CPROVER_assume( (jump<__thw[codeVar][__cs_thread_index][__last_used_pos_of[codeVar]] )
				&& (__ticket[codeVar][jump+1]>ticket_pos)			
				&& (__ticket[codeVar][jump] <= ticket_pos)			
					);						
						
	return (__value[codeVar][jump]);
}
void Write_atomic(__CS_typeV codeVar, intV val){
	if (__CS_ret) return;
	
	__CS_typeM last_pos = __thw[codeVar][__cs_thread_index][__last_used_pos_of[codeVar]];
	
	if (last_pos >= __memory_notvalid_of[codeVar] ) {__CS_ret=1; return;}
	__last_used_pos_of[codeVar]=last_pos;

	
	__CPROVER_assume (
				(__ticket[codeVar][last_pos] == (ticket_pos+1))
			&&  (__value[codeVar][last_pos] == val)
			&&  (!__visible[codeVar][last_pos])
		) ;
	ticket_pos=__ticket[codeVar][last_pos];
}



void Write_var_atomic(){
	if (__CS_ret) return;
	
	__CS_typeM last_pos = __thw_atomic[__cs_thread_index][__last_used_pos_of_atomic];
	
	if (last_pos >= __memory_notvalid_of_atomic ) {__CS_ret=1; return;}
	__last_used_pos_of_atomic=last_pos;

	
	__CPROVER_assume (
				(__ticket_atomic[last_pos] > ticket_pos)
			//&&  (__value_atomic[last_pos] == val)
		) ;
	ticket_pos=__ticket_atomic[last_pos];

}
intV Read_var_atomic(){
	__CS_typeM jump;
	
	if ((__CS_ret) || ( jump >= __memory_notvalid_of_atomic )) {__CS_ret=1; return;}
	
	__CS_typeM ticket_jump = __ticket_atomic[jump];
    __CPROVER_assume( (jump<__thw_atomic[__cs_thread_index][__last_used_pos_of_atomic] )
				&& (__ticket_atomic[jump+1]>ticket_pos)			
				//&& ( !(ticket_jump > ticket_pos) || (__visible[codeVar][jump]) )
				);						
						/*&& ( !(ticket_jump > ticket_pos) || (__visible[codeVar][jump]) )*/

	ticket_pos = (ticket_jump > ticket_pos) ? ticket_jump : ticket_pos;
	/*&& ( !(ticket_jump > ticket_pos) || (__visible[codeVar][jump]) )*/

}


/*



intV Read_var_atomic(){
	__CS_typeM jump;
	
	if ((__CS_ret) || ( jump >= __memory_notvalid_of_atomic )) {__CS_ret=1; return;}
	
    __CPROVER_assume( (jump<__thw_atomic[__cs_thread_index][__last_used_pos_of_atomic] )
				&& (__ticket_atomic[jump+1]>ticket_pos)			
				&& (__ticket_atomic[jump] <= ticket_pos)			
					);						
						
	return (__value_atomic[jump]);
}
*/
void Take_lock__atomic_function(){

	Write_var_atomic();
	//if (__CS_ret) return;
	//__CPROVER_assume (__value_atomic[__last_used_pos_of_atomic-1] == MaxNumThreads);

}




void Release_lock__atomic_function(){
//	if (__CS_ret) return;
	Write_var_atomic();
}


intV __pthread_create_thread1(__CS_pthread_t *thread_id, void *attr, void *arg);
intV __pthread_create_thread2(__CS_pthread_t *thread_id, void *attr, void *arg);
intV __pthread_create_thread3(__CS_pthread_t *thread_id, void *attr, void *arg);
void __CSEQ_atomic_CAS(
unsigned *__cs_param___CSEQ_atomic_CAS_v, 
unsigned __cs_param___CSEQ_atomic_CAS_e, 
unsigned __cs_param___CSEQ_atomic_CAS_u, 
unsigned *__cs_param___CSEQ_atomic_CAS_r, 
unsigned *__cs_param___CSEQ_atomic_CAS_flag)
{
	Take_lock__atomic_function();
	if (__CS_ret) return;
_Bool __cs_local___CSEQ_atomic_CAS___cs_tmp_if_cond_0;
__cs_local___CSEQ_atomic_CAS___cs_tmp_if_cond_0 = (Read_ptr(__cs_param___CSEQ_atomic_CAS_v)) == __cs_param___CSEQ_atomic_CAS_e;
if (__cs_local___CSEQ_atomic_CAS___cs_tmp_if_cond_0)
		{
*__cs_param___CSEQ_atomic_CAS_flag = 1, *__cs_param___CSEQ_atomic_CAS_v = __cs_param___CSEQ_atomic_CAS_u, *__cs_param___CSEQ_atomic_CAS_r = 1;
		}
		else
		{
*__cs_param___CSEQ_atomic_CAS_r = 0;
		}
Release_lock__atomic_function();
}
;
;
;
void __CSEQ_atomic_assert1(unsigned __cs_param___CSEQ_atomic_assert1_inc__v)
{
	Take_lock__atomic_function();
	if (__CS_ret) return;
		{
_Bool __cs_local___CSEQ_atomic_assert1___cs_tmp_if_cond_1;
__cs_local___CSEQ_atomic_assert1___cs_tmp_if_cond_1 = !(Read_atomic(dec_flag) || (Read_atomic(value) > __cs_param___CSEQ_atomic_assert1_inc__v));
if (__cs_local___CSEQ_atomic_assert1___cs_tmp_if_cond_1)
				{
 if (!(0)){
	if (__CS_ret) Release_lock__atomic_function(); return; 	__CS_error = 1;  Release_lock__atomic_function();	Release_lock__atomic_function(); return; 
};
(void) 0;
				}
		}
		;
Release_lock__atomic_function();
}
void __CSEQ_atomic_assert2(unsigned __cs_param___CSEQ_atomic_assert2_dec__v)
{
	Take_lock__atomic_function();
	if (__CS_ret) return;
		{
_Bool __cs_local___CSEQ_atomic_assert2___cs_tmp_if_cond_4;
__cs_local___CSEQ_atomic_assert2___cs_tmp_if_cond_4 = !(Read_atomic(inc_flag) || (Read_atomic(value) < __cs_param___CSEQ_atomic_assert2_dec__v));
if (__cs_local___CSEQ_atomic_assert2___cs_tmp_if_cond_4)
				{
 if (!(0)){
	if (__CS_ret) Release_lock__atomic_function(); return; 	__CS_error = 1;  Release_lock__atomic_function();	Release_lock__atomic_function(); return; 
};
(void) 0;
				}
		}
		;
Release_lock__atomic_function();
}
void __CSEQ_atomic_CAS_cs_struct_value_cs_struct_inc_flag(unsigned *__cs_param___CSEQ_atomic_CAS_cs_struct_value_cs_struct_inc_flag_v, unsigned __cs_param___CSEQ_atomic_CAS_cs_struct_value_cs_struct_inc_flag_e, unsigned __cs_param___CSEQ_atomic_CAS_cs_struct_value_cs_struct_inc_flag_u, unsigned *__cs_param___CSEQ_atomic_CAS_cs_struct_value_cs_struct_inc_flag_r, unsigned *__cs_param___CSEQ_atomic_CAS_cs_struct_value_cs_struct_inc_flag_flag)
								{
									Take_lock__atomic_function();
									if (__CS_ret) return;
										_Bool __cs_local___CSEQ_atomic_CAS___cs_tmp_if_cond_0;
										__cs_local___CSEQ_atomic_CAS___cs_tmp_if_cond_0 = (Read_ptr(__cs_param___CSEQ_atomic_CAS_cs_struct_value_cs_struct_inc_flag_v)) == __cs_param___CSEQ_atomic_CAS_cs_struct_value_cs_struct_inc_flag_e;
										if (__cs_local___CSEQ_atomic_CAS___cs_tmp_if_cond_0)
										{
												*__cs_param___CSEQ_atomic_CAS_cs_struct_value_cs_struct_inc_flag_flag = 1, *__cs_param___CSEQ_atomic_CAS_cs_struct_value_cs_struct_inc_flag_v = __cs_param___CSEQ_atomic_CAS_cs_struct_value_cs_struct_inc_flag_u, *__cs_param___CSEQ_atomic_CAS_cs_struct_value_cs_struct_inc_flag_r = 1;
										}
										else
										{
												*__cs_param___CSEQ_atomic_CAS_cs_struct_value_cs_struct_inc_flag_r = 0;
										}
Release_lock__atomic_function();
}
void __CSEQ_atomic_CAS_cs_struct_value_cs_struct_dec_flag(unsigned *__cs_param___CSEQ_atomic_CAS_cs_struct_value_cs_struct_dec_flag_v, unsigned __cs_param___CSEQ_atomic_CAS_cs_struct_value_cs_struct_dec_flag_e, unsigned __cs_param___CSEQ_atomic_CAS_cs_struct_value_cs_struct_dec_flag_u, unsigned *__cs_param___CSEQ_atomic_CAS_cs_struct_value_cs_struct_dec_flag_r, unsigned *__cs_param___CSEQ_atomic_CAS_cs_struct_value_cs_struct_dec_flag_flag)
								{
									Take_lock__atomic_function();
									if (__CS_ret) return;
										_Bool __cs_local___CSEQ_atomic_CAS___cs_tmp_if_cond_0;
										__cs_local___CSEQ_atomic_CAS___cs_tmp_if_cond_0 = (Read_ptr(__cs_param___CSEQ_atomic_CAS_cs_struct_value_cs_struct_dec_flag_v)) == __cs_param___CSEQ_atomic_CAS_cs_struct_value_cs_struct_dec_flag_e;
										if (__cs_local___CSEQ_atomic_CAS___cs_tmp_if_cond_0)
										{
												*__cs_param___CSEQ_atomic_CAS_cs_struct_value_cs_struct_dec_flag_flag = 1, *__cs_param___CSEQ_atomic_CAS_cs_struct_value_cs_struct_dec_flag_v = __cs_param___CSEQ_atomic_CAS_cs_struct_value_cs_struct_dec_flag_u, *__cs_param___CSEQ_atomic_CAS_cs_struct_value_cs_struct_dec_flag_r = 1;
										}
										else
										{
												*__cs_param___CSEQ_atomic_CAS_cs_struct_value_cs_struct_dec_flag_r = 0;
										}
Release_lock__atomic_function();
}
void *thr1_0(void *__cs_param_thr1_arg)
{
int __cs_local_thr1_r;
__cs_local_thr1_r = nondet_int();
_Bool __cs_local_thr1___cs_tmp_if_cond_7;
__cs_local_thr1___cs_tmp_if_cond_7 = __cs_local_thr1_r;
if (__cs_local_thr1___cs_tmp_if_cond_7)
		{
static unsigned __cs_retval__inc_1;
				{
unsigned __cs_local_inc_inc__v;
unsigned __cs_local_inc_inc__vn;
unsigned __cs_local_inc_inc__casret;
						;
int __cs_local_inc___cs_dowhile_onetime_1;
__cs_local_inc___cs_dowhile_onetime_1 = 0;
						{
__cs_local_inc_inc__v = Read(value);
_Bool __cs_local_inc___cs_tmp_if_cond_2;
__cs_local_inc___cs_tmp_if_cond_2 = __cs_local_inc_inc__v == (0u - 1);
if (__cs_local_inc___cs_tmp_if_cond_2)
								{
__cs_retval__inc_1 = 0;
goto __exit__inc_1;
								}
__cs_local_inc_inc__vn = __cs_local_inc_inc__v + 1;
__CSEQ_atomic_CAS_cs_struct_value_cs_struct_inc_flag(0, __cs_local_inc_inc__v, __cs_local_inc_inc__vn, &__cs_local_inc_inc__casret, 0);
						}
__cs_local_inc___cs_dowhile_onetime_1++;
if (nondet_int()	){__CS_ret=1; return 0;} __CPROVER_assume(!(__cs_local_inc___cs_dowhile_onetime_1 < 1));
;
__exit_loop_1:
						;
if (!(__cs_local_inc_inc__casret == 0))
						{
goto __exit_loop_2;
						}
						{
__cs_local_inc_inc__v = Read(value);
_Bool __cs_local_inc___cs_tmp_if_cond_3;
__cs_local_inc___cs_tmp_if_cond_3 = __cs_local_inc_inc__v == (0u - 1);
if (__cs_local_inc___cs_tmp_if_cond_3)
								{
__cs_retval__inc_1 = 0;
goto __exit__inc_1;
								}
__cs_local_inc_inc__vn = __cs_local_inc_inc__v + 1;
__CSEQ_atomic_CAS_cs_struct_value_cs_struct_inc_flag(0, __cs_local_inc_inc__v, __cs_local_inc_inc__vn, &__cs_local_inc_inc__casret, 0);
						}
if (!(__cs_local_inc_inc__casret == 0))
						{
goto __exit_loop_2;
						}
						{
__cs_local_inc_inc__v = Read(value);
_Bool __cs_local_inc___cs_tmp_if_cond_3;
__cs_local_inc___cs_tmp_if_cond_3 = __cs_local_inc_inc__v == (0u - 1);
if (__cs_local_inc___cs_tmp_if_cond_3)
								{
__cs_retval__inc_1 = 0;
goto __exit__inc_1;
								}
__cs_local_inc_inc__vn = __cs_local_inc_inc__v + 1;
__CSEQ_atomic_CAS_cs_struct_value_cs_struct_inc_flag(0, __cs_local_inc_inc__v, __cs_local_inc_inc__vn, &__cs_local_inc_inc__casret, 0);
						}
if (nondet_int()	){__CS_ret=1; return 0;} __CPROVER_assume(!(__cs_local_inc_inc__casret == 0));
;
__exit_loop_2:
						;
__CSEQ_atomic_assert1(__cs_local_inc_inc__v);;
__cs_retval__inc_1 = __cs_local_inc_inc__vn;
goto __exit__inc_1;
__exit__inc_1:
						;
				}
__cs_retval__inc_1;
		}
		else
		{
static unsigned __cs_retval__dec_1;
				{
unsigned __cs_local_dec_dec__v;
unsigned __cs_local_dec_dec__vn;
unsigned __cs_local_dec_dec__casret;
						;
int __cs_local_dec___cs_dowhile_onetime_2;
__cs_local_dec___cs_dowhile_onetime_2 = 0;
						{
__cs_local_dec_dec__v = Read(value);
_Bool __cs_local_dec___cs_tmp_if_cond_5;
__cs_local_dec___cs_tmp_if_cond_5 = __cs_local_dec_dec__v == 0;
if (__cs_local_dec___cs_tmp_if_cond_5)
								{
__cs_retval__dec_1 = 0u - 1;
goto __exit__dec_1;
								}
__cs_local_dec_dec__vn = __cs_local_dec_dec__v - 1;
__CSEQ_atomic_CAS_cs_struct_value_cs_struct_dec_flag(0, __cs_local_dec_dec__v, __cs_local_dec_dec__vn, &__cs_local_dec_dec__casret, 0);
						}
__cs_local_dec___cs_dowhile_onetime_2++;
if (nondet_int()	){__CS_ret=1; return 0;} __CPROVER_assume(!(__cs_local_dec___cs_dowhile_onetime_2 < 1));
;
__exit_loop_3:
						;
if (!(__cs_local_dec_dec__casret == 0))
						{
goto __exit_loop_4;
						}
						{
__cs_local_dec_dec__v = Read(value);
_Bool __cs_local_dec___cs_tmp_if_cond_6;
__cs_local_dec___cs_tmp_if_cond_6 = __cs_local_dec_dec__v == 0;
if (__cs_local_dec___cs_tmp_if_cond_6)
								{
__cs_retval__dec_1 = 0u - 1;
goto __exit__dec_1;
								}
__cs_local_dec_dec__vn = __cs_local_dec_dec__v - 1;
__CSEQ_atomic_CAS_cs_struct_value_cs_struct_dec_flag(0, __cs_local_dec_dec__v, __cs_local_dec_dec__vn, &__cs_local_dec_dec__casret, 0);
						}
if (!(__cs_local_dec_dec__casret == 0))
						{
goto __exit_loop_4;
						}
						{
__cs_local_dec_dec__v = Read(value);
_Bool __cs_local_dec___cs_tmp_if_cond_6;
__cs_local_dec___cs_tmp_if_cond_6 = __cs_local_dec_dec__v == 0;
if (__cs_local_dec___cs_tmp_if_cond_6)
								{
__cs_retval__dec_1 = 0u - 1;
goto __exit__dec_1;
								}
__cs_local_dec_dec__vn = __cs_local_dec_dec__v - 1;
__CSEQ_atomic_CAS_cs_struct_value_cs_struct_dec_flag(0, __cs_local_dec_dec__v, __cs_local_dec_dec__vn, &__cs_local_dec_dec__casret, 0);
						}
if (nondet_int()	){__CS_ret=1; return 0;} __CPROVER_assume(!(__cs_local_dec_dec__casret == 0));
;
__exit_loop_4:
						;
__CSEQ_atomic_assert2(__cs_local_dec_dec__v);;
__cs_retval__dec_1 = __cs_local_dec_dec__vn;
goto __exit__dec_1;
__exit__dec_1:
						;
				}
__cs_retval__dec_1;
		}
goto __exit_thr1;
__exit_thr1:
		;
//__pthread_exit(NULL);;
	}
void *thr1_1(void *__cs_param_thr1_arg)
{
int __cs_local_thr1_r;
__cs_local_thr1_r = nondet_int();
_Bool __cs_local_thr1___cs_tmp_if_cond_7;
__cs_local_thr1___cs_tmp_if_cond_7 = __cs_local_thr1_r;
if (__cs_local_thr1___cs_tmp_if_cond_7)
		{
static unsigned __cs_retval__inc_1;
				{
unsigned __cs_local_inc_inc__v;
unsigned __cs_local_inc_inc__vn;
unsigned __cs_local_inc_inc__casret;
						;
int __cs_local_inc___cs_dowhile_onetime_1;
__cs_local_inc___cs_dowhile_onetime_1 = 0;
						{
__cs_local_inc_inc__v = Read(value);
_Bool __cs_local_inc___cs_tmp_if_cond_2;
__cs_local_inc___cs_tmp_if_cond_2 = __cs_local_inc_inc__v == (0u - 1);
if (__cs_local_inc___cs_tmp_if_cond_2)
								{
__cs_retval__inc_1 = 0;
goto __exit__inc_1;
								}
__cs_local_inc_inc__vn = __cs_local_inc_inc__v + 1;
__CSEQ_atomic_CAS_cs_struct_value_cs_struct_inc_flag(0, __cs_local_inc_inc__v, __cs_local_inc_inc__vn, &__cs_local_inc_inc__casret, 0);
						}
__cs_local_inc___cs_dowhile_onetime_1++;
if (nondet_int()	){__CS_ret=1; return 0;} __CPROVER_assume(!(__cs_local_inc___cs_dowhile_onetime_1 < 1));
;
__exit_loop_1:
						;
if (!(__cs_local_inc_inc__casret == 0))
						{
goto __exit_loop_2;
						}
						{
__cs_local_inc_inc__v = Read(value);
_Bool __cs_local_inc___cs_tmp_if_cond_3;
__cs_local_inc___cs_tmp_if_cond_3 = __cs_local_inc_inc__v == (0u - 1);
if (__cs_local_inc___cs_tmp_if_cond_3)
								{
__cs_retval__inc_1 = 0;
goto __exit__inc_1;
								}
__cs_local_inc_inc__vn = __cs_local_inc_inc__v + 1;
__CSEQ_atomic_CAS_cs_struct_value_cs_struct_inc_flag(0, __cs_local_inc_inc__v, __cs_local_inc_inc__vn, &__cs_local_inc_inc__casret, 0);
						}
if (!(__cs_local_inc_inc__casret == 0))
						{
goto __exit_loop_2;
						}
						{
__cs_local_inc_inc__v = Read(value);
_Bool __cs_local_inc___cs_tmp_if_cond_3;
__cs_local_inc___cs_tmp_if_cond_3 = __cs_local_inc_inc__v == (0u - 1);
if (__cs_local_inc___cs_tmp_if_cond_3)
								{
__cs_retval__inc_1 = 0;
goto __exit__inc_1;
								}
__cs_local_inc_inc__vn = __cs_local_inc_inc__v + 1;
__CSEQ_atomic_CAS_cs_struct_value_cs_struct_inc_flag(0, __cs_local_inc_inc__v, __cs_local_inc_inc__vn, &__cs_local_inc_inc__casret, 0);
						}
if (nondet_int()	){__CS_ret=1; return 0;} __CPROVER_assume(!(__cs_local_inc_inc__casret == 0));
;
__exit_loop_2:
						;
__CSEQ_atomic_assert1(__cs_local_inc_inc__v);;
__cs_retval__inc_1 = __cs_local_inc_inc__vn;
goto __exit__inc_1;
__exit__inc_1:
						;
				}
__cs_retval__inc_1;
		}
		else
		{
static unsigned __cs_retval__dec_1;
				{
unsigned __cs_local_dec_dec__v;
unsigned __cs_local_dec_dec__vn;
unsigned __cs_local_dec_dec__casret;
						;
int __cs_local_dec___cs_dowhile_onetime_2;
__cs_local_dec___cs_dowhile_onetime_2 = 0;
						{
__cs_local_dec_dec__v = Read(value);
_Bool __cs_local_dec___cs_tmp_if_cond_5;
__cs_local_dec___cs_tmp_if_cond_5 = __cs_local_dec_dec__v == 0;
if (__cs_local_dec___cs_tmp_if_cond_5)
								{
__cs_retval__dec_1 = 0u - 1;
goto __exit__dec_1;
								}
__cs_local_dec_dec__vn = __cs_local_dec_dec__v - 1;
__CSEQ_atomic_CAS_cs_struct_value_cs_struct_dec_flag(0, __cs_local_dec_dec__v, __cs_local_dec_dec__vn, &__cs_local_dec_dec__casret, 0);
						}
__cs_local_dec___cs_dowhile_onetime_2++;
if (nondet_int()	){__CS_ret=1; return 0;} __CPROVER_assume(!(__cs_local_dec___cs_dowhile_onetime_2 < 1));
;
__exit_loop_3:
						;
if (!(__cs_local_dec_dec__casret == 0))
						{
goto __exit_loop_4;
						}
						{
__cs_local_dec_dec__v = Read(value);
_Bool __cs_local_dec___cs_tmp_if_cond_6;
__cs_local_dec___cs_tmp_if_cond_6 = __cs_local_dec_dec__v == 0;
if (__cs_local_dec___cs_tmp_if_cond_6)
								{
__cs_retval__dec_1 = 0u - 1;
goto __exit__dec_1;
								}
__cs_local_dec_dec__vn = __cs_local_dec_dec__v - 1;
__CSEQ_atomic_CAS_cs_struct_value_cs_struct_dec_flag(0, __cs_local_dec_dec__v, __cs_local_dec_dec__vn, &__cs_local_dec_dec__casret, 0);
						}
if (!(__cs_local_dec_dec__casret == 0))
						{
goto __exit_loop_4;
						}
						{
__cs_local_dec_dec__v = Read(value);
_Bool __cs_local_dec___cs_tmp_if_cond_6;
__cs_local_dec___cs_tmp_if_cond_6 = __cs_local_dec_dec__v == 0;
if (__cs_local_dec___cs_tmp_if_cond_6)
								{
__cs_retval__dec_1 = 0u - 1;
goto __exit__dec_1;
								}
__cs_local_dec_dec__vn = __cs_local_dec_dec__v - 1;
__CSEQ_atomic_CAS_cs_struct_value_cs_struct_dec_flag(0, __cs_local_dec_dec__v, __cs_local_dec_dec__vn, &__cs_local_dec_dec__casret, 0);
						}
if (nondet_int()	){__CS_ret=1; return 0;} __CPROVER_assume(!(__cs_local_dec_dec__casret == 0));
;
__exit_loop_4:
						;
__CSEQ_atomic_assert2(__cs_local_dec_dec__v);;
__cs_retval__dec_1 = __cs_local_dec_dec__vn;
goto __exit__dec_1;
__exit__dec_1:
						;
				}
__cs_retval__dec_1;
		}
goto __exit_thr1;
__exit_thr1:
		;
//__pthread_exit(NULL);;
	}

int __pthread_create_thr1_0(__CS_pthread_t *thread_id, void *attr, void *arg){
	int __ret=0;
__CS_typeT my_thread_index;
__CS_typeM my_ticket_pos;

   __CS_typeM my__last_used_pos_of[NumVars];
   __CS_typeM my__last_used_pos_of_atomic = __last_used_pos_of_atomic;;
   my__last_used_pos_of[value] = __last_used_pos_of[value];
   my__last_used_pos_of[inc_flag] = __last_used_pos_of[inc_flag];
   my__last_used_pos_of[dec_flag] = __last_used_pos_of[dec_flag];

   if (MaxNumThreads==++number_threads) return 0;
	my_thread_index = __cs_thread_index; 
 	my_ticket_pos   = ticket_pos;
 	__cs_thread_index = number_threads;
   n_treads_createad++;
 	
__CPROVER_assume(__thw[value][__cs_thread_index][0] > __last_used_pos_of[value]);
__CPROVER_assume(__thw[inc_flag][__cs_thread_index][0] > __last_used_pos_of[inc_flag]);
__CPROVER_assume(__thw[dec_flag][__cs_thread_index][0] > __last_used_pos_of[dec_flag]);
__CPROVER_assume(__thw_atomic[__cs_thread_index][0] > __last_used_pos_of_atomic);
	if (nondet_int()){ __CS_ret=1; __ret=-1;}
 	else { thr1_0( arg); }
 	*thread_id=__cs_thread_index;
 	//__CPROVER_assume((thw[__cs_thread_index][thread_pos] >=memory_notvalid) );
 	 	//__CPROVER_assume((thread_pos< memory_notvalid) && (thw[__cs_thread_index][thread_pos] >=memory_notvalid) );
 	
__CPROVER_assume(__thw[value][__cs_thread_index][__last_used_pos_of[value]] >=__memory_notvalid_of[value]) ;
__CPROVER_assume(__thw[inc_flag][__cs_thread_index][__last_used_pos_of[inc_flag]] >=__memory_notvalid_of[inc_flag]) ;
__CPROVER_assume(__thw[dec_flag][__cs_thread_index][__last_used_pos_of[dec_flag]] >=__memory_notvalid_of[dec_flag]) ;
__CPROVER_assume(__thw_atomic[__cs_thread_index][__last_used_pos_of_atomic] >=__memory_notvalid_of_atomic) ;
 	//if (__CS_ret==1) terminated[__cs_thread_index]=1;
	terminated[__cs_thread_index]=!__CS_ret;
	__CPROVER_assume(ticket_pos_terminated[__cs_thread_index]==ticket_pos);
	//sistemare thread_pos_terminated[__cs_thread_index]=ticket_pos;
	//ticket_pos_terminated[__cs_thread_index]=ticket_pos;
 	__CS_ret=0;
 	__cs_thread_index = my_thread_index;
 	ticket_pos   = my_ticket_pos;
	
   __last_used_pos_of[value] = my__last_used_pos_of[value];
   __last_used_pos_of[inc_flag] = my__last_used_pos_of[inc_flag];
   __last_used_pos_of[dec_flag] = my__last_used_pos_of[dec_flag];
   __last_used_pos_of_atomic = my__last_used_pos_of_atomic;
	return __ret;
}

int __pthread_create_thr1_1(__CS_pthread_t *thread_id, void *attr, void *arg){
	int __ret=0;
__CS_typeT my_thread_index;
__CS_typeM my_ticket_pos;

   __CS_typeM my__last_used_pos_of[NumVars];
   __CS_typeM my__last_used_pos_of_atomic = __last_used_pos_of_atomic;;
   my__last_used_pos_of[value] = __last_used_pos_of[value];
   my__last_used_pos_of[inc_flag] = __last_used_pos_of[inc_flag];
   my__last_used_pos_of[dec_flag] = __last_used_pos_of[dec_flag];

   if (MaxNumThreads==++number_threads) return 0;
	my_thread_index = __cs_thread_index; 
 	my_ticket_pos   = ticket_pos;
 	__cs_thread_index = number_threads;
   n_treads_createad++;
 	
__CPROVER_assume(__thw[value][__cs_thread_index][0] > __last_used_pos_of[value]);
__CPROVER_assume(__thw[inc_flag][__cs_thread_index][0] > __last_used_pos_of[inc_flag]);
__CPROVER_assume(__thw[dec_flag][__cs_thread_index][0] > __last_used_pos_of[dec_flag]);
__CPROVER_assume(__thw_atomic[__cs_thread_index][0] > __last_used_pos_of_atomic);
	if (nondet_int()){ __CS_ret=1; __ret=-1;}
 	else { thr1_1( arg); }
 	*thread_id=__cs_thread_index;
 	//__CPROVER_assume((thw[__cs_thread_index][thread_pos] >=memory_notvalid) );
 	 	//__CPROVER_assume((thread_pos< memory_notvalid) && (thw[__cs_thread_index][thread_pos] >=memory_notvalid) );
 	
__CPROVER_assume(__thw[value][__cs_thread_index][__last_used_pos_of[value]] >=__memory_notvalid_of[value]) ;
__CPROVER_assume(__thw[inc_flag][__cs_thread_index][__last_used_pos_of[inc_flag]] >=__memory_notvalid_of[inc_flag]) ;
__CPROVER_assume(__thw[dec_flag][__cs_thread_index][__last_used_pos_of[dec_flag]] >=__memory_notvalid_of[dec_flag]) ;
__CPROVER_assume(__thw_atomic[__cs_thread_index][__last_used_pos_of_atomic] >=__memory_notvalid_of_atomic) ;
 	//if (__CS_ret==1) terminated[__cs_thread_index]=1;
	terminated[__cs_thread_index]=!__CS_ret;
	__CPROVER_assume(ticket_pos_terminated[__cs_thread_index]==ticket_pos);
	//sistemare thread_pos_terminated[__cs_thread_index]=ticket_pos;
	//ticket_pos_terminated[__cs_thread_index]=ticket_pos;
 	__CS_ret=0;
 	__cs_thread_index = my_thread_index;
 	ticket_pos   = my_ticket_pos;
	
   __last_used_pos_of[value] = my__last_used_pos_of[value];
   __last_used_pos_of[inc_flag] = my__last_used_pos_of[inc_flag];
   __last_used_pos_of[dec_flag] = my__last_used_pos_of[dec_flag];
   __last_used_pos_of_atomic = my__last_used_pos_of_atomic;
	return __ret;
}

void *main_thread(int __cs_param_main_argc, char *__cs_param_main_argv[])
{
__cs_t __cs_local_main_t;
		{
__pthread_create_thr1_0(&__cs_local_main_t,  0,  0);;
		}
		{
__pthread_create_thr1_1(&__cs_local_main_t,  0,  0);;
		}
if (nondet_int()	){__CS_ret=1; return 0;} __CPROVER_assume(!1);
;
__exit_loop_5:
		;
__exit_main:
		;
//__pthread_exit(NULL);;
}


void guessMU(void){  
 
 
//INITIALIZATION OF SHARED VARIABLES 
//END INITIALIZATION OF SHARED VARIABLES

__CS_typeM tmp_ticket_pos_terminated[MaxNumThreads];
	ticket_pos_terminated[0] = tmp_ticket_pos_terminated[0];
	__CPROVER_assume((tmp_ticket_pos_terminated[0] >= 0 ) && (tmp_ticket_pos_terminated[0] < MEM_SIZE + NumVars ));
	ticket_pos_terminated[1] = tmp_ticket_pos_terminated[1];
	__CPROVER_assume((tmp_ticket_pos_terminated[1] >= 0 ) && (tmp_ticket_pos_terminated[1] < MEM_SIZE + NumVars ));
	ticket_pos_terminated[2] = tmp_ticket_pos_terminated[2];
	__CPROVER_assume((tmp_ticket_pos_terminated[2] >= 0 ) && (tmp_ticket_pos_terminated[2] < MEM_SIZE + NumVars ));

__CS_typeM ticket_tmp[MEM_SIZE]; 
_Bool visible_tmp[MEM_SIZE]; 
intV __value_tmp[MEM_SIZE]; 
__CS_typeM  nondet_memory[NumVars]; 
__CS_typeM thread_tmp[MEM_SIZE]; 
	//for each scalar variable we guess the MU
	__CS_type  nondet___atomic;
	__CPROVER_assume( (nondet___atomic>0) && (nondet___atomic <= LOCK_SIZE) );
	__memory_notvalid_of_atomic = nondet___atomic;
	__ticket_atomic[0] = 0;			

	//for variable value: size: 11
	__ticket[value][0] = 0;
	__memory_notvalid_of[value] = nondet_memory[0];
	__CPROVER_assume( (__memory_notvalid_of[value]>0) && (__memory_notvalid_of[value] <= value_SIZE) );

	__thread_id[value][1] = thread_tmp[0];
	__visible[value][1] = visible_tmp[0];
	__CPROVER_assume((__thread_id[value][1] >= 0) && (__thread_id[value][1] < GuessedNumThreads));
	__value[value][1] = __value_tmp[0];
	__ticket[value][1]=ticket_tmp[0]; 
	__CPROVER_assume( (__ticket[value][1] < MEM_SIZE)
	               && (__ticket[value][1]>__ticket[value][0])
	               && (!__used_ticket[__ticket[value][1]]) );
	__used_ticket[__ticket[value][1]] = 1;

	__thread_id[value][2] = thread_tmp[1];
	__visible[value][2] = visible_tmp[1];
	__CPROVER_assume((__thread_id[value][2] >= 0) && (__thread_id[value][2] < GuessedNumThreads));
	__value[value][2] = __value_tmp[1];
	__ticket[value][2]=ticket_tmp[1]; 
	__CPROVER_assume( (__ticket[value][2] < MEM_SIZE)
	               && (__ticket[value][2]>__ticket[value][1])
	               && (!__used_ticket[__ticket[value][2]]) );
	__used_ticket[__ticket[value][2]] = 1;

	__thread_id[value][3] = thread_tmp[2];
	__visible[value][3] = visible_tmp[2];
	__CPROVER_assume((__thread_id[value][3] >= 0) && (__thread_id[value][3] < GuessedNumThreads));
	__value[value][3] = __value_tmp[2];
	__ticket[value][3]=ticket_tmp[2]; 
	__CPROVER_assume( (__ticket[value][3] < MEM_SIZE)
	               && (__ticket[value][3]>__ticket[value][2])
	               && (!__used_ticket[__ticket[value][3]]) );
	__used_ticket[__ticket[value][3]] = 1;

	__thread_id[value][4] = thread_tmp[3];
	__visible[value][4] = visible_tmp[3];
	__CPROVER_assume((__thread_id[value][4] >= 0) && (__thread_id[value][4] < GuessedNumThreads));
	__value[value][4] = __value_tmp[3];
	__ticket[value][4]=ticket_tmp[3]; 
	__CPROVER_assume( (__ticket[value][4] < MEM_SIZE)
	               && (__ticket[value][4]>__ticket[value][3])
	               && (!__used_ticket[__ticket[value][4]]) );
	__used_ticket[__ticket[value][4]] = 1;

	__thread_id[value][5] = thread_tmp[4];
	__visible[value][5] = visible_tmp[4];
	__CPROVER_assume((__thread_id[value][5] >= 0) && (__thread_id[value][5] < GuessedNumThreads));
	__value[value][5] = __value_tmp[4];
	__ticket[value][5]=ticket_tmp[4]; 
	__CPROVER_assume( (__ticket[value][5] < MEM_SIZE)
	               && (__ticket[value][5]>__ticket[value][4])
	               && (!__used_ticket[__ticket[value][5]]) );
	__used_ticket[__ticket[value][5]] = 1;

	__thread_id[value][6] = thread_tmp[5];
	__visible[value][6] = visible_tmp[5];
	__CPROVER_assume((__thread_id[value][6] >= 0) && (__thread_id[value][6] < GuessedNumThreads));
	__value[value][6] = __value_tmp[5];
	__ticket[value][6]=ticket_tmp[5]; 
	__CPROVER_assume( (__ticket[value][6] < MEM_SIZE)
	               && (__ticket[value][6]>__ticket[value][5])
	               && (!__used_ticket[__ticket[value][6]]) );
	__used_ticket[__ticket[value][6]] = 1;

	__thread_id[value][7] = thread_tmp[6];
	__visible[value][7] = visible_tmp[6];
	__CPROVER_assume((__thread_id[value][7] >= 0) && (__thread_id[value][7] < GuessedNumThreads));
	__value[value][7] = __value_tmp[6];
	__ticket[value][7]=ticket_tmp[6]; 
	__CPROVER_assume( (__ticket[value][7] < MEM_SIZE)
	               && (__ticket[value][7]>__ticket[value][6])
	               && (!__used_ticket[__ticket[value][7]]) );
	__used_ticket[__ticket[value][7]] = 1;

	__thread_id[value][8] = thread_tmp[7];
	__visible[value][8] = visible_tmp[7];
	__CPROVER_assume((__thread_id[value][8] >= 0) && (__thread_id[value][8] < GuessedNumThreads));
	__value[value][8] = __value_tmp[7];
	__ticket[value][8]=ticket_tmp[7]; 
	__CPROVER_assume( (__ticket[value][8] < MEM_SIZE)
	               && (__ticket[value][8]>__ticket[value][7])
	               && (!__used_ticket[__ticket[value][8]]) );
	__used_ticket[__ticket[value][8]] = 1;

	__thread_id[value][9] = thread_tmp[8];
	__visible[value][9] = visible_tmp[8];
	__CPROVER_assume((__thread_id[value][9] >= 0) && (__thread_id[value][9] < GuessedNumThreads));
	__value[value][9] = __value_tmp[8];
	__ticket[value][9]=ticket_tmp[8]; 
	__CPROVER_assume( (__ticket[value][9] < MEM_SIZE)
	               && (__ticket[value][9]>__ticket[value][8])
	               && (!__used_ticket[__ticket[value][9]]) );
	__used_ticket[__ticket[value][9]] = 1;

	__thread_id[value][10] = thread_tmp[9];
	__visible[value][10] = visible_tmp[9];
	__CPROVER_assume((__thread_id[value][10] >= 0) && (__thread_id[value][10] < GuessedNumThreads));
	__value[value][10] = __value_tmp[9];
	__ticket[value][10]=ticket_tmp[9]; 
	__CPROVER_assume( (__ticket[value][10] < MEM_SIZE)
	               && (__ticket[value][10]>__ticket[value][9])
	               && (!__used_ticket[__ticket[value][10]]) );
	__used_ticket[__ticket[value][10]] = 1;

	__thread_id[value][11] = thread_tmp[10];
	__visible[value][11] = visible_tmp[10];
	__CPROVER_assume((__thread_id[value][11] >= 0) && (__thread_id[value][11] < GuessedNumThreads));
	__value[value][11] = __value_tmp[10];
	__ticket[value][11]=ticket_tmp[10]; 
	__CPROVER_assume( (__ticket[value][11] < MEM_SIZE)
	               && (__ticket[value][11]>__ticket[value][10])
	               && (!__used_ticket[__ticket[value][11]]) );
	__used_ticket[__ticket[value][11]] = 1;

	//__ticket[value][MEM_SIZE_VARS]=ticket_tmp[11]; 
	__ticket[value][value_SIZE]=MEM_SIZE; 
//	__ticket[value][0] = 0;


	//for variable inc_flag: size: 11
	__ticket[inc_flag][0] = 0;
	__memory_notvalid_of[inc_flag] = nondet_memory[1];
	__CPROVER_assume( (__memory_notvalid_of[inc_flag]>0) && (__memory_notvalid_of[inc_flag] <= inc_flag_SIZE) );

	__thread_id[inc_flag][1] = thread_tmp[11];
	__visible[inc_flag][1] = visible_tmp[11];
	__CPROVER_assume((__thread_id[inc_flag][1] >= 0) && (__thread_id[inc_flag][1] < GuessedNumThreads));
	__value[inc_flag][1] = __value_tmp[11];
	__ticket[inc_flag][1]=ticket_tmp[11]; 
	__CPROVER_assume( (__ticket[inc_flag][1] < MEM_SIZE)
	               && (__ticket[inc_flag][1]>__ticket[inc_flag][0])
	               && (!__used_ticket[__ticket[inc_flag][1]]) );
	__used_ticket[__ticket[inc_flag][1]] = 1;

	__thread_id[inc_flag][2] = thread_tmp[12];
	__visible[inc_flag][2] = visible_tmp[12];
	__CPROVER_assume((__thread_id[inc_flag][2] >= 0) && (__thread_id[inc_flag][2] < GuessedNumThreads));
	__value[inc_flag][2] = __value_tmp[12];
	__ticket[inc_flag][2]=ticket_tmp[12]; 
	__CPROVER_assume( (__ticket[inc_flag][2] < MEM_SIZE)
	               && (__ticket[inc_flag][2]>__ticket[inc_flag][1])
	               && (!__used_ticket[__ticket[inc_flag][2]]) );
	__used_ticket[__ticket[inc_flag][2]] = 1;

	__thread_id[inc_flag][3] = thread_tmp[13];
	__visible[inc_flag][3] = visible_tmp[13];
	__CPROVER_assume((__thread_id[inc_flag][3] >= 0) && (__thread_id[inc_flag][3] < GuessedNumThreads));
	__value[inc_flag][3] = __value_tmp[13];
	__ticket[inc_flag][3]=ticket_tmp[13]; 
	__CPROVER_assume( (__ticket[inc_flag][3] < MEM_SIZE)
	               && (__ticket[inc_flag][3]>__ticket[inc_flag][2])
	               && (!__used_ticket[__ticket[inc_flag][3]]) );
	__used_ticket[__ticket[inc_flag][3]] = 1;

	__thread_id[inc_flag][4] = thread_tmp[14];
	__visible[inc_flag][4] = visible_tmp[14];
	__CPROVER_assume((__thread_id[inc_flag][4] >= 0) && (__thread_id[inc_flag][4] < GuessedNumThreads));
	__value[inc_flag][4] = __value_tmp[14];
	__ticket[inc_flag][4]=ticket_tmp[14]; 
	__CPROVER_assume( (__ticket[inc_flag][4] < MEM_SIZE)
	               && (__ticket[inc_flag][4]>__ticket[inc_flag][3])
	               && (!__used_ticket[__ticket[inc_flag][4]]) );
	__used_ticket[__ticket[inc_flag][4]] = 1;

	__thread_id[inc_flag][5] = thread_tmp[15];
	__visible[inc_flag][5] = visible_tmp[15];
	__CPROVER_assume((__thread_id[inc_flag][5] >= 0) && (__thread_id[inc_flag][5] < GuessedNumThreads));
	__value[inc_flag][5] = __value_tmp[15];
	__ticket[inc_flag][5]=ticket_tmp[15]; 
	__CPROVER_assume( (__ticket[inc_flag][5] < MEM_SIZE)
	               && (__ticket[inc_flag][5]>__ticket[inc_flag][4])
	               && (!__used_ticket[__ticket[inc_flag][5]]) );
	__used_ticket[__ticket[inc_flag][5]] = 1;

	__thread_id[inc_flag][6] = thread_tmp[16];
	__visible[inc_flag][6] = visible_tmp[16];
	__CPROVER_assume((__thread_id[inc_flag][6] >= 0) && (__thread_id[inc_flag][6] < GuessedNumThreads));
	__value[inc_flag][6] = __value_tmp[16];
	__ticket[inc_flag][6]=ticket_tmp[16]; 
	__CPROVER_assume( (__ticket[inc_flag][6] < MEM_SIZE)
	               && (__ticket[inc_flag][6]>__ticket[inc_flag][5])
	               && (!__used_ticket[__ticket[inc_flag][6]]) );
	__used_ticket[__ticket[inc_flag][6]] = 1;

	__thread_id[inc_flag][7] = thread_tmp[17];
	__visible[inc_flag][7] = visible_tmp[17];
	__CPROVER_assume((__thread_id[inc_flag][7] >= 0) && (__thread_id[inc_flag][7] < GuessedNumThreads));
	__value[inc_flag][7] = __value_tmp[17];
	__ticket[inc_flag][7]=ticket_tmp[17]; 
	__CPROVER_assume( (__ticket[inc_flag][7] < MEM_SIZE)
	               && (__ticket[inc_flag][7]>__ticket[inc_flag][6])
	               && (!__used_ticket[__ticket[inc_flag][7]]) );
	__used_ticket[__ticket[inc_flag][7]] = 1;

	__thread_id[inc_flag][8] = thread_tmp[18];
	__visible[inc_flag][8] = visible_tmp[18];
	__CPROVER_assume((__thread_id[inc_flag][8] >= 0) && (__thread_id[inc_flag][8] < GuessedNumThreads));
	__value[inc_flag][8] = __value_tmp[18];
	__ticket[inc_flag][8]=ticket_tmp[18]; 
	__CPROVER_assume( (__ticket[inc_flag][8] < MEM_SIZE)
	               && (__ticket[inc_flag][8]>__ticket[inc_flag][7])
	               && (!__used_ticket[__ticket[inc_flag][8]]) );
	__used_ticket[__ticket[inc_flag][8]] = 1;

	__thread_id[inc_flag][9] = thread_tmp[19];
	__visible[inc_flag][9] = visible_tmp[19];
	__CPROVER_assume((__thread_id[inc_flag][9] >= 0) && (__thread_id[inc_flag][9] < GuessedNumThreads));
	__value[inc_flag][9] = __value_tmp[19];
	__ticket[inc_flag][9]=ticket_tmp[19]; 
	__CPROVER_assume( (__ticket[inc_flag][9] < MEM_SIZE)
	               && (__ticket[inc_flag][9]>__ticket[inc_flag][8])
	               && (!__used_ticket[__ticket[inc_flag][9]]) );
	__used_ticket[__ticket[inc_flag][9]] = 1;

	__thread_id[inc_flag][10] = thread_tmp[20];
	__visible[inc_flag][10] = visible_tmp[20];
	__CPROVER_assume((__thread_id[inc_flag][10] >= 0) && (__thread_id[inc_flag][10] < GuessedNumThreads));
	__value[inc_flag][10] = __value_tmp[20];
	__ticket[inc_flag][10]=ticket_tmp[20]; 
	__CPROVER_assume( (__ticket[inc_flag][10] < MEM_SIZE)
	               && (__ticket[inc_flag][10]>__ticket[inc_flag][9])
	               && (!__used_ticket[__ticket[inc_flag][10]]) );
	__used_ticket[__ticket[inc_flag][10]] = 1;

	__thread_id[inc_flag][11] = thread_tmp[21];
	__visible[inc_flag][11] = visible_tmp[21];
	__CPROVER_assume((__thread_id[inc_flag][11] >= 0) && (__thread_id[inc_flag][11] < GuessedNumThreads));
	__value[inc_flag][11] = __value_tmp[21];
	__ticket[inc_flag][11]=ticket_tmp[21]; 
	__CPROVER_assume( (__ticket[inc_flag][11] < MEM_SIZE)
	               && (__ticket[inc_flag][11]>__ticket[inc_flag][10])
	               && (!__used_ticket[__ticket[inc_flag][11]]) );
	__used_ticket[__ticket[inc_flag][11]] = 1;

	//__ticket[inc_flag][MEM_SIZE_VARS]=ticket_tmp[22]; 
	__ticket[inc_flag][inc_flag_SIZE]=MEM_SIZE; 
//	__ticket[inc_flag][0] = 0;


	//for variable dec_flag: size: 11
	__ticket[dec_flag][0] = 0;
	__memory_notvalid_of[dec_flag] = nondet_memory[2];
	__CPROVER_assume( (__memory_notvalid_of[dec_flag]>0) && (__memory_notvalid_of[dec_flag] <= dec_flag_SIZE) );

	__thread_id[dec_flag][1] = thread_tmp[22];
	__visible[dec_flag][1] = visible_tmp[22];
	__CPROVER_assume((__thread_id[dec_flag][1] >= 0) && (__thread_id[dec_flag][1] < GuessedNumThreads));
	__value[dec_flag][1] = __value_tmp[22];
	__ticket[dec_flag][1]=ticket_tmp[22]; 
	__CPROVER_assume( (__ticket[dec_flag][1] < MEM_SIZE)
	               && (__ticket[dec_flag][1]>__ticket[dec_flag][0])
	               && (!__used_ticket[__ticket[dec_flag][1]]) );
	__used_ticket[__ticket[dec_flag][1]] = 1;

	__thread_id[dec_flag][2] = thread_tmp[23];
	__visible[dec_flag][2] = visible_tmp[23];
	__CPROVER_assume((__thread_id[dec_flag][2] >= 0) && (__thread_id[dec_flag][2] < GuessedNumThreads));
	__value[dec_flag][2] = __value_tmp[23];
	__ticket[dec_flag][2]=ticket_tmp[23]; 
	__CPROVER_assume( (__ticket[dec_flag][2] < MEM_SIZE)
	               && (__ticket[dec_flag][2]>__ticket[dec_flag][1])
	               && (!__used_ticket[__ticket[dec_flag][2]]) );
	__used_ticket[__ticket[dec_flag][2]] = 1;

	__thread_id[dec_flag][3] = thread_tmp[24];
	__visible[dec_flag][3] = visible_tmp[24];
	__CPROVER_assume((__thread_id[dec_flag][3] >= 0) && (__thread_id[dec_flag][3] < GuessedNumThreads));
	__value[dec_flag][3] = __value_tmp[24];
	__ticket[dec_flag][3]=ticket_tmp[24]; 
	__CPROVER_assume( (__ticket[dec_flag][3] < MEM_SIZE)
	               && (__ticket[dec_flag][3]>__ticket[dec_flag][2])
	               && (!__used_ticket[__ticket[dec_flag][3]]) );
	__used_ticket[__ticket[dec_flag][3]] = 1;

	__thread_id[dec_flag][4] = thread_tmp[25];
	__visible[dec_flag][4] = visible_tmp[25];
	__CPROVER_assume((__thread_id[dec_flag][4] >= 0) && (__thread_id[dec_flag][4] < GuessedNumThreads));
	__value[dec_flag][4] = __value_tmp[25];
	__ticket[dec_flag][4]=ticket_tmp[25]; 
	__CPROVER_assume( (__ticket[dec_flag][4] < MEM_SIZE)
	               && (__ticket[dec_flag][4]>__ticket[dec_flag][3])
	               && (!__used_ticket[__ticket[dec_flag][4]]) );
	__used_ticket[__ticket[dec_flag][4]] = 1;

	__thread_id[dec_flag][5] = thread_tmp[26];
	__visible[dec_flag][5] = visible_tmp[26];
	__CPROVER_assume((__thread_id[dec_flag][5] >= 0) && (__thread_id[dec_flag][5] < GuessedNumThreads));
	__value[dec_flag][5] = __value_tmp[26];
	__ticket[dec_flag][5]=ticket_tmp[26]; 
	__CPROVER_assume( (__ticket[dec_flag][5] < MEM_SIZE)
	               && (__ticket[dec_flag][5]>__ticket[dec_flag][4])
	               && (!__used_ticket[__ticket[dec_flag][5]]) );
	__used_ticket[__ticket[dec_flag][5]] = 1;

	__thread_id[dec_flag][6] = thread_tmp[27];
	__visible[dec_flag][6] = visible_tmp[27];
	__CPROVER_assume((__thread_id[dec_flag][6] >= 0) && (__thread_id[dec_flag][6] < GuessedNumThreads));
	__value[dec_flag][6] = __value_tmp[27];
	__ticket[dec_flag][6]=ticket_tmp[27]; 
	__CPROVER_assume( (__ticket[dec_flag][6] < MEM_SIZE)
	               && (__ticket[dec_flag][6]>__ticket[dec_flag][5])
	               && (!__used_ticket[__ticket[dec_flag][6]]) );
	__used_ticket[__ticket[dec_flag][6]] = 1;

	__thread_id[dec_flag][7] = thread_tmp[28];
	__visible[dec_flag][7] = visible_tmp[28];
	__CPROVER_assume((__thread_id[dec_flag][7] >= 0) && (__thread_id[dec_flag][7] < GuessedNumThreads));
	__value[dec_flag][7] = __value_tmp[28];
	__ticket[dec_flag][7]=ticket_tmp[28]; 
	__CPROVER_assume( (__ticket[dec_flag][7] < MEM_SIZE)
	               && (__ticket[dec_flag][7]>__ticket[dec_flag][6])
	               && (!__used_ticket[__ticket[dec_flag][7]]) );
	__used_ticket[__ticket[dec_flag][7]] = 1;

	__thread_id[dec_flag][8] = thread_tmp[29];
	__visible[dec_flag][8] = visible_tmp[29];
	__CPROVER_assume((__thread_id[dec_flag][8] >= 0) && (__thread_id[dec_flag][8] < GuessedNumThreads));
	__value[dec_flag][8] = __value_tmp[29];
	__ticket[dec_flag][8]=ticket_tmp[29]; 
	__CPROVER_assume( (__ticket[dec_flag][8] < MEM_SIZE)
	               && (__ticket[dec_flag][8]>__ticket[dec_flag][7])
	               && (!__used_ticket[__ticket[dec_flag][8]]) );
	__used_ticket[__ticket[dec_flag][8]] = 1;

	__thread_id[dec_flag][9] = thread_tmp[30];
	__visible[dec_flag][9] = visible_tmp[30];
	__CPROVER_assume((__thread_id[dec_flag][9] >= 0) && (__thread_id[dec_flag][9] < GuessedNumThreads));
	__value[dec_flag][9] = __value_tmp[30];
	__ticket[dec_flag][9]=ticket_tmp[30]; 
	__CPROVER_assume( (__ticket[dec_flag][9] < MEM_SIZE)
	               && (__ticket[dec_flag][9]>__ticket[dec_flag][8])
	               && (!__used_ticket[__ticket[dec_flag][9]]) );
	__used_ticket[__ticket[dec_flag][9]] = 1;

	__thread_id[dec_flag][10] = thread_tmp[31];
	__visible[dec_flag][10] = visible_tmp[31];
	__CPROVER_assume((__thread_id[dec_flag][10] >= 0) && (__thread_id[dec_flag][10] < GuessedNumThreads));
	__value[dec_flag][10] = __value_tmp[31];
	__ticket[dec_flag][10]=ticket_tmp[31]; 
	__CPROVER_assume( (__ticket[dec_flag][10] < MEM_SIZE)
	               && (__ticket[dec_flag][10]>__ticket[dec_flag][9])
	               && (!__used_ticket[__ticket[dec_flag][10]]) );
	__used_ticket[__ticket[dec_flag][10]] = 1;

	__thread_id[dec_flag][11] = thread_tmp[32];
	__visible[dec_flag][11] = visible_tmp[32];
	__CPROVER_assume((__thread_id[dec_flag][11] >= 0) && (__thread_id[dec_flag][11] < GuessedNumThreads));
	__value[dec_flag][11] = __value_tmp[32];
	__ticket[dec_flag][11]=ticket_tmp[32]; 
	__CPROVER_assume( (__ticket[dec_flag][11] < MEM_SIZE)
	               && (__ticket[dec_flag][11]>__ticket[dec_flag][10])
	               && (!__used_ticket[__ticket[dec_flag][11]]) );
	__used_ticket[__ticket[dec_flag][11]] = 1;

	//__ticket[dec_flag][MEM_SIZE_VARS]=ticket_tmp[33]; 
	__ticket[dec_flag][dec_flag_SIZE]=MEM_SIZE; 
//	__ticket[dec_flag][0] = 0;

	//for atomic locks
	__ticket_atomic[0] = 0;
	__thread_id_atomic[1] = thread_tmp[33];
	__CPROVER_assume((__thread_id_atomic[1] >= 0) && (__thread_id_atomic[1] < GuessedNumThreads));
	__ticket_atomic[1]=ticket_tmp[33]; 
	__CPROVER_assume( (__ticket_atomic[1] < MEM_SIZE)
	               && (__ticket_atomic[1]>__ticket_atomic[0])
	               && (!__used_ticket[__ticket_atomic[1]]) );
	__used_ticket[__ticket_atomic[1]] = 1;

	__thread_id_atomic[2] = __thread_id_atomic[1];
	__ticket_atomic[2]=ticket_tmp[34]; 
	__CPROVER_assume( (__ticket_atomic[2] < MEM_SIZE)
	               && (__ticket_atomic[2]>__ticket_atomic[1])
	               && (!__used_ticket[__ticket_atomic[2]]) );
	__used_ticket[__ticket_atomic[2]] = 1;

	__thread_id_atomic[3] = thread_tmp[35];
	__CPROVER_assume((__thread_id_atomic[3] >= 0) && (__thread_id_atomic[3] < GuessedNumThreads));
	__ticket_atomic[3]=ticket_tmp[35]; 
	__CPROVER_assume( (__ticket_atomic[3] < MEM_SIZE)
	               && (__ticket_atomic[3]>__ticket_atomic[2])
	               && (!__used_ticket[__ticket_atomic[3]]) );
	__used_ticket[__ticket_atomic[3]] = 1;

	__thread_id_atomic[4] = __thread_id_atomic[3];
	__ticket_atomic[4]=ticket_tmp[36]; 
	__CPROVER_assume( (__ticket_atomic[4] < MEM_SIZE)
	               && (__ticket_atomic[4]>__ticket_atomic[3])
	               && (!__used_ticket[__ticket_atomic[4]]) );
	__used_ticket[__ticket_atomic[4]] = 1;

	__thread_id_atomic[5] = thread_tmp[37];
	__CPROVER_assume((__thread_id_atomic[5] >= 0) && (__thread_id_atomic[5] < GuessedNumThreads));
	__ticket_atomic[5]=ticket_tmp[37]; 
	__CPROVER_assume( (__ticket_atomic[5] < MEM_SIZE)
	               && (__ticket_atomic[5]>__ticket_atomic[4])
	               && (!__used_ticket[__ticket_atomic[5]]) );
	__used_ticket[__ticket_atomic[5]] = 1;

	__thread_id_atomic[6] = __thread_id_atomic[5];
	__ticket_atomic[6]=ticket_tmp[38]; 
	__CPROVER_assume( (__ticket_atomic[6] < MEM_SIZE)
	               && (__ticket_atomic[6]>__ticket_atomic[5])
	               && (!__used_ticket[__ticket_atomic[6]]) );
	__used_ticket[__ticket_atomic[6]] = 1;

	__thread_id_atomic[7] = thread_tmp[39];
	__CPROVER_assume((__thread_id_atomic[7] >= 0) && (__thread_id_atomic[7] < GuessedNumThreads));
	__ticket_atomic[7]=ticket_tmp[39]; 
	__CPROVER_assume( (__ticket_atomic[7] < MEM_SIZE)
	               && (__ticket_atomic[7]>__ticket_atomic[6])
	               && (!__used_ticket[__ticket_atomic[7]]) );
	__used_ticket[__ticket_atomic[7]] = 1;

	__thread_id_atomic[8] = __thread_id_atomic[7];
	__ticket_atomic[8]=ticket_tmp[40]; 
	__CPROVER_assume( (__ticket_atomic[8] < MEM_SIZE)
	               && (__ticket_atomic[8]>__ticket_atomic[7])
	               && (!__used_ticket[__ticket_atomic[8]]) );
	__used_ticket[__ticket_atomic[8]] = 1;

	__thread_id_atomic[9] = thread_tmp[41];
	__CPROVER_assume((__thread_id_atomic[9] >= 0) && (__thread_id_atomic[9] < GuessedNumThreads));
	__ticket_atomic[9]=ticket_tmp[41]; 
	__CPROVER_assume( (__ticket_atomic[9] < MEM_SIZE)
	               && (__ticket_atomic[9]>__ticket_atomic[8])
	               && (!__used_ticket[__ticket_atomic[9]]) );
	__used_ticket[__ticket_atomic[9]] = 1;

	__thread_id_atomic[10] = __thread_id_atomic[9];
	__ticket_atomic[10]=ticket_tmp[42]; 
	__CPROVER_assume( (__ticket_atomic[10] < MEM_SIZE)
	               && (__ticket_atomic[10]>__ticket_atomic[9])
	               && (!__used_ticket[__ticket_atomic[10]]) );
	__used_ticket[__ticket_atomic[10]] = 1;

	__ticket_atomic[LOCK_SIZE]=MEM_SIZE; 
	int ticket_index=43; 
	/*for each scalar variable, for each thread:
	at each position we calculate
	what is the next write of that thread of that varable.
	*/
	//for variable value
     __thw[value][0][11]=MEM_SIZE;
     __thw[value][1][11]=MEM_SIZE;
     __thw[value][2][11]=MEM_SIZE;
    __thw[value][0][10] =    (__thread_id[value][11] == 0) ? 11 : __thw[value][0][11] ; 
    __thw[value][1][10] =    (__thread_id[value][11] == 1) ? 11 : __thw[value][1][11] ; 
    __thw[value][2][10] =    (__thread_id[value][11] == 2) ? 11 : __thw[value][2][11] ; 
 
    __thw[value][0][9] =    (__thread_id[value][10] == 0) ? 10 : __thw[value][0][10] ; 
    __thw[value][1][9] =    (__thread_id[value][10] == 1) ? 10 : __thw[value][1][10] ; 
    __thw[value][2][9] =    (__thread_id[value][10] == 2) ? 10 : __thw[value][2][10] ; 
 
    __thw[value][0][8] =    (__thread_id[value][9] == 0) ? 9 : __thw[value][0][9] ; 
    __thw[value][1][8] =    (__thread_id[value][9] == 1) ? 9 : __thw[value][1][9] ; 
    __thw[value][2][8] =    (__thread_id[value][9] == 2) ? 9 : __thw[value][2][9] ; 
 
    __thw[value][0][7] =    (__thread_id[value][8] == 0) ? 8 : __thw[value][0][8] ; 
    __thw[value][1][7] =    (__thread_id[value][8] == 1) ? 8 : __thw[value][1][8] ; 
    __thw[value][2][7] =    (__thread_id[value][8] == 2) ? 8 : __thw[value][2][8] ; 
 
    __thw[value][0][6] =    (__thread_id[value][7] == 0) ? 7 : __thw[value][0][7] ; 
    __thw[value][1][6] =    (__thread_id[value][7] == 1) ? 7 : __thw[value][1][7] ; 
    __thw[value][2][6] =    (__thread_id[value][7] == 2) ? 7 : __thw[value][2][7] ; 
 
    __thw[value][0][5] =    (__thread_id[value][6] == 0) ? 6 : __thw[value][0][6] ; 
    __thw[value][1][5] =    (__thread_id[value][6] == 1) ? 6 : __thw[value][1][6] ; 
    __thw[value][2][5] =    (__thread_id[value][6] == 2) ? 6 : __thw[value][2][6] ; 
 
    __thw[value][0][4] =    (__thread_id[value][5] == 0) ? 5 : __thw[value][0][5] ; 
    __thw[value][1][4] =    (__thread_id[value][5] == 1) ? 5 : __thw[value][1][5] ; 
    __thw[value][2][4] =    (__thread_id[value][5] == 2) ? 5 : __thw[value][2][5] ; 
 
    __thw[value][0][3] =    (__thread_id[value][4] == 0) ? 4 : __thw[value][0][4] ; 
    __thw[value][1][3] =    (__thread_id[value][4] == 1) ? 4 : __thw[value][1][4] ; 
    __thw[value][2][3] =    (__thread_id[value][4] == 2) ? 4 : __thw[value][2][4] ; 
 
    __thw[value][0][2] =    (__thread_id[value][3] == 0) ? 3 : __thw[value][0][3] ; 
    __thw[value][1][2] =    (__thread_id[value][3] == 1) ? 3 : __thw[value][1][3] ; 
    __thw[value][2][2] =    (__thread_id[value][3] == 2) ? 3 : __thw[value][2][3] ; 
 
    __thw[value][0][1] =    (__thread_id[value][2] == 0) ? 2 : __thw[value][0][2] ; 
    __thw[value][1][1] =    (__thread_id[value][2] == 1) ? 2 : __thw[value][1][2] ; 
    __thw[value][2][1] =    (__thread_id[value][2] == 2) ? 2 : __thw[value][2][2] ; 
 
    __thw[value][0][0] =    (__thread_id[value][1] == 0) ? 1 : __thw[value][0][1] ; 
    __thw[value][1][0] =    (__thread_id[value][1] == 1) ? 1 : __thw[value][1][1] ; 
    __thw[value][2][0] =    (__thread_id[value][1] == 2) ? 1 : __thw[value][2][1] ; 
 
	//for variable inc_flag
     __thw[inc_flag][0][11]=MEM_SIZE;
     __thw[inc_flag][1][11]=MEM_SIZE;
     __thw[inc_flag][2][11]=MEM_SIZE;
    __thw[inc_flag][0][10] =    (__thread_id[inc_flag][11] == 0) ? 11 : __thw[inc_flag][0][11] ; 
    __thw[inc_flag][1][10] =    (__thread_id[inc_flag][11] == 1) ? 11 : __thw[inc_flag][1][11] ; 
    __thw[inc_flag][2][10] =    (__thread_id[inc_flag][11] == 2) ? 11 : __thw[inc_flag][2][11] ; 
 
    __thw[inc_flag][0][9] =    (__thread_id[inc_flag][10] == 0) ? 10 : __thw[inc_flag][0][10] ; 
    __thw[inc_flag][1][9] =    (__thread_id[inc_flag][10] == 1) ? 10 : __thw[inc_flag][1][10] ; 
    __thw[inc_flag][2][9] =    (__thread_id[inc_flag][10] == 2) ? 10 : __thw[inc_flag][2][10] ; 
 
    __thw[inc_flag][0][8] =    (__thread_id[inc_flag][9] == 0) ? 9 : __thw[inc_flag][0][9] ; 
    __thw[inc_flag][1][8] =    (__thread_id[inc_flag][9] == 1) ? 9 : __thw[inc_flag][1][9] ; 
    __thw[inc_flag][2][8] =    (__thread_id[inc_flag][9] == 2) ? 9 : __thw[inc_flag][2][9] ; 
 
    __thw[inc_flag][0][7] =    (__thread_id[inc_flag][8] == 0) ? 8 : __thw[inc_flag][0][8] ; 
    __thw[inc_flag][1][7] =    (__thread_id[inc_flag][8] == 1) ? 8 : __thw[inc_flag][1][8] ; 
    __thw[inc_flag][2][7] =    (__thread_id[inc_flag][8] == 2) ? 8 : __thw[inc_flag][2][8] ; 
 
    __thw[inc_flag][0][6] =    (__thread_id[inc_flag][7] == 0) ? 7 : __thw[inc_flag][0][7] ; 
    __thw[inc_flag][1][6] =    (__thread_id[inc_flag][7] == 1) ? 7 : __thw[inc_flag][1][7] ; 
    __thw[inc_flag][2][6] =    (__thread_id[inc_flag][7] == 2) ? 7 : __thw[inc_flag][2][7] ; 
 
    __thw[inc_flag][0][5] =    (__thread_id[inc_flag][6] == 0) ? 6 : __thw[inc_flag][0][6] ; 
    __thw[inc_flag][1][5] =    (__thread_id[inc_flag][6] == 1) ? 6 : __thw[inc_flag][1][6] ; 
    __thw[inc_flag][2][5] =    (__thread_id[inc_flag][6] == 2) ? 6 : __thw[inc_flag][2][6] ; 
 
    __thw[inc_flag][0][4] =    (__thread_id[inc_flag][5] == 0) ? 5 : __thw[inc_flag][0][5] ; 
    __thw[inc_flag][1][4] =    (__thread_id[inc_flag][5] == 1) ? 5 : __thw[inc_flag][1][5] ; 
    __thw[inc_flag][2][4] =    (__thread_id[inc_flag][5] == 2) ? 5 : __thw[inc_flag][2][5] ; 
 
    __thw[inc_flag][0][3] =    (__thread_id[inc_flag][4] == 0) ? 4 : __thw[inc_flag][0][4] ; 
    __thw[inc_flag][1][3] =    (__thread_id[inc_flag][4] == 1) ? 4 : __thw[inc_flag][1][4] ; 
    __thw[inc_flag][2][3] =    (__thread_id[inc_flag][4] == 2) ? 4 : __thw[inc_flag][2][4] ; 
 
    __thw[inc_flag][0][2] =    (__thread_id[inc_flag][3] == 0) ? 3 : __thw[inc_flag][0][3] ; 
    __thw[inc_flag][1][2] =    (__thread_id[inc_flag][3] == 1) ? 3 : __thw[inc_flag][1][3] ; 
    __thw[inc_flag][2][2] =    (__thread_id[inc_flag][3] == 2) ? 3 : __thw[inc_flag][2][3] ; 
 
    __thw[inc_flag][0][1] =    (__thread_id[inc_flag][2] == 0) ? 2 : __thw[inc_flag][0][2] ; 
    __thw[inc_flag][1][1] =    (__thread_id[inc_flag][2] == 1) ? 2 : __thw[inc_flag][1][2] ; 
    __thw[inc_flag][2][1] =    (__thread_id[inc_flag][2] == 2) ? 2 : __thw[inc_flag][2][2] ; 
 
    __thw[inc_flag][0][0] =    (__thread_id[inc_flag][1] == 0) ? 1 : __thw[inc_flag][0][1] ; 
    __thw[inc_flag][1][0] =    (__thread_id[inc_flag][1] == 1) ? 1 : __thw[inc_flag][1][1] ; 
    __thw[inc_flag][2][0] =    (__thread_id[inc_flag][1] == 2) ? 1 : __thw[inc_flag][2][1] ; 
 
	//for variable dec_flag
     __thw[dec_flag][0][11]=MEM_SIZE;
     __thw[dec_flag][1][11]=MEM_SIZE;
     __thw[dec_flag][2][11]=MEM_SIZE;
    __thw[dec_flag][0][10] =    (__thread_id[dec_flag][11] == 0) ? 11 : __thw[dec_flag][0][11] ; 
    __thw[dec_flag][1][10] =    (__thread_id[dec_flag][11] == 1) ? 11 : __thw[dec_flag][1][11] ; 
    __thw[dec_flag][2][10] =    (__thread_id[dec_flag][11] == 2) ? 11 : __thw[dec_flag][2][11] ; 
 
    __thw[dec_flag][0][9] =    (__thread_id[dec_flag][10] == 0) ? 10 : __thw[dec_flag][0][10] ; 
    __thw[dec_flag][1][9] =    (__thread_id[dec_flag][10] == 1) ? 10 : __thw[dec_flag][1][10] ; 
    __thw[dec_flag][2][9] =    (__thread_id[dec_flag][10] == 2) ? 10 : __thw[dec_flag][2][10] ; 
 
    __thw[dec_flag][0][8] =    (__thread_id[dec_flag][9] == 0) ? 9 : __thw[dec_flag][0][9] ; 
    __thw[dec_flag][1][8] =    (__thread_id[dec_flag][9] == 1) ? 9 : __thw[dec_flag][1][9] ; 
    __thw[dec_flag][2][8] =    (__thread_id[dec_flag][9] == 2) ? 9 : __thw[dec_flag][2][9] ; 
 
    __thw[dec_flag][0][7] =    (__thread_id[dec_flag][8] == 0) ? 8 : __thw[dec_flag][0][8] ; 
    __thw[dec_flag][1][7] =    (__thread_id[dec_flag][8] == 1) ? 8 : __thw[dec_flag][1][8] ; 
    __thw[dec_flag][2][7] =    (__thread_id[dec_flag][8] == 2) ? 8 : __thw[dec_flag][2][8] ; 
 
    __thw[dec_flag][0][6] =    (__thread_id[dec_flag][7] == 0) ? 7 : __thw[dec_flag][0][7] ; 
    __thw[dec_flag][1][6] =    (__thread_id[dec_flag][7] == 1) ? 7 : __thw[dec_flag][1][7] ; 
    __thw[dec_flag][2][6] =    (__thread_id[dec_flag][7] == 2) ? 7 : __thw[dec_flag][2][7] ; 
 
    __thw[dec_flag][0][5] =    (__thread_id[dec_flag][6] == 0) ? 6 : __thw[dec_flag][0][6] ; 
    __thw[dec_flag][1][5] =    (__thread_id[dec_flag][6] == 1) ? 6 : __thw[dec_flag][1][6] ; 
    __thw[dec_flag][2][5] =    (__thread_id[dec_flag][6] == 2) ? 6 : __thw[dec_flag][2][6] ; 
 
    __thw[dec_flag][0][4] =    (__thread_id[dec_flag][5] == 0) ? 5 : __thw[dec_flag][0][5] ; 
    __thw[dec_flag][1][4] =    (__thread_id[dec_flag][5] == 1) ? 5 : __thw[dec_flag][1][5] ; 
    __thw[dec_flag][2][4] =    (__thread_id[dec_flag][5] == 2) ? 5 : __thw[dec_flag][2][5] ; 
 
    __thw[dec_flag][0][3] =    (__thread_id[dec_flag][4] == 0) ? 4 : __thw[dec_flag][0][4] ; 
    __thw[dec_flag][1][3] =    (__thread_id[dec_flag][4] == 1) ? 4 : __thw[dec_flag][1][4] ; 
    __thw[dec_flag][2][3] =    (__thread_id[dec_flag][4] == 2) ? 4 : __thw[dec_flag][2][4] ; 
 
    __thw[dec_flag][0][2] =    (__thread_id[dec_flag][3] == 0) ? 3 : __thw[dec_flag][0][3] ; 
    __thw[dec_flag][1][2] =    (__thread_id[dec_flag][3] == 1) ? 3 : __thw[dec_flag][1][3] ; 
    __thw[dec_flag][2][2] =    (__thread_id[dec_flag][3] == 2) ? 3 : __thw[dec_flag][2][3] ; 
 
    __thw[dec_flag][0][1] =    (__thread_id[dec_flag][2] == 0) ? 2 : __thw[dec_flag][0][2] ; 
    __thw[dec_flag][1][1] =    (__thread_id[dec_flag][2] == 1) ? 2 : __thw[dec_flag][1][2] ; 
    __thw[dec_flag][2][1] =    (__thread_id[dec_flag][2] == 2) ? 2 : __thw[dec_flag][2][2] ; 
 
    __thw[dec_flag][0][0] =    (__thread_id[dec_flag][1] == 0) ? 1 : __thw[dec_flag][0][1] ; 
    __thw[dec_flag][1][0] =    (__thread_id[dec_flag][1] == 1) ? 1 : __thw[dec_flag][1][1] ; 
    __thw[dec_flag][2][0] =    (__thread_id[dec_flag][1] == 2) ? 1 : __thw[dec_flag][2][1] ; 
 
	//for atomic locks
     __thw_atomic[0][10]=11;
     __thw_atomic[1][10]=11;
     __thw_atomic[2][10]=11;
    __thw_atomic[0][9] =    (__thread_id_atomic[10] == 0) ? 10 : __thw_atomic[0][10] ; 
    __thw_atomic[1][9] =    (__thread_id_atomic[10] == 1) ? 10 : __thw_atomic[1][10] ; 
    __thw_atomic[2][9] =    (__thread_id_atomic[10] == 2) ? 10 : __thw_atomic[2][10] ; 
 
    __thw_atomic[0][8] =    (__thread_id_atomic[9] == 0) ? 9 : __thw_atomic[0][9] ; 
    __thw_atomic[1][8] =    (__thread_id_atomic[9] == 1) ? 9 : __thw_atomic[1][9] ; 
    __thw_atomic[2][8] =    (__thread_id_atomic[9] == 2) ? 9 : __thw_atomic[2][9] ; 
 
    __thw_atomic[0][7] =    (__thread_id_atomic[8] == 0) ? 8 : __thw_atomic[0][8] ; 
    __thw_atomic[1][7] =    (__thread_id_atomic[8] == 1) ? 8 : __thw_atomic[1][8] ; 
    __thw_atomic[2][7] =    (__thread_id_atomic[8] == 2) ? 8 : __thw_atomic[2][8] ; 
 
    __thw_atomic[0][6] =    (__thread_id_atomic[7] == 0) ? 7 : __thw_atomic[0][7] ; 
    __thw_atomic[1][6] =    (__thread_id_atomic[7] == 1) ? 7 : __thw_atomic[1][7] ; 
    __thw_atomic[2][6] =    (__thread_id_atomic[7] == 2) ? 7 : __thw_atomic[2][7] ; 
 
    __thw_atomic[0][5] =    (__thread_id_atomic[6] == 0) ? 6 : __thw_atomic[0][6] ; 
    __thw_atomic[1][5] =    (__thread_id_atomic[6] == 1) ? 6 : __thw_atomic[1][6] ; 
    __thw_atomic[2][5] =    (__thread_id_atomic[6] == 2) ? 6 : __thw_atomic[2][6] ; 
 
    __thw_atomic[0][4] =    (__thread_id_atomic[5] == 0) ? 5 : __thw_atomic[0][5] ; 
    __thw_atomic[1][4] =    (__thread_id_atomic[5] == 1) ? 5 : __thw_atomic[1][5] ; 
    __thw_atomic[2][4] =    (__thread_id_atomic[5] == 2) ? 5 : __thw_atomic[2][5] ; 
 
    __thw_atomic[0][3] =    (__thread_id_atomic[4] == 0) ? 4 : __thw_atomic[0][4] ; 
    __thw_atomic[1][3] =    (__thread_id_atomic[4] == 1) ? 4 : __thw_atomic[1][4] ; 
    __thw_atomic[2][3] =    (__thread_id_atomic[4] == 2) ? 4 : __thw_atomic[2][4] ; 
 
    __thw_atomic[0][2] =    (__thread_id_atomic[3] == 0) ? 3 : __thw_atomic[0][3] ; 
    __thw_atomic[1][2] =    (__thread_id_atomic[3] == 1) ? 3 : __thw_atomic[1][3] ; 
    __thw_atomic[2][2] =    (__thread_id_atomic[3] == 2) ? 3 : __thw_atomic[2][3] ; 
 
    __thw_atomic[0][1] =    (__thread_id_atomic[2] == 0) ? 2 : __thw_atomic[0][2] ; 
    __thw_atomic[1][1] =    (__thread_id_atomic[2] == 1) ? 2 : __thw_atomic[1][2] ; 
    __thw_atomic[2][1] =    (__thread_id_atomic[2] == 2) ? 2 : __thw_atomic[2][2] ; 
 
    __thw_atomic[0][0] =    (__thread_id_atomic[1] == 0) ? 1 : __thw_atomic[0][1] ; 
    __thw_atomic[1][0] =    (__thread_id_atomic[1] == 1) ? 1 : __thw_atomic[1][1] ; 
    __thw_atomic[2][0] =    (__thread_id_atomic[1] == 2) ? 1 : __thw_atomic[2][1] ; 
 


}
int main(int argc, char **argv)
{
GuessedNumThreads=nondet_int();
__CPROVER_assume(GuessedNumThreads<=MaxNumThreads);
guessMU();
//ticket_pos=NumVars-1;
//cseq: simulation of the threads main
main_thread(argc, argv);
  //__CPROVER_assume((thw[__cs_thread_index][thread_pos] >=memory_notvalid) );
  
__CPROVER_assume(__thw[value][__cs_thread_index][__last_used_pos_of[value]] >=__memory_notvalid_of[value]) ;
__CPROVER_assume(__thw[inc_flag][__cs_thread_index][__last_used_pos_of[inc_flag]] >=__memory_notvalid_of[inc_flag]) ;
__CPROVER_assume(__thw[dec_flag][__cs_thread_index][__last_used_pos_of[dec_flag]] >=__memory_notvalid_of[dec_flag]) ;
__CPROVER_assume(__thw_atomic[__cs_thread_index][__last_used_pos_of_atomic] >=__memory_notvalid_of_atomic) ;
  __CPROVER_assume(GuessedNumThreads==n_treads_createad);
//cseq: Error check
assert(__CS_error != 1);
}


//atomico: 1


//self.arrayWriteVars[value]: 0
//self.arrayWriteVars[inc_flag]: 0
//self.arrayWriteVars[dec_flag]: 0
//num_writes_variabile: 0
//max: 0

//operator *::__cs_param___CSEQ_atomic_CAS_v---

//operator *::__cs_param___CSEQ_atomic_CAS_v---r
//assignment: __cs_local___CSEQ_atomic_CAS___cs_tmp_if_cond_0=(*__cs_param___CSEQ_atomic_CAS_v) == __cs_param___CSEQ_atomic_CAS_e;

//operator *::__cs_param___CSEQ_atomic_CAS_flag---l
//assignment: *__cs_param___CSEQ_atomic_CAS_flag=1;

//operator *::__cs_param___CSEQ_atomic_CAS_flag---l

//operator *::__cs_param___CSEQ_atomic_CAS_flag---l

//operator *::__cs_param___CSEQ_atomic_CAS_v---l
//assignment: *__cs_param___CSEQ_atomic_CAS_v=__cs_param___CSEQ_atomic_CAS_u;

//operator *::__cs_param___CSEQ_atomic_CAS_v---l

//operator *::__cs_param___CSEQ_atomic_CAS_v---l

//operator *::__cs_param___CSEQ_atomic_CAS_r---l
//assignment: *__cs_param___CSEQ_atomic_CAS_r=1;

//operator *::__cs_param___CSEQ_atomic_CAS_r---l

//operator *::__cs_param___CSEQ_atomic_CAS_r---l

//operator *::__cs_param___CSEQ_atomic_CAS_r---l
//assignment: *__cs_param___CSEQ_atomic_CAS_r=0;

//operator *::__cs_param___CSEQ_atomic_CAS_r---l

//operator *::__cs_param___CSEQ_atomic_CAS_r---l
//assignment: __cs_local___CSEQ_atomic_assert1___cs_tmp_if_cond_1=!(dec_flag || (value > __cs_param___CSEQ_atomic_assert1_inc__v));
//assignment: __cs_local___CSEQ_atomic_assert2___cs_tmp_if_cond_4=!(inc_flag || (value < __cs_param___CSEQ_atomic_assert2_dec__v));
//assignment: __cs_local_thr1_r=___XXXXX__nondet_int();
//assignment: __cs_local_thr1___cs_tmp_if_cond_7=__cs_local_thr1_r;
//assignment: __cs_local_inc___cs_dowhile_onetime_1=0;
//assignment: __cs_local_inc_inc__v=value;
//assignment: __cs_local_inc___cs_tmp_if_cond_2=__cs_local_inc_inc__v == (0u - 1);
//assignment: __cs_retval__inc_1=0;
//assignment: __cs_local_inc_inc__vn=__cs_local_inc_inc__v + 1;

//operator &::value---l

//operator &::__cs_local_inc_inc__casret---l

//operator &::inc_flag---l
//__CSEQ_atomic_CAS_cs_struct_value_cs_struct_inc_flag(&<param-global-null>
// __cs_local_inc_inc__v
// __cs_local_inc_inc__vn
// &__cs_local_inc_inc__casret
// &<param-global-null>)

//operator *::__cs_param___CSEQ_atomic_CAS_v---l

//operator *::__cs_param___CSEQ_atomic_CAS_v---r
//assignment: __cs_local___CSEQ_atomic_CAS___cs_tmp_if_cond_0=(*__cs_param___CSEQ_atomic_CAS_v) == __cs_param___CSEQ_atomic_CAS_e;

//operator *::__cs_param___CSEQ_atomic_CAS_flag---l
//assignment: *__cs_param___CSEQ_atomic_CAS_flag=1;

//operator *::__cs_param___CSEQ_atomic_CAS_flag---l

//operator *::__cs_param___CSEQ_atomic_CAS_flag---l

//operator *::__cs_param___CSEQ_atomic_CAS_v---l
//assignment: *__cs_param___CSEQ_atomic_CAS_v=__cs_param___CSEQ_atomic_CAS_u;

//operator *::__cs_param___CSEQ_atomic_CAS_v---l

//operator *::__cs_param___CSEQ_atomic_CAS_v---l

//operator *::__cs_param___CSEQ_atomic_CAS_r---l
//assignment: *__cs_param___CSEQ_atomic_CAS_r=1;

//operator *::__cs_param___CSEQ_atomic_CAS_r---l

//operator *::__cs_param___CSEQ_atomic_CAS_r---l

//operator *::__cs_param___CSEQ_atomic_CAS_r---l
//assignment: *__cs_param___CSEQ_atomic_CAS_r=0;

//operator *::__cs_param___CSEQ_atomic_CAS_r---l

//operator *::__cs_param___CSEQ_atomic_CAS_r---l
//assignment: __cs_local_inc_inc__v=value;
//assignment: __cs_local_inc___cs_tmp_if_cond_3=__cs_local_inc_inc__v == (0u - 1);
//assignment: __cs_retval__inc_1=0;
//assignment: __cs_local_inc_inc__vn=__cs_local_inc_inc__v + 1;

//operator &::value---l

//operator &::__cs_local_inc_inc__casret---l

//operator &::inc_flag---l
//assignment: __cs_local_inc_inc__v=value;
//assignment: __cs_local_inc___cs_tmp_if_cond_3=__cs_local_inc_inc__v == (0u - 1);
//assignment: __cs_retval__inc_1=0;
//assignment: __cs_local_inc_inc__vn=__cs_local_inc_inc__v + 1;

//operator &::value---l

//operator &::__cs_local_inc_inc__casret---l

//operator &::inc_flag---l
//assignment: __cs_retval__inc_1=__cs_local_inc_inc__vn;
//assignment: __cs_local_dec___cs_dowhile_onetime_2=0;
//assignment: __cs_local_dec_dec__v=value;
//assignment: __cs_local_dec___cs_tmp_if_cond_5=__cs_local_dec_dec__v == 0;
//assignment: __cs_retval__dec_1=0u - 1;
//assignment: __cs_local_dec_dec__vn=__cs_local_dec_dec__v - 1;

//operator &::value---l

//operator &::__cs_local_dec_dec__casret---l

//operator &::dec_flag---l
//__CSEQ_atomic_CAS_cs_struct_value_cs_struct_dec_flag(&<param-global-null>
// __cs_local_dec_dec__v
// __cs_local_dec_dec__vn
// &__cs_local_dec_dec__casret
// &<param-global-null>)

//operator *::__cs_param___CSEQ_atomic_CAS_v---l

//operator *::__cs_param___CSEQ_atomic_CAS_v---r
//assignment: __cs_local___CSEQ_atomic_CAS___cs_tmp_if_cond_0=(*__cs_param___CSEQ_atomic_CAS_v) == __cs_param___CSEQ_atomic_CAS_e;

//operator *::__cs_param___CSEQ_atomic_CAS_flag---l
//assignment: *__cs_param___CSEQ_atomic_CAS_flag=1;

//operator *::__cs_param___CSEQ_atomic_CAS_flag---l

//operator *::__cs_param___CSEQ_atomic_CAS_flag---l

//operator *::__cs_param___CSEQ_atomic_CAS_v---l
//assignment: *__cs_param___CSEQ_atomic_CAS_v=__cs_param___CSEQ_atomic_CAS_u;

//operator *::__cs_param___CSEQ_atomic_CAS_v---l

//operator *::__cs_param___CSEQ_atomic_CAS_v---l

//operator *::__cs_param___CSEQ_atomic_CAS_r---l
//assignment: *__cs_param___CSEQ_atomic_CAS_r=1;

//operator *::__cs_param___CSEQ_atomic_CAS_r---l

//operator *::__cs_param___CSEQ_atomic_CAS_r---l

//operator *::__cs_param___CSEQ_atomic_CAS_r---l
//assignment: *__cs_param___CSEQ_atomic_CAS_r=0;

//operator *::__cs_param___CSEQ_atomic_CAS_r---l

//operator *::__cs_param___CSEQ_atomic_CAS_r---l
//assignment: __cs_local_dec_dec__v=value;
//assignment: __cs_local_dec___cs_tmp_if_cond_6=__cs_local_dec_dec__v == 0;
//assignment: __cs_retval__dec_1=0u - 1;
//assignment: __cs_local_dec_dec__vn=__cs_local_dec_dec__v - 1;

//operator &::value---l

//operator &::__cs_local_dec_dec__casret---l

//operator &::dec_flag---l
//assignment: __cs_local_dec_dec__v=value;
//assignment: __cs_local_dec___cs_tmp_if_cond_6=__cs_local_dec_dec__v == 0;
//assignment: __cs_retval__dec_1=0u - 1;
//assignment: __cs_local_dec_dec__vn=__cs_local_dec_dec__v - 1;

//operator &::value---l

//operator &::__cs_local_dec_dec__casret---l

//operator &::dec_flag---l
//assignment: __cs_retval__dec_1=__cs_local_dec_dec__vn;
//assignment: __cs_local_thr1_r=___XXXXX__nondet_int();
//assignment: __cs_local_thr1___cs_tmp_if_cond_7=__cs_local_thr1_r;
//assignment: __cs_local_inc___cs_dowhile_onetime_1=0;
//assignment: __cs_local_inc_inc__v=value;
//assignment: __cs_local_inc___cs_tmp_if_cond_2=__cs_local_inc_inc__v == (0u - 1);
//assignment: __cs_retval__inc_1=0;
//assignment: __cs_local_inc_inc__vn=__cs_local_inc_inc__v + 1;

//operator &::value---l

//operator &::__cs_local_inc_inc__casret---l

//operator &::inc_flag---l
//assignment: __cs_local_inc_inc__v=value;
//assignment: __cs_local_inc___cs_tmp_if_cond_3=__cs_local_inc_inc__v == (0u - 1);
//assignment: __cs_retval__inc_1=0;
//assignment: __cs_local_inc_inc__vn=__cs_local_inc_inc__v + 1;

//operator &::value---l

//operator &::__cs_local_inc_inc__casret---l

//operator &::inc_flag---l
//assignment: __cs_local_inc_inc__v=value;
//assignment: __cs_local_inc___cs_tmp_if_cond_3=__cs_local_inc_inc__v == (0u - 1);
//assignment: __cs_retval__inc_1=0;
//assignment: __cs_local_inc_inc__vn=__cs_local_inc_inc__v + 1;

//operator &::value---l

//operator &::__cs_local_inc_inc__casret---l

//operator &::inc_flag---l
//assignment: __cs_retval__inc_1=__cs_local_inc_inc__vn;
//assignment: __cs_local_dec___cs_dowhile_onetime_2=0;
//assignment: __cs_local_dec_dec__v=value;
//assignment: __cs_local_dec___cs_tmp_if_cond_5=__cs_local_dec_dec__v == 0;
//assignment: __cs_retval__dec_1=0u - 1;
//assignment: __cs_local_dec_dec__vn=__cs_local_dec_dec__v - 1;

//operator &::value---l

//operator &::__cs_local_dec_dec__casret---l

//operator &::dec_flag---l
//assignment: __cs_local_dec_dec__v=value;
//assignment: __cs_local_dec___cs_tmp_if_cond_6=__cs_local_dec_dec__v == 0;
//assignment: __cs_retval__dec_1=0u - 1;
//assignment: __cs_local_dec_dec__vn=__cs_local_dec_dec__v - 1;

//operator &::value---l

//operator &::__cs_local_dec_dec__casret---l

//operator &::dec_flag---l
//assignment: __cs_local_dec_dec__v=value;
//assignment: __cs_local_dec___cs_tmp_if_cond_6=__cs_local_dec_dec__v == 0;
//assignment: __cs_retval__dec_1=0u - 1;
//assignment: __cs_local_dec_dec__vn=__cs_local_dec_dec__v - 1;

//operator &::value---l

//operator &::__cs_local_dec_dec__casret---l

//operator &::dec_flag---l
//assignment: __cs_retval__dec_1=__cs_local_dec_dec__vn;

//operator &::__cs_local_main_t---l

//operator &::__cs_local_main_t---l

//operator &::__cs_local_main_t---l

//operator &::__cs_local_main_t---l

//operator &::__cs_local_main_t---l

//operator &::__cs_local_main_t---l

//operator &::__cs_local_main_t---l

//operator &::__cs_local_main_t---l
//value:
//inc_flag:
//dec_flag:
//__cs_param___CSEQ_atomic_CAS_v:__CSEQ_atomic_CAS
//__cs_param___CSEQ_atomic_CAS_e:__CSEQ_atomic_CAS
//__cs_param___CSEQ_atomic_CAS_u:__CSEQ_atomic_CAS
//__cs_param___CSEQ_atomic_CAS_r:__CSEQ_atomic_CAS
//__cs_param___CSEQ_atomic_CAS_flag:__CSEQ_atomic_CAS
//__cs_local___CSEQ_atomic_CAS___cs_tmp_if_cond_0:__CSEQ_atomic_CAS
//__cs_param___CSEQ_atomic_assert1_inc__v:__CSEQ_atomic_assert1
//__cs_local___CSEQ_atomic_assert1___cs_tmp_if_cond_1:__CSEQ_atomic_assert1
//__cs_param___CSEQ_atomic_assert2_dec__v:__CSEQ_atomic_assert2
//__cs_local___CSEQ_atomic_assert2___cs_tmp_if_cond_4:__CSEQ_atomic_assert2
//__cs_param_thr1_arg:thr1_0
//__cs_local_thr1_r:thr1_0
//__cs_local_thr1___cs_tmp_if_cond_7:thr1_0
//__cs_retval__inc_1:thr1_0
//__cs_local_inc_inc__v:thr1_0
//__cs_local_inc_inc__vn:thr1_0
//__cs_local_inc_inc__casret:thr1_0
//__cs_local_inc___cs_dowhile_onetime_1:thr1_0
//__cs_local_inc___cs_tmp_if_cond_2:thr1_0
//__cs_local_inc___cs_tmp_if_cond_3:thr1_0
//__cs_retval__dec_1:thr1_0
//__cs_local_dec_dec__v:thr1_0
//__cs_local_dec_dec__vn:thr1_0
//__cs_local_dec_dec__casret:thr1_0
//__cs_local_dec___cs_dowhile_onetime_2:thr1_0
//__cs_local_dec___cs_tmp_if_cond_5:thr1_0
//__cs_local_dec___cs_tmp_if_cond_6:thr1_0
//__cs_param_thr1_arg:thr1_1
//__cs_local_thr1_r:thr1_1
//__cs_local_thr1___cs_tmp_if_cond_7:thr1_1
//__cs_retval__inc_1:thr1_1
//__cs_local_inc_inc__v:thr1_1
//__cs_local_inc_inc__vn:thr1_1
//__cs_local_inc_inc__casret:thr1_1
//__cs_local_inc___cs_dowhile_onetime_1:thr1_1
//__cs_local_inc___cs_tmp_if_cond_2:thr1_1
//__cs_local_inc___cs_tmp_if_cond_3:thr1_1
//__cs_retval__dec_1:thr1_1
//__cs_local_dec_dec__v:thr1_1
//__cs_local_dec_dec__vn:thr1_1
//__cs_local_dec_dec__casret:thr1_1
//__cs_local_dec___cs_dowhile_onetime_2:thr1_1
//__cs_local_dec___cs_tmp_if_cond_5:thr1_1
//__cs_local_dec___cs_tmp_if_cond_6:thr1_1
//__cs_local_main_t:main
//numLocks=0
