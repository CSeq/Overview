void Jump_atomic(){

 __CS_typeM jump;
 __CPROVER_assume(jump<thw[thread_index][thread_pos] && (jump >= thread_pos));
 if (( jump >= memory_notvalid ) || (__CS_ret) ) {__CS_ret=1; return;}

 thread_pos=jump;
 
}


int Read_atomic(__CS_typeV codeVar){

/////////////////////////
<insert-assume-atomic-here>
////////////////////////
//int ret = __memory[codeVar][thread_pos];
return (__memory[codeVar][thread_pos]);
}
