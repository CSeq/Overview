#!/usr/bin/env python
"""

	CSeq:  C Sequentialiser

		   Converts from multi-thread C to sequentialised C


		   This software was developed by Omar Inverso for the University of Southampton,
		   it is built on top of PyCParser (by Eli Bendersky, BSD licensed),
		   which uses PLY (by David M. Beazley).

	Features not implemented yet:
		- For the list of pthread primitives not supported, see global variable 'notHandledPrimitives' below.

		- basic pthreads primitives:
			- pthread_join() and pthread_exit() do not support handling return values from threads

		- mutexes:
			- pthread_mutex_init() is always assumed to be ok, also no checks are done to avoid use of non initialised mutexes
			- pthread_mutex_destroy() is always ok, also no checks are done to avoid use of destoryed mutexes

		- dynamic memory allocation (malloc) of global variables
		- dynamic thread creation
		- support of include files (at the moment we only use the fake ones for parsing purposes)

	Preprocessing needed (see assumption for the relevant restriction):

	Assumptions on the original C code (such assumptions will not necessarily be checked for!):
		    ----- TODO: OLD ASSUMPTIONS BELOW TO RE-CHECK -----------
		01. There are no variables or function names whose prefix is '__CS_'

		02. No local variable has the same name of a global variable
		   (variable shadowing is not handled properly yet)

		03. All calls to pthread_join() have the last parameter set to 0 or NULL
		   (at the moment we don't handle the return value from the thread we are joining)

		04. All calls to pthread_exit() have the parameter set to 0 or NULL
		   (which means that the exiting thread does not want to return anything)

		05. The input file has the following structure:
		    0. #include statements | 1. global var declarations | 2. function definition | 3. main(), therefore:
		    	- the include statements are all at the top of the input source file, without spaces (# include) and empty lines
		    	  moreover, the include files will not be sequentialised (it is always possible to preprocess the input
		    	  in order to expand the include files and have them sequentialised as well).
				- the declarations (of both variables and functions) are after the include statements
				- the main() function is at the bottom of the input source file
				- the function definitions are between the declarations and the main()
				- no declaration on global variables occurs between function definitions
				
		06. Each function (including main()) has the following structure:
			1. var declarations | 2. other statements
			that means that once the first non-declaration statement appears,
			it is not possible anymore to have other declarations.

		07. Assignment statements in for loops  'for (i=<expr>; i<k; i++)'  are such that <expr> is simple, e.g. 'i = 6';

		08. The main() function returns an int (int main(......))
		
		09. The main() has the following structure: (TODO.. see notes!) 
		
		10. No function calls within atomic sections / atomic functions.

	Conversion of variables:
		- local variables are unchanged
		- global variables are treated as follows:
			 - global declaration statements such as "int x;" are changed to "int x[MAXROUND];"
			 - global declaration statements with an init expression such as "int x = 0;" are changed to "int x[MAXROUND] = {0};"

"""
"""

#define __llbmc_assert(b) __CPROVER_assert(b, __FILE__)
#define __llbmc_assume(b) __CPROVER_assume(b)

#define __llbmc_nondef_char() nondet_char()
#define __llbmc_nondef_int() nondet_int()
#define __llbmc_nondef_uint16_t() nondet_uint16_t()
#define __llbmc_nondef_uint32_t() nondet_uint32_t()

"""
"""
Sample command-line:

CIL:
	cilly --save-temps -D HAPPY_MOOD -I fake_libc_include/ --domakeCFG --dooneRet --noPrintLn in.c

ESBMC:
	esbmc --64 --no-slice --unwind 12 --inlining --no-bounds-check --no-div-by-zero-check --no-pointer-check --no-unwinding-assertions input.c

CBMC:
	cbmc --no-unwinding-assertions --unwind 12 input.c
	
LLBMC:
	clang -c -g -I. -emit-llvm input.c -o input.bc; 
	llbmc --no-max-loop-iterations-checks --ignore-missing-function-bodies -no-overflow-checks -no-div-by-zero-checks --max-loop-iterations=12 input.bc

CPAchecker:
	scripts/cpa.sh -predicateAnalysis -spec ErrorLabel.spc input.c

Poirot:
	poirot4c.bat /main:main
	
"""

from pycparser import parse_file, c_parser, c_ast
from time import gmtime, strftime
import getopt, sys, os.path

# This is not required if you've installed pycparser into
# your site-packages/ with setup.py
#
sys.path.extend(['.', '..'])
sys.path.append('.')

# CSeq will throw an error and terminate if any of the following function calls are found.
# Put here everything not handled at the moment!
#
notHandledPrimitives = [ 'pthread_mutex_trylock', 'pthread_mutex_timedlock', 'pthread_mutex_consistent']  # mutexes
notHandledPrimitives += ['pthread_cond_timedwait', 'pthread_cond_destroy'] # conditionals
notHandledPrimitives += ['malloc', 'free', 'calloc'] # dynamic memory allocation


# The following block is the output main function,
# notice all the placeholders to be expanded at the end of the parsing.
#
mainSimulationBlock = (
"void *main_thread(void *arg)\n"
"{\n"
"\t<insert-main-parameters-decl-here>\n"
"\t<insert-mainthread-here>\n"
"}\n"
"\n"
"<insert-main-prototype-here>\n"
"{\n"
"\t//cseq: Copies of global variables\n"
"\t__CS_type __CS_cp___CS_thread_status[__CS_ROUNDS][__CS_THREADS+1];\n"
"\t__CS_type *__CS_cp___CS_thread_lockedon[__CS_ROUNDS][__CS_THREADS+1];\n"
"\t<insert-copyvars-here>\n"
"\n"
"\t//cseq: Copy statements for global variables:\n"
"\t//cseq: for each global variable x,\n"
"\t//cseq: copy into x[1...___CS_ROUNDS] <--- __CS_cp_x[1..___CS_ROUNDS].\n"
"\t//cseq: This is used to fill global variables with non-initialised data.\n"
"\t<insert-copy-block-here>\n"
"\n"
"\t//cseq: create new thread for the main function\n"
"\t__CS_round = 0;\n"
"\t__CS_thread_index = 0;\n"
"\t__CS_thread_born_round[0] = __CS_round;\n"
"\t__CS_thread_status[0][0] = __THREAD_RUNNING;\n"
"\t__CS_thread[0] = main_thread;\n"
"\t__CS_thread_allocated[0] = 1;\n"
"\n"
"\t//cseq: simulation of the threads\n"
"\t<insert-thread-simulations-here>\n"
"\n"
"\t//cseq: Consistency checks for global variables:\n"
"\t//cseq: for each global variable x,\n"
"\t//cseq: check that x[0...___CS_ROUNDS-1] == __CS_cp_x[1..___CS_ROUNDS].\n"
"\t<insert-consistency-block-here>\n"
"\n"
"\t//cseq: Error check\n"
"\t<insert-extra-error-check>\n"
"\t___XXXXX__FINAL_assert(__CS_error != 1);\n"
"}\n"
"\n"
)

extraChecks = (
"\t___XXXXX__FINAL_assert(__CS_error_detail != __ERR_MAXTHREADS_REACHED);\n"
"\t___XXXXX__FINAL_assert(__CS_error_detail != __ERR_ASSERT_FAILURE);\n"
"\t___XXXXX__FINAL_assert(__CS_error_detail != __ERR_ERROR_LABEL_REACHED);\n"
"\t___XXXXX__FINAL_assert(__CS_error_detail != __ERR_UNLOCK_ATTEMPT);\n"
"\t___XXXXX__FINAL_assert(__CS_error_detail != __ERR_JOIN_FAILED_WRONG_THREAD_ID);\n"
"\t___XXXXX__FINAL_assert(__CS_error_detail != __ERR_JOIN_FAILED_THREAD_NOT_CREATED);\n"
)

#
threadLaunchBlock = (
"\tif (__CS_thread_allocated[<insert-thread-number-here>] == 1) {\n"
"\t\t__CS_round = __CS_thread_born_round[<insert-thread-number-here>];\n"
"\t\t__CS_ret = 0;\n"
"\t\t__CS_thread[<insert-thread-number-here>](0);\n"
#"\t\tif (__CS_ret==__CS_ret_ERROR) __CS_thread_status[__CS_round][<insert-thread-number-here>] = __THREAD_FINISHED_ERROR;\n"
#"\t\tif (__CS_ret==0) __CS_thread_status[__CS_round][<insert-thread-number-here>] = __THREAD_FINISHED_NO_ERROR;\n"
"\t\tif (__CS_ret!=__CS_ret_PREEMPTED) __CS_thread_status[__CS_round][<insert-thread-number-here>] = __THREAD_FINISHED;\n"
"\t}\n"
)


threadLaunchBlockEXPERIMENTAL = (
"\tif (__CS_thread_allocated[<insert-thread-number-here>] == 1) {\n"
"\t\tunsigned int __SwitchPoints[__CS_ROUNDS];\n"
"\n"
"\t\t<insert-switch-point-assume>\n"
"\n"
"\t\t<insert-switch-point-assignment>\n"
"\n"
"\t\t__CS_StmtCount = 0;\n"
"\t\t__CS_SwitchDone = 0;\n"
"\t\t__CS_round = __CS_thread_born_round[<insert-thread-number-here>];\n"
"\t\t__CS_ret = 0;\n"
"\t\t__CS_thread[<insert-thread-number-here>](0);\n"
"\t\tif (__CS_ret==__CS_ret_ERROR) __CS_thread_status[__CS_round][<insert-thread-number-here>] = __THREAD_FINISHED_ERROR;\n"
"\t\tif (__CS_ret==0) __CS_thread_status[__CS_round][<insert-thread-number-here>] = __THREAD_FINISHED_NO_ERROR;\n"
"\t}\n"
)


# Block of code to be inserted before and after each statement, to simulate context switches.
# This is split into two functions in an attempt to make debugging easier.
# The placeholder <return_statement> will be changed to "return" or "return 0" depending on
# whether the function is void.
#
csBlock = (
"__CS_cs(); if (__CS_ret != 0) <return_statement>;"
##"if (nondet_int()) { __CS_cs(); if (__CS_ret != 0) <return_statement>;} else <return_statement>;"
## "{__CS_type k; ___XXXXX__assume(__CS_round < __CS_ROUNDS-k); __CS_round += k; } if (__CS_ret != 0) <return_statement>;"
)

#
errorBlock = (
"ERROR: __CS_error = 1; __CS_ret = __CS_ret_ERROR; <return_statement>;\n"
)

errorBlockDetail = (
"ERROR: __CS_error = 1; __CS_ret = __CS_ret_ERROR; __CS_error_detail = __ERR_ERROR_LABEL_REACHED; <return_statement>;\n"
)


pthreadExitBlock = (
"\t__CS_ret = 2;\n"
"\t<return_statement>;\n"
)


def printFile(filename):
	if not os.path.isfile(filename):
		print "ERROR: printfile(%s): file does not exist.\n" % filename
		return
	
	in_file = open(filename,"r")
	text = in_file.read()
	in_file.close()

	return text

''' Check whether a file contains at least one occurrence of 'string' in any of its lines
'''
def fileContains(filename, string):
	if os.path.isfile(filename):
		myfile = open(filename)
		lines = list(myfile)

		for line in lines:
			if string in line: return True
	else: return False

	return False

class colors:
	BLACK = '\033[90m'
	RED = '\033[91m'
	GREEN = '\033[92m'
	YELLOW = '\033[93m'
	BLUE = '\033[94m'
	NO = '\033[0m'


class CSequentialiser(object):
	""" Uses the same visitor pattern as c_ast.NodeVisitor, but modified to
		return a value from each visit method, using string accumulation in 
		generic_visit.
	"""
	def __init__(self, ast, maxrounds, maxthreads, detail):
		global errorBlock, errorBlockDetail
		self.detail = detail

		if detail: errorBlock = errorBlockDetail

		self.currentFunct = '' # name of the function being parsed (if any)
		self.funcName = ['']  # names of all the functions (consider '' to be a special function to model global scope)

		self.currentVarAssign = '' # name of the current variable used as a lvalue in an assignment statement

		self.currentStruct = ''
		self.structName = []
		self.currentAnonStructsCount = 0   # counts the number of anonymous structures (used to assign consecutive names)

		self.mainParametersDecl = ''     # parameters of the main() function to be transferred to thread 0.

		""" The following are indexed either using
			(struct, variable)  for struct fields, or
			(function, variable) local variables and function parameters, or
			('', variable) for global variables.	

			See _generate_decl(self, n) below for details. 
		"""
		self.varNames = {}    # names of all the variables (global, local, parameters) + variables in structs
		self.varType = {}     # int, char, ....
		self.varArity = {}    # 0 for scalar, k for k-dimensional arrays
		self.varSize = {}     #  [] for scalar, [n1,...,k] for k-dimensional arrays
		self.varKind = {}     # g, l, p, s
		self.varMallocd = {}  # used only for pointers
		self.varID = {}       # unique IDs for variables, as they are found while parsing, starting with 0
		self.varCount = 0     #
		self.extraGlovalVarCount = 0 # Count global variables introduced in the above data structures, but not from original input. 

		self.varNames[''] = [] # initialisation for global var names ('' is the global scope)

		# Add an extra variable to model thread statuses.
		self.varNames[''].append('__CS_thread_status')
		self.varType['','__CS_thread_status'] = '__CS_type '
		self.varArity['','__CS_thread_status'] = '1'
		self.varSize['','__CS_thread_status'] = [maxthreads+1]
		self.varKind['','__CS_thread_status'] = 'g'
		self.varMallocd['','__CS_thread_status'] = False
		self.varID['','__CS_thread_status'] = self.varCount
		self.varCount += 1
		self. extraGlovalVarCount += 1

		# Add an extra variable to model threads wait for conditional variables.
		self.varNames[''].append('__CS_thread_lockedon')
		self.varType['','__CS_thread_lockedon'] = '__CS_type *'
		self.varArity['','__CS_thread_lockedon'] = '1'
		self.varSize['','__CS_thread_lockedon'] = [maxthreads+1]
		self.varKind['','__CS_thread_lockedon'] = 'g'
		self.varMallocd['','__CS_thread_lockedon'] = False
		self.varID['','__CS_thread_lockedon'] = self.varCount
		self.varCount += 1
		self. extraGlovalVarCount += 1

		# Add an extra variable to keep track of the size of dynamically allocated vars.
		self.varNames[''].append('__CS_size')
		self.varType['','__CS_size'] = 'int'
		self.varArity['','__CS_size'] = '1'
		self.varSize['','__CS_size'] = [0]      # This will be set at the end of the parsing, when we'll know how many variables there are
		self.varKind['','__CS_size'] = 'g'
		self.varMallocd['','__CS_size'] = False
		self.varID['','__CS_size'] = self.varCount
		self.varCount += 1
		self.extraGlovalVarCount += 1

		# Handling of typedefs.
		# We put in the first variable below the last part of a typedef statement, 
		# and in the second variable its correspondent expansion.
		#
		# Anonymous typedefs are no exception, as they are assigned an internal name to be used as described.
		#
		self.typedefs = []          # contains last the part of a typedef stmt, e.g. typedef struct struct_name {.... } last_part;
		self.typedefExpansion = {}  # e.g. typedefs['field'] = struct { int a; int b; ... }  from the original typedef statement
	
		# TODO: True when the copyvar block etc. in the top of the main() function still
		# has to be added. We have to wait for all the declarations at the top of the main()
		# to show up before adding any assignment operations!
		self.append = True

		# The following variables are needed for handling the global variables in the original
		# source code.
		self.globalInitVarNodes = []  # all the initialised global variable nodes in a list

		# Statements start with indentation of self.indentLevel spaces, using
		# the _make_indent method
		#
		self.indentLevel = 0			# to keep track of the depth of the block {}
		self.INDENT_SPACING = '\t'	# ....

		# set debugMode to True or False to enable / disable debug		
		self.debugMode = False

		if self.debugMode:
			self.declMarkerA = colors.GREEN + '[' + colors.NO
			self.declMarkerB = colors.GREEN + ']' + colors.NO
			self.typeMarkerA = colors.YELLOW + '{' + colors.NO
			self.typeMarkerB = colors.YELLOW + '}' + colors.NO
			self.stmtMarkerA = colors.RED + '<' + colors.NO
			self.stmtMarkerB = colors.RED + '>' + colors.NO
			self.structMarkerA = colors.BLACK + '<' + colors.NO
			self.structMarkerB = colors.BLACK + '>' + colors.NO
		else:
			self.declMarkerA = ''
			self.declMarkerB = ''
			self.typeMarkerA = ''
			self.typeMarkerB = ''
			self.stmtMarkerA = ''
			self.stmtMarkerB = ''
			self.structMarkerA = ''
			self.structMarkerB = ''

		# = True while parsing the subtree for a function declaration
		self.parsingFuncDecl = False

		# = True while parsing the subtree for a struct (or union) declaration
		self.parsingStruct = False

		# = True while parsing the main() function
		self.parsingMain = False

		# = True while parsing the condition block of a while loop
		self.parsingWhileCond = False

		# Set when parsing a statement with side effects (i.e., function call, assignment, unary op)
		self.parsingSideEffect = False

		# Declarations have always one of the following two forms: 
		#		 <lastDeclarationL> = <lastDeclarationR>;   when there is an init expression
		#			   OR
		#		 <lastDeclarationL>;   when there is no init expression
		self.lastDeclarationL = ''
		self.lastDeclarationR = ''
		self.lastDeclaration = ''

		self.copyVariableDeclaration = ''

		# The following union declaration will be used to keep
		# the old value of a global variable immediately before any complex assignment operation
		# (such as the ones with a function call in the Lvalue).
		# This value can be used thereafter to simulate when a context switch happens
		# while performing function calls from within the assignment,
		# to restore the original value of the variable with a single assignment statement
		# (C unions support this).
		self.unionDeclaration = 'union __CS__u {\n'

		# init expressions for global variables will be moved into this string and then 
		# printed inside the main() function
		self.globalInitStatements = ''
 
		# this will set to True after parsing the first function definition (not declaration!)
		self.firstFunctionDefinitionDone = False

		# set to True while parsing void functions
		self.parsingVoidFunction = False

		# set to True while parsing typedef blocks 
		self.parsingTypedef = False

		self._maxthreads = maxthreads
		self._maxrounds = maxrounds

		# set to False when we still have to add to the main() the memcmp block,
		# and set to True when that has been done 
		self.memcmpBlockGenerated = False

		# used to avoid inserting csBlock() blocks in functions whose name starts with '__VERIFIER_atomic'
		self.parsingAtomic = False
		

	def _make_indent(self, delta=0):
		return (self.indentLevel+delta) * self.INDENT_SPACING


	def _make_header(self):
		# This block is added at the top of the output file.
		# All the function calls starting with '___XXXXX__' are place-holders and 
		# will be replaced later on, depending on the format chosen.
		# The placeholder <insert-include-statements-here> will be replaced with the original
		# #include lines (that we assume to be at the top of the input and without empty lines)
		# exactly as they were.
		if not self.detail:	headerBlock = printFile("include/cseq-include.c")
		else: headerBlock = printFile("include/cseq-include.full.c")

		headerBlock1 =  '/*  Generated by CSeq 0.5 (-t%s -r%s -f<insert-backend-here>) <insert-date-here>  */\n\n' % (str(self._maxthreads), str(self._maxrounds))
		headerBlock1 = headerBlock1 + headerBlock.replace("\t", self.INDENT_SPACING)
		headerBlock1 = headerBlock1.replace("<set-maxround-here>", str(self._maxrounds))
		headerBlock1 = headerBlock1.replace("<set-maxthread-here>", str(self._maxthreads))
		headerBlock1 = headerBlock1.replace("<set-maxvars-here>", str(self.varCount))

		return headerBlock1 + '//cseq: Sequentialised code starts here.\n'

	
	def visit(self, node):
		method = 'visit_' + node.__class__.__name__
		if self.debugMode: print self._make_indent() + "calling method: " + method + '\n'
		return getattr(self, method, self.generic_visit)(node)

	
	def generic_visit(self, node):
		#~ print('generic:', type(node))
		if node is None: return ''
		else: return ''.join(self.visit(c) for c in node.children())

	
	def visit_Constant(self, n):
		return n.value

		
	def visit_ID(self, n):
		# The arguments of the initial main() function are assigned to global variables in the new main,
		# and accessed in main_thread() function using the modified name.
		#
		if self.parsingMain and n.name in self.varNames['main'] and self.varKind['main', n.name] == 'p':
			## print "NAME: %s" % n.name
			#print "TYPE: %s\n\n" % n.type
			return '__CS_main_arg_' + n.name
		# global variables are changed to arrays,
		# for example the expression (a + b == 0) is changed to (a[__CS_round] + b == 0)
		# if a is global and b is local.
		#
		elif n.name in self.varNames['']: return n.name + '[__CS_round]'
		else: return n.name


	def visit_ArrayRef(self, n):
		arrref = self._parenthesize_unless_simple(n.name)
		return arrref + '[' + self.visit(n.subscript) + ']'


	def visit_StructRef(self, n):
		sref = self._parenthesize_unless_simple(n.name)
		return sref + n.type + self.visit(n.field)


	def visit_FuncCall(self, n):
		self.parsingSideEffect = True

		fref = self._parenthesize_unless_simple(n.name)

		# pthread_ primitives currenly not-handled will cause CSeq to quit.
		if fref in notHandledPrimitives:  # e.g. 'pthread_cond_wait', ...
			#print "UNKNOWN (code:02)\n"
			print("Conversion error:  use of '%s' is currently not handled." % fref)
			sys.exit(-1)

		# Maps the original pthread api calls to CSeq-simulated functions. 
		if fref == 'pthread_mutex_lock': fref = '__CS_pthread_mutex_lock'
		if fref == 'pthread_mutex_unlock': fref = '__CS_pthread_mutex_unlock'
		if fref == 'pthread_mutex_init': fref = '__CS_pthread_mutex_init'
		if fref == 'pthread_mutex_destroy': fref = '__CS_pthread_mutex_destroy'
		if fref == 'pthread_join': fref = '__CS_pthread_join'
		if fref == 'pthread_create': fref = '__CS_pthread_create'

		if fref == 'pthread_cond_init': fref = '__CS_pthread_cond_init'
		if fref == 'pthread_cond_wait': fref = '__CS_pthread_cond_wait'
		if fref == 'pthread_cond_signal': fref = '__CS_pthread_cond_signal'

		if fref == 'pthread_exit':
			fref = ''
			return fref 

			'''
			fref = "//cseq: Translation for " + fref + '(' + self.visit(n.args) + ')' + '\n'
			pthreadExitBlock2 = pthreadExitBlock.replace('\t', self.INDENT_SPACING)

			if self.parsingVoidFunction == True:
				pthreadExitBlock3 = pthreadExitBlock2.replace('<return_statement>', "return")
			else:
				pthreadExitBlock3 = pthreadExitBlock2.replace('<return_statement>', "return 0")

			fref = fref + pthreadExitBlock3 + self._make_indent()
			return fref
			'''

		# Mapping of verifier-specific function calls to handle several benchmarks without editing them.
		###### if self.parsingMain == False:
		''' __ESBMC_assume() is just a ESBMC-friendly call for __VERIFIER_assume(),
			it may be found in some benchmarks...
		''' 
		if fref == 'assume': fref = '__CS_assume'
		if fref == '__ESBMC_assume': fref = '__CS_assume'
		if fref == '__VERIFIER_assume': fref = '__CS_assume'

		if fref == 'assert': fref = '__CS_assert'
		if fref == '__ESBMC_assert': fref = '__CS_assert'
		if fref == '__VERIFIER_assert': fref = '__CS_assert'

		# Mapping of standard verifier function calls in the main()
		if fref == '__VERIFIER_nondet_int': fref = '___XXXXX__nondet_int'
		if fref == '__VERIFIER_assume': fref = '___XXXXX__assume'
		
		if fref == '__ESBMC_atomic_begin' or fref == '__VERIFIER_atomic_begin' or fref == '__CS_atomic_begin':
			fref = '//cseq: atomic section starts here '
			self.parsingAtomic = True
		
		if fref == '__ESBMC_atomic_end' or fref == '__VERIFIER_atomic_end' or fref == '__CS_atomic_end':
			fref = '//cseq: atomic section stops here '
			self.parsingAtomic = False 

		return fref + '(' + self.visit(n.args) + ')'


	def visit_UnaryOp(self, n):
		self.parsingSideEffect = True

		operand = self._parenthesize_unless_simple(n.expr)
		if n.op == 'p++':
			return '%s++' % operand
		elif n.op == 'p--':
			return '%s--' % operand
		elif n.op == 'sizeof':
			# Always parenthesize the argument of sizeof since it can be 
			# a name.
			return 'sizeof(%s)' % self.visit(n.expr)
		else:
			return '%s%s' % (n.op, operand)


	def visit_BinaryOp(self, n):
		lval_str = self._parenthesize_if(n.left, lambda d: not self._is_simple_node(d))
		rval_str = self._parenthesize_if(n.right, lambda d: not self._is_simple_node(d))
		return '%s %s %s' % (lval_str, n.op, rval_str)
	
        
	def visit_Assignment(self, n):
		self.parsingSideEffect = True
		rval_str = self._parenthesize_if(n.rvalue, lambda n: isinstance(n, c_ast.Assignment))
		
		preAssignment = ''
		postAssignment = ''

		s = '%s %s %s' % (self.visit(n.lvalue), n.op, rval_str)

		# the assignment statements for global variables have to be treated differently 
		# when the Rvalue is not a constant or a simple expression
		if type(n.lvalue) == c_ast.ID:
			if n.lvalue.name in self.varNames[''] and n.lvalue.name not in self.varNames[self.currentFunct]: # only consider global variables
				# if the rvalue of the assignment statement is not a constant then while executing it
				# a context switch might happen (unless it is not a call to malloc(), in which case a different logic is used.
				#
				if 'malloc(' in rval_str:
				##### if type(n.rvalue) == c_ast.FuncCall and self._parenthesize_unless_simple(n.rvalue.name) == 'malloc':
					# Case 1: dynamic memory allocation in the main()
					if self.parsingMain:
						self.varMallocd['',n.lvalue.name] = True
						self.varArity['',n.lvalue.name] = 1
						##### self.varSize['',n.lvalue.name].append(self.visit(n.rvalue.args))
						self.varSize['',n.lvalue.name].append(-1)

						s = preAssignment + '%s %s %s' % (self.visit(n.lvalue), n.op, rval_str) + postAssignment
						s = s.replace('malloc(', 'malloc(__CS_size[<set-round-index-here>][%s] = __CS_cp___CS_size[<set-round-indexB-here>][%s] = (') % (self.varID['',n.lvalue.name],self.varID['',n.lvalue.name])

						s2 = ''

						for i in range(0, self._maxrounds):
							s2 += s.replace('[__CS_round]', '['+ str(i)+']',1) + '); '
							s2 = s2.replace('[__CS_round]', '['+ str(i+1)+']',1)
							s2 = s2.replace('<set-round-index-here>', str(i))
							s2 = s2.replace('<set-round-indexB-here>', str(i))

						s = s2
					# Case 2: dynamic memory allocation in threads
					else:
						self.varMallocd['',n.lvalue.name] = True
						self.varArity['',n.lvalue.name] = 1
						##### self.varSize['',n.lvalue.name].append(self.visit(n.rvalue.args))
						self.varSize['',n.lvalue.name].append(-1)

						s = preAssignment + '%s %s %s' % (self.visit(n.lvalue), n.op, rval_str) + postAssignment
						## s = s.replace('malloc(', '__CS_malloc(%s,__CS_size[__CS_round][%s] = (') % (self.varID['',n.lvalue.name], self.varID['',n.lvalue.name])
						s = s.replace('malloc(', '__CS_malloc(%s, ') % (self.varID['',n.lvalue.name])
						## s = s.replace('malloc(', 'malloc(__CS_size[__CS_round][%s] = ') % (self.varID['',n.lvalue.name])

				elif type(n.rvalue) != c_ast.Constant:
					preAssignment = '//cseq: Translation for the assignment statement "%s %s %s", case 2\n' % (self.visit(n.lvalue), n.op, rval_str)
					preAssignment += self._make_indent(0) + '__CS_u.%s = %s;' % (self.visit(n.lvalue), self.visit(n.lvalue)) + '\n' +  self._make_indent(0)
					postAssignment = ';\n' + self._make_indent(0) + 'if (__CS_ret) ' + self.visit(n.lvalue) + '= __CS_u.' + self.visit(n.lvalue)
					s = preAssignment + '%s %s %s' % (self.visit(n.lvalue), n.op, rval_str) + postAssignment

		### self.currentVarAssign = ''
		return s


	def visit_IdentifierType(self, n):
		# Change 'pthread_mutex_t' to 'int' and so on,
		# put here everything type specific from pthread api that needs to be 
		# mapped into 'fake' CSeq types for simulation! 
		#
		if n.names[0] == 'pthread_t': n.names[0] = '__CS_pthread_t'
		if n.names[0] == 'pthread_mutex_t': n.names[0] = '__CS_pthread_mutex_t'
		if n.names[0] == 'pthread_cond_t': n.names[0] = '__CS_pthread_cond_t'

		### tm = ''.join(n.names)
		### print "VARIABLE TYPE: " +tm+ '\n'

		return ' '.join(n.names)

	
	def visit_Decl(self, n, no_type=False):
		initExpression = ''
		self.lastDeclarationL = ''
		self.lastDeclarationR = ''


		# no_type is used when a Decl is part of a DeclList, where the type is
		# explicitly only for the first declaration in a list.
		#
		s = n.name if no_type else self._generate_decl(n)
		### print "NEW DECLARATION %s TYPE:%s\n" % (n.name, n.type)

		# Transform global variables into arrays.
		# If already the original variable is an array, add another dimention.
		#
		if self.indentLevel < 1 and self.parsingFuncDecl == False and 'FuncDecl' not in str(n.type) and 'Struct' not in str(n.type) and 'Union' not in str(n.type):
			self.indentLevel+=1
			indent = self._make_indent();
			self.indentLevel-=1

			if s.find(' '+n.name+'[') == -1: s = s + '[__CS_ROUNDS]'
			else: s = s.replace(' '+n.name+'[', ' '+n.name+'[__CS_ROUNDS]'+'[')

			# Remove the  static  modifier before global variables,
			# or in a struct that'll give syntax error.
			self.unionDeclaration += indent + s.replace('static ', '') + ';\n'

			# Dynamically allocated memory assigned to pointers..
			dynSize = ''

			if self.__isPointer(self.currentFunct,n.name): #### TODO the var here must be GLOBAL!!!
				s2 = s.replace(' *'+n.name+'[__CS_ROUNDS]', ' *__CS_cp_'+n.name+'[__CS_ROUNDS]')
			else:
				s2 = s.replace(' '+n.name+'[__CS_ROUNDS]', ' __CS_cp_'+n.name+'[__CS_ROUNDS]')

			self.copyVariableDeclaration += indent + s2 + ';'+ dynSize +'\n'

		self.lastDeclarationL = s

		if n.bitsize: s += ' : ' + self.visit(n.bitsize)

		if n.init:
			# Add {} brackets when the declaration statement refers to a global variable with an init expression.
			# Example: int x = 0; ---->  int x[___CS_ROUNDS] = {0}. 
			if not (self.indentLevel < 1 and self.parsingFuncDecl == False and 'FuncDecl' not in str(n.type) and 'Struct' not in str(n.type) and 'Union' not in str(n.type)):
				bracketR = bracketL = ''
			else:
				bracketL = '{'
				bracketR = '}'

			if isinstance(n.init, c_ast.ExprList): s += ' = {' + bracketL + self.visit(n.init) + bracketR + '}'
			else: s += ' = ' + bracketL + self.visit(n.init) + bracketR

		self.lastDeclaration = s

		return s


	def visit_DeclList(self, n):
		s = self.visit(n.decls[0])
		if len(n.decls) > 1:
			s += ', ' + ', '.join(self.visit_Decl(decl, no_type=True) for decl in n.decls[1:])
		return s

	
	def visit_Typedef(self, n):
		s = ''
		if n.storage: s += ' '.join(n.storage) + ' '

		self.parsingTypedef = True
		typestring = self._generate_type(n.type)
		self.parsingTypedef = False

		# Typical  typedef struct  statement...
		if  typestring.startswith("struct "):
			## print "     adding typedef name '" +s+ "'"
			## print "     adding typedef type '" +typestring+ "'"

			leftPart = typestring[:typestring.find('{')]
			if leftPart.endswith(' '): leftPart = leftPart[:-1]
			if leftPart.endswith('\n'): leftPart = leftPart[:-1]
			if leftPart.endswith(' '): leftPart = leftPart[:-1]

			rightPart = typestring[typestring.rfind('} ')+2:]

			## print "      LEFT: '" + leftPart + "'"
			## print "      RIGHT: '" + rightPart + "'"

			self.typedefs.append(rightPart)
			self.typedefExpansion[rightPart] = leftPart

		s += typestring
		return s

	
	def visit_Cast(self, n):
		s = '(' + self._generate_type(n.to_type) + ')' 
		return s + ' ' + self._parenthesize_unless_simple(n.expr)


	def visit_ExprList(self, n):
		visited_subexprs = []
		for expr in n.exprs:
			if isinstance(expr, c_ast.ExprList):
				visited_subexprs.append('{' + self.visit(expr) + '}')
			else:
				visited_subexprs.append(self.visit(expr))
		return ', '.join(visited_subexprs)


	def visit_Enum(self, n):
		s = 'enum'
		if n.name: s += ' ' + n.name
		if n.values:
			s += ' {'
			for i, enumerator in enumerate(n.values.enumerators):
				s += enumerator.name
				if enumerator.value: 
					s += ' = ' + self.visit(enumerator.value)
				if i != len(n.values.enumerators) - 1: 
					s += ', '
			s += '}'
		return s

	# Note: function definition = function declaration + body.
	# This method will not be called when parsing simple declarations of function prototypes.
	#
	def visit_FuncDef(self, n):
		self.currentFunct = n.decl.name
		self.funcName.append(n.decl.name)
		self.varNames[self.currentFunct] = []

		# Note: the function definition is in two parts:
		#       one is 'decl' and the other is 'body'
		decl = self.visit(n.decl)

		if n.decl.name == 'main': self.parsingMain = True
		if n.decl.name.startswith('__VERIFIER_atomic'): self.parsingAtomic = True
		if decl.startswith("void") and not decl.startswith("void *"): self.parsingVoidFunction = True
		else: self.parsingVoidFunction = False

		''' Before printing the first function definition, print the union _u containing the global variable names.
			This union will be used in visit_Assignment(), to temporary store the old value of a given global variable.
			We use the union to reduce the space state, as only one variable at a time needs this backup space.
		'''
		if self.firstFunctionDefinitionDone == False:
			if len(self.varNames['']) > self.extraGlovalVarCount:   # Union is not empty
				decl = self.unionDeclaration + '};\n\nunion __CS__u __CS_u;\n\n' + decl

			self.firstFunctionDefinitionDone = True

		body = ''

		# The body is a Compound node
		if n.decl.name.startswith('__VERIFIER_atomic'): # no csBlock in atomic functions
			body += self.visit(n.body)
		elif self.parsingStruct:
			body += self.visit(n.body)
		else:
			# Add csBlocks as the last statement in each function.
			# This may be unrechable code if the last statement is a return, 
			# but that is fine.
			#
			if not self.parsingMain:
				body += self.visit(n.body)
				body = body[:body.rfind('\n}')]   # Eliminate the last closing braket for this compound block.
				body += '\n' + self._make_indent(1) + csBlock + '\n}\n' 
			else:
				body += self.visit(n.body)

		# The placeholder <return_statement> is changed to "return" or "return 0",
		# depending on whether the function is void.
		### functionBlock = decl + '\n{\n' + body + '}\n\n'
		functionBlock = decl + '\n' + body + '\n'

		#if decl.startswith("void") and not decl.startswith("void *"): # void function requests "return;"
		if self.parsingVoidFunction == True:
			functionBlock = functionBlock.replace("<return_statement>", "return")
		else: # non void functions request "return 0;"
			functionBlock = functionBlock.replace("<return_statement>", "return 0")

		if n.decl.name == 'main': self.parsingMain = False

		if n.decl.name.startswith('__VERIFIER_atomic'): self.parsingAtomic = False

		if n.decl.name == 'main':
			# Prepare the sequentialised main() function.
			#
			oldMainBlock = functionBlock[functionBlock.find('{')+2:]
			oldMainBlock = oldMainBlock[:oldMainBlock.rfind('}')-1]
			oldMainBlock = oldMainBlock.replace('main(', 'main_thread(', 1)

			functionBlock = mainSimulationBlock

			''' 2.  Build the memory compare block to be inserted at the bottom of main() for thread-wrapping.
			'''
			memcmpBlock = ''
			
			# For each global variable....
			'''	There are several cases:
			
					1. scalar variables
					2. arrays
					3. structs / unions
					4. pointers !!

			'''
			for v in self.varNames['']:
				if not self.varMallocd['',v]:
					comment = '  //cseq: Consistency of ' + v

					for line in self.__explodeVariable(v):
						indexBracket = line.find('[')
						indexDot = line.find('.')

						for i in range (1, self._maxrounds):
							# Scalar.
							if indexBracket == indexDot == -1:
								left = line + '['+str(i-1)+']'
								right = line + '['+str(i)+']' # + "  dot: %d, brk: %d" % (indexDot, indexBracket)
							# Array.
							elif indexDot == -1 or (indexBracket > -1 and indexBracket < indexDot):
								left = line.replace(v+'[', v+'['+str(i-1)+'][',1)
								right = line.replace(v+'[', v+'['+str(i)+'][',1) 
							# Struct.
							else:
								left = line.replace(v+'.', v+'['+str(i-1)+'].',1)
								right = line.replace(v+'.', v+'['+str(i)+'].',1)

							memcmpBlock += self.INDENT_SPACING + '___XXXXX__assume(%s == %s);' % (left, '__CS_cp_'+right)

							if i == 1:
								memcmpBlock += comment
								comment = ''

							memcmpBlock += '\n'
				else:
					comment = '  //cseq: Consistency of ' + v + ' (dynamic, ID:%s)' % (self.varID['',v])
					for i in range (1, self._maxrounds):
						left = v + '[%s]' % (i-1)
						right = v + '[%s]' % (i)
						size = '__CS_size[%s][%s]' % (i-1,self.varID['',v])
		
						memcmpBlock += self.INDENT_SPACING + '___XXXXX__assume(__CS_memcmp(%s, %s, %s) == 0);' % (left, '__CS_cp_'+right, size)

						if i == 1:
							memcmpBlock += comment
							comment = ''

						memcmpBlock += '\n'

			memcmpBlock += '\n'

			''' 3.  Build the memory copy block to be inserted at the top of main() to fill global variables with nondet values.
			'''
			memCopyBlock = ''

			# For each global variable....
			'''	There are several cases:
			
					1. scalar variables
					2. arrays
					3. structs / unions
					4. pointers !!!

			'''
			for v in self.varNames['']:
				comment = '  //cseq: Copy of ' + v

				for line in self.__explodeVariable(v):
					indexBracket = line.find('[')
					indexDot = line.find('.')

					for i in range (1, self._maxrounds):
						# Scalar.
						if indexBracket == indexDot == -1:
							index = line + '['+str(i)+']'
						# Array.
						elif indexDot == -1 or (indexBracket > -1 and indexBracket < indexDot):
							index = line.replace(v+'[', v+'['+str(i)+'][',1)
						# Struct.
						else:
							index = line.replace(v+'.', v+'['+str(i)+'].',1)

						memCopyBlock += self.INDENT_SPACING + '%s = %s;' % (index, '__CS_cp_'+index)
						# if i == 1: memCopyBlock += '  // cseq: copy ' + str(line) + '\n'
						if i == 1:
							memCopyBlock += comment
							comment = ''

						memCopyBlock += '\n'

			''' 4.  Build the thread simulation block inserted between the two above copy and consistency blocks.
			'''
			threadSimulBlock = ''
			for j in range(0, self._maxthreads+1):
				boh = threadLaunchBlock.replace('<insert-thread-number-here>', str(j));
				threadSimulBlock += boh + '\n'

			# ....
			switchPointAssumeStatements = '';
			'''
			for j in range(0, self._maxrounds-1):
				switchPointAssumeStatements += '\t\t___XXXXX__assume(__SwitchPoints[%s] < __SwitchPoints[%s]);\n' % (j, j+1)

			threadSimulBlock = threadSimulBlock.replace('\t\t<insert-switch-point-assume>\n', switchPointAssumeStatements)

			# ....
			switchPointAssignmentStatements = ''
			for j in range(0, self._maxrounds):

				switchPointAssignmentStatements += '\t\t__CS_SwitchPoints[%s] = __SwitchPoints[%s];\n' % (j, j)

			threadSimulBlock = threadSimulBlock.replace('\t\t<insert-switch-point-assignment>\n', switchPointAssignmentStatements)
			'''


			''' 5.  Eventually, put all parts together.
			'''
			functionBlock = mainSimulationBlock
			functionBlock = functionBlock.replace('\t<insert-consistency-block-here>\n', memcmpBlock)
			functionBlock = functionBlock.replace('\t<insert-copy-block-here>\n', memCopyBlock)
			functionBlock = functionBlock.replace('\t<insert-copyvars-here>\n', self.copyVariableDeclaration)
			functionBlock = functionBlock.replace('\t<insert-thread-simulations-here>\n', threadSimulBlock)
			functionBlock = functionBlock.replace('\t<insert-mainthread-here>\n', oldMainBlock)
			functionBlock = functionBlock.replace('<insert-main-prototype-here>', decl)
			functionBlock = functionBlock.replace('\t<insert-main-parameters-decl-here>\n', self.mainParametersDecl);

			if not self.detail: 
				functionBlock = functionBlock.replace("\t<insert-extra-error-check>\n", '')
			else:
				functionBlock = functionBlock.replace("\t<insert-extra-error-check>\n", extraChecks)
			'''
			memCopyBlock += self.INDENT_SPACING + "//cseq: Copies of global variables\n"
			memCopyBlock += self.copyVariableDeclaration + '\n'
			'''
			functionBlock = functionBlock.replace('\t<insert-main-parameters-assign-here>\n', '');


		return functionBlock


	def visit_FileAST(self, n):
		s = ''
		
		for ext in n.ext:
			if isinstance(ext, c_ast.FuncDef): s += self.visit(ext)
			else: s += self.visit(ext) + ';\n'

		return self._make_header() + s


	def visit_Compound(self, n):
		'''
		s = ''

		if n.block_items:
			s += ''.join(self._generate_stmt(stmt) for stmt in n.block_items)

		return s
		'''
		s = self._make_indent() + '{\n'
		self.indentLevel += 1
		if n.block_items:
			##s += '<<<< COUNT %s' % len(n.block_items)
			s += ''.join(self._generate_stmt(stmt) for stmt in n.block_items)

		self.indentLevel -= 1

		s += self._make_indent() + '}\n'
		
		return s

	
	def visit_EmptyStatement(self, n):
		return ';'

	
	def visit_ParamList(self, n):
		return ', '.join(self.visit(param) for param in n.params)


	def visit_Return(self, n):
		if self.parsingMain == True:
			return ''

		s = 'return'
		if n.expr: s += ' ' + self.visit(n.expr)
		return s + ';'


	def visit_Break(self, n):
		return 'break;'

		
	def visit_Continue(self, n):
		return 'continue;'

	
	def visit_TernaryOp(self, n):
		s = self.visit(n.cond) + ' ? '
		s += self.visit(n.iftrue) + ' : '
		s += self.visit(n.iffalse)
		return s
	

	def visit_If(self, n):
		s = 'if ('
		if n.cond: s += self.visit(n.cond)
		s += ')\n'
		t = self._generate_stmt(n.iftrue, add_indent=True)   
		if not t.startswith(self._make_indent()+ ('{\n')):      # add brakets for single non parenthesised statements after if
			t = self._make_indent() + '{\n' + t + self._make_indent() + '}\n'
		#t = '--->' + t +'<---'
		s += t
		
		if n.iffalse:
			s += '\n' + self._make_indent() + 'else\n'
			e = self._generate_stmt(n.iffalse, add_indent=True)
			if not t.startswith(self._make_indent()+ ('{\n')):      # add brakets for single non parenthesised statements after if
				e = self._make_indent() + '{\n' + e + self._make_indent() + '}\n'	
			s += e
		return s
	

	def visit_For(self, n):
		s = 'for ('
		if n.init: s += self.visit(n.init)
		s += ';'
		if n.cond: s += ' ' + self.visit(n.cond)
		s += ';'
		if n.next: s += ' ' + self.visit(n.next)
		s += ')\n'
		t = self._generate_stmt(n.stmt, add_indent=True)
		if not t.startswith(self._make_indent()+ ('{\n')):      # add brakets for single non parenthesised statements after if
			t = self._make_indent() + '{\n' + t + self._make_indent() + '}\n'
		s += t		
		return s


	def visit_While(self, n):
		#
		# How do we check for side effects?
		#
		# At the beginning of visiting the while condition block (  while(....) ),
		# self.parsingSideEffect is reset. 
		# If after visiting the condition block it has been set, then it means
		# that it contains at least an assignment statement, a unary op or a function call.
		# If after visiting the condition block it is still not set,
		# it means that no assignment stmts, unary ops or function call are present.
		# The flag is in fact set by visit_... methods for each of these ast nodes.
		#
		self.parsingSideEffect = False

		s = 'while ('
		if n.cond: s += self.visit(n.cond)
		#if self.parsingSideEffect: s += ' SIDE EFFECT HERE '
		#else: s+= ' NO SE HERE '
		s += ')\n'

		t = self._generate_stmt(n.stmt, add_indent=True)

		if not t.startswith(self._make_indent()+ ('{\n')):      # add brakets for single non parenthesised statements after if
			t = self._make_indent() + '{\n' + t + self._make_indent() + '}\n'

		# When the while condition has no side effects,
		# and the while block is either the empty statement (;) or the empty block ({}),
		# the following transformation is done:
		#
		#     while (cond) {}    --->     assume(!cond);
		#
		if not self.parsingSideEffect and (type(n.stmt) in (c_ast.EmptyStatement,) or not n.stmt.block_items):
			s = s.replace('while (', '___XXXXX__assume(!(', 1)
			s = s[:len(s)-2] + '));\n'
			t = ''

		## s += '<<<<<' +t+ '>>>>>'
		s += t
		return s


	def visit_DoWhile(self, n):
		s = 'do\n'
		t = self._generate_stmt(n.stmt, add_indent=True)
		if not t.startswith(self._make_indent()+ ('{\n')):      # add brakets for single non parenthesised statements after if
			t = self._make_indent() + '{\n' + t + self._make_indent() + '}\n'

		s += t
		s += self._make_indent() + 'while ('
		if n.cond: s += self.visit(n.cond)
		s += ');'
		return s


	def visit_Switch(self, n):
		s = 'switch (' + self.visit(n.cond) + ')\n'
		s += self._generate_stmt(n.stmt, add_indent=True)
		return s


	# Thanks to work by James Brierley who first discovered this bug
	# These AST objects have a statement list, original code looks for them as statements.
	# http://code.google.com/p/pycparser/issues/detail?id=79
	''' 
	def visit_Case(self, n):
		s = 'case ' + self.visit(n.expr) + ':\n'
		s += self._generate_stmt(n.stmts, add_indent=True) ######### OMAR: shouldn't be 'n.stmts'???
		return s

	
	def visit_Default(self, n):
		return 'default:\n' + self._generate_stmt(n.stmts, add_indent=True) ######## OMAR: shouldn't be 'n.stmts'???
	'''
	def visit_Case(self, n):
		s = 'case ' + self.visit(n.expr) + ':\n'
		self.indentLevel += 2
		for stmt in n.stmts:
			s += self._generate_stmt(stmt)
		self.indentLevel -= 2
		return s


	# Thanks to work by James Brierley who first discovered this bug
	# These AST objects have a statement list, original code looks for them as statements.
	# http://code.google.com/p/pycparser/issues/detail?id=79		
	def visit_Default(self, n):
		s = 'default:\n'
		self.indentLevel += 2
		for stmt in n.stmts:
			s += self._generate_stmt(stmt)
		self.indentLevel -= 2
		return s


	def visit_Label(self, n):
		'''
		# cseq <=0.4 below (main() function handled differently):
		if (n.name == 'ERROR'):
			if self.parsingMain == False: # not parsing the main() function 
				if self.parsingVoidFunction == True:
					return errorBlock.replace('<return_statement>', 'return') + self._generate_stmt(n.stmt)
				else:
					return errorBlock.replace('<return_statement>', 'return 0') + self._generate_stmt(n.stmt)
			else:  # parsing the main() function
				return errorBlock.replace('<return_statement>', '__CS_assert(0)') + self._generate_stmt(n.stmt)
		else:
			return n.name + ':\n' + self._generate_stmt(n.stmt)
		'''
		if (n.name == 'ERROR'):
			if self.parsingVoidFunction == True:
				return errorBlock.replace('<return_statement>', 'return') + self._generate_stmt(n.stmt)
			else:
				return errorBlock.replace('<return_statement>', 'return 0') + self._generate_stmt(n.stmt)


		else:
			return n.name + ':\n' + self._generate_stmt(n.stmt)


	def visit_Goto(self, n):
		return 'goto ' + n.name + ';'


	def visit_EllipsisParam(self, n):
		return '...'


	def visit_Struct(self, n):
		# Assigns a name to anonymous structs
		if n.name == None:
			n.name = '__CS_anonstruct_' + str(self.currentAnonStructsCount)
			self.currentAnonStructsCount += 1

		# This method is called more than once on the same struct,
		# the following is done only on the first time.
		#
		if n.name not in self.structName:
			self.currentStruct = n.name
			self.structName.append(n.name)
			self.varNames[self.currentStruct] = []

		oldParsingStruct = self.parsingStruct
		self.parsingStruct = True
		s = self._generate_struct_union(n, 'struct')
		self.parsingStruct = oldParsingStruct

		# Parsing  typedef struct
		'''
		if self.parsingTypedef: 
			print "    PARSING TYPEDEF STRUCT!!!!!!"
			print "       s: " + s 
			print "    name: " + str(n.name) + '\n\n\n'
		'''

		return s


	def visit_Typename(self, n):
		return self._generate_type(n.type)

		
	def visit_Union(self, n):
		oldParsingStruct = self.parsingStruct
		self.parsingStruct = True
		s = self._generate_struct_union(n, 'union')
		self.parsingStruct = oldParsingStruct
		
		return s


	def visit_NamedInitializer(self, n):
		s = ''
		
		for name in n.name:
			if isinstance(name, c_ast.ID): s += '.' + name.name
			elif isinstance(name, c_ast.Constant): s += '[' + name.value + ']'

		s += ' = ' + self.visit(n.expr)
		return s


	def _generate_struct_union(self, n, name):
		""" Generates code for structs and unions. name should be either 
			'struct' or union.
		"""
		s = name + ' ' + (n.name or '')
		if n.decls:
			s += '\n'
			s += self._make_indent() 
			self.indentLevel += 1
			s += '{\n'
			for decl in n.decls:
				s += self._generate_stmt(decl)
			self.indentLevel -= 1
			s += self._make_indent() + '}'
		return self.structMarkerA + s + self.structMarkerB


	def _generate_stmt(self, n, add_indent=False):
		""" Generation from a statement node. This method exists as a wrapper
			for individual visit_* methods to handle different treatment of 
			some statements in this context.
		"""
		typ = type(n)
		if add_indent: self.indentLevel += 1
		indent = self._make_indent()
		if add_indent: self.indentLevel -= 1


		##if typ not in (c_ast.Decl,) and self.parsingTypedef == False and self.parsingMain == False and self.parsingAtomic == False and self.parsingStruct == False:
		if typ not in (c_ast.Decl,) and self.parsingTypedef == False and self.parsingAtomic == False and self.parsingStruct == False:
			if typ in (c_ast.EmptyStatement,):
				return indent + self.visit(n) + '\n'
			elif typ in ( 
					c_ast.Decl, c_ast.Assignment, c_ast.Cast, c_ast.UnaryOp,
					c_ast.BinaryOp, c_ast.TernaryOp, c_ast.FuncCall, c_ast.ArrayRef,
					c_ast.StructRef):
				# These can also appear in an expression context so no semicolon
				# is added to them automatically
				#
				### return indent +'(a)' + cs + indent + self.visit(n) + ';\n'
				return indent + csBlock + '\n'+ indent + self.visit(n) + ';\n'
			elif typ in (c_ast.Compound,):
				# No extra indentation required before the opening brace of a 
				# compound - because it consists of multiple lines it has to 
				# compute its own indentation.
				#
				cmp = self.visit(n)
				cmp = cmp[:cmp.rfind('\n')]  # Do it twice to get rid of both the last two '\n' and the last '}'
				cmp = cmp[:cmp.rfind('\n')]   
				cmp += '\n' + self._make_indent(1) + csBlock + '\n'
				cmp += self._make_indent() + '}'
				return cmp
			else:
				return indent + csBlock + '\n' + indent + self.visit(n) + '\n'
		else:
			if typ in ( 
				c_ast.Decl, c_ast.Assignment, c_ast.Cast, c_ast.UnaryOp,
				c_ast.BinaryOp, c_ast.TernaryOp, c_ast.FuncCall, c_ast.ArrayRef,
				c_ast.StructRef):
				# These can also appear in an expression context so no semicolon
				# is added to them automatically
				#
				return indent + self.visit(n) + ';\n'
			elif typ in (c_ast.Compound,):
				# No extra indentation required before the opening brace of a 
				# compound - because it consists of multiple lines it has to 
				# compute its own indentation.
				#
				return self.visit(n)
			else:
				return indent + self.visit(n) + '\n'


	def _generate_decl(self, n):
		""" Generation from a Decl node.
		"""
		if self.debugMode == True:
			### s = self.declMarkerA +'('+ str(self.indentLevel) +')' + str(n.type)
			s = self.declMarkerA
		else: s = ''
		
		# use flags to keep track through recursive calls of what is being parsed (START)
		if 'FuncDecl' in str(n.type):
			oldParsingFuncDecl = self.parsingFuncDecl
			self.parsingFuncDecl = True
			self.CurrentFunct = n.name
			###self.varNames[self.currentFunct] = []

		if 'Struct' in str(n.type): self.parsingStruct = True

		if n.funcspec: s = ' '.join(n.funcspec) + ' '
		if n.storage: s += ' '.join(n.storage) + ' '

		if self.debugMode == True: s += self._generate_type(n.type) + self.declMarkerB
		else: s += self._generate_type(n.type)

		# use flags to keep track through recursive calls of what is being parsed (END)
		if 'FuncDecl' in str(n.type):
			### self.parsingFuncDecl = False
			self.parsingFuncDecl = oldParsingFuncDecl
			self.CurrentFunct = ''

		if 'Struct' in str(n.type): self.parsingStruct = False


		""" Handling of struct declarations.
		"""
		if 'Struct' in str(n.type):
			# new structure declaration
			1
			if self.parsingStruct:
				# new field in a structure
				1

		""" Handling of variable declarations.

			Each variable has the following info associated with it:

				name, type, kind, arity, size
	
			name
		    	varName[''] = list of global variables
		    	varName['x'] = list local variables in function or struct 'x'
				              (incl. input params for functions)

			type
				the type as declared in the original code (e.g. 'unsigned int', 'char *', ...)

			kind
				'g'  for global variables
				'l'  for local variables
				'p'  for function input parameters
				'f'  for struct fields

			arity
				0  for scalar variables
				k  for for k-dimensional arrays

			size
				[] for scalar variables
				[size1, ..., sizek] for k-dimensional arrays

		"""
		# Whatever is not a function or a struct here, is a variable declaration
		# TODO: see what else should be excluded to only have var declarations after the if
		#
		if 'FuncDecl' not in str(n.type) and 'Struct' not in str(n.type) and 'Union' not in str(n.type):
			# Variable name (for variables) or field name (for structs fields).
			#
			# At this point,
			# any variable declaration can occur (a) in the global scope,
			# or (b) in a function or (c) in a struct.
			#
			# Each of those will have a name, apart from the global scope,
			# for which name we use the empty string. We call it Context. 
			#
			# For example,
			#   if a variable V is declared in a function F, its Context is F.
			#   if a variable V is declared in a struct S, its Context is S.
			#   if a variable V is declared globally, its Context is ''.
			#
			# We use the context to index the arrays:
			# (1) to index the array name
			# (2) to index the arrays type, kind, arity, size,
			# in this case with the tuple (context, variable)
			#
			if not self.parsingStruct: variableContext = self.currentFunct
			else: variableContext = self.currentStruct

			##print "appending var  [%s]\n          from context [%s]\n          type [%s]\n          string [%s]\n\n\n" % (n.name, variableContext, n.type, s)  

			if not n.name in self.varNames[variableContext]:   # avoid duplicates
				# print "appending var  [%s]\n          from context [%s]\n          type [%s]\n          string [%s]\n\n\n" % (n.name, variableContext, n.type, s)  
				self.varNames[variableContext].append(n.name)
				# Associate each new variable with a unique IDs
				self.varID[variableContext,n.name] = self.varCount
				self.varCount += 1

			# Variable or field type
			if s.count('[') > 0: s2 = s[ :s.find('[')]		
			else: s2 = s

			s2 = s2[:-len(n.name)]
			if s2.endswith(' '): s2 = s2[:-1]

			# Typedef expansion:
			# when some type of variable is found for which there is an entry in the list of typedefs,
			# expands directly in the symbol table the corresponding string.
			#
			for x in self.typedefs:
				## print "found %s ---> %s" % (x, self.typedefExpansion[x])

				if s2 == x:
					s2 = self.typedefExpansion[x]

				if s2.startswith(x+ ' '):
					s2 = s2.replace(x+' ', self.typedefExpansion[x]+' ', 1)

				s2 = s2.replace(' '+x+' ', ' '+self.typedefExpansion[x]+' ')

			self.varType[variableContext,n.name] = s2

			# Variable kind
			if self.parsingFuncDecl:    # parameter (from a function declaration)
				self.varKind[variableContext, n.name] = 'p'

				## print "FOUND MAIN PARAMETER %s, DECL %s\n\n" % (n.name, s)
				if variableContext == 'main':
					varDecl = s;
					varDecl = varDecl.replace(' '+n.name, ' __CS_main_arg_'+n.name)
					varDecl = varDecl.replace(' *'+n.name, ' *__CS_main_arg_'+n.name)
					varDecl = varDecl.replace(' *__CS_main_arg_'+n.name+'[]', ' **__CS_main_arg_'+n.name)

					self.mainParametersDecl += '\t' + varDecl + ';\n'

			elif self.parsingStruct:    # field in a struct (this are not really variables, but we handle them using the same data structures)
				self.varKind[variableContext, n.name] = 'f'
			elif self.indentLevel < 1:  # global variable
				self.varKind[variableContext, n.name] = 'g'
			else:                       # local variable
				self.varKind[variableContext, n.name] = 'l'

			# Variable arity (scalars have arity 0)
			self.varArity[variableContext,n.name] = int(s.count('['))

			# Variable size(s) (for scalars that is an empty array)
			self.varSize[variableContext,n.name] = []

			tmp_s = s
			i = self.varArity[variableContext,n.name]

			while i > 0:
				tmp = tmp_s[tmp_s.find("[")+1:tmp_s.find("]")]

				if tmp == '': ithSize = -1           # Unbounded array. This is equivalent to declare a pointer. TODO
				elif not tmp.isdigit(): ithSize = -2 # Array size given by a complex expression. This is like dynamically allocated blocks. TODO
				else: ithSize = int(tmp)             # Array size given by a constant expression

				self.varSize[variableContext,n.name].append(ithSize)
				tmp_s = tmp_s[tmp_s.find("]")+1:]
				i = i-1

			# This is used later on to see if a pointer is ever associated with a malloc()
			self.varMallocd[variableContext,n.name] = False


		# Initialisation of global variables:
		#
		#	 self.indentLevel < 1  is to identify the block depth (we want depth to be = 0)
		#	 self.parsingFuncDecl == False  is to exclude variable declaration within function prototypes
		#	'FuncDecl' not in str(n.type)  is to exclude declaration of global function prototypes (at block level 0)
		#
		if self.indentLevel < 1 and self.parsingFuncDecl == False and 'FuncDecl' not in str(n.type):
			# if the global var is initialised, we save its associated node in the AST, 
			# so to perform the initialisation later on from within the main()
			if 'None' != str(n.init):  # there is an init expression for the var (e.g. int x = 0;)
				self.globalInitVarNodes.append(n)
	
		return s
	

	def _generate_type(self, n, modifiers=[]):
		""" Recursive generation from a type node. n is the type node. 
			modifiers collects the PtrDecl, ArrayDecl and FuncDecl modifiers 
			encountered on the way down to a TypeDecl, to allow proper
			generation from it.
		"""
		typ = type(n)
		### print(n, modifiers, len(modifiers))
		
		if typ == c_ast.TypeDecl:
			s = '' + self.typeMarkerA
			if n.quals: s += ' '.join(n.quals) + ' '
			s += self.visit(n.type)
			
			nstr = n.declname if n.declname else ''
			# Resolve modifiers.
			# Wrap in parens to distinguish pointer to array and pointer to
			# function syntax.
			#
			for i, modifier in enumerate(modifiers):
				if isinstance(modifier, c_ast.ArrayDecl):
					if (i != 0 and isinstance(modifiers[i - 1], c_ast.PtrDecl)):
						nstr = '(' + nstr + ')'
					nstr += '[' + self.visit(modifier.dim) + ']'
				elif isinstance(modifier, c_ast.FuncDecl):
					if (i != 0 and isinstance(modifiers[i - 1], c_ast.PtrDecl)):
						nstr = '(' + nstr + ')'
					nstr += '(' + self.visit(modifier.args) + ')'
				elif isinstance(modifier, c_ast.PtrDecl):
					if modifier.quals:
						nstr = '* %s %s' % (' '.join(modifier.quals), nstr)
					else:
						nstr = '*' + nstr

			if nstr: s += ' ' + nstr
			return s + self.typeMarkerB
		elif typ == c_ast.Decl:
			return self.typeMarkerA + self._generate_decl(n.type) + self.typeMarkerB
		elif typ == c_ast.Typename:
			return self.typeMarkerA + self._generate_type(n.type) + self.typeMarkerB
		elif typ == c_ast.IdentifierType:
			return self.typeMarkerA + ' '.join(n.names) + ' ' + self.typeMarkerB
		elif typ in (c_ast.ArrayDecl, c_ast.PtrDecl, c_ast.FuncDecl):
			###### if typ == c_ast.ArrayDecl: print "ARRAY DECL!!!! %s\n" % n.dim.value ## array value
			return self.typeMarkerA + self._generate_type(n.type, modifiers + [n]) + self.typeMarkerB
		else:
			return self.typeMarkerA + self.visit(n) + self.typeMarkerB


	def _parenthesize_if(self, n, condition):
		""" Visits 'n' and returns its string representation, parenthesized
			if the condition function applied to the node returns True.
		"""
		s = self.visit(n)
		if condition(n): return '(' + s + ')'
		else: return s


	def _parenthesize_unless_simple(self, n):
		""" Common use case for _parenthesize_if
		"""
		return self._parenthesize_if(n, lambda d: not self._is_simple_node(d))


	def _is_simple_node(self, n):
		""" Returns True for nodes that are "simple" - i.e. nodes that always
			have higher precedence than operators.
		"""
		return isinstance(n,(c_ast.Constant, c_ast.ID, c_ast.ArrayRef, c_ast.StructRef, c_ast.FuncCall))



	'''

        Internal functions.

	'''

	# Output the assert statements for global variables (excluding dynamically allocated, symbolic-sized vars).
	#
	def __explodeVariable(self, v):
		blocks = []

		# 1: scalar variables
		#
		if self.varArity['',v] == 0  and not self.varType['',v].startswith('struct ') and not self.varType['',v].startswith('union '):
		## if self.varArity['',v] == 0  and not self.__isStruct('',v) and not self.varType['',v].startswith('union '):
			# print "> %s,%s  scalar, arity = %s" % ('',v,self.varArity['',v])
			blocks.extend([v])

		# 2: arrays
		#
		#elif self.varArity[f,v] > 0  and  not self.varType[f,v].startswith('struct ') :
		elif self.varArity['',v] > 0 and not self.varMallocd['',v] :
			# print "> %s,%s  array, arity = %s" % ('',v,self.varArity['',v])
			blocks.extend(self.__explodeArray(v, '', v))

		# 3: structs / unions
		#
		elif not self.varMallocd['',v]:
			# print "> %s,%s  struct, arity = %s" % ('',v,self.varArity['',v])
			blocks.extend(self.__explodeStruct(v, self.varType['', v][7:]))

		return blocks


	# Returns all possible tuples of indexes for a variable  v  from function  f.
	#
	# For example, given v[3][2], that is: (0,0), (0,1), (1,0), (1,1), (2,0), (2,1)
	#
	def __genTuples(self, f, v):
		lst = self.varSize[f,v]
		return reduce(lambda prev, b: [xs + [i] for xs in prev for i in range(0,b)], lst, [[]])


	# Returns all possible fields in a struct  s.
	#
	def __genFields(self, s):
		return self.varNames[s]


	# Checks whether variable  v  from function  f  is scalar. 
	#
	def __isScalar(self, f, v):
		if self.varArity[f, v] == 0  and not self.varType[f, v].startswith('struct ') and not self.varType[f, v].startswith('union '):
			return 1
		else:
			return 0


	# Return the type of the variable without spaces and modifiers (useful for symbol-table lookups).
	# For example:    'const char *'  ---->  'char'
	#
	def __getBasicType(self, f, v):
		# See what is the type the variable is referring to.
		# First we need to get rid of any type modifiers (e.g. 'const'),
		# then of pointer symbols (*'s) and spaces (' ') to get the basic type
		# for lookup in the list of typedefs.
		#
		basicType = self.varType[f, v]

		if basicType.startswith('const '): basicType = basicType[6:]

		if ' ' in basicType: basicType = basicType[:basicType.find(' ')]
		if '*' in basicType: basicType = basicType[:basicType.find('*')]

		return basicType		


	# Checks whether variable  v  from function  f  is of a type which refers to a previous typedef.
	# This is used, for example, to see if a given variable is a struct,
	# as the  struct  keyword might be hidden by a typedef (as they usually are!)  
	#
	def __isTypedef(self, f, v):
		if __getBasicType(f,v) in self.typedefs: return 1
		else: return 0


	# Checks whether variable  v  from function  f  is a struct.
	#
	def __isStruct(self, f, v):
		result = 0

		if  self.varType[f, v].startswith('struct '):
			result = 1
		#elif self.__getBasicType(f,v) in self.typedefs:
		#	if self.typedefExpansion[self.__getBasicType(f,v)].startswith('struct '):
		#		result = 1

		### print "    variable (%s) frm (%s) is (%s)" % (v, f, result)

		return result

	# Returns the name of the struct a variable refers to, expanding typedefs if necessary.
	#
	def __getStructName(self, s, field):
		name = ''

		if  self.varType[f, v].startswith('struct '):
			name = self.varType[s, field][7:]
		#elif self.__getBasicType(s,field) in self.typedefs:
		#	if self.typedefExpansion[self.__getBasicType(s,field)].startswith('struct '):
		#		name = self.typedefExpansion[self.__getBasicType(s,field)][7:]

		return name

	# Checks whether variable  v  from function  f  is an array.
	#
	def __isArray(self, f, v):
		if self.varArity[f,v] > 0: return 1
		else: return 0


	# Checks whether variable  v  from function  f  is an array.
	#
	def __isPointer(self, f, v):
		if self.varType[f,v].endswith('*'): return 1
		else: return 0


	# Recursively explode an array  f  from function  v  (see also __explodeStruct).
	#
	def __explodeArray(self, prefix, f, v):
		'''
		print "explode array"
		print "    prefix " + prefix
		print "    f: " + f
		print "    v: " + v
		print "\n\n\n"
		'''
		block = []

		# Arrays are exploded using any possible combination of indexes.
		for tuple in self.__genTuples(f,v):
			indexes = str(tuple).replace(', ', '][')

			# if self.varType[f, v].startswith('struct '):
			if self.__isStruct(f, v):
				#  structName = self.varType[f, v][7:]
				structName = self.__getStructName(f, v)
				block.extend(self.__explodeStruct(prefix+indexes, structName))
			else:
				block.extend([str(prefix+indexes)])

		return block


	# Recursively explode a struct  s  (see also __explodeArray).
	#
	def __explodeStruct(self, prefix, s):
		'''
		print "explode struct"
		print "    prefix " + prefix
		print "    s: " + s
		print "\n\n\n"
		'''

		block = []

		# Struct are exploded using any possible field.
		for field in self.__genFields(s):
			if self.__isArray(s, field):
				block.extend(self.__explodeArray(prefix+'.'+field, s, field))
			elif self.__isStruct(s, field):
				structName = self.__getStructName(s, field)
				block.extend(self.__explodeStruct(prefix+'.'+field, structName))
			else:
				block.extend([prefix+'.'+field])

		return block




























''' 
	strip()  -  Strips every line in the given string
				from the line with '_____STARTSTRIPPINGFROMHERE_____' as substring
				to the one with '_____STOPSTRIPPINGFROMHERE_____' as substring.

				Lines are identified by '\n'
'''
def strip(s):
	s2 = ''
	status = 0

	for line in s.split('\n'):
		if '_____STARTSTRIPPINGFROMHERE_____' in line:
			status = 1
			continue;

		if '_____STOPSTRIPPINGFROMHERE_____' in line:
			status = 2
			continue;

		if status == 0 or status == 2: s2 += line + '\n'

	return s2



''' 
	sequentialise()  -  Generates the sequentialised version for the given .C source file

'''
def sequentialise(inputFilename, outputFilename, outputFormat, cppArgs, maxRounds, maxThreads, debug, detail):
	# Generate AST.
	ast = parse_file(inputFilename, use_cpp=True, cpp_args=cppArgs)

	if debug: ast.show()

	# Generate the sequentialised representation for the input code.
	generator = CSequentialiser(ast, maxRounds, maxThreads, detail)

	# Put all the sequentialised code into s.
	s = generator.visit(ast)


	# Optimisation: remove code from cs() for conditional variables when not needed.
	if not fileContains(inputFilename, 'pthread_cond'):
		s = s.replace('___XXXXX__assume(__CS_thread_lockedon[k][__CS_thread_index] == 0);', '');

	# Specific back-end calls.   TODO double-check __XXXX_assume -->>>> ???
	if outputFormat == 'esbmc':
		s = s.replace('___XXXXX__nondet_int()', 'nondet_int()')
		s = s.replace('___XXXXX__assume', '__ESBMC_assume')
		s = s.replace('___XXXXX__assert', '__ESBMC_assert')
		s = s.replace('int ___XXXXX__dummyBlock1;\n', '');
		s = s.replace('int ___XXXXX__dummyBlock2;\n', '');
		s = s.replace('___XXXXX__FINAL_assert', 'assert');
	elif outputFormat == 'cbmc':
		s = s.replace('___XXXXX__nondet_int()', 'nondet_int()')
		s = s.replace('___XXXXX__assume', '__CPROVER_assume')
		s = s.replace('___XXXXX__assert', '__CPROVER_assert')
		s = s.replace('int ___XXXXX__dummyBlock1;\n', '');
		s = s.replace('int ___XXXXX__dummyBlock2;\n', '');
		s = s.replace('___XXXXX__FINAL_assert', 'assert');
	elif outputFormat == 'llbmc':
		s = s.replace('___XXXXX__nondet_int()', '__llbmc_nondef_int()')
		s = s.replace('___XXXXX__assume', '__llbmc_assume')
		s = s.replace('___XXXXX__assert', '__llbmc_assert')
		s = s.replace('int ___XXXXX__dummyBlock1;\n', '');
		s = s.replace('int ___XXXXX__dummyBlock2;\n', '');
		s = s.replace('___XXXXX__FINAL_assert', 'assert');
	elif outputFormat == 'poirot':
		s = s.replace('___XXXXX__nondet_int()', 'poirot_nondet()')
		s = s.replace('___XXXXX__assume', '__hv_assume')
		s = s.replace('___XXXXX__assert', 'POIROT_ASSERT')
		s = s.replace('int ___XXXXX__dummyBlock1;\n', '');
		s = s.replace('int ___XXXXX__dummyBlock2;\n', '');
		s = s.replace('___XXXXX__FINAL_assert', 'POIROT_ASSERT');
	elif outputFormat == 'cpachecker':
		s = s.replace('___XXXXX__nondet_int()', 'nondet_int()')
		s = s.replace('___XXXXX__assume', '__CS_CPA_ASSUME')
		s = s.replace('___XXXXX__assert', '__CS_ASSERT')  # <------
		s = s.replace('int ___XXXXX__dummyBlock1;\n', 'void __CS_CPA_ASSERT(int expression) { if (!expression) { ERROR: goto ERROR; } return; }\n');
		s = s.replace('int ___XXXXX__dummyBlock2;\n', 'void __CS_CPA_ASSUME(int expression) { if (!expression) { LOOP: goto LOOP; } return; }\n');
		s = s.replace('___XXXXX__FINAL_assert', '__CS_CPA_ASSERT');

	s = s.replace("<insert-backend-here>", outputFormat)
	s = s.replace('<insert-main-args-here>\n', generator.mainParametersDecl)
	s = s.replace('<insert-date-here>', strftime("%Y-%m-%d %H:%M:%S", gmtime()))

	# Add the original include statements at the top of the output file.
	includeStatements = ''
	
	myfile = open(inputFilename)
	allLines = list(myfile)
	assertAdded = False

	for i in range(len(allLines)):
		if allLines[i].startswith('#include'):
			if not allLines[i].startswith('#include <pthread.h>'):
				includeStatements += allLines[i];

			if allLines[i].startswith('#include <assert.h>'):
				assertAdded = True
		else: break
	
	includeStatements += "#include <stdlib.h>\n"   # For malloc(), ...

	if not assertAdded: includeStatements += "#include <assert.h>\n\n"
	else: includeStatements += '\n'
	
	s = s.replace("<insert-include-statements-here>", includeStatements)


	# Strip the output from every line coming from the fake_includes introduces by PYCparser.
	if outputFilename == '':
		print (strip(s))
	else:
		fd = os.open(outputFilename, os.O_RDWR|os.O_CREAT)
		os.write(fd, strip(s))






	if not debug: return
	print "parameters for main():\n"+ generator.mainParametersDecl

	# Print debug information.
	# Comment the return statement above...
	#
	# List of all variables
	print "Variables:"
	for f in generator.funcName:
		if not f == '':	print "   " + f
		else: print "   (global)"
		
		for v in generator.varNames[f]:
			# detailed var description
			s = "       "
			s += "id " + str(generator.varID[f,v]) + "  "
			s += "var '" + v + "'   "
			s += "type '" + generator.varType[f, v] + "'   "
			s += "kind '" + generator.varKind[f, v] + "'   "
			s += "arity '" + str(generator.varArity[f, v]) + "'   "
			s += "size '" + str(generator.varSize[f, v]) + "'   "
			s += "mallocd '" + str(generator.varMallocd[f,v]) + "'"
			
			print s

	print '\n'

	# List of all fields
	print "Fields:"
	for f in generator.structName:
		if not f == '':	print "   " + str(f)
		else: print "   (global)"
		
		for v in generator.varNames[f]:
			# detailed var description
			s = "       "
			s += "id " + str(generator.varID[f,v]) + "  "
			s += "var '" + v + "'   "
			s += "type '" + generator.varType[f, v] + "'   "
			s += "kind '" + generator.varKind[f, v] + "'   "
			s += "arity '" + str(generator.varArity[f, v]) + "'   "
			s += "size '" + str(generator.varSize[f, v]) + "'   "
			s += "mallocd '" + str(generator.varMallocd[f,v]) + "'"

			
			print s

	print '\n'

	print "Typedefs:"
	for x in generator.typedefs:
		print x + " -> " + generator.typedefExpansion[x]

	print '\n'

	print "Pointer variables:"
	for f in generator.funcName:
		if not f == '':	print "   " + f
		else: print "   (global)"
		
		for v in generator.varNames[f]:
			if generator.varType[f,v].endswith('*'):
				s = "       "
				s += "var '" + v + "'   "
				s += "type '" + generator.varType[f, v] + "'   "
				s += "kind '" + generator.varKind[f, v] + "'   "
				s += "arity '" + str(generator.varArity[f, v]) + "'   "
				s += "size '" + str(generator.varSize[f, v]) + "'   "
			
				print s

	print '\n'


#------------------------------------------------------------------------------

def usage(cmd):
	print "CSeq   |   C sequentialiser"
	print " 0.5   |   June 2013\n"

	print " Usage:"
	print "   -h, --help                         display this help screen"
	print "   -d, --debug                        show AST and symbol tables\n"
	print "   -i<filename>, --input=<filename>   read input from the filename"
	print "   -o<filename>, --output=<filename>  write output to the filename"
	print "   -f<fmt>, --format=<fmt>            output file format (std, esbmc, cbmc, llbmc, poirot*, cpachecker*)"
	print "   -t<X>, --threads<X>                set max threads for the sequentialisation (default: 5)"
	print "   -r<X>, --rounds<X>                 set max rounds for the sequentialisation (default: 10)\n"
	print " Example:"
	print "   %s  --input input-c-file.c   --output=output-c-file.c  -t3  -r 6  -u25  -fesbmc\n" % cmd
	print " Note: poirot and cpachecker support is only experimental.\n"


def main(args):
	cmd = args[0]

	try:
		opts, args = getopt.getopt(sys.argv[1:], "hdi:o:f:t:r:D", ["help", "detail", "input=", "output=", "format=", "threads=", "rounds=", "debug"])
	except getopt.GetoptError, err: # print help information and exit:
		usage(cmd)
		print "error: " +str(err) # will print something like "option -a not recognized"
		sys.exit(2)

	inputfile = outputfile = ''

	# Set default values for conversion parameters just in case
	format = 'esbmc'
	threads = 5
	rounds = 10

	debug = detail = False

	for o, a in opts:
		if o == "-v": verbose = True
		elif o in ("-h", "--help"):
			usage(cmd)
			sys.exit()
		elif o in ("-D", "--debug"): debug = True
		elif o in ("-d", "--detail"): detail = True
		elif o in ("-i", "--input"): inputfile = a
		elif o in ("-o", "--output"): outputfile = a
		elif o in ("-f", "--format"): format = a
		elif o in ("-t", "--threads"): threads = int(a)
		elif o in ("-r", "--rounds"): rounds = int(a)
		else: assert False, "unhandled option"

	# Check command-line parameters
	if inputfile == '':
		usage(cmd)
		print "error: input file name not specified\n"
		sys.exit(2)

	if not os.path.isfile(inputfile):
		usage(cmd)
		print "error: unable to open input file (%s)\n" % inputfile
		sys.exit(2)

	if format not in ('std', 'esbmc', 'cbmc', 'llbmc', 'poirot', 'cpachecker'):
		usage(cmd)
		print "error: output format (%s) not supported\n" % format
		sys.exit(2)

	sequentialise(inputfile, outputfile, format, r'-Iinclude', rounds, threads, debug, detail)


if __name__ == "__main__":
	main(sys.argv[0:])

