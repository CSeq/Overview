"""

    CSeq-ESBMC:  C Sequentialiser front-end for the ESBMC verifier

                 This small script runs CSeq.py on the given input file,
                 saves its sequentialised version and then 
                 calls ESBMC on it to perform verification.

"""


#!/usr/bin/env python
import os, sys, getopt
from time import gmtime, strftime

class colors:
    BLACK = '\033[90m'
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    NO = '\033[0m'



def rreplace(s, old, new, occurrence):
    li = s.rsplit(old, occurrence)
    return new.join(li)


def usage():
    print "CSeq-ESBMC:   verification front-end for multi-thread C code based on CSeq and ESBMC\n"
    print "Usage:"
    print "   -h, --help    display this help screen\n"
    print "   -t<X>, --threads<X>    set maxthread for the sequentialisation (default: 5)"
    print "   -r<X>, --rounds<X>    set maxround for the sequentialisation (default: 10)"
    print "   -u<X>, --unwind<X>    set loop unwinding parameter (default: 12)"
    print "   -i<filename>, --input=filename   read input from the filename\n"
    print "   -o<filename>, --output=filename   write output to the filename\n"
    print "   example:  -i input-c-file.c -t3 -r 6 -u25\n"


def main(args):
    ''' 1. Check command-line options
    '''
    try:
        opts, args = getopt.getopt(sys.argv[1:], "hi:u:t:r:", ["help", "input=", "unwind=", "threads=","rounds="])
    except getopt.GetoptError, err:
        # print help information and exit:
        usage()
        print "error: " +str(err) # will print something like "option -a not recognized"
        sys.exit(2)

    inputfile = ''
    unwind = ''
    threads = ''
    rounds = ''

    for o, a in opts:
        if o == "-v":
            verbose = True
        elif o in ("-h", "--help"):
            usage()
            sys.exit()
        elif o in ("-i", "--input"):
            inputfile = a
        elif o in ("-u", "--unwind"):
            unwind = a
        elif o in ("-t", "--threads"):
            threads = int(a)
        elif o in ("-r", "--rounds"):
            rounds = int(a)
        else:
            assert False, "unhandled option"

    if inputfile == '':
        usage()
        print "error: input file name not specified\n"
        sys.exit(2)


    # set default values if needed
    if unwind == '': unwind = 12
    if threads == '': threads = 5
    if rounds == '': rounds = 10



    ''' 2. Call CSeq and save the sequentialised file as 'SEQ_.....'
    '''
    print "\nsequentialising input file: %s...\n" % inputfile

    if '/' in inputfile: seqfile = rreplace(inputfile, '/', '/SEQ_', 1)
    else: seqfile = 'SEQ_' + inputfile

    cmdline = 'python cseq.py' + ' -i'+str(inputfile) + ' -u'+str(unwind) + ' -t'+str(threads) + ' -r'+str(rounds)
    print "command line: '%s'\n" % cmdline
    cseqanswer = os.system(cmdline + " > " +seqfile);



    ''' 3. Check that sequentialisation went fine
    if os.path.isfile(seqfile):
        myfile = open(seqfile)
        cseqAnswer = list(myfile)

        if 'UNKNOWN (code:' in cseqAnswer:
            print "UNKNOWN (see output file %s for details)\n" % seqfile
            sys.exit(-1)
    else:
        print "UNKNOWN (unable to perform sequentialisation)\n" % seqfile
        sys.exit(-1)
    '''
    logfilename = seqfile+'.LOG'


    if cseqanswer != 0:
        print "(see log file %s for details)\n" % (logfilename)
        print "(see output file %s for details)\n" % seqfile
        print colors.YELLOW + "UNKNOWN" + colors.NO
        sys.exit(-1)



    ''' 4. Run ESBMC on the sequentialised file
    '''
    print "\nverifying: " +  inputfile + " (%s)...\n" % seqfile

    options = " --64 --no-slice --unwind "+ str(unwind)+ " --inlining --no-bounds-check --no-div-by-zero-check --no-pointer-check --no-unwinding-assertions "
    cmdline = 'esbmc ' + options + seqfile + ' > ' + logfilename
    print "command line: '%s'\n" % cmdline
    os.system(cmdline)


    if os.path.isfile(logfilename):
        myfile = open(logfilename)
        esbmcAnswer = list(myfile)

        if 'VERIFICATION FAILED\n' in esbmcAnswer:
            print "(see log file %s for a counterexample)\n" % (logfilename)
            print colors.RED + "FALSE" + colors.NO
        elif 'VERIFICATION SUCCESSFUL\n' in esbmcAnswer:
            print colors.GREEN + "TRUE" + colors.NO 
        else: 
            print "(see log file %s for details)\n" % (logfilename)
            print colors.YELLOW + "UNKNOWN" + colors.NO


    

if __name__ == '__main__':
    import sys
    main(sys.argv[0:])
