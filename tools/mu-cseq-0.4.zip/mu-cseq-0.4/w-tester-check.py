#!/usr/bin/env python

"""

	CSeq-tester:  C Sequentialiser benchmark tester.
	
				  This small script runs  cseq-feeder.py  on all the files at the given path.
				 (please try  ./cseq-tester.py  for a complete list of options).


"""


import os, sys, getopt
from time import gmtime, strftime

class colors:
	BLACK = '\033[90m'
	RED = '\033[91m'
	GREEN = '\033[92m'
	YELLOW = '\033[93m'
	BLUE = '\033[94m'
	NO = '\033[0m'
'''
class colors:
	BLACK = ''
	RED = ''
	GREEN = ''
	YELLOW = ''
	BLUE = ''
	NO = '\033[0m'
'''


def usage(cmd):
	print "wSeq-tester:   verification front-end for multi-thread C code based on wSeq\n"
	print "Usage:"
	print "   -h, --help	display this help screen\n"
	#print "   -s, --skip    do not perform any sequentialisation, run the backend on the original files"
	#print "   -w<X>, --wait<X>         waiting time in seconds before killing if not done (default: 1500)\n"
	print "   -p<path>, --path=path    read test cases from the given path"
	#print "   -f<fmt>, --format=<fmt>  backend tool to use (std, esbmc, cbmc or llbmc)"
	#print "   -t<X>, --threads<X>      set maxthread for the sequentialisation (default: 5)"
	#print "   -r<X>, --rounds<X>       set maxround for the sequentialisation (default: 10)"
	print "   -u<X>, --unwind<X>                 set loop unwinding parameter (default: 12)\n"
	print "   -f<X>, --ufor<X>                   set for unwinding parameter\n"
	print "   -w<X>, --nwrites<X>                set max number of writes\n"
	print "   example:  %s -p benchmarks_set1 -w 23 --unwind 1 -f 12 -d 3800\n" % cmd


def getbackendtime(filename):
	if not os.path.isfile(filename): return '-1';

	for line in open(filename):
		if 'overall' in line:
		   return line[:line.rfind('overall')].replace(' ', '')

	return '-1'


def findStr2(filename):
	if not os.path.isfile(filename): return '-1';

	#print "ciao"+filename
	risultato=""
	for line in open(filename):
		if line.startswith("size:"):
			risultato = risultato + line[8:len(line)-11]+", "
		if line.endswith("clauses\n"):
			risultato = risultato + line[8:len(line)-9]+", "
		if line.startswith("space:"):
			risultato = risultato + line[8:len(line)-2]+", "
			#print line
		if line.endswith("peak\n"):
			risultato = risultato + line[8:len(line)-6]+", "
		if line.startswith("time:"):
			risultato = risultato + line[8:len(line)-12]+", "
		if line.endswith("backend\n"):
			risultato = risultato + line[8:len(line)-9]+", "
		if line.endswith("overall\n"):
			risultato = risultato + line[8:len(line)-9]+", "

	return risultato

def findStr(filename,correct):
	if not os.path.isfile(filename): return '-1';

	#print "ciao"+filename
	
	risultato=""
	for line in open(filename):
		#print correct +','+ line +','+ filename
		return correct +','+ line.replace(colors.YELLOW,"").replace(colors.GREEN,"").replace(colors.RED,"").replace(colors.NO,"")


def findtime(filename):
	if not os.path.isfile(filename): return '-1';

	for line in open(filename):
		if line.startswith("time:"):
		   return line

	return '-1'
	

''' Check whether the given string appears as a substring in at least one line of the given file.
'''
def check(filename, string):
	if not os.path.isfile(filename): return False

	for line in open(filename):
		if string in line:
			print '  ' + line,
			return True

	return False


def main(args):
	''' 1. Check command-line options
	'''

	cmd = args[0]

	try:
		#opts, args = getopt.getopt(sys.argv[1:], "hsp:f:u:t:r:w:", ["help", "skip", "path=", "format=", "unwind=", "threads=","rounds=", "wait="])
		opts, args = getopt.getopt(sys.argv[1:], "hp:o:x:d:u:l:v:w:P:M:B:f:b:t:s:c:l:D:z:T", ["help", "path=", "output=",  "ucheck=", "depth=", "unwind=", "mlocks=", "vlocks=", "nwrites=", "npointers=", "nmalloc=", "bitvector=", "ufor=", "bit", "threads", "spec=", "witness=", "partial-loops", "debug", "backend=","timelimit="])
	except getopt.GetoptError, err:
		# print help information and exit:
		usage(cmd)
		print "error: " +str(err) # will print something like "option -a not recognized"
		sys.exit(2)

	dontsequentialise = False

	inputpath = ''
	unwind = 1
	threads = ''
	rounds = ''
	format = 'cbmc'
	seconds = ''
	depth=4000
	locks = 3
	vlocks = 3
	ucheck=0
	ufor=17
	bit=32
	witness=""
	backend=""
	partialLoops = 0	
	nwrites=24
	timelimit=0

	#Competition parameters
	unwind=1
	vlocks=6
	mlocks=7
	nwrites=6
	npointers=2 
	nmalloc=3 
	bitvector=7 
	ufor=2
	

	
	for o, a in opts:
		#if o == "-v":
		#	verbose = True
		if o in ("-c", "--witness"): witness = a
		elif o in ("-z", "--backend"): backend = a
		#elif o in ("-l", "--partial-loops"): partialLoops = 1
		elif o in ("-h", "--help"):
			usage(cmd)
			sys.exit()
		elif o in ("-s", "--spec"): spec = a
		elif o in ("-p", "--path"):
			inputpath = a
		#elif o in ("-f", "--format"): format = a
		elif o in ("-u", "--unwind"):
			unwind = a
		elif o in ("-t", "--threads"):
			threads = int(a)
		elif o in ("-r", "--rounds"):
			rounds = int(a)
		elif o in ("-l", "--mlocks"): mlocks = a
		elif o in ("-v", "--vlocks"): vlocks = a
		elif o in ("-x", "--ucheck"): ucheck = int(a)
		elif o in ("-w", "--nwrites"): nwrites = int(a)
		elif o in ("-P", "--npointers"): npointers = int(a)
		elif o in ("-M", "--nmalloc"): nmalloc = int(a)
		elif o in ("-B", "--bitvector"): bitvector = int(a)
		elif o in ("-d", "--depth"): depth = int(a)
		elif o in ("-f", "--ufor"): ufor = int(a)
		elif o in ("-t", "--threads"): threads = int(a)
		elif o in ("-T", "--timelimit"): timelimit = int(a)
		elif o in ("-b", "--bit"): bit = int(a)
		'''
		elif o in ("-w", "--wait"):
			seconds = a
		else:
			assert False, "unhandled option"

		'''
	if timelimit==0:
		timelimit=3000
	
	
	#print "backend="+backend
	#sys.exit(2)
	
	
	# Validation of command-line parameters
	if inputpath == '':
		usage(cmd)
		print "error: path for input test cases not specified\n"
		sys.exit(2)

	if not os.path.isdir(inputpath):
		usage(cmd)
		print "error: the given path (%s) for input test cases does not exist\n" % inputpath
		sys.exit(2)
	'''
	if format not in ('std', 'esbmc', 'cbmc', 'llbmc', 'cpachecker'):
		usage(cmd)
		print "error: output format (%s) not supported\n" % format
		sys.exit(2)
	'''
	# Set default values if needed
	if unwind == '': unwind = 1
	if threads == '': threads = 5
	if rounds == '': rounds = 10
	if format == '': format = 'esbmc'
	if seconds == '': seconds = 600
	if nwrites == '': nwrites = 25


	if inputpath.endswith('/'): directory = inputpath[:-1]
	else: directory = inputpath


	# print "path: " + "./"+directory.rsplit('/', 1)[0]

	# if directory not in os.listdir("./"+directory.rsplit('/', 1)[0]):
	#	print "The path  '%s'  cannot be reached from the current path.\n" % directory
	#	return

	# delete the old files from the previous sequentialisation
	logfilename = directory + '.' + format + ".log"
	csvlogfilename = directory + '.' + format + ".csv"

	os.system('rm ' + directory + '/_cs_* 2> /dev/null')
	os.system('rm ' + directory + '/*.strip.c 2> /dev/null')
	os.system('rm ' + directory + '/*.c.* 2> /dev/null')
	os.system('sync')
	os.system('rm ' +logfilename + ' 2> /dev/null')
	os.system('rm ' +csvlogfilename + ' 2> /dev/null')

	# Open a file
	fd = os.open( logfilename, os.O_RDWR|os.O_CREAT )
	csv_fd = os.open( csvlogfilename, os.O_RDWR|os.O_CREAT )

	os.write(fd, "Log started")
	os.write(fd, strftime("  %Y-%m-%d %H:%M:%S", gmtime()) +'\n')

	new_csv_entry = 'filename, var, cla, spa, peak, pre, back, over, res\n'
	#print new_csv_entry
	os.write(csv_fd, new_csv_entry)

	''' 2. Verifying files...
	'''
	#print '\n	  verifying  *.c & *.i in  %s/\n' % directory

	os.system('rm ' + directory + '/*.LOG 2> /dev/null')
	os.system('rm ' + directory + '/:* 2> /dev/null')

	#parameters = " --nwrites %s --unwind %s --ucheck %s -f %s -z %s --ufor %s -b %s" % (nwrites, unwind, ucheck, format, depth, ufor, bit)
	#parameters = " -w %s --unwind %s --depth %s -f %s -l %s -v %s -b %s" % (nwrites, unwind, depth, ufor, locks, vlocks, bit)
	#parameters = "  --spec %s --unwind %s --vlocks %s --mlocks %s --nwrites %s --npointers %s --nmalloc %s --bitvector %s --ufor %s" % (spec,unwind, vlocks, mlocks, nwrites, npointers, nmalloc, bitvector,ufor)
	#competition parameters 2016
	parameters = "  --spec %s " % (spec)

	#print parameters
	
	
	if dontsequentialise == True: parameters += " -s"
	
	os.write(fd, "parameters: %s\n\n" % parameters);

	
	
	lst = os.listdir(inputpath)
	lst.sort()
	
	for file in lst:
		#if file.endswith('.c') or file.endswith('.i'):
		if file.endswith('.i'):
		#if file.endswith('.i') and file.find('true')>=0:
			filename = directory+'/'+file
			logfilename = filename+'.LOG'

			#cmdline = "timeout %s ./museq-feeder.py -i %s %s -t %s --spec %s --witness %s" % (seconds, filename, parameters,threads, spec, witness)
			#cmdline = "timeout %s ./museq-feeder.py -i %s --spec ALL.spc --witness log.txt -w25 -f%s -u%s --depth %s" % (seconds, filename, ufor, unwind, depth)
			#cmdline = "./mu-seq-wrapper.py -T600 -M10000 -t%s -u%s -w%s -i %s --backend %s" % (threads,unwind,nwrites,filename,backend) 
			#######cmdline = "./mu-seq-wrapper.py -T600 -M10000 --depth %s -f12 -t5 -u1 -w23 --MaxThreadCreate 3 -i %s --spec %s" % (depth,filename,spec) 
			#cmdline = "./	py -i %s --spec %s -w10 -l15 -u3 -b 5" % (filename,spec) 
			cmdline = "./mu-cseq.py -i %s %s" % (filename,parameters) 
			print cmdline
			#cmdline = "./mu-cseq.py -i %s" % (filename) 
			#cmdline = "./cseq-original.py -i %s  %s" % (filename,parameters) 
			#sys.exit(2)
			#cmdline = "timeout %s ./mu-cseq.py -i %s --spec %s --witness %s" % (seconds, filename, spec, witness)
			if partialLoops==1:
				cmdline += " --partial-loops"
			cmdline += ' > ' + logfilename
			#print cmdline
			
			
			os.write(fd, "	  /" +strftime("  %Y-%m-%d %H:%M:%S", gmtime()))
			#print '	  verifying  %s...' % filename
			os.write(fd, '\n	 |  verifying  %s...\n' % filename)

			#print "	  cmdline: %s" % cmdline




			#time ./cseq-original.py --unwind 3 --vlocks 7 --mlocks 7 --nwrites 7 --npointers 5 --nmalloc 2 --bitvector 32 -i ../svcomp2015-cfiles/pthread-ext/25_stack_false_longest.c

			os.system(cmdline)
			'''
			myfileParameters = open("./parametri.txt","r")
			data = myfileParameters.read()
			if "schema a" in data:
				print "schema a: "+filename
			else:
				print "schema b: "+filename

			continue
			'''
			success = ''

			if check(logfilename, colors.RED+'FALSE') == True:
				os.write(fd, "	 |  "+ colors.RED + "FAIL: " + colors.NO + filename +'\n') 
				success = 'FALSE'
			elif check(logfilename, colors.GREEN+'TRUE') == True:
				os.write(fd, "	 |  "+ colors.GREEN  + "SUCC: " + colors.NO + filename + '\n')
				success = 'TRUE'
			else:
				os.write(fd, "	 |  "+ colors.YELLOW + "UNKNOWN: " +  colors.NO + filename + '\n')
				success = 'UNKNOWN'

			#testingtime = "	 |  time: " + getbackendtime(logfilename) 
			testingtime = "	 |  " + findtime(logfilename) 
			if not testingtime.endswith('\n'): testingtime += '\n'
			testingtime1 = testingtime[13:len(testingtime)-12]
			
			
			os.write(fd, testingtime)
			os.write(fd, "	  \\" +strftime("  %Y-%m-%d %H:%M:%S", gmtime()) +'\n\n')

			#new_csv_entry = file + ', ' + getbackendtime(logfilename) + ', ' + success + '\n'
			correct="FAILED"
			if (logfilename.find("false")>=0 and success=='FALSE') or (logfilename.find("true")>=0 and success=='TRUE') :
				correct="PASS"
			new_csv_entry = findStr(logfilename, correct)
			#print new_csv_entry
			os.write(csv_fd, new_csv_entry)

			if correct=="FAILED":
				print colors.RED
			else:
				print colors.GREEN
			print correct+colors.NO+"\n"

			



if __name__ == '__main__':
	import sys
	main(sys.argv[0:])
