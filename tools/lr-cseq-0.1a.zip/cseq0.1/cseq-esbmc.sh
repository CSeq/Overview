#!/bin/bash

args=("$@")
python cseq-esbmc.py -i ${args[0]} -t5 -u20 -r6
