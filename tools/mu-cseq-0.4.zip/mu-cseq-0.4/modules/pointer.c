
intV address[NumVars];//ordinati strett. crescente;


//void Write_ptr(__CS_typeV codeVar, intV offset, intV val){
void Write_ptr(intV addr, intV val){
	//intV addr = Read(codeVar)+offset;
	__CS_typeV pos;
	__CPROVER_assume(pos<NumVars);
	__CPROVER_assume(address[pos]==addr);
	Write(pos, val);
//	__CPROVER_assume((address[pos] <= addr) && (addr < address[pos+1]));
//	if (address[pos] == addr ) Write(pos, val);
	
	
}

//intV Read_ptr(__CS_typeV codeVar, intV offset){
intV Read_ptr(intV addr){
	//intV addr = Read(codeVar)+offset;
	__CS_typeV pos;
	__CPROVER_assume(pos<NumVars);
	__CPROVER_assume(address[pos]==addr);
	intV valueRet=Read(pos);
	//return Read(pos);
	return valueRet;
}
