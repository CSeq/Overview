#!/usr/bin/env python
'''
    Lazy-CSeq 1.1
    SV-COMP 2017 wrapper script

'''
import sys, getopt, os.path, shlex, subprocess, time
import core.utils as utils

svcompparams = []
svcompparams.append('--time=120  --svcomp --stop-on-fail --depth=1400  --unwind-for=1  --unwind-while=1 --unwind-for-max=50 --softunwindbound --rounds=2 -l lazy')
svcompparams.append('--time=90 --svcomp --stop-on-fail --depth=350 --unwind-for=2  --unwind-while=2 --rounds=2 -l lazy')
svcompparams.append('--time=60  --svcomp --stop-on-fail --depth=250 --unwind-for=16 --unwind-while=3 --rounds=1 -l lazy')
svcompparams.append('--time=90  --svcomp --stop-on-fail --depth=500 --softunwindbound --unwind-while=1 --unwind-for-max=11 --rounds=11 --norobin -l lazy')
svcompparams.append('--time=240 --svcomp --stop-on-fail --depth=560 --softunwindbound --unwind-while=1 --unwind-for=2 --unwind-for-max=3 --rounds 4 -l lazy')

def usage(cmd, errormsg):
    print "Lazy-Cseq SV-COMP'17 wrapper script\n"
    print " Usage:"
    print "   -h, --help                            display this help screen"
    print ""
    print "   -i<filename>, --input=<filename>      read input from the filename"
    print "   -s<specfile>, --spec=<specfile>       SV-COMP specfile (default:ALL.prp)"
    print "   -w<logfile>, --witness=<logfile>      counterexample output file (default:a.log)"
    print "   -V, --version                         print version"
    print '\n' + errormsg + '\n'
    sys.exit(1)


def main(args):
    realstarttime = time.time()    # save wall time
    cmd = args[0]

    try:
        opts, args = getopt.getopt(sys.argv[1:], "hi:s:w:V", ["help", "input=", "spec=", "witness=", "version"])
    except getopt.GetoptError, err:
        print "error"
        usage(cmd, 'error: ' +str(err))

    inputfile = spec = witness = ''

    for o, a in opts:
        if o == "-v": verbose = True
        elif o in ("-h", "--help"): usage(cmd, "")
        elif o in ("-w", "--witness"): witness = a
        elif o in ("-s", "--spec"): spec = a
        elif o in ("-i", "--input"): inputfile = a
        elif o in ("-V", "--version"):
            print "1.0-svcomp17"
            sys.exit(0)
        else: assert False, "unhandled option"

    # Check parameters
    if inputfile == '':
        print 'error: input file name not specified'
        sys.exit(1)

    if not os.path.isfile(inputfile):
        print 'error: unable to open input file (%s)' % inputfile
        sys.exit(1)

    if witness == '': witness = inputfile + '.log'

    if spec == '': spec = 'ALL.prp'

    # if not os.path.isfile(spec):
    #     print 'error: unable to open spec file (%s)' % spec
    #     sys.exit(1)

    # Start the algorithm
    last = ''
    for params in svcompparams:
        cmdline = './cseq.py %s --input %s --witness %s' % (params, inputfile, witness)
        # print cmdline

        if last == 'FALSE':
            # print '0.00,',
            continue
        try:
            p = subprocess.Popen(shlex.split(cmdline), stdout=subprocess.PIPE)
            out, err = p.communicate()

            # Only get the last line
            out = out.splitlines()[-1]
            out = out.replace(utils.colors.BLINK, '')
            out = out.replace(utils.colors.GREEN, '')
            out = out.replace(utils.colors.DARKRED, '')
            out = out.replace(utils.colors.RED, '')
            out = out.replace(utils.colors.BLACK, '')
            out = out.replace(utils.colors.NO, '')

            # lasttime = float(out[out[:out.rfind(', ')].rfind(", ") + 2:out.rfind(', ')].strip())
            # str = '%2.2f,' % float(lasttime)
            # print str,

            if 'UNSAFE' in out:
                last = 'FALSE'
                continue
            elif 'SAFE' in out: last = 'TRUE';
            elif 'TIMEOUT' in out: last = 'TRUE';
            else: last = 'UNKNOWN';

        except subprocess.CalledProcessError, err:
            last = 'UNKNOWN';
            continue

    # # Check that the filename matches verification outcome.
    # verdict = utils.colors.YELLOW +'--'+ utils.colors.NO
    # if last != 'UNKNOWN':
    #     if ('_false' in inputfile or '_unsafe' in inputfile) and last == 'TRUE':
    #         verdict = utils.colors.RED +'ko'+ utils.colors.NO
    #     elif ('_true' in inputfile or '_safe' in inputfile) and last == 'FALSE':
    #         verdict = utils.colors.RED +'ko'+ utils.colors.NO
    #     else:
    #         verdict = utils.colors.GREEN +'ok'+ utils.colors.NO
    # print "%s, %s, %s, %2.2f" % (verdict, last, inputfile, (time.time() - realstarttime))

    # Uncomment below line to get final results
    print "%s, %s, %2.2f" % (last, witness, (time.time() - realstarttime))


if __name__ == "__main__":
    main(sys.argv[0:])

