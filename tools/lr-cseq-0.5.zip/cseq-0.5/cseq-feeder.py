#!/usr/bin/env python

"""

	CSeq-feeder:  C Sequentialiser front-end for the ESBMC/CBMC/LLBMC/.. verifiers.
			  	 (Nov. 2012: extended version to handle .i preprocessed files in addition to .c files)
				 (Dec. 2012: last version to handle multiple back-end rather than ESBMC only)
				 (Jan. 2013: fine-tuning of back-end options, --skip option)
                 (May  2013: detecting insufficient maxthread parameter, CBMC-only)

				  This small script runs  cseq.py  on the given input file,
				  saves its sequentialised version and then 
				  feeds it to the specified tool to perform verification.
				 (please try  ./cseq-feeder.py  for a complete list of options).


"""

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                  Options & parameters below. 

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
# Name of the executable file to run, by backend.
backendFilename = {}
backendFilename['esbmc'] = 'esbmc'
backendFilename['cbmc'] = 'cbmc'
backendFilename['llbmc'] = 'llbmc'

# Command-line parameters, by backend.
cmdLineOptions = {};
# 2600s cmdLineOptions['esbmc'] = '--64  --no-slice --no-bounds-check --no-div-by-zero-check --no-pointer-check --no-unwinding-assertions'
cmdLineOptions['esbmc'] = '--no-slice --no-bounds-check --no-div-by-zero-check --no-pointer-check --no-unwinding-assertions --z3-ir '

# 1600 cmdLineOptions['esbmc'] = '--64 --no-slice --inlining --no-bounds-check --no-div-by-zero-check --no-pointer-check --no-unwinding-assertions'
cmdLineOptions['cbmc'] = '--no-unwinding-assertions'
cmdLineOptions['llbmc'] = '-no-max-function-call-depth-checks -no-memory-free-checks -no-shift-checks -no-memcpy-disjoint-checks -no-memory-access-checks -no-memory-allocation-checks --no-max-loop-iterations-checks --ignore-missing-function-bodies -no-overflow-checks -no-div-by-zero-checks'

# Expressions to check for from the log to check whether verification went fine.
verificationOK = {}
verificationOK['esbmc'] = 'VERIFICATION SUCCESSFUL\n'
verificationOK['cbmc'] = 'VERIFICATION SUCCESSFUL\n'
verificationOK['llbmc'] = 'No error detected.\n'
verificationOK['cpachecker'] = 'Verification result: SAFE. No error path found by chosen configuration.\n'

# Expressions to check for from the log to check whether verification failed.
verificationFAIL = {}
verificationFAIL['esbmc'] = 'VERIFICATION FAILED\n'
verificationFAIL['cbmc'] = 'VERIFICATION FAILED\n'
verificationFAIL['llbmc'] = 'Error detected.\n'
verificationFAIL['cpachecker'] = 'Verification result: UNSAFE. Error path found by chosen configuration.\n'




'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                  Nothing to set past this point.

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
import os, sys, getopt, time

from time import sleep
from threading import Timer

from time import gmtime, strftime

import signal
import sys


class colors:
	BLACK = '\033[90m'
	RED = '\033[91m'
	GREEN = '\033[92m'
	YELLOW = '\033[93m'
	BLUE = '\033[94m'
	NO = '\033[0m'

'''
def hello():
	global timer_count
	global t

	t = Timer(1.0, hello)
	t.start()

	if timer_count == 0:
		print "       ",
		timer_count += 1
		sys.stdout.flush()
	elif timer_count <= 3:
		print ".",
		timer_count += 1
		sys.stdout.flush()
	else:
		print "\n"
		timer_count = 0;
		sys.stdout.flush()


timer_count = 0
t = Timer(1.0, hello)
'''


'''
def signal_handler(signal, frame):
	t.cancel()
	sys.exit(0)
'''


def rreplace(s, old, new, occurrence):
	li = s.rsplit(old, occurrence)
	return new.join(li)


def usage(cmd):
	print "CSeq-Feeder:   verification front-end for CSeq\n"
	print "Usage:"
	print "   -h, --help                         display this help screen\n"
	print "   -s, --skip                         do not sequentialise, run the backend on the original file"
	print "   -d, --detail                       output detail of error condition (cbmc-only)"
	print "   -c, --cex                          output counterexample from backend\n"
	print "   -i<filename>, --input=<filename>   read input from given filename"
	print "   -o<filename>, --output=<filename>  write output to given filename"
	print "   -f<fmt>, --format=<fmt>            output file format (std, esbmc, cbmc or llbmc)"
	print "   -t<X>, --threads<X>                set maxthread for the sequentialisation (default: 5)"
	print "   -r<X>, --rounds<X>                 set maxround for the sequentialisation (default: 10)"
	print "   -u<X>, --unwind<X>                 set loop unwinding parameter (default: 12)\n"
	print "   example:  %s -i input-c-file.c -t3 -r 6 -u25\n" % cmd



''' 
	strip()  -  Strips every line in the given string
				from the line with 'startmarker' as substring
				to the one with 'endmarker' as substring.

				Lines are identified by '\n'
'''
def strip(s, startmarker, endmarker):
	s2 = ''
	status = 0

	for line in s:
		if line.startswith(startmarker) and status == 0:
			print "start marker found\n"
			status = 1
			continue;

		if line.endswith(endmarker) and line.startswith(startmarker) and status == 1:
			print "end marker found\n"
			status = 2
			continue;

		if status == 0 or status == 2: s2 += line + '\n'

	return s2


''' Check whether a file starts with 'string'
'''
def fileStartsWith(filename, string):
	if os.path.isfile(filename):
		myfile = open(filename)
		lines = list(myfile)

		if lines[0].startswith(string): return True
		else: return False

	else: return False

	return False


''' Check whether a file contains at least one occurrence of 'string' in any of its lines
'''
def fileContains(filename, string):
	if os.path.isfile(filename):
		myfile = open(filename)
		lines = list(myfile)

		for line in lines:
			if string in line: return True
	else: return False

	return False


''' For now, we assume that if the input file contains "__attribute__ ((",
	it is in (.i) preprocessed format rather than in plain (.c) format.
'''
def isPreprocessed(filename):
	return fileContains(filename, "__attribute__ ((")


def stripIfNeeded(filename):
	stripped = False
	'''
	if isPreprocessed(inputfile):
		print "il file %s e' un file (.i)\n" % inputfile
	else:
		print "il file %s non e' un file (.i)\n" % inputfile

	
	if fileStartsWith(inputfile, '# '):
		print "il file %s comincia con '# '\n" % inputfile
	else:
		print "il file %s non comincia con '# '\n" % inputfile	
	'''

	if isPreprocessed(filename):
		if fileStartsWith(filename, '# '):
			# delete every line from the top of the file to 
			# the very last line starting with '# '
			myfile = open(filename)
			allLines = list(myfile)

			##print "LINE %d %s\n" %(i, allLines[i])

			for i in range(len(allLines)):
				stillLinesWithDash = False

				# are there any more lines from the i-th on which start with '# '?
				for j in range(i, len(allLines)):
					if allLines[j].startswith('# '):
						stillLinesWithDash = True
						break

				if stillLinesWithDash == False:
					# copy all the remaining lines in a file
					out_file = open(filename+'.c',"w")

					for j in range(i, len(allLines)):
						out_file.write(allLines[j])

					out_file.close()
					stripped = True
					break
		else:
			# delete every line from the top of the file to 
			# the very last line starting with 'extern ',
			# then keep deleting until the fist line ending with ';' is reached 
			myfile = open(filename)
			allLines = list(myfile)

			for i in range(len(allLines)):
				stillLinesWithExtern = False

				# are there any more lines from the i-th on which start with 'extern '?
				for j in range(i, len(allLines)):
					if allLines[j].startswith('extern '):
						stillLinesWithExtern = True
						break

				if stillLinesWithExtern == False:
					# copy all the remaining lines in a file
					out_file = open(filename+'.c',"w")
					out_file.write("#include <pthread.h>")

					lastStatementStripped = False # the last statement to strip can have multiple lines

					for j in range(i, len(allLines)):
						if not lastStatementStripped:   # skip until the first ';'
							if not allLines[j].endswith(';\n'):
								lastStatementStripped = True
								continue

						if ')) __attribute__ ((' not in allLines[j]:
							out_file.write(allLines[j])

					out_file.close()
					stripped = True
					break
	return stripped



def main(args):
	### signal.signal(signal.SIGINT, signal_handler)


	''' 1. Check command-line options
	'''
	cmd = args[0]

	try:
		opts, args = getopt.getopt(sys.argv[1:], "hdsci:f:u:t:r:", ["help", "detail", "skip", "cex", "input=", "format=", "unwind=", "threads=","rounds="])
	except getopt.GetoptError, err:
		# print help information and exit:
		usage(cmd)
		print "error: " +str(err) # will print something like "option -a not recognized"
		sys.exit(2)

	inputfile = format = seconds = ''
	unwind = threads = rounds = 0
	
	dontsequentialise = False
	outputcounterexample = False
	outputdetail = False

	for o, a in opts:
		if o == "-v": verbose = True
		elif o in ("-h", "--help"):
			usage(cmd)
			sys.exit()
		elif o in ("-d", "--detail"): outputdetail = True
		elif o in ("-s", "--skip"): dontsequentialise = True
		elif o in ("-c", "--cex"): outputcounterexample = True
		elif o in ("-i", "--input"): inputfile = a
		elif o in ("-f", "--format"): format = a
		elif o in ("-u", "--unwind"): unwind = a
		elif o in ("-t", "--threads"): threads = int(a)
		elif o in ("-r", "--rounds"): rounds = int(a)
		else: assert False, "unhandled option"

	if inputfile == '':
		usage(cmd)
		print "error: input file name not specified\n"
		sys.exit(2)

	# set default values if needed
	if unwind == 0: unwind = 12
	if threads == 0: threads = 5
	if rounds == 0: rounds = 10
	if format == '': format = 'cbmc'


	''' 1'. Intermediate step - if the filename ends with .i, then the file has to be stripped
								and transformed back into a .c file in order to get properly
								parsed with PYCparser 
	'''
	if '/' in inputfile: seqfile = rreplace(inputfile, '/', '/_cs_', 1)
	else: seqfile = '_cs_' + inputfile

	### stripped = stripIfNeeded(inputfile)
	### if stripped: inputfile = inputfile + '.c'

	logfilename = seqfile + '.log'



	''' 2. Call CSeq and save the sequentialised file as '_cs_.....'
	'''
	print ("\ninput:  %s") % (inputfile)

	cmdline = 'python cseq.py' + ' -i '+str(inputfile) + ' -t'+str(threads) + ' -r'+str(rounds) + ' -f'+format
	if outputdetail: cmdline += ' -d'
	cseqanswer = os.system(cmdline + " > " +seqfile);

	##printit()



	''' 3. Check that sequentialisation went fine
	if os.path.isfile(seqfile):
		myfile = open(seqfile)
		cseqAnswer = list(myfile)

		if '
NOWN (code:' in cseqAnswer:
			print "UNKNOWN (see output file %s for details)\n" % seqfile
			sys.exit(-1)
	else:
		print "UNKNOWN (unable to perform sequentialisation)\n" % seqfile
		sys.exit(-1)
	'''

	if cseqanswer != 0:
		print "       (unable to sequentialise input file  -  see output from CSeq below for details)\n"
		print colors.BLACK + '-----------------------------------------------------------------'
		with open(seqfile) as file:
			data = file.read()
			print data
		print '-----------------------------------------------------------------' + colors.NO + '\n'
		
		print colors.YELLOW + "        UNKNOWN\n" + colors.NO
		sys.exit(-1)

	''' 4. Run the verification tool (from the command-line option -f) on the sequentialised file
	'''
	print ("output: %s") % (seqfile)

	if dontsequentialise == True:
		seqfile = inputfile
		print "\nnote!  --skip  option used, no sequentialisation will be verified!" 
	
	print "log:    %s\n" % (logfilename)
	print "start:  %s\n" % (strftime("%Y-%m-%d %H:%M:%S", gmtime()))

	##t.start()
	start_time = time.time()  # Save the time.

	if dontsequentialise == False: # normal behaviour (no --skip)
		if format == 'esbmc':
			cmdline =  backendFilename[format] + ' --unwind '+ str(unwind)+ ' ' + cmdLineOptions[format] + ' ' + seqfile + ' > ' + logfilename
		elif format == 'cbmc':
			cmdline = backendFilename[format] + ' --unwind '+ str(unwind)+ ' ' + cmdLineOptions[format] + ' ' + seqfile + ' > ' + logfilename
		elif format == 'llbmc':
			# note: there are two different statements here,
			#  (1) for Clang to generate llvm code, and
			#  (2) for llbmc to perform model-checking
			cmdline = "clang -c -g -I. -emit-llvm %s -o %s.bc 2> %s; " % (seqfile, seqfile, logfilename)
			cmdline += backendFilename[format] + ' --max-loop-iterations=' + str(unwind) + ' ' + cmdLineOptions[format] + ' ' + seqfile +'.bc' + ' 1> ' + logfilename

		elif format == 'cpachecker':
			options = ' -predicateAnalysis  -spec ErrorLabel.spc '
			cmdline = 'scripts/cpa.sh ' + options + seqfile + ' > ' + logfilename 
	'''
	else: # add error label reachability check when performing verification on non-sequentialised code (--skip used)
		if format == 'esbmc':
			options = "  --error-label ERROR --64 --no-slice --unwind "+ str(unwind)+ " --inlining --no-bounds-check --no-div-by-zero-check --no-pointer-check --no-unwinding-assertions "
			cmdline = 'esbmc ' + options + seqfile + ' > ' + logfilename
		elif format == 'cbmc':
			options = ' --no-unwinding-assertions --unwind ' + str(unwind) + ' '
			options = ' --error-label ERROR --no-unwinding-assertions --unwind ' + str(unwind) + ' '
			cmdline = ' cbmc ' + options + seqfile + ' > ' + logfilename
		elif format == 'llbmc':
			options = ' --ignore-missing-function-bodies -no-overflow-checks -no-div-by-zero-checks --max-loop-iterations=' + str(unwind) + ' '
			cmdline = "clang -c -g -I. -emit-llvm %s -o %s.bc; " % (seqfile, seqfile)
			cmdline += ' llbmc '  +options + seqfile  +'.bc' + ' > ' + logfilename
	'''
	## print "command line: '%s'\n" % cmdline
	os.system(cmdline)

	##timer_count = -1;	

	if os.path.isfile(logfilename):
		myfile = open(logfilename)
		backendAnswer = list(myfile)

		print "time:   %0.2fs\n" % (time.time() - start_time)

 		if verificationFAIL[format] in backendAnswer:
			if   '  assertion __CS_error_detail != __ERR_MAXTHREADS_REACHED\n' in backendAnswer:
				print                 "       (too many threads, try either increasing value for -t parameter or disabling maxthread check)"
				print colors.YELLOW + "        UNKNOWN" + colors.NO
			elif '  assertion __CS_error_detail != __ERR_ERROR_LABEL_REACHED\n' in backendAnswer:
				print                 "       (error label reachable)"
				print colors.RED + "        UNSAFE" + colors.NO
			elif '  assertion __CS_error_detail != __ERR_ASSERT_FAILURE\n' in backendAnswer:
				print                 "       (assertion failure reachable)"
				print colors.RED + "        UNSAFE" + colors.NO
			elif '  assertion __CS_error_detail != __ERR_UNLOCK_ATTEMPT\n' in backendAnswer:
				print                 "       (mutex unlock failure)"
				print colors.RED + "        UNSAFE" + colors.NO
			elif '  assertion __CS_error_detail != __ERR_JOIN_FAILED_WRONG_THREAD_ID\n' in backendAnswer:
				print                 "       (thread join failure: thread id out of range)"
				print colors.RED + "        UNSAFE" + colors.NO
			elif '  assertion __CS_error_detail != __ERR_JOIN_FAILED_THREAD_NOT_CREATED\n' in backendAnswer:
				print                 "       (thread join failure: thread not created, also try increasing value for -t parameter)"
				print colors.RED + "        UNSAFE" + colors.NO
			elif '  assertion __CS_error_detail != __ERR_COND_WAIT_MUTEX_NOT_OWNED\n' in backendAnswer:
				print                 "       (conditional wait error: mutex not owned by the current thread)"
				print colors.RED + "        UNSAFE" + colors.NO
			else:
				print colors.RED + "        UNSAFE" + colors.NO
		elif verificationOK[format] in backendAnswer:
			print colors.GREEN + "        SAFE" + colors.NO 
		else: 
			print colors.YELLOW + "        UNKNOWN" + colors.NO

	print ''

	if outputcounterexample:
		with open(logfilename) as file:
			data = file.read()
			print data
		

if __name__ == '__main__':
	import sys
	main(sys.argv[0:])





