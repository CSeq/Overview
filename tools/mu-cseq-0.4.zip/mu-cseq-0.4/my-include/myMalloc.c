intV mallocP[NumMalloc+1];  //in mallocP[NumMalloc]=bigNumber
_Bool mallocPallocated[NumMalloc];


intV MyMalloc(intV size){
	__CS_typeV pos;
	__CPROVER_assume(pos<NumMalloc);
	__CPROVER_assume(!mallocPallocated[pos] 
				&&	(mallocP[pos]+size < mallocP[pos+1])
				);
	mallocPallocated[pos]=1;
	return (mallocP[pos]);	
}

void MyFree(__CS_typeV codeVar){
	intV addr = Read(codeVar);
	__CS_typeV pos;
	__CPROVER_assume(pos<NumMalloc);
	__CPROVER_assume(mallocPallocated[pos] 
				&&	(mallocP[pos] == addr)
				);
	mallocPallocated[pos]=0;
	Write(codeVar,0);
}
