""" CSeq Workarounds module
    written by Omar Inverso, University of Southampton.
    maintained by Truc Nguyen Lam, University of Southampton.
"""
VERSION = 'workaround-0.1-2016.11.13'
# VERSION = 'workaround-0.0-2015.01.13'
# VERSION = 'workaround-0.0-2015.01.13'
# VERSION = 'workaround-0.0-2014.12.24'  # CSeq-1.0beta
# VERSION = 'workaround-0.0-2014.10.26'   # CSeq-Lazy-0.6: newseq-0.6a, newseq-0.6c, SVCOMP15
# VERSION = 'workaround-0.0-2014.10.09'
# VERSION = 'workaround-0.0-2014.06.05' (CSeq-Lazy-0.4)
# VERSION = 'workaround-0.0-2014.03.14' (CSeq-Lazy-0.3)
# VERSION = 'workaround-0.0-2014.02.25' (CSeq-Lazy-0.2)
"""

    In this module are performed all the code transformations needed as workarounds to known backend bugs/issues, or
    useful transformations to make the code more simple and meet assumptions of modules invoked later
    (later modules can thus avoid to handle the full C syntax)

    Transformation 2 (ESBMC 1.21.1 bug - not implemented yet, TODO)
       (x >= k)  --> (x == k || x >= k+1)

    Transformation 3 (to avoid problem with strict syntax checking by some backend)
            insert (void *) argument to thread prototypes when missing, for example:
            void *thread()  --> void *thread(void *)

    Transformations inherited from old merger (light pre-processing to avoid corner-cases):
        - add brackets to single-statements blocks

        - split declaration of variables of the same kind:
            int x,y; --> int x; int y;

        - split declaration of local variables + init value to two separate statements:
            int x = value; --> int x; x = value;
            
          (there are few exceptions see in the code, serach for initType)


        - remove  if(!1) { .. }  and  if(0) { .. }

        - assign a name to anonymous structures:
            struct { int f1; char f2; ... }    -->   struct __anon_0 { int f1; char f2; ... }

        - remove (void *) 0 --> 0

        - change do {stmts} while (0) --> stmts

    Transformation 4:
        structure->field            -->     (*structure).field
        structure->field->field     -->   (*(*structure).field).field    TODO: test/check this one properly

    Transformation 5:
        __cz_thread_local_variablename --> variablename[pthread_self()]

    Transformation 6:
        remove auto,inline,volatile,register from beginning of declarations.

    Transformation 7:
        remove (whatever cast) before thread function in `pthread_create` call

    Transformation 8:
        fix PTHREAD_MUTEX_INITIALIZER     initialization
            PTHREAD_COND_INITIALIZER
            PTHREAD_RWLOCK_INITIALIZER
            
         
     Transformation 10:
         see if there's any mutexattr

Changelog:
    2016.11.18  bugfixes for svcomp 2017, add workarounds 7 and 8
    2015.01.13  bugfixes
    2014.12.09  further code refactory to match the new organisation of the CSeq framework
    2014.10.26  structure dereference workaround (transformation 4)
    2014.10.09  moved in this module all the transformations from  merger.py
    2014.06.05  added workaround #3 (see above)
    2014.02.25  switched to  module.Module  base class for modules
"""

import inspect, os, sys, getopt, time
import pycparser.c_parser, pycparser.c_ast, pycparser.c_generator
import core.common, core.module, core.parser, core.utils

#from pycparser import c_ast

class workarounds(core.module.Translator):
    __threadLocals = []
    finished_stripping_stuff = False

    __parsingFunction = ''
    currentAnonStructsCount = 0  # counts the number of anonymous structures (used to assign consecutive names)

    def visit_Cast(self, n):
        ''' Remove cast to NULL pointer in C
        '''
        s = '(' + self._generate_type(n.to_type) + ')'
        s += ' ' + self._parenthesize_unless_simple(n.expr)
        if s == '(void *) 0': s = '0'
        return s

    def visit_ID(self, n):
        if n.name in self.__threadLocals:
            return '__cz_thread_local_' + n.name + '[__cs_thread_index]'
        else:
            return n.name
            
    def visit_FileAST(self, n):
        self.any_mutexattr = False
        ans = super().visit_FileAST(n) # + "\n" + self.visit_FuncDef(self.mainNode, visitMain = True)
        return "_Bool __cs_uses_mutexattr = " + ("1" if self.any_mutexattr else "0") + ";\n"+ ans

    def visit_FuncDef(self, n):
        self.__parsingFunction = n.decl.name

        decl = self.visit(n.decl)

        # Remove static declaration of function
        if decl.startswith('static '): decl = decl[7:]

        # workaround #3: insert (void *) argument to thread prototypes when missing
        if n.decl.name in self.Parser.threadName and (decl.endswith('()') or decl.endswith('(void)')):
            decl = decl[:decl.rfind('(')] + '(void *__cs_unused)'

        self.indent_level = 0
        body = self.visit(n.body)

        if n.param_decls:
            knrdecls = ';\n'.join(self.visit(p) for p in n.param_decls)
            self.__parsingFunction = ''
            return decl + '\n' + knrdecls + ';\n' + body + '\n'
        else:
            self.__parsingFunction = ''
            return decl + '\n' + body + '\n'
            
    def visit_Typedef(self, n):
        if n.name == "_____STOPSTRIPPINGFROMHERE_____":
            self.finished_stripping_stuff = True
            return super().visit_Typedef(n)
        elif self.finished_stripping_stuff and n.name in ("spinlock_t", "pthread_mutex_t", "pthread_mutexattr_t"):
            return ""
        else:
            return super().visit_Typedef(n)
            
    def visit_TernaryOp(self, n):
        if type(n.iftrue) is pycparser.c_ast.FuncCall and type(n.iftrue.name) is pycparser.c_ast.ID and n.iftrue.name.name == "reach_error":
            return "assert(!("+self.visit(n.cond)+"))"
        else:
            return super().visit_TernaryOp(n)

    def visit_FuncCall(self, n):
        fref = self._parenthesize_unless_simple(n.name)
        args = ''
        ''' Transformation 7
        '''
        assert fref != 'pthread_getspecific'
        if fref == 'pthread_create':
            # Extract the function name (passed as 3rd argument)
            fName = ''
            if isinstance(n.args.exprs[2], pycparser.c_ast.Cast):
                fName = self._parenthesize_unless_simple(n.args.exprs[2].expr)
            else:
                fName = self.visit(n.args.exprs[2])
            fName = fName[1:] if fName.startswith('&') else fName

            args += self.visit(n.args.exprs[0]) + ', '
            args += self.visit(n.args.exprs[1]) + ', '
            args += fName + ', '
            args += self.visit(n.args.exprs[3])
        else:
            args = self.visit(n.args)
            if fref == "spin_lock_init":
                args += ", NULL"
            if fref.startswith("pthread_mutexattr"):
                self.any_mutexattr = True

        return fref + '(' + args + ')'

    def visit_Decl(self, n, no_type=False):
        # no_type is used when a Decl is part of a DeclList, where the type is
        # explicitly only for the first delaration in a list.
        #

        s = n.name if no_type else self._generate_decl(n)

        if n.bitsize: s += ' : ' + self.visit(n.bitsize)

        # when an init expression is used,
        # remove it from the declaration statement and insert a separate
        # statement for the assignment.
        #
        assignmentStmt = ''

        initType = 0

        # Transformation 8:
        pthread_init_dict = {
            'pthread_mutex_t': 'PTHREAD_MUTEX_INITIALIZER',
            'pthread_cond_t': 'PTHREAD_COND_INITIALIZER',
            'pthread_rwlock_t': 'PTHREAD_RWLOCK_INITIALIZER'
        }

        if n.init:
            if isinstance(n.init, pycparser.c_ast.InitList):
                initType = 1
                if (self.__parsingFunction, n.name) in self.Parser.varType and self.Parser.varType[
                    self.__parsingFunction, n.name] in pthread_init_dict:
                    assignmentStmt = ' = ' + pthread_init_dict[self.Parser.varType[self.__parsingFunction, n.name]]
                else:
                    assignmentStmt = ' = {' + self.visit(n.init) + '}'

            elif isinstance(n.init, pycparser.c_ast.ExprList):
                initType = 1
                assignmentStmt = ' = (' + self.visit(n.init) + ')'
#S: const vars now are threated as the others in this transformation
#            elif (n.quals and 'const' in n.quals):
#                initType = 1
#                assignmentStmt = ' = ' + self.visit(n.init)  
            else:
                initType = 0
                assignmentStmt = ' = ' + self.visit(n.init)

        # Transformation 6:
        # remove storage class keywords from any declaration,
        # as they are not used at all in this tool for verification.
        #
        if s.startswith('auto '): s = s[5:]
        if s.startswith('inline '): s = s[7:]
        if s.startswith('extern '): s = s[7:]
        if s.startswith('volatile '): s = s[9:]
        if s.startswith('register '): s = s[9:]

        # Split the declaration statement from initialization statement.
        #
        # Remember thread-local variables
        if (n.name is not None) and (n.name.startswith('__cz_thread_local_')):
            self.__threadLocals.append(n.name.replace('__cz_thread_local_', ''))

        '''   OMAROMAROMAR   '''
        if self.__parsingFunction != '' and n.init:
            # Special consideration for init of string
            if self._is_dynamic_size_array(self.__parsingFunction, n.name):
                return s + assignmentStmt
            if initType == 1:
                return s + assignmentStmt
            return s + '; ' + n.name + assignmentStmt

        return s + assignmentStmt

    def _checkStartBrace(self, s):
        for l in s.splitlines():
            if l.startswith('# ') or l.strip() == '':
                continue
            if l.lstrip().startswith('{'):
                return True
            else:
                return False
        return False

    def visit_If(self, n):
        cond = ''

        s = 'if ('
        cond = self.visit(n.cond)
        if n.cond: s += cond
        s += ')\n'

        # Eliminate dead code
        processedCond = core.utils.remove_line_markers(cond)
        if processedCond == '0' or processedCond == '!1':
            return ''

        # Eliminate redundant code
        if processedCond == '1':
            return self._generate_stmt(n.iftrue, add_indent=True)

        t = self._generate_stmt(n.iftrue, add_indent=True)

        # if not t.startswith(self._make_indent()+ ('{\n')):   # always add brackets when missing
        if not self._checkStartBrace(t):  # always add brackets when missing
            t = self._make_indent() + '{\n' + t + self._make_indent() + '}\n'

        s += t

        if n.iffalse:
            s += self._make_indent() + 'else\n'
            e = self._generate_stmt(n.iffalse, add_indent=True)

            # if not e.startswith(self._make_indent()+ ('{\n')):   # always add brackets when missing
            if not self._checkStartBrace(e):  # always add brackets when missing
                e = self._make_indent() + '{\n' + e + self._make_indent() + '}\n'

            s += e

        return s

    def visit_For(self, n):
        ''' MEMCACHED

        s = 'for ('

        if n.init: s += self.visit(n.init)

        s += ';'

        if n.cond: s += ' ' + self.visit(n.cond)

        s += ';'

        if n.next: s += ' ' + self.visit(n.next)

        s += ')\n'
        t = self._generate_stmt(n.stmt, add_indent=True)

        # if not t.startswith(self._make_indent()+ ('{\n')):   # always add brackets when missing
        if not self._checkStartBrace(t):   # always add brackets when missing
            t = self._make_indent() + '{\n' + t + self._make_indent() + '}\n'

        return s+t

        MEMCACHED '''

        endbracket = ''  # no end bracket unless n.init is a decllist

        s = 'for ('

        # Transforms
        #    for(int k=0, k<=....) body
        #
        # into:
        #    {int k; for(k=0, k<=....) body }
        #
        # notice newly added enclosing brackets to limit the scope of variable k.
        #
        # along with Transformation 10

        if n.init:
            if type(n.init) == pycparser.c_ast.DeclList:
                caz = self._generate_decl(n.init.decls[0])
                s = '{ ' + caz + '; ' + s
                s += n.init.decls[0].name + ' = ' + self.visit(n.init.decls[0].init)
                endbracket = '}'  # remember we need to close that extra bracket

                if len(n.init.decls) > 1:
                    self.error("multiple declarations not supported here",
                               snippet=True)  # TODO generalise to multiple decl in decllist
            else:
                s += self.visit(n.init)

        s += ';'

        if n.cond: s += ' ' + self.visit(n.cond)

        s += ';'

        # n.next case modified to handle for Transformation 10
        step = ' '
        if n.next:
            step = self.visit(n.next)
            if type(n.next) != pycparser.c_ast.Assignment:  # added for Transformation 10
                s += ' ' + step
                step = ' '

        s += ')\n'

        # always add brackets when missing
        if type(n.stmt) != pycparser.c_ast.Compound:
            self.indent_level += 1
            t = self._generate_stmt(n.stmt, add_indent=True)
            if step != ' ':  # Transf. 10
                t += "; " + step + ";"  # Transf. 10
            self.indent_level -= 1
            t = self._make_indent() + '{\n' + t + self._make_indent() + '}\n'
        else:
            t = self._generate_stmt(n.stmt, add_indent=True)
            if step != ' ':  # Transf. 10
                replacement = "; " + step + '; }'  # Transf. 10
                t = replacement.join(t.rsplit('}', 1))  # Transf. 10

        return s + t + self._make_indent() + endbracket

    def visit_Struct(self, n):
        # Assign a name to anonymous structs
        if n.name is None:
            n.name = 'anonstruct_' + str(self.currentAnonStructsCount)
            self.currentAnonStructsCount += 1

        return self._generate_struct_union_enum(n, 'struct')

    def visit_Union(self, n):
        if n.name is None:
            n.name = 'anonstruct_' + str(self.currentAnonStructsCount)
            self.currentAnonStructsCount += 1

        return self._generate_struct_union_enum(n, 'union')

    def visit_StructRef(self, n):
        sref = self._parenthesize_unless_simple(n.name)

        ret = ''

        # workaround no. 4
        if n.type == '->':
            ret = ('(*' + sref + ').' + self.visit(n.field))
        else:
            ret = sref + n.type + self.visit(n.field)

        return ret

    def visit_While(self, n):
        s = 'while ('

        if n.cond: s += self.visit(n.cond)

        s += ')\n'

        t = self._generate_stmt(n.stmt, add_indent=True)

        # if not t.startswith(self._make_indent()+ ('{\n')):   # always add brackets when missing
        if not self._checkStartBrace(t):  # always add brackets when missing
            t = self._make_indent() + '{\n' + t + self._make_indent() + '}\n'

        return s + t

    def visit_DoWhile(self, n):
        cond = self.visit(n.cond) if n.cond else ''

        s = 'do\n'

        t = self._generate_stmt(n.stmt, add_indent=True)

        if not self._checkStartBrace(t):  # always add brackets when missing
            t = self._make_indent() + '{\n' + t + self._make_indent() + '}\n'

        s += t
        s += self._make_indent() + 'while ('

        s += cond

        s += ');'

        return s

    def _is_dynamic_size_array(self, f, v):
        if (f, v) not in self.Parser.varID:
            return False

        if self.Parser.varArity[f, v] == 1 and self.Parser.varSize[f, v][0] == -1:
            return True

        return False

    def loadfromstring(self, string, env, fill_only_fields=None):
        super(workarounds, self).loadfromstring(string, env, fill_only_fields=['threadName', 'varType', 'varID', 'varArity', 'varSize'])


#    def visit_Assignment(self, n):
#        n.show()
#        rval_str = self._parenthesize_if(
#                            n.rvalue,
#                            lambda n: isinstance(n, c_ast.Assignment))
#        print( '%s %s %s' % (self.visit(n.lvalue), n.op, rval_str) )
#        sys.exit(0)

